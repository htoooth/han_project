/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-06-23 15:55:03
# LastModified : 2014-08-06 15:08:31
# FileName     : ssstructdef.h
# Description  : 
 ******************************************************************************/
#ifndef _SSSTRUCTDEF_H
#define _SSSTRUCTDEF_H
#pragma pack(4)

#include "../scdefine/scstructdef.h"

struct _StConnectInfo {
	int		fd;			// file desccription
	int		id;			// idx
	int		contype;	// connect type see CON_TYPE_XXX
	char	ip[16];		// client ip
	int		port;		// client port
	void*	pdata;
};

struct _StMainSvrInfo {
	StNetAddrInfo	addr;
	int				usercount;
};

struct _StMainSvrUpUser {
	int		usercount;
};

struct _StEtermSvrResult {
	int     zhijianid;
    int     cmdtype;
};

#pragma pack()
#endif // _SSSTRUCTDEF_H
