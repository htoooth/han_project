/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-11 20:45:31
# LastModified : 2014-06-23 16:27:19
# FileName     : ssprotocol.h
# Description  : 
 ******************************************************************************/
#ifndef _SSPROTOCOL_H
#define _SSPROTOCOL_H

enum __S_MAIN_CMD {
	MAINSVR_LOGINSVR_TYPE = 100,
	MAINSVR_ETERMSVR_TYPE,

    SYSTEM_PROTOCOL_TYPE = (unsigned int)-1,
};

enum __CONNECT_TYPE {
	CON_TYPE_NULL = 0,
	CON_TYPE_CLIENT_COM = 10,
	CON_TYPE_MAINSVR_LOGINSVR = 100,
    CON_TYPE_MAINSVR_ETERMSVR,
}; 
//assistcmd CON_TYPE_MAINSVR_ETERMSVR
enum __MAINSVR_ETERMSVR_TYPE_{
    ME_TYPE_VERIFY_KEYWORD = 1,
	ME_TYPE_ETERMRESULT,
//    ME_USER_LOGIN,
//    ME_USER_LOGOUT,
};
//assistcmd MAINSVR_LOGINSVR_TYPE
enum __MAINSVR_LOGINSVR_TYPE_ {
	ML_UPDATA_SVRUSER = 1,              
	ML_MAINSVR_INFO,      
};

enum __SYSTEM_PROTOCOL_TYPE {
    SP_LOGINMAIN_VERIFY_KEYWORD = 1,
    SP_LOGINSVR_SET_DEALDATAPTR,
    SP_ETERMMAIN_VERIFY_KEYWORD,
};

#define __key_mainsvr_loginsvr__ "mainsvr_loginsvr_login"

#define __key_mainsvr_etermsvr__ "mainsvr_etermsvr_login"

#endif // _SERVERDEF_H
