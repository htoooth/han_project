/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-26 17:53:54
# LastModified : 2015-01-21 15:42:20
# FileName     : main.cpp
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <iostream>
#include <vector>

#include "showmsg.h"
#include "readconf.h"
#include "svrloop.h"
#include "dbevent.h"
#include "perdealcmd.h"

int main(int argc, char *argv[]) {

#ifdef TEST

/*	std::string temp;
	std::getline(std::cin, temp);
	StAvCmdInfo inf = {0};
	PerDealCmd::GetAvhCmdInfo(temp, inf);

	while(1) {
		std::string str, strout;
		std::getline(std::cin, str);

	//	bool bsucc = PerDealCmd::IsFlightNum(str.c_str());
	//	MSGOUT(en_Msg_Debug, "%d", bsucc);
		
		StAvCmdInfo inf = {0};
		bool bsucc = PerDealCmd::GetAvhCmdInfo(str, inf);
		strout = PerDealCmd::FormatAvStr(inf);
		MSGOUT(en_Msg_Debug, "%d : %s", bsucc, strout.c_str());
	
	}
 */
	const char* p27 = " 05SEP(FRI) BJSCAN VIA MU DIRECT ONLY  \n\
1- *MU3116  AS# YA MS ES KQ NQ RQ              PEKCAN 1230   1545   33A 0^L  E  \n\
>   CZ3102                                                          T2 --  3:15\n\
2  *MU3112  AS# YA MS ES KS NQ RQ              PEKCAN 1330   1645   33A 0^L  E  \n\
>   CZ3106                                                          T2 --  3:15\n\
3  *MU3114  DS# YA MS ES KQ NQ RQ              PEKCAN 1530   1845   380 0^D  E  \n\
>   CZ3104                                                          T2 --  3:15\n\
4  *MU3873  DS# FA PQ AQ YA BQ MQ EQ HQ KQ LQ  NAYCAN 1710   2010   737 0    E  \n\
>   KN5889      NQ RQ SQ VQ TQ GQ ZQ QQ UQ XQ                              3:00\n\
5  *MU3100  DS# YA MS ES KQ NQ RQ              PEKCAN 1730   2045   787 0^D  E  \n\
>   CZ3122                                                          T2 --  3:15\n\
6  *MU3118  AS# YA MS ES KQ NQ RQ              PEKCAN 1830   2145   787 0^D  E  \n\
>   CZ3100                                                          T2 --  3:15\n\
7  *MU3108  DS# YA MS ES KQ NQ RQ              PEKCAN 1930   2245   321 0^C  E  \n\
>   CZ3110                                                          T2 --  3:15\n\
8+ *MU3816  DS# FA PQ AQ YA BQ MQ EQ HQ KQ LQ  NAYFUO 2130   2355   737 0    E  \n\
>   KN5862      NQ RQ SQ VQ TQ GQ ZQ QQ UQ XQ                              2:25\n\
**  CZ3000/3100/6000 PLEASE CHECK IN 45 MINUTES BEFORE DEPARTURE AT PEK \n\
**  HU7000-HU7899 PLEASE CHECK IN 30 MINUTES BEFORE DEPARTURE AT PEK";
	
	const char* p26 = " 28SEP(SUN) BJSMIL                                                              \n\
1-  CA1515  PEKSHA 1530   1740   77S 0^S  E   DS# F3 A2 OS W2 YA BQ MQ HQ KQ LQ*\n\
    CA967   PVGMXP 0130   0805+1 330 0^M  E   DS# C8 DS ZQ JQ RS Y6 BQ MQ HQ KQ*\n\
2   CA1549  PEKSHA 1630   1840   77L 0^S  E   DS# FA A6 O1 WA YA BQ MQ HQ KQ LQ*\n\
    \n\
    CA967   PVGMXP 0130+1 0805+1 330 0^M  E   DS# C8 DS ZQ JQ RS Y6 BQ MQ HQ KQ*\n\
    \n\
 12SEP(SUN) BJSMIL                             \n\
3   CA1855  PEKSHA 1730   1940   32A 0^D  E   DS# FA A1 OS YA BQ MQ HQ KQ LQ QQ*\n\
    CA967   PVGMXP 0130+1 0805+1 330 0^M  E   DS# C8 DS ZQ JQ RS Y6 BQ MQ HQ KQ*\n\
4+  CA1885  PEKSHA 1830   2040   330 0^S  E   DS# F2 AS OS YA BQ MQ HQ KQ LQ QQ*\n\
    CA967   PVGMXP 0130+1 0805+1 330 0^M  E   DS# C8 DS ZQ JQ RS Y6 BQ MQ HQ KQ*\n\
**  CZ3000/3100/6000 PLEASE CHECK IN 45 MINUTES BEFORE DEPARTURE AT PEK      \n\
**  FLIGHT OF 8L PLEASE CHECK IN 45 MINUTES BEFORE DEPARTURE AT PEK          \n\
**  HU7000-HU7899 PLEASE CHECK IN 45 MINUTES BEFORE DEPARTURE AT PEK\n";
    const char* p31 = " MU2380 08OCT(WED)-13OCT(MON) HGHXIY                                            \n\
1   08OCT14 HGHXIY 2045   2305   320 0^  F8 P4 YA BA MA EA HA KA LQ NQ RQ SQ VQ \n\
                                         TQ GQ ZQ QQ                            \n\
2   09OCT14 HGHXIY 2045   2305   320 0^  F8 P4 YA BQ MA EA HA KA LA NA RA SA VA \n\
                                         T1 GQ ZQ QS                            \n\
3   10OCT14 HGHXIY 2045   2305   320 0^  F8 P4 YA BA MA EA HQ KA LQ NA RA SA VA \n\
                                         TA GQ ZQ QS                            \n\
4   11OCT14 HGHXIY 2045   2305   319 0^  F8 P4 YA BA MA EA HQ KA LQ NA RA SA VA \n\
                                         TQ GQ ZQ QS                            \n\
5   12OCT14 HGHXIY 2045   2305   320 0^  F7 P3 YA BA MA EA HQ KA LQ NA RA SA VA \n\
                                         TA GQ ZQ QS                            \n\
6   13OCT14 HGHXIY 2045   2305   320 0^  F7 P4 YA BA MA EA HQ KA LQ NA RA SA VA \n\
                                         TA GQ ZQ QS                            \n";
	const char* p29 = " 28SEP(SUN) SHABJS                                                              \n\
1- *ZH1884  PVGPEK 1615   1845   330 0^S  E   DS# FA YA BS MS HS KS LS QS GS SA*\n\
2   CA1884  PVGPEK 1615   1845   330 0^S  E   DS# FA AA OS YA BS MS HS KS LS QS*\n\
3   CA1518  SHAPEK 1655   1915   77L 0^S  E   DS# FA AA OS W1 YL BQ MQ HQ KQ LQ*\n\
4  *ZH1518  SHAPEK 1655   1915   77L 0^S  E   DS# FA YL BQ MQ HQ KQ LQ QQ GQ SL*\n\
5  *HO1904  SHAPEK 1655   1915   77L 0^S  E   DS# YL BQ MQ TQ EQ VQ             \n\
6  *CZ9906  SHAPEK 1700   1925   33E 0^D  E   AS# YA BQ MQ KQ LQ EQ             \n\
7   MU5119  SHAPEK 1700   1925   33E 0^D  E   AS# FL PQ YA BS MQ EQ HQ KQ LQ NQ*\n\
8  *MU4135  SHAPEK 1725   2005   738 0^S  E   AS# YA ES HS KS LS NS             \n\
9+  MF8557  SHAPEK 1725   2005   738 0^S  E   AS# F5 AS JS CS YA HS B6 MS LS KS*\n";

    const char* p28 = " 28SEP(SUN) BJSMIL                                                              \n\
1-  CA1515  PEKSHA 1530   1740   77S 0^S  E   DS# F3 A2 OS W2 YA BQ MQ HQ KQ LQ*\n\
    CA967   PVGMXP 0130+1 0805+1 330 0^M  E   DS# C8 DS ZQ JQ RS Y6 BQ MQ HQ KQ*\n\
2   CA1549  PEKSHA 1630   1840   77L 0^S  E   DS# FA A6 O1 WA YA BQ MQ HQ KQ LQ*\n\
    CA967   PVGMXP 0130+1 0805+1 330 0^M  E   DS# C8 DS ZQ JQ RS Y6 BQ MQ HQ KQ*\n\
3   CA1855  PEKSHA 1730   1940   32A 0^D  E   DS# FA A1 OS YA BQ MQ HQ KQ LQ QQ*\n\
    CA967   PVGMXP 0130+1 0805+1 330 0^M  E   DS# C8 DS ZQ JQ RS Y6 BQ MQ HQ KQ*\n\
4+  CA1885  PEKSHA 1830   2040   330 0^S  E   DS# F2 AS OS YA BQ MQ HQ KQ LQ QQ*\n\
    CA967   PVGMXP 0130+1 0805+1 330 0^M  E   DS# C8 DS ZQ JQ RS Y6 BQ MQ HQ KQ*\n\
**  CZ3000/3100/6000 PLEASE CHECK IN 45 MINUTES BEFORE DEPARTURE AT PEK      \n\
**  FLIGHT OF 8L PLEASE CHECK IN 45 MINUTES BEFORE DEPARTURE AT PEK          \n\
**  HU7000-HU7899 PLEASE CHECK IN 45 MINUTES BEFORE DEPARTURE AT PEK\n";
	const char* p1 = " 12JAN(MON) BJSMIL                                                             \n\
1-  CA949   DS# CA DA ZA JA I2 RA YL BL ML HL  PEKMXP 1345   1800   330 0^M  E \n\
>               KL LL QL GL SL XL NL VL UL TL EL                    T3 T1 11:15 \n\
2   TK021   DS! C7 D7 K7 J7 I7 R0 U9 O9 A9 Z6  PEKIST 0050   0510   77W 0 M  E  \n\
>               Y9 B9 M6 H4 S2 E0 Q0 TC LC VC PC WC X0 N0 G0        3  I  10:20 \n\
    TK1873  DS! C7 D7 K7 J7 I7 R0 Y9 B9 M6 H4     MXP 0815   1015   321 0 M  E  \n\
>               S2 E0 Q0 TC LC VC PC WC X6 N0 G0                    I  1  16:25 \n\
3   TK021   DS! C7 D7 K7 J7 I7 R2 U9 O9 A9 Z9  PEKIST 0050   0510   77W 0 M  E  \n\
>               Y9 B9 M9 H9 S9 E9 Q9 T9 L6 V1 PC WC X0 N0 G0        3  I  10:20 \n\
    TK1895  DS! C7 D7 K7 J7 I7 R2 Y9 B9 M9 H9     MXP 1205   1400   320 0 M  E  \n\
>               S9 E9 Q9 T9 L6 V1 PC WC X9 N0 G0                    I  1  20:10 \n\
4   TK021   DS! C9 D9 K9 J9 I9 R2 U9 O9 A9 Z9  PEKIST 0050   0510   77W 0 M  E  \n\
>               Y9 B9 M9 H9 S9 E9 Q9 T9 L9 V9 P9 W6 X3 N0 G0        3  I  10:20 \n\
    TK1875  DS! C9 D9 K9 J9 I9 R2 Y9 B9 M9 H9     MXP 1600   1755   321 0 M  E  \n\
>               S9 E9 Q9 T9 L9 V9 P9 W6 X9 N0 G0                    I  1  24:05 \n\
5+  TK021   DS! C9 D9 K9 J9 I9 R2 U9 O9 A9 Z9  PEKIST 0050   0510   77W 0 M  E  \n\
>               Y9 B9 M9 H9 S9 E9 Q9 T9 L9 V9 P9 W7 X3 N0 G0        3  I  10:20 \n\
    TK1877  DS! C9 D9 K9 J9 I9 R2 Y9 B9 M9 H9     MXP 2105   2305   320 0 M  E  \n\
>               S9 E9 Q9 T9 L9 V9 P9 W7 X9 N0 G0                    I  1  29:15\n";

	const char* p2 = "nm:1fs/df 1err/dd \n\
-1kdjhfkf\n\
dffhdfghhgf";
// 	while(1)
// 	{
// 		std::string str, strres;
// 		std::getline(std::cin, str);
// 		std::vector<std::string> vecstr;
// 		time_t t = PerDealCmd::GetTimeFromEtermStr(str.c_str());
// 		fprintf(stderr, "time: %ld\n", t);
// 	}
// 
// 	while(1)
// 	{
// 		std::cout << p1 << std::endl;
// 		std::string str, strres;
// 		std::getline(std::cin, str);
// 		if(PerDealCmd::TransformSdCmd(str.c_str(), p1, strres)) {
// 			fprintf(stderr, "%s", strres.c_str());
// 		}
// 		else {
// 			MSGOUT(en_Msg_Debug, "err input");
// 		}
// 	}

	while(1)
	{
		std::string str, strres;
		std::getline(std::cin, str);
		StSSSeatInfo info = {{0}};
		if(PerDealCmd::GetSSSeatInfo(str.c_str(), &info)) {
			MSGOUT(en_Msg_Debug, "com: %s, num: %s, seat: %s, date: %s, start: %s, end: %s, count: %s, tstart: %s, tend: %s",
					info.strcom, info.strplannum, info.strseat, info.strdate, info.strstart, info.strend, info.strnum, info.strtstart, info.strtend);
		}
		else {
            MSGOUT(en_Msg_Debug, "com: %s, num: %s, seat: %s, date: %s, start: %s, end: %s, count: %s, tstart: %s, tend: %s",
                info.strcom, info.strplannum, info.strseat, info.strdate, info.strstart, info.strend, info.strnum, info.strtstart, info.strtend);
			MSGOUT(en_Msg_Debug, "err input");
		}
	}
    std::string str, strres;
    std::getline(std::cin, str);

    StAvCmdInfo inf = {0}, info = {0};
    bool bsucc = PerDealCmd::GetAvhCmdInfo(str, inf);


    MSGOUT(en_Msg_Debug, "%d : %s", bsucc, PerDealCmd::FormatAvStr(inf).c_str()); 
    while(1) {

        std::getline(std::cin, str);

        bsucc = PerDealCmd::DealAvhCmdByRes(str, inf, p28, info);
        MSGOUT(en_Msg_Debug, "%d : %s", bsucc, PerDealCmd::FormatAvStr(info).c_str());

    }
	return 0;
/*
	while(1) {
		std::string str, strout;
		std::getline(std::cin, str);
		StAvCmdInfo info = {0};
	//	PerDealCmd::GetAvhCmdInfo(str, info);

		PerDealCmd::DealAvhCmdByRes(str, inf, strout, info);
	
		strout = PerDealCmd::FormatAvStr(info);
		MSGOUT(en_Msg_Debug, "%s", strout.c_str());
*/
		/*
		if (info.type == en_Avh_Type_Qurey) {
			MSGOUT(en_Msg_Debug, "FLIGHT : %s/%s/%s/%s/%s/%s/%s", 
					info.qurey.avstr, info.qurey.citystart, info.qurey.cityend, 
					info.qurey.strdate, info.qurey.strtime, info.qurey.strcom, info.qurey.strlimit);
		}
		else if (info.type == en_Avh_Type_Flight) {
			MSGOUT(en_Msg_Debug, "QUREY : %s/%s/%s/%s", 
					info.flight.avstr, info.flight.strdate, info.flight.offset);
		}
		else {
			MSGOUT(en_Msg_Debug, "error : %d", info.type);
		}
		if (strout.length() != 0)
			memcpy(&inf, &info, sizeof(info));
		StAvCmdInfo info = {0};
		strout = PerDealCmd::DealAvhCmdByRes(str, info, "");
		MSGOUT(en_Msg_Debug, "%s--------", strout.c_str());
	}
		*/
//	PerDealCmd::InitConfig("a.txt");

	return 0;
#else

	ReadConf cf;
	cf.readfile("server.conf");

	char buf[40] = {0};
	cf.getvalue("bindport", buf, sizeof(buf));
	short port = atoi(buf);
	if(port <= 0) {
		MSGOUT(en_Msg_Error, "main readconf bind port error!!!");
		return 1;
	}

	memset(buf, 0, sizeof(buf));
	cf.getvalue("dbthread", buf, sizeof(buf));
	unsigned int n = atoi(buf);
	if(n <=0 )
		n = 2;

	memset(buf, 0, sizeof(buf));
	cf.getvalue("logfile", buf, sizeof(buf));

	FILE* pf = NULL;
	if(strcmp(buf, "stderr") != 0) {
		pf = fopen(buf, "ab");
		if(pf != NULL)
			setWriteFile(pf);
	}

	MSGOUT(en_Msg_Normal, "<-----------------start---------------->");

	ServerMain svr;
	MysqlHandle sql;
    svr.StartServer(&sql, port, en_Normal_Connect, n);  
    //svr.StartServer(&sql, port, en_SSLv23_Connect, n);
    //svr.StartServer(&sql, port, en_TLSv1_Connect, n);   
    //svr.StartServer(&sql, port, en_DTLSv1_Connect, n);
    //svr.StartServer(&sql, port, en_TLSv1_Connect, n);   
    //svr.StartServer(&sql, port, en_SSLv3_Connect, n);

	if(pf != NULL)
		fclose(pf);

	MSGOUT(en_Msg_Normal, "<-----------------end---------------->");
	
	return 0;
#endif
}
