/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-07-16 20:05:30
# LastModified : 2014-12-09 13:08:00
# FileName     : etermloop.h
# Description  : 
 ******************************************************************************/
#ifndef _ETERMLOOP_H
#define _ETERMLOOP_H

#include <queue>
#include <semaphore.h>
#include <pthread.h>
#include <list>
#include <set>

#include "evcenter.h"
#include "xtyclient.h"
#include "etermclient.h"
#include "etermcmdqueue.h"
#include "etermaccont.h"

class EtermCmdQueue;
class EtermSvrLoop;
class EtermSocket;

enum {
	TIMER_GET_ETERM_INFO = 1,
};

enum _en_EtermSock_Status {
    en_EtermSock_Status_Null = 0,
    en_EtermSock_Status_Init,
    en_EtermSock_Status_SendDA,
    en_EtermSock_Status_SendSI,
    en_EtermSock_Status_Working,
    en_EtermSock_Stauts_SystemUse,
};

enum _en_EtermSocketCmd_Status {
    en_EtermSocketCmd_Idle = 1,
    en_EtermSocketCmd_Book,
    en_EtermSocketCmd_Query,
};

struct StEtermLogin {
    int     sysid;
    int     companyid;
	char	name[16];	// user name
	char	pwd[16];	// user password
	char	ip[16];		// eterm connect id
    char    sistr[32];  // si login str
	int		port;		// connect port
	int    	usertype;	// eterm type (travelsky or normal)
};

struct StEtermSockAddInfo
{
    EtermSocket*    psock;
    int             sysid;
    int             companyid;
    time_t          heartsendtime;
};

struct StEtermLoginReTry
{
    int     trycount;
    time_t  lasttrytime;
};

struct StEtermTimer
{
    unsigned int    uid;
    unsigned int    umsec;
};

struct StEtermCmdSocketTask
{
    EtermSocket*            psock;
    StEtermRequest              cmd;
};

struct StEtermCmdResult
{
    StEtermRequest      cmd;
    void*           pdata;
    unsigned int    ulen;
};

struct StEtermCloseInfo
{
    int             sysid;
    EtermSocket*    psock;
    bool            bready;
    StEtermLogin    login;
    StEtermRequest  request;
    
};

class EtermSocket : public CenterSocket
{                                                              
public:
	EtermSocket();
	virtual ~EtermSocket();
public:
	// pdata: EtermSvrLoop*
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual bool OnRecvData(char* pdata, unsigned int len);
	virtual void OnClose();
public:
	void SendCmd(StEtermRequest* pcmd);
	void SetLoginData(StEtermLogin* plogin);
	bool LoginEtermSys();
	int GetSystemId();
    int GetCompanyId();
	bool IsReady();
    EtermClient* GetCurClientPtr(); 
    void ClearCurStatus();
    void SendHeartPackage();
    void GetLoginData(StEtermLogin* plogin);
    time_t GetLastUserTime();
    int GetCurCmdCtrlType();
    void SendCmdStr(const char* pstr);
    void SendSICmd();
    void RefreshLogFileName();
protected:
    void SetCurCmdCtrlType(int cmdstatus);
	bool DealAFullData(char* pdata, unsigned int ulen);
    int senddata(char* pdata, unsigned int len);
    void RefreshLastUseTime();
    void RefreshCurCmdCtrlStatus(const char* phead);
protected:
    int             m_companyid;
	int				m_sysid;
	unsigned short	m_etermid;
	StEtermLogin	m_logindata;
	EtermSvrLoop*	m_peterm;
	bool			m_bready;
    StEtermRequest  m_curcmd;
	unsigned int	m_urecvlen;
	unsigned int	m_utotallen;
	char*			m_pdata;
    time_t          m_lastusetime;
    std::queue<char>    m_qloginsend;  // login send special data
    pthread_mutex_t m_mulogfile;
    char            m_logfilename[40];
    int             m_status;
    int             m_cmdstatus;
};

/**************************************************************************************/

class EtermSvrLoop : public IServer, public ISvrCallback
{
public:
	virtual void _end_callback(const char* pstr, void* pdata, int ntype);
public:
	// pdata: QueueEventModule*
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual bool _is_end();
public:
	EtermSvrLoop();
	virtual ~EtermSvrLoop();
	bool DealClientData(int fd, void* pdata, unsigned int ulen);
    bool DealMainSvrData(int fd, void* pdata, unsigned int ulen);
    /*************************************************************************/
	void AddEtermConfig(StEtermLogin* plogin);
	void OnEtermSockClose(int sysid, EtermSocket* psock, StEtermLogin* plogin, bool bready);
	void AddEtermUser(_en_Eterm_Client_Type connecttype, int connectfd, StEtermLoginRet* pret);
	bool DealEtermResult(StEtermRequest* pcmd, void* pdata, unsigned int ulen, bool bend = true);
	void AddIdleSock(int sysid, EtermSocket* psock);
	void OnClientClose(int fd);
    void OnMainSvrClose(int fd);
	bool ConnectXTY(const char* pip, int port);
	void DealXTYRet(const char* name, const char* pwd, int id, const char* pip, int port, int errtype);
    void DealDBResult(int assistcmd, void* pdata, unsigned int ulen, void* pclient);
    int CheckClientUserExist(int zhijianid);

    void SetSystemMsg(const char* pstr);
    void SetMsgboxMsg(const char* pstr);

    void FlushSendCmdQueue();

    void PostFlushSendCmdRequest();
    void SiPID();
public:
    // DB result function
    void AddEtermAllowInfo(int sysid, StEtermLimitInfo* pinfo, int count);
    void AddEtermForbidInfo(int sysid, StEtermLimitInfo* pinfo, int count);
    void ReleaseAllLimitInfo();
    void AssignEtermCmd(StEtermRequest* pcmd);
    void AddPNRInfo(int sysid, const char* pPNR);
    void AddCompanyCode(int sysid, const char* pCode);
    void GetXTYAccount();
    void PostEtermResult(int assistcmd, void* pdata, unsigned int ulen, void* pclient);
public:
	void OnEtermTimer(unsigned int uid);
	void SetEtermTimer(unsigned int uid, unsigned int msec);
	void EtermKillTimer(unsigned int uid);
protected:
	void PostEtermReuqest(int assistcmd, void* pdata, unsigned int ulen, void* pclient);
    void SendDataToClient(int fd, void* pdata, unsigned int ulen);
    void SendStrToClient(int fd, int zhijianid, const std::string& str);
    void SendStrToMainSvr(int fd, int zhijianid, const std::string& str, void* paddinfo);
	void PushCmdToDB(StEtermRequest* cmd);
	void AddSockToBusy(EtermClient* pclient, EtermSocket* psock, bool bbreak);

	void DealSendResult(char* pdata, unsigned short id);

    bool DealClientEtermString(int connectfd, const char* pstrcmd, int line);

    bool DealServerEtermString(int connectfd, int zhijianid, const char* pstrcmd, void* paddinfo);

    bool DealEtermWebRequest(int connectfd, const char* pdata, unsigned int ulen);

    bool DealEterm3InOneRequest(int connectfd, const char* pdata, unsigned int ulen);

    void SendMsgboxToClient(int fd, const char* pstr);
    void CloseClientConnect(int fd);

    void SaveAllUserInfo();
protected:
    void DBEtermLoginRet(void* pdata, unsigned int ulen, void* pclient);

    void AddCmdToQueue(StEtermRequest* pcmd, int* arreterm, unsigned int arrsize);

    EtermSocket* GetIdleSocket(int sysid);

    EtermSocket* GetUsedSocket(EtermClient* pclient);

    void FreeUsedSocket(EtermClient* pclient);

protected:
	QueueEventModule*	m_pdb;
	bool				m_bend;
	ISvrCallback*		m_pcb;
	XTYClient			m_xty;
protected:
	std::map<EtermClient*, EtermSocket*>	m_resbusy;
    std::map<EtermClient*, EtermSocket*>	m_restemp;
    // map<sysid, >
	std::map<int, EtermSocket*>	            m_residle;

    // map<sysid, companeid>
    std::map<int, StEtermSockAddInfo*>  m_tosock;

	EtermCmdQueue	        	m_queuecmd;

    // map<fd, >
	std::map<int, EtermClient*>	    m_mapclientuser;

    // map<fd, map<zhijianid, > >
    std::map<int, std::map<int, EtermClient*> >     m_mapsvruser;

    // map<zhijianid, retry info>
    std::map<int, StEtermLoginReTry*>      m_mtrycount;

    std::queue<StEtermLogin>                m_qoffline;

    char            m_systemmsg[4096];
    char            m_msgboxmsg[4096];
protected:

	// only DB result change...
    // map<sysid, >
    std::map<int, EtermAccont*>		m_mapetermlimit;

    // map<strPNR, sysid>
    std::map<std::string, int>			m_mapPNR;
    std::map<std::string, int>			m_mapCode;

    bool    m_bflushsendcmd;

protected:
	// for end thread use...
    sem_t               m_endsem;
};

#endif // _ETERMLOOP_H
