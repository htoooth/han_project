/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-07-13 15:10:51
# LastModified : 2014-12-09 13:23:27
# FileName     : perdealcmd.h
# Description  : 
 ******************************************************************************/
#ifndef _PERDEALCMD_H
#define _PERDEALCMD_H

#include <map>
#include <string>
#include <vector>

enum _en_Eterm_Msg_Type {
    en_Eterm_Msg_Normal = 0,
    en_Eterm_Msg_Msgbox,
};

enum _en_Cmd_Break_Type {
	en_Cmd_Brk_Not		= 0x00000000,
	en_Cmd_Brk_Can		= 0x00000001,
};

enum _en_Cmd_Permision_Type {
	en_Cmd_Per_Forbid	= 0x00000000,
	en_Cmd_Per_Allow	= 0x00000001,
};

enum _en_PNR_Type
{
    en_PNR_TypeNull = 0,
    en_PNR_EtermSystem,
    en_PNR_AirCompany,
};

struct StCmdInfo {
	char	cmd[8];
	int		breaktype;	// break type
};

//	en_Avh_Type_Qurey = 1,
// AV:H/PEKCAN/05SEP/1200/MU/D
struct StAvQureyInfo {
	char		avstr[4];		// av,avh,ava,ave,avo,avm,avs,avt,avw
	char		citystart[4];	// sha etc.
	char		cityend[4];		// pek etc.
	char		strdate[8];		// 10AUG14
	char		strtime[8];		// 2120
	char		strcom[4];		// MU
	char		strlimit[4];	// D or N
};

//	en_Avh_Type_Flight,
// AV:CA1475/20APR//4 
struct StAvFlightInfo {
	char		avstr[4];		// av,avh,ava,ave,avo,avm,avs,avt,avw
	char		flight[8];		// flight info CA985 etc.
	char		strdate[8];		// 20AUG
	char		offset[4];		// //1 etc.
};

struct StSSSeatInfo
{
    char    strcom[4];
    char    strplannum[8];
    char    strseat[4];
    char    strdate[8];
    char    strstart[4]; 
    char    strend[4];
    char    strcode[4]; 
    char    strnum[4];
    char    strtstart[8];
    char    strtend[8];
};

enum _en_Avh_Cmd_Type {
    en_Avh_Type_Null = 0,
	en_Avh_Type_Qurey,
    en_Avh_Type_Flight, 
    en_Avh_Type_ReturnA,
    en_Avh_Type_Foreign,
};

struct StAvCmdInfo {
	int		type;
	union	{
		StAvQureyInfo	qurey;
		StAvFlightInfo	flight;
	};
};

class PerDealCmd {
public:
	static bool InitConfig(StCmdInfo* pinfo, int count);

    static bool InitGB2312();

	static void ReleaseRes();

	static bool JudgeCmdType(std::string strcmd, StCmdInfo* pinfo);
	
	static bool DealLocalCmd(std::string cmd, std::string strcmd, std::string& strout);

    // return 1 : cmd info; 2 : web request; -1 : error
	static int GetCmdFromData(void* pdata, unsigned int ulen, std::string& strout, int& line);

	static bool OffsetEtermData(const std::string& strdata, int offsetday, std::string& strout);

	static time_t GetTimeFromEtermStr(const char* pstr);

	static bool OffsetEtermTime(const std::string& strtime, int addmin, std::string& strout, bool& btow);

	static void GetLocalTimeInfo(int* year, int* month = NULL, int* day = NULL, int* hour = NULL, int* minute = NULL, int* second = NULL);

	static bool GetAvhCmdInfo(const std::string& strcmd, StAvCmdInfo& info);

	static void SpliteCmd(const std::string& strcmd, std::vector<std::string>& veout, const char* pkey = "/: ");

	static bool DealAvhCmdByRes(const std::string& strcmd, const StAvCmdInfo& info, const std::string& strres, StAvCmdInfo& out);

	static std::string& replace_all(std::string& str, const std::string& old_value, const std::string& new_value);

	static bool IsFlightNum(const char* str);

	static bool IsNumStr(const char* str);

	static std::string FormatAvStr(const StAvCmdInfo& info);

    static int code_convert(const char* from_charset, const char* to_charset, const char* inbuf, size_t inlen, char* outbuf, size_t outlen);

    static void splitchinese(const char* pstr, unsigned int ulen, std::vector<std::string>& vecstring);

    static void EnCodeChineseStr(const char* pin, int inlen, std::string& strres);

    static bool FormatEtermRes(const char* pstr, int id, char* pout, unsigned int* plen, int msgtype = en_Eterm_Msg_Normal);

    static bool GetPNRFromCmd(const char* pstr, std::string& strPNR);

    static bool GetStrFromEtermData(void* pdata, unsigned int ulen, std::string& strout);

    static bool GetEtermStrPos(void* pdata, unsigned int ulen, unsigned int* pstart, unsigned int* plen);

	static void DecodeChineseStr(const char* pstr, unsigned int ulen, std::string& strout);

    static void DecodeChinese(char* pstr, unsigned int ulen);

    static bool TransformSdCmd(const char* psdcmd, const char* pavres, std::string& strout);

    // pstrcmd : SS:CA1351 Y 1OCT PEKCAN
    static bool GetSSSeatInfo(const char* pstrcmd, StSSSeatInfo* pssinfo);

	// clear space \ and other symbol
    static void WipeoffString(const char* pstr, char* pout, unsigned int uoutlen);

    static bool GetPNRStrFromCmd(const char* pstr, std::string& strout);

    static void GetNameFromNMCmd(const char* pstr, std::vector<std::string>& vecname);

    static void GetLineFromeCmd(const char* pstr, std::vector<std::string>& vecline);

    static bool GetCompanyBigCode(const char* pstr, std::string& strbigcode);

    static bool GetPNRStringFromCmd(const char* pstr, std::string& strPNR);

    static void ToUpperStr(std::string& str);

    static void ToUpperStrPtr(char* pstr);

    static bool GetDAInfo(const char* pstr);

    static void _trimstdstring(std::string& str);

    static void _trimcharstring(char* pstr);

    // pout will malloc in this function
    static bool AddEnterToEtermRetStr(char* pdata, unsigned int ulen, char** pout, unsigned int* plen);

    // A~Z or a~z or 0~9
    static bool IsNormalWord(const char c);

//    static void SplteString(const char* pstr, std::vector<std::string>& vecstr);

protected:
	static std::map<std::string, StCmdInfo*>	s_mapinfo;

    static std::map<std::string, unsigned short>	s_mapzh;

    static std::map<unsigned short, std::string>	s_mapnum;
};

#endif // _PERDEALCMD_H
