/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-27 14:36:25
# LastModified : 2014-12-08 15:26:19
# FileName     : svrloop.cpp
# Description  : 
******************************************************************************/
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

#include "svrloop.h"
#include "readconf.h"
#include "scstructdef.h"
#include "scprotocol.h"
#include "ssprotocol.h"
#include "ssstructdef.h"
#include "dbdefine.h"
#include "etermaccont.h"
#include "perdealcmd.h"

bool ServerMain::OnSocketRead(int fd, void* pdata, unsigned int ulen) {

    if(m_mapfd.find(fd) == m_mapfd.end() || pdata == NULL) 
        return false;

    return DealClientData(fd, pdata, ulen);
}

bool ServerMain::OnSocketConnect(int fd, struct sockaddr_in* paddr) {

    _StConnectInfo* p = (_StConnectInfo*)malloc(sizeof(_StConnectInfo));
    memset(p, 0, sizeof(_StConnectInfo));
    p->fd = fd;

    p->pdata = (_StConnectData*)malloc(sizeof(_StConnectData));
    memset(p->pdata, 0, sizeof(_StConnectData));

    strcpy(p->ip, inet_ntoa(paddr->sin_addr));
    p->port = ntohs(paddr->sin_port);

    m_mapfd[fd] = p;

    MSGOUT(en_Msg_Normal, "ServerMain::OnSocketRead connect fd:%d, ip:%s", fd, inet_ntoa(paddr->sin_addr));

    return true;
}

void ServerMain::OnSocketClose(int fd) {

    std::map<int, void*>::iterator it = m_mapfd.find(fd);
    if (it != m_mapfd.end()) {
        _StConnectInfo* p = (_StConnectInfo*)(it->second);
        if(p != NULL) {
            if (p->pdata != NULL) {				
                free(p->pdata);
                p->pdata = NULL;
            }
            free(p);
            p = NULL;
        }
        m_mapfd.erase(it);

        if (m_mmainsvrfd.find(fd) != m_mmainsvrfd.end()) {
            m_eternIns.OnMainSvrClose(fd);
            m_mmainsvrfd.erase(fd);
        }
        else {
            m_eternIns.OnClientClose(fd);
        }
    }
    MSGOUT(en_Msg_Normal, "ServerMain::OnSocketClose fd:%d", fd);
}

void ServerMain::OnEventTimer(unsigned int uid) {
    switch(uid) {
    case TIMER_ETERM_SIPID:
        {   
            // time_t nowtime = time(NULL) - 60;
            // if (nowtime/(24*60*60) != m_lastsiTime/(24*60*60)) {
            //     MSGOUT(en_Msg_Debug, "ssssssssssssssssssssssssssssssssssssss");
            //     m_eternIns.SiPID();
            // }
            // settimer(TIMER_ETERM_SIPID, TIME_ETERM_SIPID);
//            MSGOUT(en_Msg_Debug, "tttttttttttttttttttttttttttttttt");
        }
        break;
    default: 
        {
            m_eternIns.OnEtermTimer(uid);
        }
    }
}

void ServerMain::SettleDBResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
    switch (maincmd)
    {
    case DB_TYPE_SERVERLOOP:
        {

        }
        break;
    case DB_TYPE_ETERMRESULT:
        {
            int fd = (int)(long)pclient;
            _StConnectInfo* pinfo = (_StConnectInfo*)m_mapfd[fd];
            if (pinfo == NULL) {
                MSGOUT(en_Msg_Normal, "send but close fd:%d", fd);
                return ;
            }
            senddata(fd, pdata, ulen);
            MSGOUT(en_Msg_Debug, "send res to client fd : %d, len : %d", fd, ulen);
        }
        break;
    case DB_TYPE_ETERMLOOP:
        {
            m_eternIns.DealDBResult(assistcmd, pdata, ulen, pclient);
        }
        break;
    case DB_TYPE_CLOSECONNECT:
        {
            int fd = (int)(long)pclient;
            closeconnect(fd);
        }
        break;
    case DB_TYPE_ETERMTIMER:
        {
            StEtermTimer* ptime = (StEtermTimer*)pdata;
            if (assistcmd == DB_ETERMTIMER_SETTIMER) {
                settimer(ptime->uid, ptime->umsec);
            }
            else if (assistcmd == DB_ETERMTIMER_KILLTIMER) {
                killtimer(ptime->uid);
            }
            else {
                MSGOUT(en_Msg_Normal, "Unkonw DB_TYPE_ETERMTIMER assist cmd: %d", assistcmd);
            }
        }
        break;
    default:
        {

        }
    }
}

bool ServerMain::_start() {

    ReadConf conf;
    conf.readfile("server.conf");
//    char buf[64] = {0};

    StopHeartPackage();

    //	if (!conf.getvalue("server_id", buf, sizeof(buf)))
    //		return false;
    //	m_addrself.id = atoi(buf);
    //	if (m_addrself.id <= 0)
    //		return false;

    //	if (!conf.getvalue("bindip", m_addrself.ip, sizeof(m_addrself.ip)))
    //		return false;

    //	memset(buf, 0, sizeof(buf));
    //	if (!conf.getvalue("bindport", buf, sizeof(buf)))
    //		return false;

    //	m_addrself.port = atoi(buf);
    //	if (m_addrself.port <= 0)
    //		return false;
    /*
    memset(buf, 0, sizeof(buf));
    if (!conf.getvalue("loginsvr_port", buf, sizeof(buf)))
    return false;
    m_addrlogin.port = atoi(buf);
    if (m_addrlogin.port <= 0)
    return false;

    if (!conf.getvalue("loginsvr_ip", m_addrlogin.ip, sizeof(m_addrlogin.ip)))
    return false;

    MSGOUT(en_Msg_Debug, "ServerMain::_start connect login server ip:%s, port:%d", m_addrlogin.ip, m_addrlogin.port);
    */
    /*
    222.73.205.23 350
    6084
    13661428666
    */

    m_eternIns._start_server(m_pDB, this);
    addmodule();

    // memset(buf, 0, sizeof(buf));
    // if (!conf.getvalue("xtysvr_port", buf, sizeof(buf)))
    //     return false;

    // int port = atoi(buf);
    // if (port <= 0)
    //     return false;

    // memset(buf, 0, sizeof(buf));
    // if (!conf.getvalue("xtysvr_ip", buf, sizeof(buf)))
    //     return false;

    //m_eternIns.ConnectXTY(buf, port);

    m_lastsiTime = time(NULL);

    settimer(TIMER_ETERM_SIPID, TIME_ETERM_SIPID);

    return true;
}

void ServerMain::_stop() {

    m_eternIns._stop_server();

    std::map<int, void*>::iterator it = m_mapfd.begin();
    for(; it != m_mapfd.end(); it++) {
        _StConnectInfo* p = (_StConnectInfo*)it->second;
        if (p == NULL)
            continue;
        if (p->pdata != NULL) {
            free(p->pdata);
            p->pdata = NULL;
        }
        free(p);
    }
    m_mapfd.clear();
}

void ServerMain::_end_callback(const char* pstr, void* pdata, int ntype) {

    ServerSet::_end_callback(pstr, pdata, ntype);
}

bool ServerMain::DealClientData(int fd, void* pdata, unsigned int ulen) {

    _StConnectInfo* pinfo = (_StConnectInfo*)m_mapfd[fd];
    if (pinfo == NULL || pdata == NULL || ulen == (unsigned int)-1 || ulen == 0)
        return false;

    NetSocketHead* phead = (NetSocketHead*)pdata;
    if (phead->uMainCmd == SYSTEM_PROTOCOL_TYPE) {
        switch(phead->uSubCmd) {
        case SP_ETERMMAIN_VERIFY_KEYWORD:
            {
                if (phead->uLen != sizeof(NetSocketHead) + strlen(__key_mainsvr_etermsvr__)
                    || memcmp(phead+1, __key_mainsvr_etermsvr__, strlen(__key_mainsvr_etermsvr__)) != 0) 
                {
                    MSGOUT(en_Msg_Debug, "verify mainserver keyword failed, fd: %d", fd);
                    return false;
                }
                else
                {
                    pinfo->contype = MAINSVR_ETERMSVR_TYPE;
                    MSGOUT(en_Msg_Debug, "verify mainserver keyword success, fd: %d", fd);
                    m_mmainsvrfd.insert(fd);
                    return true;
                }
            }
            break;
        default:
            return false;
        }
    }


    if (m_mmainsvrfd.find(fd) != m_mmainsvrfd.end()) {
        return m_eternIns.DealMainSvrData(fd, pdata, ulen);
    }
    else {
        return m_eternIns.DealClientData(fd, pdata, ulen);
    }
}
