/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-08-21 18:16:32
# LastModified : 2014-12-09 11:24:23
# FileName     : etermclient.h
# Description  : 
 ******************************************************************************/
#ifndef _ETERMCLIENT_H
#define _ETERMCLIENT_H

#include <string>
#include <vector>
#include <map>

#include "perdealcmd.h"

enum _en_Eterm_Client_Type
{
    en_Eterm_CType_Null = 0,
    en_Eterm_CType_Server,
    en_Eterm_CType_Client,
};


enum _en_Eterm_Client_Status
{
    en_Eterm_Client_Null = 0, 
    en_Eterm_Client_AfterSS,  
    en_Eterm_Client_AfterIOK,
    en_Eterm_Client_SystemRt,
};

struct StEtermLoginRet
{
	int		loginret;
	int 	zhijianid;
	int		companyid;
    char    zhijianname[16];
    int     curcount;
    int     limitcount;
};

class EtermClient {
public:
    EtermClient();
    virtual ~EtermClient();
public:                                                                                                   
    void InitClientInfo(int connecttype, int describeid, int zhijianid, int companyid, const char* name, int count);

    void InitClientCountInfo(int curcount, int limitcount);

	int GetZhijianID();

    int GetCompanyID();

    const char* GetUserName();

	// deal send cmd (av sd command)  return false permission forbidden or format error
	bool DealCmd(const char* pstrcmd, std::string& strcmdout, std::string& strhead, std::string& strret, int& breaktype);

	// pcmd : cmd string;  pres : eterm return data include head
	void AddEtermReturnStr(const std::string& pres);

	// add cmd permission info 
	void AddCmdPerInfo(const std::string& strcmd, int pertype);

    void ClearResult();

 //   void FormatBookingRet(std::string& strout);

    void ClearSSInfo();

    bool IsBookEnd();

    void GetEndIOKStr(char* out, unsigned int ulen);

protected:
    int				m_connecttype;  		// client connect or mainserver connect
    int				m_describefd;           // client connect : fd; server connect : serverfd
    int	            m_zhijianid;            // zhijian id  
    int            	m_companyid;
    char            m_username[16];         // 
    int 			m_bookstatus;
    int             m_curcount;
    int             m_limitecount;
    bool            m_bbookend;
    // about av
	int	            m_avidx;		        // avh curent index
    StAvCmdInfo	m_avinfo;               // last av cmd info
	std::vector<std::string>	m_vecres;   // av cmd res;               
	// cmd permission info <eterm cmd, pemission type>
	std::map<std::string, int>	m_mapcmdper; 
//	std::vector<std::string>	m_vecticketcmd;
//	std::vector<std::string>	m_vecname;
//	std::vector<std::string>	m_vecaddinfo;
};

#endif // _ETERMCLIENT_H
