/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-25 15:38:07
# LastModified : 2014-08-31 19:49:07
# FileName     : dbevent.cpp
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <string.h>

#include "dbevent.h"
#include "dbdefine.h"
#include "showmsg.h"
#include "scstructdef.h"
#include "scprotocol.h"
#include "ssprotocol.h"
#include "ssstructdef.h"
#include "readconf.h"
#include "etermloop.h"


bool MysqlHandle::_start_server(void* pdata, ISvrCallback* pcb) {
	ReadConf cf;
	if (-1 == cf.readfile("server.conf")) {
		MSGOUT(en_Msg_Error, "MysqlHandle::_start_server server.conf error!!!");
	}
	_mysql_param param = {{0}};
	do {
		if(!cf.getvalue("mysql_dbname", param.dbname, sizeof(param.dbname)))
			break;
		if(!cf.getvalue("mysql_username", param.username, sizeof(param.username)))
			break;
		if(!cf.getvalue("mysql_passwd", param.passwd, sizeof(param.passwd)))
			break;
		if(!cf.getvalue("mysql_addr", param.addr, sizeof(param.addr)))
			break;
		if(!cf.getvalue("mysql_charset", param.charset, sizeof(param.charset)))
			break;

		char buf[10] = {0};
		if(!cf.getvalue("mysql_port", buf, sizeof(buf)))
			break;
		param.port = atoi(buf);
		if (param.port <= 0)
			break;

		m_psqlmgr = new MySqlMgr();
		if(!m_psqlmgr->_start_server(&param, NULL)) {
			MSGOUT(en_Msg_Error, "MysqlHandle::_start_server mysql _start_server error!!!");
			break;
		}

		return QueueEventModule::_start_server(pdata, pcb);
	}while(false);
	
	MSGOUT(en_Msg_Error, "MysqlHandle::_start_server mysql conf error!!!");
	return false;	
}

void MysqlHandle::_stop_server() {
	QueueEventModule::_stop_server();
	m_psqlmgr->_stop_server();
	delete (MySqlMgr*)m_psqlmgr;
	m_psqlmgr = NULL;
}

void MysqlHandle::SettleQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	MYSQL* psql = (MYSQL*)m_psqlmgr->GetIdleDB();
    if (psql == NULL)
	{
		psql = (MYSQL*)m_psqlmgr->NewIdleDB();
		if (psql == NULL) {
			MSGOUT(en_Msg_Error,
					"MysqlHandle::SettleQueueEvent (2) connect mysql failed!!!");
			return ;
		}
	}
	try {
		switch(maincmd) {
			case DB_TYPE_ETERMLOOP:
			{
				dealetermloop(psql, maincmd, assistcmd, pdata, ulen, pclient);
			}
			break;
			case DB_TYPE_SERVERLOOP:
			{
				dealserverloop(psql, maincmd, assistcmd, pdata, ulen, pclient);	
			}
			break;
			case DB_TYPE_ETERMRESULT:
			case DB_TYPE_CLOSECONNECT:
			{
				PostQueueResult(maincmd, assistcmd, pdata, ulen, pclient);
			}
			break;
			default:
				MSGOUT(en_Msg_Normal, "MysqlHandle::SettleQueueEvent unknow cmd maincmd:%d, assistcmd:%d, pdata:%p, len:%u", maincmd, assistcmd, pdata, ulen);
			break;
		}
		m_psqlmgr->SaveIdleDB(psql);
	}
	catch(...) {
         if (m_psqlmgr != NULL && psql != NULL)
         {
             MSGOUT(en_Msg_Error,
                     "MysqlHandle::SettleQueueEvent maincmd:%d, assistcmd:%d, pdata:%p, len:%u, errstr: %s",
                     maincmd, assistcmd, pdata, ulen, mysql_error(psql));
             m_psqlmgr->FreeConnect(psql);
         }
	}
}

void MysqlHandle::verifyloginpwd(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {

	if (ulen != 0xA2 || pdata == NULL)
		throw DB_ERROR_PARAMERR;

	struct TempLogin{
		char	head[2];
		char	name[16];
		char	passwd[16];
		char	non1[16];
		char	mac[12];
		char	ip[15];
		char	ver[8];
		char	non2[6];
		char	non3[71];
	};
	TempLogin *p = (TempLogin*)pdata;

    const char *proc = "proc_etermtest_checkloginpwd";
    char buf[4096] = {0};
    sprintf(buf, "call %s ('%s', '%s');", proc, p->name, p->passwd);

    MSGOUT(en_Msg_Debug, "%s", buf);

    StEtermLoginRet info = {0};

    strcpy(info.zhijianname, p->name);

    int res = mysql_query(psql, buf);
    if (res != 0) {
        throw DB_ERROR_PROCERR;
    }
    int ret = 0;
    do {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL) {
            break;
        }
        else {
            if(res->row_count == 1) {
                MYSQL_ROW row = mysql_fetch_row(res);
                if(row == NULL) {
                    mysql_free_result(res);
                    break;
                }
                MSGOUT(en_Msg_Debug, "0, %s, 1: %s, 2: %s", row[0], row[1], row[2]);
                info.zhijianid = atoi(row[0]);
                info.companyid = atoi(row[1]);
                info.curcount = atoi(row[2]);
                ret = 1;
            }
            else {
                ret = 0;
            }
            mysql_free_result(res);
        }
    }
    while(!mysql_next_result(psql));

	info.loginret = ret;

    MSGOUT(en_Msg_Debug, "Check result : res:%d, name: %s, pwd: %s, zhijianid: %d, companyid: %d", ret, p->name, p->passwd, info.zhijianid, info.companyid);
	PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_VERIFYLOGINPWD, &info, sizeof(StEtermLoginRet), pclient);
}

void MysqlHandle::dealetermloop(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	switch(assistcmd) {
		case DB_ETERM_VERIFYLOGINPWD:
		{
			verifyloginpwd(psql, maincmd, assistcmd, pdata, ulen, pclient);
		}
		break;
		case DB_ETERM_ADDALLOWROLE:
		{
			int sysid = *((int*)pdata);
			getetermallowrole(psql, sysid);
		}
		break;
		case DB_ETERM_ADDFORBIDROLE:
		{
			int sysid = *((int*)pdata);
			getetermforbidrole(psql, sysid);
		}
		break;
		case DB_ETERM_DISPATCHCMD:
		{
			StEtermRequest* pcmd = (StEtermRequest*)pdata;
			if (/*!DBDealEtermCmd(pcmd) && */!DBLocalDealEtermCmd(pcmd)) {
				PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_DISPATCHCMD, pdata, ulen, pclient);
			}
		}
		break;
        case DB_ETERM_XTYACCONTINFO:
        {
            GetXTYAccontinfo(psql);
        }
        break;
        case DB_ETERM_GETETERMACCONT:
        {
            GetEtermAccontInfo(psql);
        }
        break;
		default:
		{
            PostQueueResult(DB_TYPE_ETERMLOOP, assistcmd, pdata, ulen, pclient);
		}
	}
}

void MysqlHandle::dealserverloop(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	switch(assistcmd) {
		default:
		{
		
		}
	}
}

void MysqlHandle::dealetermcmd(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient)
{
    
    //const char *proc = "proc_simpleverifypwd";
    StEtermRequest* pcmd = (StEtermRequest*)pdata;

    std::string strPNR;
    PerDealCmd::GetPNRFromCmd(pcmd->cmd.strcmd, strPNR);
//    sprintf(buf, "call %s (%d, '%s', %d, '%s', '%s');", proc, p->idx, p->passwd, p->logintype, p->mac, pinfo->ip);

   /*
    int res = mysql_query(psql, buf);                          
    if (res != 0) {
        throw DB_ERROR_PROCERR;
    }
    int ret = VERIFY_ERROR_UNKNOW;
    do {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL) {
            break;
        }
        else {
            if(res->row_count == 1) {
                ret = VERIFY_ERROR_NULL;
            }
            else {
                ret = VERIFY_ERROR_PWD;
            }
            mysql_free_result(res);
        }
    }
    while(!mysql_next_result(psql));
    */
}

void MysqlHandle::getetermallowrole(MYSQL* psql, int sysid) {
    /*
    const char *proc = "proc_simpleverifypwd";

    char buf[4096] = {0};
    sprintf(buf, "call %s (%d);", proc, sysid);


    int res = mysql_query(psql, buf);
    if (res != 0) {
        throw DB_ERROR_PROCERR;
    }
    int ret = VERIFY_ERROR_UNKNOW;
    do {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL) {
            break;
        }
        else {
            if(res->row_count == 1) {
                ret = VERIFY_ERROR_NULL;
            }
            else {
                ret = VERIFY_ERROR_PWD;
            }
            mysql_free_result(res);
        }
    }
    while(!mysql_next_result(psql));
    */

    StEtermLimitInfo info = {0};
    info.sysid = sysid;
    info.companyid = 101;



    PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_ADDALLOWROLE, &info, sizeof(info), (void*)(long)sysid);
}

void MysqlHandle::getetermforbidrole(MYSQL* psql, int sysid) {
    /*
    const char *proc = "proc_simpleverifypwd";

    char buf[4096] = {0};
    sprintf(buf, "call %s (%d);", proc, sysid);

    int res = mysql_query(psql, buf);
    if (res != 0) {
        throw DB_ERROR_PROCERR;
    }
    int ret = VERIFY_ERROR_UNKNOW;
    do {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL) {
            break;
        }
        else {
            if(res->row_count == 1) {
                ret = VERIFY_ERROR_NULL;
            }
            else {
                ret = VERIFY_ERROR_PWD;
            }
            mysql_free_result(res);
        }
    }
    while(!mysql_next_result(psql));
    */

    StEtermLimitInfo info = {0};

    PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_ADDFORBIDROLE, &info, sizeof(info), (void*)(long)sysid);
}

bool MysqlHandle::DBDealEtermCmd(StEtermRequest* pcmd) {
    if (pcmd == NULL || pcmd->requesttype != en_Eterm_Request_Cmd) {
		return false;
	}

    MSGOUT(en_Msg_Debug, "DB deal Cmd, zhijianid: %d, comid: %d, cmd: %s", pcmd->zhijianid, pcmd->companyid, pcmd->cmd.strcmd);

	const char* pstr = "Did not support current command!!!";

	char buf[4096] = {0};
	unsigned int ulen = sizeof(buf);
	PerDealCmd::FormatEtermRes(pstr, pcmd->zhijianid, buf, &ulen);

	char retbuf[4096] = {0};
    NetSocketHead* phead = (NetSocketHead*)retbuf;
    phead->uMainCmd = MAINSVR_ETERMSVR_TYPE;
    phead->uSubCmd = ME_TYPE_ETERMRESULT;
    phead->uLen = sizeof(NetSocketHead) + strlen(pstr)+1 +  sizeof(_StEtermSvrResult);
    _StEtermSvrResult* pres = (_StEtermSvrResult*)(phead+1);
    pres->zhijianid = pcmd->zhijianid;
    memcpy(pres+1, pstr, strlen(pstr)+1);

	if (strcmp(pcmd->cmd.cmdhead, "AB") == 0) {
		if (pcmd->connectype == en_Eterm_CType_Client) {
			PostQueueResult(DB_TYPE_ETERMRESULT, 0, buf, ulen, (void*)(long)pcmd->connectfd);
		}
		else {
			PostQueueResult(DB_TYPE_ETERMRESULT, 0, retbuf, phead->uLen, (void*)(long)pcmd->connectfd);
		}

		return true;
	}
	else if (strcmp(pcmd->cmd.cmdhead, "ML") == 0) {
		if (pcmd->connectype == en_Eterm_CType_Client) {
			PostQueueResult(DB_TYPE_ETERMRESULT, 0, buf, ulen, (void*)(long)pcmd->connectfd);
		}
		else {
			PostQueueResult(DB_TYPE_ETERMRESULT, 0, retbuf, phead->uLen, (void*)(long)pcmd->connectfd);
		}
		return true;
	}
	else if (strcmp(pcmd->cmd.cmdhead, "RTNM") == 0) {
		if (pcmd->connectype == en_Eterm_CType_Client) {
			PostQueueResult(DB_TYPE_ETERMRESULT, 0, buf, ulen, (void*)(long)pcmd->connectfd);
		}
		else {
			PostQueueResult(DB_TYPE_ETERMRESULT, 0, retbuf, phead->uLen, (void*)(long)pcmd->connectfd);
		}
		return true;
	}
	else if (strcmp(pcmd->cmd.cmdhead, "RT") == 0) {
		std::string strPNR = "";
		if (PerDealCmd::GetPNRStrFromCmd(pcmd->cmd.strcmd, strPNR)) {
			return false;
		}
		if (pcmd->connectype == en_Eterm_CType_Client) {
			PostQueueResult(DB_TYPE_ETERMRESULT, 0, buf, ulen, (void*)(long)pcmd->connectfd);
		}
		else {
			PostQueueResult(DB_TYPE_ETERMRESULT, 0, retbuf, phead->uLen, (void*)(long)pcmd->connectfd);
		}
		return true;
	}
	return false;
}

void MysqlHandle::GetEtermAccontInfo(MYSQL* psql)
{
    StEtermLogin info = {0};
 //   return;
 /* 
    strcpy(info.name, "SHPL");
    strcpy(info.pwd, "123456789");
    strcpy(info.ip, "58.214.36.74");      
    info.port = 350;
    info.usertype = en_Eterm_Type_Normal;
  */ 
      /*
    info.sysid = 123045;
    info.companyid = 101;           
    
    strcpy(info.name, "o71f4341");
    strcpy(info.pwd, "sz123456");
    strcpy(info.ip, "122.119.97.12");      
    info.port = 443;
    info.usertype = en_Eterm_Type_Original;
  
    PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_GETETERMACCONT, &info, sizeof(StEtermLogin), NULL);
 */
    info.sysid = 10001;
    info.companyid = 1;           
  
    strcpy(info.name, "o7444261");
    strcpy(info.pwd, "150415sha");
   // strcpy(info.ip, "PEK3.ETERM.COM.CN");      
    strcpy(info.ip, "122.119.97.12");      
    strcpy(info.sistr, "SI 46548/12345a");
    //strcpy(info.sistr, "SI 26735/11111");
    info.port = 443;
    info.usertype = en_Eterm_Type_Original;

    PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_GETETERMACCONT, &info, sizeof(StEtermLogin), NULL);

    info.sysid = 10002;
    strcpy(info.name, "o7444251");
    PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_GETETERMACCONT, &info, sizeof(StEtermLogin), NULL);
}

void MysqlHandle::GetXTYAccontinfo( MYSQL* psql )
{
    StXTYEtermAccontInfo info = {{0}};

    info.companyid = 230;
    info.sysid = 10021;
    strcpy(info.pwd, "DY1361199720");                                                                  
    strcpy(info.name, "SHA336a001");
   // PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_XTYACCONTINFO, &info, sizeof(StXTYEtermAccontInfo), NULL);

    info.sysid = 10022;
    strcpy(info.name, "SHA336a002");
    //PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_XTYACCONTINFO, &info, sizeof(StXTYEtermAccontInfo), NULL);

    info.sysid = 10023;
    strcpy(info.name, "SHA336a003");
   // PostQueueResult(DB_TYPE_ETERMLOOP, DB_ETERM_XTYACCONTINFO, &info, sizeof(StXTYEtermAccontInfo), NULL);
}

void MysqlHandle::GetAccontDetailInfo( MYSQL* psql, int sysid )
{
      
}

bool MysqlHandle::DBLocalDealEtermCmd( StEtermRequest* pcmd )
{
    if (pcmd == NULL || pcmd->requesttype != en_Eterm_Request_Cmd) {
        return false;
    }
    // TODO

    return false;
}
