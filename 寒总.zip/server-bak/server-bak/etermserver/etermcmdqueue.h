/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-12-08 15:16:59
# LastModified : 2014-12-09 13:42:04
# FileName     : etermcmdqueue.h
# Description  : 
 ******************************************************************************/
#ifndef ETERMCMDQUEUE_H
#define ETERMCMDQUEUE_H

class EtermClient;
#include <list>

enum _en_Eterm_Request
{
    en_Eterm_Request_Cmd = 1,
    en_Eterm_Request_Web,
    en_Eterm_Request_3InOne,
};

struct _etermcmdrequest {
    int		        curline;		// line info
    char            cmdhead[16];    // av rt etc.        
    char	        strcmd[1024];	// cmd string
};

struct _etermwebrequest {
    char            data[4096];
    unsigned int    ulen;
};

struct StEtermRequest {                                    
    int             connectype;     // client or server
	int		        connectfd;		// connect fd 
    int             zhijianid;      // request eterm id
    int             companyid;      // company id
	int		        breaktype;		// cmd break type  
    void*           paddinfo;       // addtion infomation
    EtermClient*    pclient;
    int             requesttype;
    union
    {
        _etermcmdrequest   cmd;
        _etermwebrequest   web;
    };
};

struct StEtermCmdTask {
    StEtermCmdTask* pnext;
    StEtermCmdTask* pprev;
    StEtermRequest  request;      
    int             arrsize;
    int*            petermarr;
};

class EtermCmdQueue
{
public:
    EtermCmdQueue();
    ~EtermCmdQueue();
public:
    void CleanAll();

    StEtermCmdTask* GetHeadItem();

    StEtermCmdTask* GetNextItem(StEtermCmdTask* pcur);

    bool PopCurItem(StEtermCmdTask* pitem);

    void PushEtermCmd(StEtermRequest* pcmd, int* arreterm, unsigned int arrsize);

    int GetSize();
private:
    StEtermCmdTask*     m_phead;
    StEtermCmdTask*     m_ptail;
    int                 m_nsize;
};

#endif // ETERMCMDQUEUE_H


