/*******************************************************************************
 # Author       : zenghao
 # Email        : zenghao.1989@163.com
 # CreateTime   : 2014-03-25 15:31:43
 # LastModified : 2014-08-31 19:49:06
 # FileName     : dbevent.h
 # Description  :
 ******************************************************************************/
#ifndef _DBEVENT_H
#define _DBEVENT_H

#include "queuebase.h"
#include "mysqlmgr.h"
#include "etermcmdqueue.h"

class MysqlHandle: public QueueEventModule {
public:
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual void SettleQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
protected:
	DataBaseClass* m_psqlmgr;
protected:
	void verifyloginpwd(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
protected:
	void dealetermloop(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
	void dealserverloop(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
	void dealetermcmd(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);

protected:
	void getetermallowrole(MYSQL* psql, int sysid);
	void getetermforbidrole(MYSQL* psql, int sysid);
    // Deal By Database  
    // return false need deal by others
	bool DBDealEtermCmd(StEtermRequest* pcmd);
    void GetEtermAccontInfo(MYSQL* psql);
    void GetXTYAccontinfo(MYSQL* psql);
    void GetAccontDetailInfo(MYSQL* psql, int sysid);
    // Deal By LocalServer
    // return false need deal by others
    bool DBLocalDealEtermCmd(StEtermRequest* pcmd);
};

#endif // _DBEVENT_H
