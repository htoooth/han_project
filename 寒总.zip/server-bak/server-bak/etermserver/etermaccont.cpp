#include "etermaccont.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

EtermAccont::EtermAccont(void)
{
    m_companyid = -1;
    m_etermsysid = -1;
}


EtermAccont::~EtermAccont(void)
{
}

void EtermAccont::InitAccontInfo( int companyid, int etermsysid )
{
    m_companyid = companyid;
    m_etermsysid = etermsysid;
}

int EtermAccont::GetCompanyID() {
	return m_companyid;
}

void EtermAccont::AddAllowInfo(StEtermLimitInfo* pinfo, int count) {
    if (pinfo == NULL || count == 0)
        return;

    for (int i = 0; i < count; i++) {
    	std::string strtemp = pinfo[i].key;
        StEtermLimitInfo* ptemp = (StEtermLimitInfo*)malloc(sizeof(StEtermLimitInfo));
        memcpy(ptemp, pinfo+i, sizeof(StEtermLimitInfo));
        m_allowinfo[strtemp] = ptemp;
    }
}

void EtermAccont::AddForbidInfo(StEtermLimitInfo* pinfo, int count) {
    if (pinfo == NULL || count == 0)
        return;

    for (int i = 0; i < count; i++) {
    	std::string strtemp = pinfo[i].key;
        StEtermLimitInfo* ptemp = (StEtermLimitInfo*)malloc(sizeof(StEtermLimitInfo));
        memcpy(ptemp, pinfo+1, sizeof(StEtermLimitInfo));
        m_forbidinfo[strtemp] = ptemp;
    }
}

void EtermAccont::ClearInfo() {
	//m_allowinfo
	std::map<std::string, StEtermLimitInfo*>::iterator it = m_allowinfo.begin();
	for (; it != m_allowinfo.end(); ++it) {
		free(it->second);
	}
	it = m_forbidinfo.begin();
	for (; it != m_forbidinfo.end(); ++it) {
			free(it->second);
	}
}

int EtermAccont::GetEtermID() {
	return m_etermsysid;
}

// return value: 1 allow; -1 forbid; 0 didn't have
int EtermAccont::TestSSCmdInfo(StSSSeatInfo* pinfo) {

	std::string strkey1 = pinfo->strplannum;
	std::string strkey2(pinfo->strplannum, 0, 2);
	strkey2 += pinfo->strstart;
	strkey2 += pinfo->strend;

	time_t ttime = PerDealCmd::GetTimeFromEtermStr(pinfo->strdate);

	std::map<std::string, StEtermLimitInfo*>::iterator it = m_forbidinfo.find(strkey1);
	//m_allowinfo  m_forbidinfo
	if (it != m_forbidinfo.end()) {
		if(NULL != strstr(it->second->seat, pinfo->strseat)) {
			if (it->second->tend == 0) {
				if (it->second->tstart < ttime) {
					return -1;
				}
			}
			else {
				if (it->second->tstart < ttime && it->second->tend > ttime) {
					return -1;
				}
			}
		}
	}
	it = m_forbidinfo.find(strkey2);
	if (it != m_forbidinfo.end()) {
		if(NULL != strstr(it->second->seat, pinfo->strseat)) {
			if (it->second->tend == 0) {
				if (it->second->tstart < ttime) {
					return -1;
				}
			}
			else {
				if (it->second->tstart < ttime && it->second->tend > ttime) {
					return -1;
				}
			}
		}
	}

	it = m_allowinfo.find(strkey1);
	if (it != m_allowinfo.end()) {
		if(NULL != strstr(it->second->seat, pinfo->strseat)) {
			if (it->second->tend == 0) {
				if (it->second->tstart < ttime) {
					return 1;
				}
			}
			else {
				if (it->second->tstart < ttime && it->second->tend > ttime) {
					return 1;
				}
			}
		}
	}
	it = m_allowinfo.find(strkey2);
	if (it != m_allowinfo.end()) {
		if(NULL != strstr(it->second->seat, pinfo->strseat)) {
			if(NULL != strstr(it->second->seat, pinfo->strseat)) {
				if (it->second->tend == 0) {
					if (it->second->tstart < ttime) {
						return 1;
					}
				}
				else {
					if (it->second->tstart < ttime && it->second->tend > ttime) {
						return 1;
					}
				}
			}
		}
	}
	return 0;
}
