/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-08-22 16:59:13
# LastModified : 2014-08-31 19:50:48
# FileName     : etermclient.cpp
# Description  : 
 ******************************************************************************/
#include <string.h>
#include <algorithm>

#include "etermclient.h"
#include "showmsg.h"

void EtermClient::InitClientInfo(int connecttype, int describeid, int zhijianid, int companyid, const char* name, int count) {
	m_connecttype = connecttype;
    m_describefd = describeid;
	m_zhijianid = zhijianid;
    m_companyid = companyid;
    m_curcount = count;
    m_bbookend = false;
    if (name != NULL)
        strcpy(m_username, name);
}

int EtermClient::GetZhijianID() {
	return m_zhijianid;
}

// deal send cmd (av sd command)  return false permission forbidden or format error
bool EtermClient::DealCmd(const char* pstrcmd, std::string& strcmdout, std::string& strhead, std::string& strret, int& breaktype)
{
	std::vector<std::string> vecline;
	std::string strcmd = pstrcmd;
	//std::transform(strcmd.begin(), strcmd.end(), strcmd.begin(), toupper);

    m_curcount += 2;
    MSGOUT(en_Msg_Debug, "id: %d, pstrcmd: %s, count: %d", m_zhijianid, strcmd.c_str(), m_curcount);

	PerDealCmd::GetLineFromeCmd(strcmd.c_str(), vecline);
	if (vecline.size() <= 0) {
        strret = "**Format (1)**";
		return false;
	}

	for (unsigned int i = 0; i < vecline.size(); i++) {
		StCmdInfo tempInfo = {{0}};
		std::string strline = vecline.at(i);
		std::transform(strline.begin(), strline.end(), strline.begin(), toupper);
		if(PerDealCmd::JudgeCmdType(strline, &tempInfo)) {
			if (strcmp(tempInfo.cmd, "NM") == 0) {
				strline = vecline.at(i);
				std::transform(strline.begin(), strline.begin()+2, strline.begin(), toupper);
			}
			vecline[i] = strline;
		}
	}

	strret = "";
	strcmdout = "";
	m_bbookend = false;

	if (vecline.size() == 1) {

		std::string strline = vecline.at(0);
		StCmdInfo info = {{0}};
		if(!PerDealCmd::JudgeCmdType(strline, &info)) {
            strret = "**Format (2)**";
			return false;
		}

		MSGOUT(en_Msg_Debug, "JudgeCmdType: %s", info.cmd);

        strhead = info.cmd;
        strcmdout = strcmd;
		breaktype = info.breaktype;

        if (strcmp(info.cmd,"\\") == 0
            || strcmp(info.cmd, "\\IOK") == 0
            || strcmp(info.cmd, "\\I") == 0
            || strcmp(info.cmd, "\\KI") == 0
            || strcmp(info.cmd, "@") == 0
            || strcmp(info.cmd, "@KI") == 0
            || strcmp(info.cmd, "@IOK") == 0
            || strcmp(info.cmd, "@I") == 0) {
                //m_bookstatus = en_Eterm_Client_AfterIOK;
            	m_bbookend = true;
            	// strcmdout = strcmd
             //    return true;
            	char endStr[256] = {0};
				GetEndIOKStr(endStr, sizeof(endStr));
				std::string strTemp = endStr;
				strTemp = strTemp + "\r" + strcmdout;
				strcmdout = strTemp;		
				MSGOUT(en_Msg_Debug, "SI str endStr: %s", strcmdout.c_str());	
				return true;	
        }
        else if (strcmp(info.cmd, "I") == 0
            || strcmp(info.cmd, "IG") == 0) {
            m_bookstatus = en_Eterm_Client_Null;
        	// strcmdout = strcmd
         //    return true;
        }


		int temp = m_avidx;
		if ((strcmp(info.cmd, "PN") == 0 || strcmp(info.cmd, "PB") == 0) && m_avinfo.type != en_Avh_Type_Null) {
			if (strcmp(info.cmd, "PN") == 0) {
				temp++;
			}
			else {
				temp--;
			}
            MSGOUT(en_Msg_Debug, "temp: %d, idx: %d, size: %d", temp, m_avidx, m_vecres.size());
			if (temp <= 0) {
                strret = "**No Page**";
				return false;
			}
			else if (temp > (int)m_vecres.size()) {
				// deal pn
				StAvCmdInfo cmdinfo = {0};
				if(!PerDealCmd::DealAvhCmdByRes(strline, m_avinfo, m_vecres[m_vecres.size()-1], cmdinfo)) {
                    strret = "**Format (3)**";
					return false;
				}
				else {
					strcmdout = PerDealCmd::FormatAvStr(cmdinfo);
					memcpy(&m_avinfo, &cmdinfo, sizeof(StAvCmdInfo));
					return true;
				}
			}
			else {
				strcmdout = "";
				strret = m_vecres[temp-1];
				m_avidx = temp;
                return true;
			}
		}
		else {
			if (strhead == "AV") {
				if (PerDealCmd::GetAvhCmdInfo(strline, m_avinfo)) {
                    MSGOUT(en_Msg_Debug, "avh info, type: %d", m_avinfo.type);
					if (m_avinfo.type == en_Avh_Type_ReturnA) {

						if (m_vecres.size() < 1) {
                            strret = "**Format (4)**";
                            return false;
						}
						else {
							StAvCmdInfo cmdinfo = {0};
							if(PerDealCmd::DealAvhCmdByRes(strline, m_avinfo, m_vecres[m_vecres.size()-1], cmdinfo)) {
								strcmdout = PerDealCmd::FormatAvStr(cmdinfo);
								memcpy(&m_avinfo, &cmdinfo, sizeof(StAvCmdInfo));
							}
							else {
                                strret = "**Format (5)**";
                                return false;
							}
						}
					}
					else {
						strcmdout = PerDealCmd::FormatAvStr(m_avinfo);
					}
				}
				else {
                    strret = "**Format (6)**";
                    return false;
				}
			}
            else if (strhead == "SD") {
                if (m_avidx > (int)m_vecres.size() || m_avidx == 0) {
                    MSGOUT(en_Msg_Debug, "idx: %d, size: %d", m_avidx, m_vecres.size());
                    strret = "**Use Av Cmd First (1)**";
                    return false;
                }
                if(!PerDealCmd::TransformSdCmd(strline.c_str(), m_vecres[m_avidx-1].c_str(), strcmdout)) {
                    strret = "**Format (7)**";
                    return false;
                }
                strhead = "SS";
                m_bookstatus = en_Eterm_Client_AfterSS;
            }
			else {

				if (strcmp(info.cmd, "SS") == 0
					|| strcmp(info.cmd, "SN") == 0
					|| strcmp(info.cmd, "RT") == 0) {
					m_bookstatus = en_Eterm_Client_AfterSS;
				}
				else if (strcmp(info.cmd, "NM") == 0
						|| strcmp(info.cmd, "SSR") == 0
						|| strcmp(info.cmd, "OSI") == 0
						|| strcmp(info.cmd, "RMK") == 0
						|| strcmp(info.cmd, "SA") == 0
						|| strcmp(info.cmd, "CT") == 0
						|| strcmp(info.cmd, "XN") == 0
						) {
					//m_vecticketcmd.push_back(strline);
					if (m_bookstatus != en_Eterm_Client_AfterSS) {
                        strret = "**Use SD or SS Cmd First (1)**";
                        return false;
					}
                    // m_bookstatus = en_Eterm_Client_AfterIOK;
				}
				strcmdout = strline;
            }
            if (strhead != "AV") {
                ClearResult();
            }
		}
		return true;
	}
	else {
		for(unsigned int i = 0; i < vecline.size(); i++) {
			StCmdInfo info = {{0}};
			std::string strline(vecline.at(i));

			if(!PerDealCmd::JudgeCmdType(strline, &info)) {
                strret = "**Format (8)**";
                return false;
			}

            if (strhead == "") {
                strhead = info.cmd;
				breaktype = info.breaktype;
            }
			if (strcmp(info.cmd, "\\") == 0
					|| strcmp(info.cmd, "\\IOK") == 0
					|| strcmp(info.cmd, "\\I") == 0
					|| strcmp(info.cmd, "\\KI") == 0
					|| strcmp(info.cmd, "@") == 0
					|| strcmp(info.cmd, "@KI") == 0
					|| strcmp(info.cmd, "@IOK") == 0
					|| strcmp(info.cmd, "@I") == 0) {
                if (i+1 != vecline.size()) {
                    strret = "**Format (9)**";
                    return false;
                }
				//m_bookstatus = en_Eterm_Client_AfterIOK;
				char endStr[256] = {0};
				GetEndIOKStr(endStr, sizeof(endStr));
				MSGOUT(en_Msg_Debug, "SI str endStr: %s", endStr);
				vecline.insert(--vecline.end(), std::string(endStr));
				m_bbookend = true;
				break;
                //return true;
			}
			else if (strcmp(info.cmd, "SS") == 0
					|| strcmp(info.cmd, "SN") == 0) {
				m_bookstatus = en_Eterm_Client_AfterSS;

			}
            else if (strcmp(info.cmd, "SD") == 0) {
                std::string strss = "";
                if (m_avidx > (int)m_vecres.size() || m_avidx == 0) {
                    MSGOUT(en_Msg_Debug, "idx: %d, size: %d", m_avidx, m_vecres.size());
                    strret = "**Use Av Cmd First (2)**";
                    return false;
                }
                if(!PerDealCmd::TransformSdCmd(strline.c_str(), m_vecres[m_avidx-1].c_str(), strss)) {
                    strret = "**Format (10)**";
                    return false;
                }
                vecline[i] = strss.substr(0, strss.length()-1);
                m_bookstatus = en_Eterm_Client_AfterSS;
            }
			else if (strcmp(info.cmd, "NM") == 0
					|| strcmp(info.cmd, "SSR") == 0
					|| strcmp(info.cmd, "OSI") == 0
					|| strcmp(info.cmd, "RMK") == 0
					|| strcmp(info.cmd, "SA") == 0
					|| strcmp(info.cmd, "CT") == 0
					|| strcmp(info.cmd, "XN") == 0
                    || strcmp(info.cmd, "TKTL") == 0
					) {
				//m_vecticketcmd.push_back(strline);
				if (m_bookstatus != en_Eterm_Client_AfterSS) {
                    strret = "**Use SD or SS Cmd First (2)**";
                    return false;
				}
			}
			else if (strcmp(info.cmd, "XS") == 0) {
				break;
			}
            else {
                strret = "**Format (11)**";
                return false;
            }
		}
        strcmdout = vecline.at(0);
        for (unsigned int i = 1 ; i < vecline.size(); i++) {
            strcmdout += "\r";
            strcmdout += vecline.at(i);
        }
	}
	return true;
}

// pcmd : cmd string;  pres : eterm return data include head
void EtermClient::AddEtermReturnStr(const std::string& pres) {
      m_vecres.push_back(pres);
      m_avidx++;
}

void EtermClient::AddCmdPerInfo(const std::string& strcmd, int pertype) {
	m_mapcmdper[strcmd] = pertype;
}

void EtermClient::ClearResult()
{
    m_avidx = 0;
    m_vecres.clear();
    memset(&m_avinfo, 0, sizeof(m_avinfo));
}

EtermClient::EtermClient()
{
    m_zhijianid = -1;
    m_companyid = -1;
    m_describefd = -1;
    m_connecttype = en_Eterm_CType_Null;

    m_bookstatus = en_Eterm_Client_Null;

    m_avidx = 0;
    memset(&m_avinfo, 0, sizeof(m_avinfo)); 
    m_vecres.clear();
    m_mapcmdper.clear(); 
}

EtermClient::~EtermClient()
{

}

int EtermClient::GetCompanyID()
{
    return m_companyid;
}

//void EtermClient::FormatBookingRet(std::string& strout) {
//
//
//	return;
//}

void EtermClient::ClearSSInfo() {

	m_bookstatus = en_Eterm_Client_Null;
}

const char* EtermClient::GetUserName()
{
    return m_username;
}

void EtermClient::InitClientCountInfo( int curcount, int limitcount )
{
    m_curcount = curcount;
    m_limitecount = limitcount;
}

bool EtermClient::IsBookEnd() {
	return m_bbookend;
}

void EtermClient::GetEndIOKStr(char* out, unsigned int ulen) {
	memset(out, 0, ulen);
	int year, month, day, hour, minute;
	PerDealCmd::GetLocalTimeInfo(&year, &month, &day, &hour, &minute);
	sprintf(out, "CT:OPT BY %s %d%02d%d %02d%02d", GetUserName(), year, month+1, day, hour, minute);
}
