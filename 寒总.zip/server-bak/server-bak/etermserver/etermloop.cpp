/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-07-16 20:21:50
# LastModified : 2015-01-04 13:11:19
# FileName     : etermloop.cpp
# Description  : 
******************************************************************************/
#include <stdlib.h>
#include <string.h>

#include "etermloop.h"
#include "showmsg.h"
#include "dbdefine.h"
#include "perdealcmd.h"
#include "etermaccont.h"
#include "etermcmdqueue.h"
#include "ssstructdef.h"
#include "ssprotocol.h"
#include "etermclient.h"
#include "etermstring.h"

EtermSocket::EtermSocket() {
    m_sysid = -1;
    m_etermid = -1;
    memset(&m_logindata, 0, sizeof(m_logindata));
    m_peterm = NULL;
    m_bready = false;
    m_urecvlen = 0;
    m_utotallen = 0;
    m_pdata = NULL;
    m_companyid = -1;
    m_lastusetime = time(NULL);
    m_status = en_EtermSock_Status_Null;
    SetCurCmdCtrlType(en_EtermSocketCmd_Idle);
    pthread_mutex_init(&m_mulogfile, NULL);
}

EtermSocket::~EtermSocket() {
    if (m_pdata != NULL && m_utotallen > 0) {
        free(m_pdata);
        m_pdata = NULL;
    }
}

bool EtermSocket::_start_server(void* pdata, ISvrCallback* pcb) {

    m_peterm = (EtermSvrLoop*)pdata;
    return CenterSocket::_start_server(NULL, pcb);
}

bool EtermSocket::OnRecvData(char* pdata, unsigned int ulen) {

    if (ulen == 0 || pdata == NULL || ulen == (unsigned int)-1 || ulen == 0)
        return false;

    if (m_utotallen > 0) {
        MSGOUT(en_Msg_Debug, "break m_utotallen : %d, m_urecvlen : %d", m_utotallen, m_urecvlen);
        m_pdata = (char*)realloc(m_pdata, m_urecvlen+ulen);
        memcpy(m_pdata+m_urecvlen, pdata, ulen);
        m_urecvlen += ulen;
        if (m_urecvlen == m_utotallen) {
            DealAFullData(m_pdata, m_utotallen);
            free(m_pdata);
            m_pdata = NULL;
            m_utotallen = 0;
            m_urecvlen = 0;
        }
        else if (m_urecvlen > m_utotallen) {
            /*
            DealAFullData(m_pdata, m_utotallen);
            free(m_pdata);
            m_pdata = NULL;
            m_utotallen = 0;
            m_urecvlen = 0;
            */
            MSGOUT(en_Msg_Error, "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        }
    }
    else {
        if (pdata[0] == 0 ) {
            m_utotallen = (unsigned char)pdata[1];	
        }
        else if (pdata[0] == 1) {
            m_utotallen = ((unsigned char)pdata[2])*256 + (unsigned char)pdata[3];	
        }	
        else {                                       
            MSGOUT(en_Msg_Warning, "unkonw cmd type!!!");
            char filename[128] = {0};
            sprintf(filename, "%s.err", m_logindata.name);
            FILE* pf = fopen(filename, "a");
            if (pf != NULL) {
                int nsiz = ulen*3+1;
                char* pbuff = (char*)malloc(nsiz);
                memset(pbuff, 0, nsiz);
                for (unsigned int i = 0; i < ulen; i++) {
                    sprintf(pbuff+i*3, "%02X ", (unsigned char)pdata[i]);
                }   
                pbuff[nsiz-1] = '\n';
                fwrite(pbuff, sizeof(char), nsiz, pf);
                fclose(pf);
            }
            return false;
        }
        MSGOUT(en_Msg_Debug, "m_utotallen : %d, ulen : %d", m_utotallen, ulen);
        if (ulen > m_utotallen) {
            DealAFullData(pdata, m_utotallen);
            unsigned int offset = m_utotallen;
            m_utotallen = 0;
            m_urecvlen = 0;
            OnRecvData(pdata+offset, ulen-offset);
        }
        else if (ulen == m_utotallen) {
            m_utotallen = 0;
            m_urecvlen = 0;
            DealAFullData(pdata, ulen);
        }
        else {
            m_pdata = (char*)malloc(ulen);
            memcpy(m_pdata, pdata, ulen);
            m_urecvlen = ulen;
        }
    }
    return true;
}

bool EtermSocket::DealAFullData(char* pdata, unsigned int ulen) {
    {
        std::string str = "";
        if (PerDealCmd::GetStrFromEtermData(pdata, ulen, str)) {
            PerDealCmd::replace_all(str, "\r", "\n");
        }
        pthread_mutex_lock(&m_mulogfile);
        FILE* plogfile = fopen(m_logfilename, "a");
        int year = 0, month = 0, day = 0, hour = 0, minute = 0, second = 0;
        PerDealCmd::GetLocalTimeInfo(&year, &month, &day, &hour, &minute, &second);
        fprintf(plogfile, "Recv Time: %04d-%02d-%02d %02d:%02d:%02d len: %d\n", 
            year, month+1, day, hour, minute, second, ulen);

        fprintf(plogfile, "Str : %s\n", str.c_str());
        for (unsigned int i = 0; i < ulen; i++) {
            fprintf(plogfile, "%02X, ", (unsigned char)pdata[i]);
        }
        fprintf(plogfile, "\n");
        fprintf(plogfile, "==================================================\n");
        fclose(plogfile);
        pthread_mutex_unlock(&m_mulogfile);
    }

    if (pdata[0] == 0) {
        if (pdata[2] == 1 && pdata[3] == 0) {
            m_etermid = *(unsigned short*)(pdata+8);

            MSGOUT(en_Msg_Debug, " eterm id : %d", m_etermid);
            char buf[17] = {0x01, (char)0xfe, 0x00, 0x11, 0x14, 0x10, 0x00, 0x02}; 
            buf[8] = pdata[5];
            senddata(buf, sizeof(buf));
            for (unsigned int i = 10; i < ulen; i+=5) {
                m_qloginsend.push(pdata[i]);
            }
        }
    }
    else if (pdata[0] == 1) {
        char heart[5] = {0x01, (char)0xFA, 0x00, 0x05, 0x00};
        char breakbyoth[5] = {0x01, (char)0xFC, 0x00, 0x05, 0x39};
        if (ulen == 5 && memcmp(pdata, heart, sizeof(heart)) == 0) {
            MSGOUT(en_Msg_Debug, "heart package return!!!");
            return true;
        }
        if (ulen == 5 && memcmp(breakbyoth, pdata, 5) == 0) {  
            MSGOUT(en_Msg_Debug, "close package, used by others!!!");
            closesocket();               
            return true;
        }
        if (m_status == en_EtermSock_Status_Init) {
            char buf[4] = {0x01, (char)0xfd, 0x00, 0x06};
            if (memcmp(buf, pdata, 4) == 0 && ulen == 6) {
                if (m_qloginsend.empty()) {
                    SendCmdStr("DA");
                    m_status = en_EtermSock_Status_SendDA;
                    /*
                    char boxbuf[68] = {0x01, 0xf9, 0x00, 0x44, 0x00, 0x01, 0x1b};
                    senddata(boxbuf, sizeof(boxbuf));
                    */
                }
                else {
                    char buf[17] = {0x01, (char)0xfe, 0x00, 0x11, 0x14, 0x10, 0x00, 0x02};
                    buf[8] = m_qloginsend.front();
                    m_qloginsend.pop();
                    senddata(buf, sizeof(buf));
                }
            }
            else if (pdata[1] == (char)0xf8) {
                SendCmdStr("DA");
            }
        }
        else if (m_status == en_EtermSock_Status_SendDA) {
            std::string str = "";
            PerDealCmd::GetStrFromEtermData(pdata, ulen, str);
            MSGOUT(en_Msg_Debug, "DA res: %s", str.c_str());

            if (CETermString::GetDAInfo(str.c_str())) {
                m_status = en_EtermSock_Status_Working;
                m_bready = true;
                if (m_peterm != NULL) {
                    m_peterm->PostEtermResult(DB_ETERM_ADDIDLEETERMSOCK, &m_sysid, sizeof(m_sysid), this);
                }
            }
            else {
                MSGOUT(en_Msg_Debug, "SI str: %s", m_logindata.sistr);
                // SendCmdStr(m_logindata.sistr);
                // m_status = en_EtermSock_Status_SendSI;
                SendSICmd();
            }
        }
        else if (m_status == en_EtermSock_Status_SendSI) {

            std::string str = "";
            PerDealCmd::GetStrFromEtermData(pdata, ulen, str);

            if (str.find("SIGNED IN") == std::string::npos) {
                m_status = en_EtermSock_Status_Null;
                MSGOUT(en_Msg_Debug, "SI login error: %s, sysid: %d, name: %s, sistr: %s", str.c_str(), m_logindata.sysid, m_logindata.name, m_logindata.sistr);
                closesocket();
                return false;
            }

            m_bready = true;
            MSGOUT(en_Msg_Debug, "SI res: %s", str.c_str());
            m_status = en_EtermSock_Status_Working;
            m_bready = true;
            if (m_peterm != NULL) {
                m_peterm->PostEtermResult(DB_ETERM_ADDIDLEETERMSOCK, &m_sysid, sizeof(m_sysid), this);
            }
        }
        else if (m_status == en_EtermSock_Status_Working) {
            if (m_peterm != NULL && m_curcmd.pclient != NULL) {
                if (m_curcmd.pclient->IsBookEnd()) {
                    std::string str = "";
                    if(PerDealCmd::GetStrFromEtermData(pdata, ulen, str)) {
                        char PNR[16] = {0};
                        if (CETermString::GetPNRCode(str.c_str(), PNR, sizeof(PNR))) {
                            MSGOUT(en_Msg_Debug, "book res success, PNR code:%s", PNR);
                        }
                        else {
                            MSGOUT(en_Msg_Debug, "book res failed, str: %s", str.c_str());
                        }
                    }
                }
                StEtermCmdResult res = {{0}};
                memcpy(&res.cmd, &m_curcmd, sizeof(m_curcmd));
                res.pdata = malloc(ulen);
                res.ulen = ulen;
                memcpy(res.pdata, pdata, ulen);
                m_peterm->PostEtermResult(DB_ETERM_CMDRETURNRESULT, &res, sizeof(res), NULL);
                return true;
            }
        }
    }	
    else {
        MSGOUT(en_Msg_Warning, "unkonw cmd type!!!");
        char filename[128] = {0};
        sprintf(filename, "%s.err", m_logindata.name);
        FILE* pf = fopen(filename, "a");
        if (pf != NULL) {
            int nsiz = ulen*3+1;
            char* pbuff = (char*)malloc(nsiz);
            memset(pbuff, 0, nsiz);
            for (unsigned int i = 0; i < ulen; i++) {
                sprintf(pbuff+i*3, "%02X ", (unsigned char)pdata[i]);
            }   
            pbuff[nsiz-1] = '\n';
            fwrite(pbuff, sizeof(char), nsiz, pf);
            fclose(pf);
        }
    }
    return true;
}

int EtermSocket::GetSystemId() {
    return m_sysid;
}

void EtermSocket::OnClose() {
    // to do...

    bool bready = m_bready;

    m_bready = false;
    memset(&m_curcmd, 0, sizeof(m_curcmd));
    m_urecvlen = 0;
    m_utotallen = 0;
    free(m_pdata);
    m_pdata = NULL;
    m_status = en_EtermSock_Status_Null;

    if (m_peterm != NULL) {
        StEtermCloseInfo info = {0};
        info.bready = bready;
        info.sysid = GetSystemId();
        memcpy(&info.login, &m_logindata, sizeof(info.login));
        memcpy(&info.request, &m_curcmd, sizeof(m_curcmd));
        m_peterm->PostEtermResult(DB_ETERM_ETERMSOCKETCLOSE, &info, sizeof(info), this); //OnEtermSockClose(this, bready);
    }
    // notify disconnect 
    MSGOUT(en_Msg_Debug, "socket close!!!, bready: %d", bready);
}

void EtermSocket::SetLoginData(StEtermLogin* plogin) {
    if (plogin != NULL)
        memcpy(&m_logindata, plogin, sizeof(StEtermLogin));
    m_sysid = plogin->sysid;
    RefreshLogFileName();
}

bool EtermSocket::LoginEtermSys()
{
    int contype = en_Normal_Connect;
    if (m_logindata.usertype == en_Eterm_Type_TravelSky || m_logindata.usertype == en_Eterm_Type_Original)
        contype = en_TLSv1_Connect; //en_SSLv3_Connect;

    if(!connectsocket(m_logindata.ip, m_logindata.port, contype)) {
        MSGOUT(en_Msg_Debug, "Connect EtermServer Error, sysid:%d, ip:%s, port: %d", m_logindata.sysid, m_logindata.ip, m_logindata.port);
        return false;
    }
    if (m_logindata.usertype == en_Eterm_Type_Normal || m_logindata.usertype == en_Eterm_Type_Original) {
        struct {
            char	head[2];
            char	name[16];
            char	passwd[16];
            char	non1[16];
            char	mac[12];
            char	ip[15];
            char	ver[8];
            char	non2[6];
            char	non3[71];
        }login;
        memset(&login, 0, sizeof(login));
        login.head[0] = 0x01;
        login.head[1] = 0xa2;
        strcpy(login.name, m_logindata.name);
        strcpy(login.passwd, m_logindata.pwd);
        for (int i = 0; i < 12; i+=2) {
            sprintf(login.mac+i, "%02X", rand()%256);
        }
        sprintf(login.ip, "%d.%d.%d.%d", 
            1+rand()%200,1+rand()%255,1+rand()%200,1+rand()%255);
        unsigned int uiplen = strlen(login.ip);
        strncpy(login.ip+uiplen, "               ", 15-sizeof(login.ip));
        sprintf(login.ver, "3715050");
        sprintf(login.non2, "000000");

        senddata((char*)&login, sizeof(login));
    }
    else if (m_logindata.usertype == en_Eterm_Type_TravelSky) {
        struct {
            char	head[2];
            char	name[8];
            char	key1[8];
            char	passwd[12];
            char	key2[4];
            char	non2[16];
            char	mac[12];
            char	ip[15];
            char	ver[8];
            char	non3[6];
            char	non4[71];
        }login;
        memset(&login, 0, sizeof(login));
        login.head[0] = 0x01;
        login.head[1] = 0xa2;
        strcpy(login.name, m_logindata.name);
        strcpy(login.passwd, m_logindata.pwd);
        for (int i = 0; i < 12; i+=2) {
            sprintf(login.mac+i, "%02X", rand()%256);
        }
        sprintf(login.ip, "%d.%d.%d.%d", 
            1+rand()%200,1+rand()%255,1+rand()%200,1+rand()%255);
        memcpy(login.key1+1, "kl auk ", 7);
        memcpy(login.key2+1, "kl ", 3);
        sprintf(login.ver, "3715050");
        sprintf(login.non2, "000000");

        senddata((char*)&login, sizeof(login));
    }
    else {
        MSGOUT(en_Msg_Error, "error usertype");
        return false;
    }
    m_status = en_EtermSock_Status_Init;
    return true;
}

void EtermSocket::SendCmd(StEtermRequest* pcmd) {

    if (pcmd == NULL)
        return;

    RefreshLastUseTime();

    MSGOUT(en_Msg_Debug, "send cmd, id: %d, cmd: %s", pcmd->zhijianid, pcmd->cmd.strcmd);

    memcpy(&m_curcmd, pcmd, sizeof(StEtermRequest));
    if (pcmd->requesttype == en_Eterm_Request_Cmd) {

        int len = strlen(pcmd->cmd.strcmd);
        if (len > 255-20)
            len = 255-20;

        char head[19] = {0};
        head[0] = 0x01;
        head[3] = 0x15 + len;
        head[7] = 0x01;
        unsigned short *p = (unsigned short*)(head+8);
        *p = m_etermid;
        head[10] = 0x70;
        head[11] = 0x02;
        head[12] = 0x1b;
        head[13] = 0x0b;
        head[14] = pcmd->cmd.curline;
        head[15] = 0x20;
        head[17] = 0x0f;
        head[18] = 0x1e;

        char tail[2] = {0x20, 0x03};
        char buff[4096] = {0};
        int nsiz = 0;
        memcpy(buff, head, sizeof(head));
        nsiz += sizeof(head);
        memcpy(buff+nsiz, pcmd->cmd.strcmd, len);
        nsiz += len;
        memcpy(buff+nsiz, tail, sizeof(tail));
        nsiz += sizeof(tail);

        int res = senddata(buff, nsiz);
        MSGOUT(en_Msg_Debug, "send cmd : %s, len : %d", pcmd->cmd.strcmd, res);
    }
    else if (pcmd->requesttype == en_Eterm_Request_Web || pcmd->requesttype == en_Eterm_Request_3InOne) {

        MSGOUT(en_Msg_Debug, "send web request, ulen: %ld", m_curcmd.web.ulen);
        senddata(m_curcmd.web.data, m_curcmd.web.ulen);
    }
}

bool EtermSocket::IsReady() {
    return m_bready;
}

EtermClient* EtermSocket::GetCurClientPtr()
{
    return m_curcmd.pclient;
}

int EtermSocket::GetCompanyId()
{
    return m_companyid;
}

void EtermSocket::SendCmdStr( const char* pstr )
{
    if (pstr == NULL)
        return;

    int len = strlen(pstr);

    char head[19] = {0};
    head[0] = 0x01;
    head[3] = 0x15 + len;
    head[7] = 0x01;
    unsigned short *p = (unsigned short*)(head+8);
    *p = m_etermid;
    head[10] = 0x70;
    head[11] = 0x02;
    head[12] = 0x1b;
    head[13] = 0x0b;
    head[14] = 0x20;
    head[15] = 0x20;
    head[17] = 0x0f;
    head[18] = 0x1e;

    char tail[2] = {0x20, 0x03};
    char buff[4096] = {0};
    int nsiz = 0;
    memcpy(buff, head, sizeof(head));
    nsiz += sizeof(head);
    memcpy(buff+nsiz, pstr, len);
    nsiz += len;
    memcpy(buff+nsiz, tail, sizeof(tail));
    nsiz += sizeof(tail);

    int res = senddata(buff, nsiz);
    MSGOUT(en_Msg_Debug, "system send cmd : %s, len : %d", pstr, res);
}

int EtermSocket::senddata( char* pdata, unsigned int len )
{
    std::string strcmd = "";
    int line = 0;
    PerDealCmd::GetCmdFromData(pdata, len, strcmd, line);

    //MSGOUT(en_Msg_Debug, "pdata : %p, %u", pdata, len);

    pthread_mutex_lock(&m_mulogfile);
    FILE* plogfile = fopen(m_logfilename, "a");
    int year = 0, month = 0, day = 0, hour = 0, minute = 0, second = 0;
    PerDealCmd::GetLocalTimeInfo(&year, &month, &day, &hour, &minute, &second);
    fprintf(plogfile, "Send Time: %04d-%02d-%02d %02d:%02d:%02d len: %d\n", 
        year, month+1, day, hour, minute, second, len);
    fprintf(plogfile, "Str: %s\n", strcmd.c_str());

    for (unsigned int i = 0; i < len; i++) {
        fprintf(plogfile, "%02X, ", (unsigned char)pdata[i]);
    }
    fprintf(plogfile, "\n");
    fclose(plogfile);
    pthread_mutex_unlock(&m_mulogfile);

    return CenterSocket::senddata(pdata, len);
}

void EtermSocket::RefreshLogFileName()
{
    int year = 0, month = 0, day = 0;
    PerDealCmd::GetLocalTimeInfo(&year, &month, &day);
    sprintf(m_logfilename, "./log/%s-%04d-%02d-%02d", m_logindata.name, year, month+1, day);
}

void EtermSocket::ClearCurStatus()
{
    memset(&m_curcmd, 0, sizeof(m_curcmd));
}

void EtermSocket::SendHeartPackage()
{
    char heart[5] = {0x01, (char)0xfb, 0x00, 0x05};
    senddata(heart, sizeof(heart));
}

void EtermSocket::GetLoginData( StEtermLogin* plogin )
{
    if (plogin != NULL) {
        memcpy(plogin, &m_logindata, sizeof(m_logindata));
    }
}

time_t EtermSocket::GetLastUserTime()
{
    return m_lastusetime;
}

void EtermSocket::RefreshLastUseTime()
{
    m_lastusetime = time(NULL);
}

int EtermSocket::GetCurCmdCtrlType()
{
    return m_cmdstatus;
}

void EtermSocket::SetCurCmdCtrlType( int cmdstatus )
{
    m_cmdstatus = cmdstatus;
}

void EtermSocket::RefreshCurCmdCtrlStatus( const char* phead )
{
    const char* pendstr[] = {"\\", "@", "\\KI", "\\IOK", "@KI", "@IOK"};
    if (strcmp(phead, "I") == 0 || strcmp(phead, "IG") == 0) {
        SetCurCmdCtrlType(en_EtermSocketCmd_Idle);
    }
    else if (GetCurCmdCtrlType() == en_EtermSocketCmd_Book) {
        for (unsigned int i = 0; i < sizeof(pendstr)/sizeof(pendstr[0]); i++) {
            if (strcmp(phead, pendstr[i]) == 0) {
                SetCurCmdCtrlType(en_EtermSocketCmd_Idle);
                break;
            }
        }
    }
    else if (strcmp(phead, "SS") == 0 || strcmp(phead, "SD") == 0) {
        SetCurCmdCtrlType(en_EtermSocketCmd_Book);
    }
    else {
        SetCurCmdCtrlType(en_EtermSocketCmd_Query);
    }
}

void EtermSocket::SendSICmd()
{
    SendCmdStr(m_logindata.sistr);
    m_status = en_EtermSock_Status_SendSI;
}


/***********************************************************************************/

EtermSvrLoop::EtermSvrLoop() {
    m_pdb = NULL;
    m_pcb = NULL;
    m_bend = true; 

    m_bflushsendcmd = false;

    sem_init(&m_endsem, 0, 0);

    memset(m_systemmsg, 0, sizeof(m_systemmsg));
    memset(m_msgboxmsg, 0, sizeof(m_msgboxmsg));
}

EtermSvrLoop::~EtermSvrLoop() {

    sem_destroy(&m_endsem);
}

void EtermSvrLoop::PostEtermReuqest(int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
    if (m_pdb != NULL)
        m_pdb->PostQueueEvent(DB_TYPE_ETERMLOOP, assistcmd, pdata, ulen, pclient);
}

bool EtermSvrLoop::DealClientData(int fd, void* pdata, unsigned int ulen) {

    if (_is_end())
        return false;

    char* phead = (char*)pdata;
    if (phead[0] == 0x01 && (unsigned char)phead[1] == 0xa2) {
        if (ulen != 0xa2)
            return false;
        PostEtermReuqest(DB_ETERM_VERIFYLOGINPWD, pdata, ulen, (void*)(long)fd);
        return true;
    }
    else if (phead[0] == 0x01 && (unsigned char)phead[1] == 0xfe) {
        char buf[6] = {0x01, (char)0xfd, 0x00, 0x06};
        char tmp[8] = {0x01, (char)0xfe, 0x00, 0x11, 0x14, 0x10, 0x00, 0x02};
        if (ulen%17 == 0 && memcmp(tmp, pdata, 8) == 0) {
            buf[5] = phead[8];
            MSGOUT(en_Msg_Debug, "xxxxxxxxxxxxxxxxxxxxx : %X", phead[8]);
            SendDataToClient(fd, buf, sizeof(buf));

            if (ulen-17 > 0) {
                return DealClientData(fd, (char*)pdata+17, ulen-17);
            }
            else /*if (phead[8] == 0x20)*/ {
                //char buf[] = "test  data dfdf asdf asdf asfa fas f";
                //SendResMessage(fd, m_eternIns.GetZhijianID(fd), buf, strlen(buf));
                // system msg....
                if (strlen(m_systemmsg) > 0) {
                    SendStrToClient(fd, m_mapclientuser[fd]->GetZhijianID(), m_systemmsg);
                }
                MSGOUT(en_Msg_Debug, "get system msg...");
            }      
            return true;
        }
    }
    else if (phead[0] == 0x01 && (unsigned char)phead[1] == 0xf9 && ulen == 68) {
        // message box info
        char tmp[68] = {0x01, (char)0xf9, 0x00, 0x44, 0x00, 0x01, 0x1b};
        if (memcmp(tmp, pdata, 68) == 0) {
//             char buf[] = {0x1b, 0x0E,
//                 0x13, 0x22, 0x13, 0x23, 0x13, 0x24, 0x13, 0x25, 0x13, 0x26, 0x13, 0x27, 0x13, 0x28, 0x13, 0x29, 0x13, 0x2A, 0x13, 0x2B, 0x13, 0x2C, 0x13, 0x2D, 0x13, 0x2E, 0x13, 0x25, 
//                 0X1B, 0X0F, 0x00};
            if (strlen(m_msgboxmsg) > 0) {
                SendMsgboxToClient(fd, m_msgboxmsg);
            }
            return true;
        }
    }
    else if (phead[0] == 0x01 && (unsigned char)phead[1] == 0xfb && ulen == 5) {
        // heart package
        char buf[5] = {0x01, (char)0xfa, 0x00, 0x05};
        SendDataToClient(fd, buf, sizeof(buf));
        return true;
    }

    int line = 0;
    std::string strcmd = "";
    int res = PerDealCmd::GetCmdFromData(pdata, ulen, strcmd, line);

    MSGOUT(en_Msg_Debug, "res: %d, str: %s", res, strcmd.c_str());

    if (1 == res) {
        return DealClientEtermString(fd, strcmd.c_str(), line);
    }
    else if (2 == res) {
        return DealEtermWebRequest(fd, (char*)pdata, ulen);
        /*
        MSGOUT(en_Msg_Debug, "Web Request: %s", strcmd.c_str());
        char head[19] = {0x01, 0x00, 0x00, 0x00, 0x29, 0x00, 0x00, 0x01, (char)0xaa, 0x2a, 0x00, 0x02, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x01};

        char str[] = "HTTP/1.1 200 OK\n\
                     Date: Mon, 09 Feb 2015 08:57:56 GMT\n\
                     Server: Apache/2.2.15 (CentOS)\n\
                     Content-Length: 201\n\
                     Connection: keep-alive\n\
                     Content-Type: text/html; charset=iso-8859-1\n\
                     \n\
                     <!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n\
                     <html><head>\n\
                     <title>404 Not Found</title>\n\
                     </head><body>\n\
                     <h1>Not Found</h1>\n\
                     <p>The requested URL was not found on this server.</p>\n\
                     <hr>\n\
                     </body></html>\n";

        char buf[4096] = {0};
        unsigned int templen = 0;
        memcpy(buf, head, sizeof(head));
        templen += sizeof(head);
        templen += 120;
        strcpy(buf+templen, str);
        templen += strlen(str);
        buf[templen] = 0x03;
        templen++;
        buf[2] = templen/256;
        buf[3] = templen%256;

        SendDataToClient(fd, buf, templen);
        return true;
        */
    }
    else if (3 == res) {
        return DealEterm3InOneRequest(fd, (char*)pdata, ulen);
    }
    else {
        return false;
    }
}

bool EtermSvrLoop::_start_server(void* pdata, ISvrCallback* pcb) {
    m_pdb = (QueueEventModule*)pdata;
    m_pcb = pcb;

    m_xty._start_server(this, this);
    //m_nmodcount++;

    m_bend = false;

    PostEtermReuqest(DB_ETERM_GETETERMACCONT, NULL, 0, NULL);

    SetEtermTimer(ETERM_TIMER_CHECKSERVERHEARTPACKAGE, ETERM_TIME_CHECKSERVERHEARTPACKAGE);
    //SetEtermTimer(ETERM_TIMER_CHECKBUSYSOCKETSTATUS, ETERM_TIME_CHECKBUSYSOCKETSTATUS);

    // struct StCmdInfo {
    // char    cmd[8];
    // int     breaktype;  // break type
    FILE* pf = fopen("cmd.txt", "r");
    while(!feof(pf)) {
        char buf[16] = {0};
        fgets(buf, sizeof(buf), pf);

        StCmdInfo info = {{0}};
        for (unsigned int i = 0; i < strlen(buf); ++i) {
            if (buf[i] == ' ') {
                strncpy(info.cmd, buf, i);
                info.breaktype = atoi(buf+i+1);
                PerDealCmd::InitConfig(&info, 1);
                MSGOUT(en_Msg_Debug, "cmd: %s, type: %d", info.cmd, info.breaktype);
            }            
        }
    }

    return true;
}

void EtermSvrLoop::_stop_server() {

    MSGOUT(en_Msg_Normal, "stop server");

    if (_is_end())
        return ;
    m_bend = true; 

    std::map<int, StEtermSockAddInfo*>::iterator it2 = m_tosock.begin();
    for (; it2 != m_tosock.end(); ) {
        free(it2->second);
        m_tosock.erase(it2++);
    }

    std::map<int, EtermClient*>::iterator it4 = m_mapclientuser.begin();
    for (; it4 != m_mapclientuser.end(); ) {
        delete it4->second;
        m_mapclientuser.erase(it4++);
    }

    std::map<int, std::map<int, EtermClient*> >::iterator it5 = m_mapsvruser.begin();
    for (; it5 != m_mapsvruser.end(); ) {
        std::map<int, EtermClient*>::iterator it6 = it5->second.begin();
        for (; it6 != it5->second.end(); ) {
            delete it6->second;
            it5->second.erase(it6++);
        }
        m_mapsvruser.erase(it5++);
    }

    m_queuecmd.CleanAll();

    ReleaseAllLimitInfo();

    CenterSocket::releasesslres();

    SaveAllUserInfo();

    if (sem_trywait(&m_endsem) == -1) {
        if (m_pcb != NULL) {
            m_pcb->_end_callback("EtermSvrLoop", this, 0);
        }
        return;
    }

    m_xty._stop_server(); 

    std::map<EtermClient*, EtermSocket*>::iterator it1 = m_resbusy.begin();
    for (; it1 != m_resbusy.end(); ) {
        it1->second->_stop_server();
        //delete it1->second;        // will delete in _end_callback
        m_resbusy.erase(it1++);
    }

    std::map<int, EtermSocket*>::iterator it3 = m_residle.begin();
    for (; it3 != m_residle.end(); ) {
        it3->second->_stop_server();
        //delete it3->second;       // will delete in _end_callback
        m_residle.erase(it3++);
    }

}

bool EtermSvrLoop::_is_end() {
    return m_bend;
}

void EtermSvrLoop::AddCompanyCode(int sysid, const char* pCode) {
    if(pCode == NULL || strlen(pCode) != 6 || sysid <= 0)
        return;
    m_mapCode[pCode] = sysid;
}

void EtermSvrLoop::AddEtermConfig(StEtermLogin* plogin) {

    EtermSocket* psock = new EtermSocket();

    psock->_start_server(this, this);
    psock->SetLoginData(plogin);
    if (!psock->LoginEtermSys()) {
        MSGOUT(en_Msg_Error, "login eterm error name: %s, sysid: %d, companyid: %d, ip: %s, port: %d", 
            plogin->name, plogin->sysid, plogin->companyid, plogin->ip, plogin->port);
        psock->_stop_server();
        delete psock;
        return;
    }

    StEtermSockAddInfo* pinfo = (StEtermSockAddInfo*)malloc(sizeof(StEtermSockAddInfo));
    memset(pinfo, 0, sizeof(StEtermSockAddInfo));

    pinfo->psock = psock;
    pinfo->companyid = plogin->companyid;
    pinfo->heartsendtime = time(NULL);
    pinfo->sysid = plogin->sysid;

    m_tosock[plogin->sysid] = pinfo;

    sem_post(&m_endsem);
    MSGOUT(en_Msg_Debug, "login eterm ok! name: %s, sysid: %d, companyid: %d, ip: %s, port: %d", 
        plogin->name, plogin->sysid, plogin->companyid, plogin->ip, plogin->port);
}

void EtermSvrLoop::OnEtermSockClose(int sysid, EtermSocket* psock, StEtermLogin* plogin, bool bready)
{

    if (_is_end() || psock == NULL)
        return;

    MSGOUT(en_Msg_Debug, "On Close !!!!!!");

    std::map<int, EtermSocket*>::iterator it1 = m_residle.find(sysid);
    if (it1 != m_residle.end()) {
        m_residle.erase(it1);
    }

    std::map<EtermClient*, EtermSocket*>::iterator it2 = m_resbusy.begin();
    for (; it2 != m_resbusy.end(); it2++) {
        if (it2->second == psock) {
            m_resbusy.erase(it2);
            break;
        }
    }

    std::map<int, StEtermSockAddInfo*>::iterator it3 = m_tosock.find(sysid);
    if (it3 != m_tosock.end()) {
        free(it3->second);
        m_tosock.erase(it3);
    }

    if (bready) {
        MSGOUT(en_Msg_Debug, "add close etermsocket: %p", psock);
        if (m_qoffline.size() < 1) {
            SetEtermTimer(ETERM_TIMER_RECONNECTETERM, ETERM_TIME_RECONNECTETERM);
        }
        m_qoffline.push(*plogin);
    }
    else {
        MSGOUT(en_Msg_Error, "eterm config error name: %s, sysid: %d, companyid: %d, ip: %s, port: %d", 
            plogin->name, plogin->sysid, plogin->companyid, plogin->ip, plogin->port);
    }
}

void EtermSvrLoop::AddIdleSock(int sysid, EtermSocket* psock) {
    /*
    if (m_metres.find(sysid) != m_metres.end()) {
    m_metres[sysid]->_stop_server();
    }
    */
    psock->ClearCurStatus();
    m_residle[sysid] = psock;
    PostFlushSendCmdRequest();
    MSGOUT(en_Msg_Debug, "add idle socket : id: %d, ptr: %p", sysid, psock);
}

void EtermSvrLoop::_end_callback(const char* pstr, void* pdata, int ntype) {
    if (strcmp("CenterSocket", pstr) == 0 && ntype == 0) {
        if (pdata == &m_xty) {
            MSGOUT(en_Msg_Normal, "XTYClient stop!!!");	
        }
        else {
            MSGOUT(en_Msg_Debug, "delete EtermSocket ptr: %p", pdata);
            EtermSocket* psock = (EtermSocket*)pdata;
            delete psock;
        }
    }
    if (sem_trywait(&m_endsem) == -1) {
        if (m_pcb != NULL) {
            m_pcb->_end_callback("EtermSvrLoop", this, 0);
        }  
    }
}

void EtermSvrLoop::OnEtermTimer(unsigned int uid) {
    switch (uid)
    {
    case ETERM_TIMER_RECONNECTETERM:
        {
            while (m_qoffline.size() > 0)
            {
                StEtermLogin login = m_qoffline.front(); 
                AddEtermConfig(&login);
                m_qoffline.pop();
            }
        }
        break;
    case ETERM_TIMER_CHECKSERVERHEARTPACKAGE:
        {
            time_t tcur = time(NULL);
            std::map<int, StEtermSockAddInfo*>::iterator it = m_tosock.begin();
            for (; it != m_tosock.end(); it++) {
                if (tcur - it->second->heartsendtime > 9*60) { 
                    PostEtermResult(DB_ETERM_SENDHEARTPACKAGE, &it->second->sysid, sizeof(it->second->sysid), NULL);
                    it->second->heartsendtime = tcur;
                    MSGOUT(en_Msg_Debug, "Heart Package sysid: %d", it->second->sysid);
                }
            } 
            SetEtermTimer(ETERM_TIMER_CHECKSERVERHEARTPACKAGE, ETERM_TIME_CHECKSERVERHEARTPACKAGE);
        }
        break;
    case ETERM_TIMER_CLEARRETRYSTATUS:
        {
            time_t temp = time(NULL);
            std::map<int, StEtermLoginReTry*>::iterator it = m_mtrycount.begin();
            for (; it != m_mtrycount.end();) {
                if(temp - it->second->lasttrytime > 5) {
                    free(it->second);
                    m_mtrycount.erase(it++);
                }
                else {
                    it++;
                }
            }
            if (!m_mtrycount.empty()) {
                SetEtermTimer(ETERM_TIMER_CLEARRETRYSTATUS, ETERM_TIME_CLEARRETRYSTATUS);
            }
        }
        break;
    case ETERM_TIMER_CHECKBUSYSOCKETSTATUS:
        {  
            MSGOUT(en_Msg_Debug, "Check Eterm Socket Cmd Status");
            time_t curtime = time(NULL);
            std::map<EtermClient*, EtermSocket*>::iterator it = m_resbusy.begin();
            for (; it != m_resbusy.end(); ) {
                if (it->second->GetCurCmdCtrlType() == en_EtermSocketCmd_Book) {
                    if(curtime - it->second->GetLastUserTime() > 60*2) {
                         it->second->SendCmdStr("I");
                    }
                }
                else {
                    if(curtime - it->second->GetLastUserTime() > 60*2) {
                        AddIdleSock(it->second->GetSystemId(), it->second);
                        m_resbusy.erase(it++);
                        continue;
                    }
                }
                it++;
            }
            SetEtermTimer(ETERM_TIMER_CHECKBUSYSOCKETSTATUS, ETERM_TIME_CHECKBUSYSOCKETSTATUS);
        }
        break;
    default:
        break;
    }
}

void EtermSvrLoop::SetEtermTimer(unsigned int uid, unsigned int msec) {
    if(m_pdb != NULL) {
        StEtermTimer timer = {0};
        timer.uid = uid;
        timer.umsec = msec;
        m_pdb->PostQueueResult(DB_TYPE_ETERMTIMER, DB_ETERMTIMER_SETTIMER, &timer, sizeof(timer), NULL);
    }  
}

void EtermSvrLoop::EtermKillTimer(unsigned int uid) {
    if(m_pdb != NULL) {
        StEtermTimer timer = {0};
        timer.uid = uid;
        m_pdb->PostQueueResult(DB_TYPE_ETERMTIMER, DB_ETERMTIMER_KILLTIMER, &timer, sizeof(timer), NULL);
    }    
}

void EtermSvrLoop::PushCmdToDB(StEtermRequest* cmd) {
    if (m_pdb != NULL && cmd != NULL) {
        m_pdb->PostQueueEvent(DB_TYPE_ETERMLOOP, DB_ETERM_DISPATCHCMD, cmd, sizeof(StEtermRequest), 0);
        MSGOUT(en_Msg_Debug, "post cmd : %s", cmd->cmd.strcmd);
    }
}                                                     

void EtermSvrLoop::AddSockToBusy(EtermClient* pclient, EtermSocket* psock, bool bbreak)
{
    if (pclient == NULL || psock == NULL)
        return;
    if (bbreak) {
        m_restemp[pclient] = psock;
    }
    else {
        m_resbusy[pclient] = psock;        
    }
}

bool EtermSvrLoop::DealEtermResult(StEtermRequest* pcmd, void* pdata, unsigned int ulen, bool bend /*= true*/) {

    if (pcmd == NULL || pdata == NULL || ulen == 0 || ulen == (unsigned int)-1)
        return false;                                                        

    if (pcmd->breaktype == en_Cmd_Brk_Can && bend) {
        EtermSocket* psock = GetUsedSocket(pcmd->pclient);
        if (psock == NULL) {
            MSGOUT(en_Msg_Error, "error busy socket, zhijianid : %d", pcmd->zhijianid);	
        }
        else {
            FreeUsedSocket(pcmd->pclient);
            AddIdleSock(psock->GetSystemId(), psock);
        }
    }
    MSGOUT(en_Msg_Debug, "post eterm result, id : %d", pcmd->zhijianid);

    if (pcmd->connectype == en_Eterm_CType_Client) {
        std::string str = "";
        std::map<int, EtermClient*>::iterator it = m_mapclientuser.find(pcmd->connectfd);
        if(PerDealCmd::GetStrFromEtermData(pdata, ulen, str)) {
            if (it == m_mapclientuser.end()) {
                MSGOUT(en_Msg_Normal, "client socket close!, fd: %d", pcmd->connectfd);
                return false;
            }
            it->second->AddEtermReturnStr(str);
        }

        DealSendResult((char*)pdata, pcmd->zhijianid);
        SendDataToClient(pcmd->connectfd, pdata, ulen);

        return true;
    }
    else if (pcmd->connectype == en_Eterm_CType_Server) {
        std::string strout = "";
        if (!PerDealCmd::GetStrFromEtermData(pdata, ulen, strout)) {
            return false;
        }

        std::map<int, std::map<int, EtermClient*> >::iterator it1 = m_mapsvruser.find(pcmd->connectfd);
        if (it1 == m_mapsvruser.end()) {
            MSGOUT(en_Msg_Normal, "server socket close!, fd: %d", pcmd->connectfd);
            return false;
        }
        std::map<int, EtermClient*>::iterator it2 = it1->second.find(pcmd->zhijianid);
        if (it2 == it1->second.end()) {
            MSGOUT(en_Msg_Normal, "server user close: svr fd: %d, zhijianid: %d", pcmd->connectfd, pcmd->zhijianid);
            return false;
        }
        it2->second->AddEtermReturnStr(strout);

        SendStrToMainSvr(pcmd->connectfd, pcmd->zhijianid, strout, pcmd->paddinfo);
        return true;
    }
    return false;
}

void EtermSvrLoop::AddEtermUser(_en_Eterm_Client_Type connecttype, int connectfd, StEtermLoginRet* pret) {
    EtermClient* p = new EtermClient;
    p->InitClientInfo(connecttype, connectfd, pret->zhijianid, pret->companyid, pret->zhijianname, pret->curcount);
    p->InitClientCountInfo(pret->curcount, pret->limitcount);
    if (connecttype == en_Eterm_CType_Client) {
        m_mapclientuser[connectfd] = p;
    }
    else if (connecttype == en_Eterm_CType_Server) {
        std::map<int, std::map<int, EtermClient*> >::iterator it1 = m_mapsvruser.find(connectfd);
        if (it1 == m_mapsvruser.end())
        {
            delete p;
            // close connect
            return;
        }
        it1->second[pret->zhijianid] = p;     
    }
}

void EtermSvrLoop::DealSendResult(char* pdata, unsigned short id)
{
    if (pdata == NULL || id == (unsigned short)-1) {
        return;
    }
    if (pdata[0] == 0x01 && pdata[1] == 0x00 
        && pdata[4] == 0x00 && pdata[5] == 0x00 && pdata[6] == 0x00 && pdata[7] == 0x01) {
            *((unsigned short*)(pdata+8)) = id;
    }
}

void EtermSvrLoop::OnClientClose(int fd) {
    EtermSocket* psock = NULL;
    EtermClient* pclient = NULL;
    std::map<int, EtermClient*>::iterator it1 = m_mapclientuser.find(fd);
    if(it1 != m_mapclientuser.end()) {
        pclient = it1->second;
        if (pclient != NULL) {
            EtermSocket* psock = GetUsedSocket(pclient);
            if (psock != NULL) {
                FreeUsedSocket(pclient);
                AddIdleSock(psock->GetSystemId(), psock);
            }

            StEtermCmdTask* ptask = m_queuecmd.GetHeadItem();
            if (ptask != NULL) {
                StEtermCmdTask* ptemp = ptask;
                ptask = m_queuecmd.GetNextItem(ptask);

                if (ptemp->request.pclient == pclient) {
                    m_queuecmd.PopCurItem(ptemp);
                }
            }
            delete pclient;
        }
        m_mapclientuser.erase(it1);
    }


    if (psock != NULL) {
        if (psock->GetCurCmdCtrlType() == en_EtermSocketCmd_Book) {
            psock->SendCmdStr("I");
        }
        AddIdleSock(psock->GetSystemId(), psock);
    }
}

bool EtermSvrLoop::ConnectXTY(const char* pip, int port) {
    bool ret = m_xty.connectsocket(pip, port, en_Normal_Connect);

    if (ret) {
        m_xty.OnConnectOK(ret);
        sem_post(&m_endsem);
    }

    MSGOUT(en_Msg_Debug, "connect XTY res : %d", ret);

    return ret;
}

void EtermSvrLoop::DealXTYRet(const char* name, const char* pwd, int id, const char* pip, int port, int errtype) {

    MSGOUT(en_Msg_Debug, "name:%s, pwd:%s, id:%d, ip:%s, port:%d, errcode:%d", 
        name, pwd, id, pip, port, errtype);
}

bool EtermSvrLoop::DealMainSvrData( int fd, void* pdata, unsigned int ulen )
{
    _StEtermSvrResult* p = (_StEtermSvrResult*)pdata;

    _StEtermSvrResult* pinfo = (_StEtermSvrResult*)malloc(sizeof(_StEtermSvrResult));
    memset(pinfo, 0, sizeof(_StEtermSvrResult));
    memcpy(pinfo, p, sizeof(_StEtermSvrResult));

    return DealServerEtermString(fd, p->zhijianid, (char*)(p+1) , pinfo);
}

void EtermSvrLoop::DealDBResult( int assistcmd, void* pdata, unsigned int ulen, void* pclient )
{
    switch(assistcmd) {
    case DB_ETERM_ADDALLOWROLE:
        {
            int count = ulen/sizeof(StEtermLimitInfo);
            AddEtermAllowInfo((int)(long)pclient, (StEtermLimitInfo*)pdata, count);
        }
        break;
    case DB_ETERM_ADDFORBIDROLE:
        {
            int count = ulen/sizeof(StEtermLimitInfo);
            AddEtermForbidInfo((int)(long)pclient, (StEtermLimitInfo*)pdata, count);
        }
        break;
    case DB_ETERM_DISPATCHCMD:
        {
            if (pdata == NULL || ulen != sizeof(StEtermRequest))
                return;
            AssignEtermCmd((StEtermRequest*)pdata);
        }
        break;
    case DB_ETERM_VERIFYLOGINPWD:
        {
            DBEtermLoginRet(pdata, ulen, pclient);
        }
        break;
    case DB_ETERM_XTYACCONTINFO:
        {
            if(ulen != sizeof(StXTYEtermAccontInfo)) {
                return;
            }
            m_xty.DealXTYAccont((StXTYEtermAccontInfo*)pdata);
        }
        break;
    case DB_ETERM_ADDXTYACCONT:
        {
            StXTYEtermAccontInfo* pinfo = (StXTYEtermAccontInfo*)pdata;
            StEtermLogin login = {0};  
            login.sysid = pinfo->sysid;
            login.companyid = pinfo->companyid;
            login.port = pinfo->port;
            login.usertype = en_Eterm_Type_TravelSky;

            strcpy(login.ip, pinfo->ip);
            strcpy(login.name, pinfo->name);
            strcpy(login.pwd, pinfo->pwd);

            AddEtermConfig(&login);
        }
        break;
    case DB_ETERM_GETETERMACCONT:
        {
            if (pdata != NULL && ulen == sizeof(StEtermLogin)) {
                StEtermLogin* plogin = (StEtermLogin*) pdata;
                AddEtermConfig(plogin);
                //PostEtermReuqest(DB_ETERM_ADDALLOWROLE, &plogin->sysid, sizeof(plogin->sysid), NULL);
            }
        }
        break;
    case DB_ETERM_ETERMSOCKRECONNCT:
        {
            MSGOUT(en_Msg_Debug, "reconnect eterm account");
            EtermSocket* psock = *((EtermSocket**)pdata);
            MSGOUT(en_Msg_Debug, "reconnect eterm account, comid: %d, sysid: %d", psock->GetCompanyId(), psock->GetSystemId());
            if (!psock->LoginEtermSys()) {
                psock->_stop_server();
                delete psock;
            }
        }
        break;
    case DB_ETERM_SENDHEARTPACKAGE:
        {
            //PostEtermReuqest(DB_ETERM_SENDHEARTPACKAGE, &it->second->sysid, sizeof(it->second->sysid), NULL);
            int sysyid = *((int*)pdata);

            std::map<int, StEtermSockAddInfo*>::iterator it = m_tosock.find(sysyid);
            if (it != m_tosock.end()) {
                it->second->psock->SendHeartPackage();
                MSGOUT(en_Msg_Debug, "Send Heart Package sysid: %d", sysyid);
            } 
        }
        break;
    case DB_ETERM_ADDIDLEETERMSOCK:
        {
            int sysid = *((int*)pdata);
            AddIdleSock(sysid, (EtermSocket*)pclient);
        }
        break;
    case DB_ETERM_CMDRETURNRESULT:
        {
            StEtermCmdResult* pres = (StEtermCmdResult*)pdata;
//             char* pret = NULL;
//             unsigned int utlen = 0;
//             if (!PerDealCmd::AddEnterToEtermRetStr((char*)pres->pdata, pres->ulen, &pret, &utlen)) {
                  DealEtermResult(&pres->cmd, pres->pdata, pres->ulen);
//             }
//             else {
//                 DealEtermResult(&pres->cmd, pret, utlen);
//                 free(pret);
//             }
            free(pres->pdata);
        }
        break;
    case DB_ETERM_ETERMSOCKETCLOSE:
        {
            StEtermCloseInfo* pinfo = (StEtermCloseInfo*)pdata;
            OnEtermSockClose(pinfo->sysid, (EtermSocket*)pclient, &pinfo->login, pinfo->bready);
        }   
        break;
    case DB_ETERM_FLUSHSENDCMD:
        {
            FlushSendCmdQueue();
            m_bflushsendcmd = false;
        }
        break;
    default:
        {

        }
    }
}

void EtermSvrLoop::SendDataToClient( int fd, void* pdata, unsigned int ulen )
{
    if (m_pdb != NULL) {
        m_pdb->PostQueueResult(DB_TYPE_ETERMRESULT, 0, pdata, ulen, (void*)(long)fd);
    }
}

void EtermSvrLoop::SendStrToMainSvr( int fd, int zhijianid, const std::string& str, void* paddinfo )
{
    if (_is_end() || paddinfo == NULL)
        return;
    if (m_pdb != NULL) {

        char buf[4096] = {0};
        NetSocketHead* phead = (NetSocketHead*)buf;
        phead->uMainCmd = MAINSVR_ETERMSVR_TYPE;
        phead->uSubCmd = ME_TYPE_ETERMRESULT;
        phead->uLen = sizeof(NetSocketHead) + str.length()+1 +  sizeof(_StEtermSvrResult);
        _StEtermSvrResult* pres = (_StEtermSvrResult*)(phead+1);
        memcpy(pres, paddinfo, sizeof(_StEtermSvrResult));
        free(paddinfo);
        memcpy(pres+1, str.c_str(), str.length()+1);
        m_pdb->PostQueueResult(DB_TYPE_ETERMRESULT, 0, buf, phead->uLen, (void*)(long)fd);
    }
}

void EtermSvrLoop::SendStrToClient( int fd, int zhijianid, const std::string& str )
{
    if (_is_end())
        return;
    if (m_pdb != NULL) {
        char buf[4096] = {0};
        unsigned int ulen = sizeof(buf);
        PerDealCmd::FormatEtermRes(str.c_str(), zhijianid, buf, &ulen);
        SendDataToClient(fd, buf, ulen); //m_pdb->PostQueueResult(DB_TYPE_ETERMRESULT, 0, buf, ulen, (void*)(long)fd);
    }
}

void EtermSvrLoop::OnMainSvrClose( int fd )
{
    std::map<int, std::map<int, EtermClient*> >::iterator it1 = m_mapsvruser.find(fd);
    if (it1 != m_mapsvruser.end()) {
        std::map<int, EtermClient*>& maptemp = m_mapsvruser[fd];
        std::map<int, EtermClient*>::iterator it2 = maptemp.begin();
        for(; it2 != maptemp.end(); ++it2) {
            EtermSocket* psock = GetUsedSocket(it2->second);
            
            if (psock != NULL) {
                FreeUsedSocket(it2->second);
                AddIdleSock(psock->GetSystemId(), psock);
            }
            delete it2->second;
        }
        m_mapsvruser.erase(it1);
    }
}

void EtermSvrLoop::AddEtermAllowInfo(int sysid, StEtermLimitInfo* pinfo, int count) {
    if (sysid <= 0 || pinfo == NULL || count <= 0)
        return;
    std::map<int, EtermAccont*>::iterator it = m_mapetermlimit.find(sysid);
    EtermAccont* paccont = NULL;
    if (it == m_mapetermlimit.end()) {
        paccont = new EtermAccont();
        paccont->InitAccontInfo(pinfo->companyid, pinfo->sysid);
        m_mapetermlimit[sysid] = paccont;
    }
    else {
        paccont = it->second;
    }
    paccont->AddAllowInfo(pinfo, count);
}

void EtermSvrLoop::AddEtermForbidInfo(int sysid, StEtermLimitInfo* pinfo, int count) {

    if (sysid <= 0 || pinfo == NULL || count <= 0)
        return;
    std::map<int, EtermAccont*>::iterator it = m_mapetermlimit.find(sysid);
    EtermAccont* paccont = NULL;
    if (it == m_mapetermlimit.end()) {
        paccont = new EtermAccont();
        m_mapetermlimit[sysid] = paccont;
    }
    else {
        paccont = it->second;
    }
    paccont->AddForbidInfo(pinfo, count);
}

void EtermSvrLoop::AssignEtermCmd(StEtermRequest* pcmd) {
    if (pcmd == NULL)
        return;

    std::string strret = "FORMAT";                                         

    if (pcmd->requesttype == en_Eterm_Request_Cmd) {
        MSGOUT(en_Msg_Debug, "EtermSvrLoop deal Cmd, zhijianid: %d, comid: %d, cmd: %s, cmdhead: %s", pcmd->zhijianid, pcmd->companyid, pcmd->cmd.strcmd, pcmd->cmd.cmdhead);
        if (strcmp(pcmd->cmd.cmdhead, "SS") == 0) {
            std::vector<std::string> vecline;
            PerDealCmd::GetLineFromeCmd(pcmd->cmd.strcmd, vecline);
            StSSSeatInfo info = {{0}};
            std::vector<int> vecres;
            std::vector<int> vectemp;
            if (PerDealCmd::GetSSSeatInfo(vecline.at(0).c_str(), &info)) {
                std::map<int, EtermAccont*>::iterator it = m_mapetermlimit.begin();
                for (; it != m_mapetermlimit.end(); it++) {
                    if (it->second->GetCompanyID() == pcmd->companyid) {
                        int ret = it->second->TestSSCmdInfo(&info);
                        if (ret == 1) {
                            vecres.push_back(it->first);
                        }
                        else if (ret == 0) {
                            vectemp.push_back(it->first);
                        }
                    }
                }
                MSGOUT(en_Msg_Debug, "limite size: %d, allow size: %d, normal size: %d", m_mapetermlimit.size(), vecres.size(), vectemp.size());
                if (vecres.empty()) {
                    if (!vectemp.empty()) {
                        AddCmdToQueue(pcmd, &vectemp[0], vectemp.size());
                        return ;
                    }
//                     else {
//                         strret = "NO PID";
//                     }
                }
                else {
                    AddCmdToQueue(pcmd, &vecres[0], vecres.size());
                    return;
                }
            }
        }
        else if (strcmp(pcmd->cmd.cmdhead, "RRT") == 0) {
            std::string strcode = "";
            if (PerDealCmd::GetCompanyBigCode(pcmd->cmd.strcmd, strcode)) {
                std::map<std::string, int>::iterator it = m_mapCode.find(strcode);
                if (it == m_mapCode.end() || it->second <= 0) {
                    strret = "NO PNR";
                    return ;
                }
                else {
                    AddCmdToQueue(pcmd, &(it->second), 1);
                    return;
                }
            }
        }
        /*
        else if (strcmp(pcmd->cmd.cmdhead, "RT") == 0) {
            std::string strPNR = "";
            if(PerDealCmd::GetPNRStringFromCmd(pcmd->cmd.strcmd, strPNR)) {
                std::map<std::string, int>::iterator it = m_mapPNR.find(strPNR);
                if (it == m_mapPNR.end() || it->second <= 0) {
                    strret = "NO PNR";
                }
                else {
                    AddCmdToQueue(pcmd, &(it->second), 1);
                    return;
                }
            }
        }
        */
        
        std::vector<int> vecres;

        std::map<int, StEtermSockAddInfo*>::iterator it = m_tosock.begin();
        for (; it != m_tosock.end(); it++) {
            if (it->second->companyid == pcmd->companyid) {
                vecres.push_back(it->first);
                MSGOUT(en_Msg_Debug, "res Push, info comid: %d, sysid: %d", it->second->companyid, it->first);
            }
        } 
        if (vecres.empty()) {
            strret = "NO PID";
        }
        else {
            AddCmdToQueue(pcmd, &vecres[0], vecres.size());
            return;
        }
        
    }
    else if (pcmd->requesttype == en_Eterm_Request_Web || pcmd->requesttype == en_Eterm_Request_3InOne) {
        std::vector<int> vecres;

        std::map<int, StEtermSockAddInfo*>::iterator it = m_tosock.begin();
        for (; it != m_tosock.end(); it++) {
            if (it->second->companyid == pcmd->companyid) {
                vecres.push_back(it->first);
                MSGOUT(en_Msg_Debug, "res Push, info comid: %d, sysid: %d", it->second->companyid, it->first);
            }
        } 
        if (vecres.empty()) {
            strret = "NO PID";
        }
        else {
            AddCmdToQueue(pcmd, &vecres[0], vecres.size());
            return;
        }
    }

    if (pcmd->connectype == en_Eterm_CType_Client) {
        SendStrToClient(pcmd->connectfd, pcmd->zhijianid, strret);
    }
    else if (pcmd->connectype == en_Eterm_CType_Server) {
        SendStrToMainSvr(pcmd->connectfd, pcmd->zhijianid, strret, pcmd->paddinfo);
    }
}

void EtermSvrLoop::AddPNRInfo(int sysid, const char* pPNR) {
    if(pPNR == NULL || strlen(pPNR) != 6 || sysid <= 0)
        return;
    m_mapPNR[pPNR] = sysid;
}

void EtermSvrLoop::DBEtermLoginRet(void* pdata, unsigned int ulen, void* pclient) {

    StEtermLoginRet* pret = (StEtermLoginRet*)pdata;
    int fd = (int)(long)pclient;

    MSGOUT(en_Msg_Debug, "loginret res: fd: %d, name: %s, zhijianid: %d, companyid: %d", fd, pret->zhijianname, pret->zhijianid, pret->companyid);

    if (pret->loginret != 1) {
        SendMsgboxToClient(fd, "Username or Password error!!!");
        CloseClientConnect(fd);
    }
    else {

        int tfd = CheckClientUserExist(pret->zhijianid);

        if (tfd != 0) {
            StEtermLoginReTry* pinfo = NULL;
            std::map<int, StEtermLoginReTry*>::iterator it = m_mtrycount.find(pret->zhijianid);
            if (it == m_mtrycount.end()) {
                pinfo = (StEtermLoginReTry*)malloc(sizeof(StEtermLoginReTry));
                memset(pinfo, 0, sizeof(StEtermLoginReTry));
                pinfo->lasttrytime = time(NULL);
                pinfo->trycount = 1;
                m_mtrycount[pret->zhijianid] = pinfo;
                if (m_mtrycount.size() <= 1) {
                    SetEtermTimer(ETERM_TIMER_CLEARRETRYSTATUS, ETERM_TIME_CLEARRETRYSTATUS);
                }
            }
            else {
                pinfo = it->second;
                pinfo->trycount++;
                pinfo->lasttrytime = time(NULL);
            }

            if (pinfo->trycount >= 3) {
                SendMsgboxToClient(tfd, "Disconnect By Other User!!!");
                CloseClientConnect(tfd);
                free(m_mtrycount[pret->zhijianid]);
                m_mtrycount.erase(pret->zhijianid);
                if (m_mtrycount.size() == 0)
                {
                    EtermKillTimer(ETERM_TIMER_CLEARRETRYSTATUS);
                }
            }
            else {
                SendMsgboxToClient(fd, "Account is being used by others!!!");
                CloseClientConnect(fd);
                return ;
            }
        }

        char buf[25] = {0};
       // buf[1] = 0x14;
        buf[1] = 0x19;
        buf[2] = 0x01;
        buf[4] = 0x03;
        *((unsigned short*)(buf+8)) = pret->zhijianid;
        buf[10] = 0x0c;
        buf[13] = 0x8c;
        buf[14] = 0x8c;
        buf[15] = 0x29;
        buf[18] = 0xa9;
        buf[19] = 0xa9;
        buf[20] = 0x20;
        buf[23] = 0xa0;
        buf[24] = 0xa0;

        AddEtermUser(en_Eterm_CType_Client, fd, pret);
        SendDataToClient(fd, buf, sizeof(buf));
    }
}

void EtermSvrLoop::SendMsgboxToClient(int fd, const char* pstr) {

    if (pstr == NULL || strlen(pstr) <= 0) {
        return ;
    }

    char buf[4096] = {0x01, (char)0xF8};
    unsigned int len = strlen(pstr) + 4;
    strcpy(buf+4, pstr);
    buf[2] = len/256;
    buf[3] = len%256;

    m_pdb->PostQueueResult(DB_TYPE_ETERMRESULT, 0, buf, len, (void*)(long)fd);
}

void EtermSvrLoop::CloseClientConnect(int fd) {
    m_pdb->PostQueueResult(DB_TYPE_CLOSECONNECT, 0, NULL, 0, (void*)(long)fd);
}

void EtermSvrLoop::AddCmdToQueue( StEtermRequest* pcmd, int* arreterm, unsigned int arrsize )
{
    if(arreterm == NULL || pcmd == NULL || arrsize <= 0)
        return;
    m_queuecmd.PushEtermCmd(pcmd, arreterm, arrsize);
    PostFlushSendCmdRequest();    
}

EtermSocket* EtermSvrLoop::GetIdleSocket( int sysid )
{
    EtermSocket* psock = NULL;
    std::map<int, EtermSocket*>::iterator it = m_residle.find(sysid);
    if (it != m_residle.end()) {
        psock = it->second;
        m_residle.erase(it);
    }
    return psock;
}

void EtermSvrLoop::GetXTYAccount()
{
    PostEtermReuqest(DB_ETERM_XTYACCONTINFO, NULL, 0, NULL);
}

void EtermSvrLoop::PostEtermResult( int assistcmd, void* pdata, unsigned int ulen, void* pclient )
{
    if (m_pdb != NULL) {
        m_pdb->PostQueueResult(DB_TYPE_ETERMLOOP, assistcmd, pdata, ulen, pclient);
    }
}

int EtermSvrLoop::CheckClientUserExist( int zhijianid )                                                                                 
{
    int fd = 0;
    std::map<int, EtermClient*>::iterator it1 = m_mapclientuser.begin();
    for(; it1 != m_mapclientuser.end(); it1++) {
        if (it1->second->GetZhijianID() == zhijianid) {
            fd = it1->first;
            break;
        }
    }

    if (fd != 0) {
        return fd;
    }

    /*
    // map<fd, map<zhijianid, > >
    pthread_mutex_lock(&m_musvruser);
    std::map<int, std::map<int, EtermClient*> >::iterator it2 = m_mapsvruser.begin();
    for (; it2 != m_mapsvruser.end(), it2++) {
    if (it2->second.find(zhijianid) != it2->second.end())
    {
    fd = it2->first;
    break;
    }
    }
    pthread_mutex_unlock(&m_musvruser);
    */

    return fd;
}

bool EtermSvrLoop::DealEtermWebRequest( int connectfd, const char* pdata, unsigned int ulen ) {
    
    if (pdata == NULL || ulen <= 0) {
        return false;
    }
    if (ulen > 4096) {
        MSGOUT(en_Msg_Normal, "web data too long, length: %u", ulen);
        return false;
    }

    StEtermRequest req = {0};

    EtermClient* pclient = NULL;
    req.connectype = en_Eterm_CType_Client;
    req.connectfd = connectfd;
    req.requesttype = en_Eterm_Request_Web;
    req.breaktype = en_Cmd_Brk_Not;

    std::map<int, EtermClient*>::iterator it = m_mapclientuser.find(connectfd);
    if (it == m_mapclientuser.end() || it->second == NULL) {
        MSGOUT(en_Msg_Debug, "user didn't exist!!! fd: %d", connectfd);
        return false;
    }
    pclient = it->second;
    req.companyid = pclient->GetCompanyID();
    req.zhijianid = pclient->GetZhijianID(); 
    req.pclient = pclient;

    memcpy(req.web.data, pdata, ulen);
    req.web.ulen = ulen;

    EtermSocket* psock = GetUsedSocket(pclient);
    if (psock == NULL) {      
        PushCmdToDB(&req);
    }
    else {
        psock->SendCmd(&req);	
    }
    
    return true;
}

bool EtermSvrLoop::DealClientEtermString( int connectfd, const char* pstrcmd, int line )
{
    std::string strout = "", strret = "";

    EtermClient* pclient = NULL;
    StEtermRequest cmd = {0};
    cmd.connectype = en_Eterm_CType_Client;
    cmd.connectfd = connectfd;
    cmd.requesttype = en_Eterm_Request_Cmd;
    cmd.cmd.curline = line;
    
    std::string strhead = "";

    PerDealCmd::_trimcharstring(cmd.cmd.strcmd);
    PerDealCmd::ToUpperStrPtr(cmd.cmd.strcmd);

    std::map<int, EtermClient*>::iterator it = m_mapclientuser.find(connectfd);
    if (it == m_mapclientuser.end() || it->second == NULL) {
        MSGOUT(en_Msg_Debug, "user didn't exist!!! fd: %d", connectfd);
        return false;
    }
    pclient = it->second;

    if(!pclient->DealCmd(pstrcmd, strout, strhead, strret, cmd.breaktype)) {
        // cmd error ...
        if (strret == "")
            strret = "**Format (0)**";
    }
    strcpy(cmd.cmd.strcmd, strout.c_str());

    cmd.companyid = pclient->GetCompanyID();
    cmd.zhijianid = pclient->GetZhijianID();
    strcpy(cmd.cmd.cmdhead, strhead.c_str()); 
    cmd.pclient = pclient;

    MSGOUT(en_Msg_Debug, "ready push cmd to db, id: %d, cmd: %s", cmd.zhijianid, cmd.cmd.strcmd);

    if (strret.length() > 0) {
        SendStrToClient(cmd.connectfd, cmd.zhijianid, strret);
    }
    else {
        EtermSocket* psock = GetUsedSocket(pclient);
        if (psock == NULL) {    
            PushCmdToDB(&cmd);
        }
        else {
            psock->SendCmd(&cmd);	
        }
    }
    return true;
}

bool EtermSvrLoop::DealServerEtermString( int connectfd, int zhijianid, const char* pstrcmd, void* paddinfo )
{
    std::string strout = "", strret = "";

    EtermClient* pclient = NULL;
    StEtermRequest cmd = {0};
    cmd.connectype = en_Eterm_CType_Server;
    cmd.connectfd = connectfd;
    cmd.requesttype = en_Eterm_Request_Cmd;
    cmd.cmd.curline = 0x20;
    cmd.paddinfo = paddinfo;
    strcpy(cmd.cmd.strcmd, pstrcmd);
    std::string strhead = "";

    PerDealCmd::_trimcharstring(cmd.cmd.strcmd);
    PerDealCmd::ToUpperStrPtr(cmd.cmd.strcmd);

    std::map<int, std::map<int, EtermClient*> >::iterator it1 = m_mapsvruser.find(connectfd);
    if (it1 == m_mapsvruser.end()) {
        return false;
    }
    std::map<int, EtermClient*>::iterator it2 = it1->second.find(zhijianid);
    if (it2 == it1->second.end() || it2->second == NULL) {
        return false;
    }
    pclient = it2->second;
    if(!pclient->DealCmd(pstrcmd, strout, strhead, strret, cmd.breaktype)) {
        // cmd error ...
        if (strret == "")
            strret = "**Format (0)**";
    }
    cmd.companyid = pclient->GetCompanyID();
    cmd.zhijianid = pclient->GetZhijianID();
    strcpy(cmd.cmd.cmdhead, strhead.c_str());
    cmd.pclient = pclient;

    if (strret.length() > 0) {
        SendStrToMainSvr(cmd.connectfd, cmd.zhijianid, strret, cmd.paddinfo);
    }
    else {
        EtermSocket* psock = GetUsedSocket(pclient);
        if (psock == NULL) {
            PushCmdToDB(&cmd);
        }
        else {
            psock->SendCmd(&cmd);	
        }
    }
    return true;
}

void EtermSvrLoop::ReleaseAllLimitInfo()
{
    std::map<int, EtermAccont*>::iterator it = m_mapetermlimit.begin();
    for (; it != m_mapetermlimit.end(); ) {
        it->second->ClearInfo();
        delete it->second;
        m_mapetermlimit.erase(it++);
    }
}

void EtermSvrLoop::SaveAllUserInfo()
{
    // map<fd, >
//     std::map<int, EtermClient*>	    m_mapclientuser;
// 
//     // map<fd, map<zhijianid, > >
//     std::map<int, std::map<int, EtermClient*> >     m_mapsvruser;
//     std::map<int, EtermClient*>::iterator it1 = m_mapclientuser.begin();
//     for ()
//     {
//     }
    
}

bool EtermSvrLoop::DealEterm3InOneRequest( int connectfd, const char* pdata, unsigned int ulen )
{
    if (pdata == NULL || ulen <= 0) {
        return false;
    }
    if (ulen > 4096) {
        MSGOUT(en_Msg_Normal, "3 in one too long, length: %u", ulen);
        return false;
    }

    StEtermRequest req = {0};

    EtermClient* pclient = NULL;
    req.connectype = en_Eterm_CType_Client;
    req.connectfd = connectfd;
    req.requesttype = en_Eterm_Request_3InOne;
    req.breaktype = en_Cmd_Brk_Not;

    std::map<int, EtermClient*>::iterator it = m_mapclientuser.find(connectfd);
    if (it == m_mapclientuser.end() || it->second == NULL) {
        MSGOUT(en_Msg_Debug, "user didn't exist!!! fd: %d", connectfd);
        return false;
    }
    pclient = it->second;
    req.companyid = pclient->GetCompanyID();
    req.zhijianid = pclient->GetZhijianID(); 
    req.pclient = pclient;

    memcpy(req.web.data, pdata, ulen);
    req.web.ulen = ulen;

    EtermSocket* psock = GetUsedSocket(pclient);
    if (psock == NULL) {     
        PushCmdToDB(&req);
    }
    else {
        psock->SendCmd(&req);	
    }

    return true;
}

void EtermSvrLoop::SetSystemMsg( const char* pstr )
{
    unsigned int ulen = sizeof(m_systemmsg);
    if (strlen(pstr) < ulen) {
        strcpy(m_systemmsg, pstr);
    }
    else {
        memcpy(m_systemmsg, pstr, ulen-1);
        m_systemmsg[ulen-1] = '\0';
    }
}

void EtermSvrLoop::SetMsgboxMsg( const char* pstr )
{
    unsigned int ulen = sizeof(m_msgboxmsg);
    if (strlen(pstr) < ulen) {
        strcpy(m_msgboxmsg, pstr);
    }
    else {
        memcpy(m_msgboxmsg, pstr, ulen-1);
        m_msgboxmsg[ulen-1] = '\0';
    }
}

void EtermSvrLoop::FlushSendCmdQueue()
{
    StEtermCmdTask* ptask = m_queuecmd.GetHeadItem();

    while(ptask != NULL) {
        bool bdeal = false;
        for (int i = 0; i < ptask->arrsize; i++) {
            EtermSocket* psock = GetIdleSocket(ptask->petermarr[i]);
            if (psock != NULL) {
                psock->SendCmd(&ptask->request);
                AddSockToBusy(ptask->request.pclient, psock, false);
                bdeal = true;
                break;
            }
        }
        StEtermCmdTask* pcurtask = ptask;
        ptask = m_queuecmd.GetNextItem(ptask);
        if (bdeal) {
            m_queuecmd.PopCurItem(pcurtask);
        }
    }
}

void EtermSvrLoop::PostFlushSendCmdRequest()
{
    if (m_bflushsendcmd)
        return;

    m_bflushsendcmd = true;

    PostEtermReuqest(DB_ETERM_FLUSHSENDCMD, NULL, 0, NULL);
}

EtermSocket* EtermSvrLoop::GetUsedSocket( EtermClient* pclient )
{
    std::map<EtermClient*, EtermSocket*>::iterator it = m_restemp.find(pclient);
    if (it != m_restemp.end()) {
        return it->second;
    }
    it = m_resbusy.find(pclient);
    if (it != m_resbusy.end()) {
        return it->second;
    }
    return NULL;
}

void EtermSvrLoop::FreeUsedSocket( EtermClient* pclient )
{
    std::map<EtermClient*, EtermSocket*>::iterator it = m_resbusy.find(pclient);
    if (it != m_resbusy.end()) {
        m_resbusy.erase(it);
        return;
    }
    it = m_restemp.find(pclient);
    if (it != m_restemp.end()) {
        m_restemp.erase(it);
        return;
    }
}

void EtermSvrLoop::SiPID()
{
    std::map<EtermClient*, EtermSocket*>::iterator it = m_resbusy.begin();
    for (; it != m_resbusy.end(); it++) {
        it->second->SendSICmd();
        it->second->RefreshLogFileName();
    }
    it = m_restemp.begin();
    for (; it != m_restemp.end(); it++) {
        it->second->SendSICmd();
        it->second->RefreshLogFileName();
    }
    std::map<int, EtermSocket*>::iterator it1 = m_residle.begin();
    for (; it1 != m_residle.end(); it1++) {
        it1->second->SendSICmd();
        it1->second->RefreshLogFileName();
    }  
}
