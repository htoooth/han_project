/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-07-13 16:46:12
# LastModified : 2015-01-21 15:55:56
# FileName     : perdealcmd.cpp
# Description  : 
 ******************************************************************************/
#include <algorithm>
#include <string.h>
#include <iconv.h>

#include "perdealcmd.h"
#include "showmsg.h"
#include "etermstring.h"

std::map<std::string, StCmdInfo*> PerDealCmd::s_mapinfo;
std::map<std::string, unsigned short> PerDealCmd::s_mapzh;
std::map<unsigned short, std::string> PerDealCmd::s_mapnum;

static const char* s_month[] = {"JAN","FEB","MAR","APR","MAY","JUN",
	            "JUL","AUG","SEP","OCT","NOV","DEC"};

//static const char* s_week[] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};

bool PerDealCmd::InitConfig(StCmdInfo* pinfo, int count) {
	if (pinfo == NULL || count <= 0)
		return false;

	for (int i = 0; i < count; i++) {
		StCmdInfo* p = (StCmdInfo*)malloc(sizeof(StCmdInfo));
		memset(p, 0, sizeof(StCmdInfo));
		memcpy(p, pinfo+i, sizeof(StCmdInfo));
		std::string strcmd = p->cmd;
		std::map<std::string, StCmdInfo*>::iterator it = s_mapinfo.find(strcmd);
		if (it != s_mapinfo.end()) {
			free((*it).second);
			s_mapinfo.erase(it);
		}
		s_mapinfo[strcmd] = p;
	}
	return true;
}

bool PerDealCmd::JudgeCmdType(std::string strcmd, StCmdInfo* pinfo) {
    
    _trimstdstring(strcmd);
    // std::string::size_type pos = strcmd.find_first_not_of("QWERTYUIOPASDFGHJKLZXCVBNM");
    // strcmd = strcmd.substr(0, pos);

    // if (strcmd.length() > 4)
    //     return false;

    // strcpy(pinfo->cmd, strcmd.c_str());
    // pinfo->breaktype = en_Cmd_Brk_Can;
    
    // return true;


//	std::transform(strcmd.begin(), strcmd.end(), strcmd.begin(), toupper);

    int n = (strcmd.length() > 4) ? 4 : strcmd.length();
    for ( ; n > 0; n--) {
        std::map<std::string, StCmdInfo*>::iterator it = s_mapinfo.find(strcmd.substr(0, n));           
        if (it != s_mapinfo.end()) {
            if (it->second != NULL) {
                memcpy(pinfo, it->second, sizeof(StCmdInfo));
                break;
            }
        }
    }
    if (n <= 0) {
        return false;
    }
    return true;
}

void PerDealCmd::ReleaseRes() {
	std::map<std::string, StCmdInfo*>::iterator it = s_mapinfo.begin();
	for ( ; it != s_mapinfo.end(); it++) {
		free((*it).second);
	}
	s_mapinfo.clear();
}

int PerDealCmd::GetCmdFromData(void* pdata, unsigned int ulen, std::string& strout, int& line)
{
    if (ulen < 21 || pdata == NULL) {
		return false;
	}
	char* pd = (char*)pdata;
	unsigned len = ((unsigned char)pd[2])*256 + (unsigned char)pd[3];
	if (len != ulen) {
		MSGOUT(en_Msg_Error, "len error");
		return false;
	}

	const char d1[2] = {0x01, 0x00}; // head 0
	const char d2[4] = {0x00, 0x00, 0x00, 0x01}; // head 4
	const char d3[4] = {0x70, 0x02, 0x1b, 0x0b}; // head 10
	const char d4[1] = {0x03}; // tail 1

	if (memcmp(d1, pd, sizeof(d1)) == 0
			&& memcmp(d2, pd+4, sizeof(d2)) == 0
			&& memcmp(d3, pd+10, sizeof(d3)) == 0
			&& memcmp(d4, pd+ulen-1, sizeof(d4)) == 0
		)
	{
        int offset = 16;
        while(!isprint(pd[offset])) {
            offset++;
        }
        strout = "";
        strout.append(pd+offset, ulen-offset-1);
        line = pd[14];

        return 1;
	}

    const char d5[2] = {0x01, 0x00}; // head 0
    const char d6[4] = {0x29, 0x00, 0x00, 0x01}; // head 4
    const char d7[4] = {(char)0xaa, 0x2a, 0x00, 0x02}; // head 10
    const char d8[1] = {0x03}; // tail 1
    if (memcmp(d5, pd, sizeof(d5)) == 0
        && memcmp(d6, pd+4, sizeof(d6)) == 0
        && memcmp(d7, pd+8, sizeof(d7)) == 0
        && memcmp(d8, pd+ulen-1, sizeof(d8)) == 0
        )
    {
        int offset = 16;
        while(!isprint(pd[offset])) {
            offset++;
        }
        strout = "";
        strout.append(pd+offset, ulen-offset-1);
        line = pd[14];

        return 2;
    }

    const char d9[2] = {0x01, 0x00};
    const char d10[8] = {0x0C, 0x00, 0x00, 0x01, 0x8C, 0x0C, 0x00, 0x02};
    if (memcmp(d9, pd, sizeof(d9)) == 0
        && memcmp(d10, pd+4, sizeof(d10)) == 0
        )
    {
        int offset = 12;
        while(!isprint(pd[offset])) {
            offset++;
        }
        strout = "";
        strout.append(pd+offset, ulen-offset-1);

        return 3;
    }

    MSGOUT(en_Msg_Debug, "data head error");
    FILE* pf = fopen("recvclient.err", "a");
    if (pf != NULL) {
        int nsiz = ulen*3+1;
        char* pbuff = (char*)malloc(nsiz);
        memset(pbuff, 0, nsiz);
        for (unsigned int i = 0; i < ulen; i++) {
            sprintf(pbuff+i*3, "%02X ", (unsigned char)pd[i]);
        }
        pbuff[nsiz-1] = '\n';
        fwrite(pbuff, sizeof(char), nsiz, pf);
        fclose(pf);
    }
    return -1;
}

bool PerDealCmd::OffsetEtermData(const std::string& strdata, int offsetday, std::string& strout) {

	const char* pnum = "0123456789";
	const char* pword = "QWERTYUIOPLKJHGFDSAZXCVBNM";
	if (isdigit(strdata.c_str()[0]) == 0)
		return false;

	std::string::size_type pos = strdata.find_first_not_of(pnum);
	if (pos == std::string::npos)
		return false;

	int day = atoi(strdata.substr(0, pos).c_str());
	if (day <= 0 || day > 31)
		return false;

	std::string::size_type postemp = strdata.find_first_not_of(pword, pos);
	std::string strmonth = strdata.substr(pos, postemp - pos);
	if (strmonth.length() != 3)
		return false;

	int month = 0;
	for (int i = 0; i < 13; i++) {
		if (i == 12)
			return false;
		if (strmonth == s_month[i]) {
			month = i;
			break;
		}
	}

	int year = 0;

	if(postemp == std::string::npos) {
		GetLocalTimeInfo(&year);
		year -= 2000;
	}
	else {
		pos = strdata.find_first_not_of(pnum, postemp);
		if (pos != std::string::npos)
			return false;
		year = atoi(strdata.substr(postemp, -1).c_str());
	}

	struct tm stm; // = {0};
	memset(&stm, 0, sizeof(stm));
	stm.tm_year = 100 + year;
	stm.tm_mon = month;
	stm.tm_mday = day;
	time_t ttemp = mktime(&stm);

	ttemp += offsetday * 24*60*60;

	struct tm* ptm = localtime(&ttemp);
	if (ptm == NULL)
		return false;

	char buf[32] = {0};
	sprintf(buf, "%02d%s%02d", ptm->tm_mday, s_month[ptm->tm_mon], ptm->tm_year - 100);
//	sprintf(buf, "%02d%s%02d %02d:%02d", 
//			ptm->tm_mday, s_month[ptm->tm_mon], ptm->tm_year - 10, ptm->tm_hour, ptm->tm_min);
	strout = buf;

	return true;
}

bool PerDealCmd::OffsetEtermTime(const std::string& strtime, int addmin, std::string& strout, bool &btow) {
	const char* pnum = "0123456789";

	if (strtime.length() != 4 || strtime.find_first_not_of(pnum) != std::string::npos) {
		return false;
	}

	btow = false;

	int hour = atoi(strtime.substr(0, 2).c_str());
	if (hour > 23)
		return false;

	int min = atoi(strtime.substr(2, 2).c_str());
	if (hour > 59)
		return false;

	min += addmin;
	if (min > 59) {
		hour++;
		min -= 60;
	}

	if (hour > 23) {
		btow = true;
		hour -= 24;
	}
	char buf[16] = {0};
	sprintf(buf, "%02d%02d", hour, min);
	strout = buf;

	return true;
}

void PerDealCmd::GetLocalTimeInfo(int* year, int* month, int* day, int* hour, int* minute, int* second) {
	time_t t = time(NULL);
	struct tm* ptm = localtime(&t);
	if (year != NULL) {
		*year = ptm->tm_year + 1900;
	}
	if (month != NULL) {
		*month = ptm->tm_mon;
	}
	if (day != NULL) {
		*day = ptm->tm_mday;
	}
	if (hour != NULL) {
		*hour = ptm->tm_hour;
	}
	if (minute != NULL) {
		*minute = ptm->tm_min;
	}
    if (second != NULL) {
        *second = ptm->tm_sec;
    }
}

// av str
bool PerDealCmd::GetAvhCmdInfo(const std::string& strcmd, StAvCmdInfo& info) {

	std::vector<std::string> vestr;
	SpliteCmd(strcmd, vestr);
	int errcode = 0;
	if (vestr.size() < 2) {
		MSGOUT(en_Msg_Debug, "error : %d", errcode++);
		return false;
	}
	for (unsigned int i = 0; i < vestr.size(); i++) {
		MSGOUT(en_Msg_Debug, "%s", vestr[i].c_str());
	}
	memset(&info, 0, sizeof(info));
	std::string avstr = "";

	int offday = 0;
	
	const char* pnum = "9876543210";
//	const char* pvalue = "0123456789QWERTYUIOPLKJHGFDSAZXCVBNM";

	int idx = 0;
	for (size_t i = 0; i < vestr.size(); i++) {
		MSGOUT(en_Msg_Debug, "i : %d, idx : %d, str : %s", i, idx, vestr[i].c_str());

		if (idx == 0) {
			if (vestr[i].length() == 3) {
				avstr = vestr[i];
			}
			else if (vestr[i].length() == 2 && vestr[i+1].length() == 1) {
				avstr = vestr[i] + vestr[i+1];
				i++;
			}
			else if (vestr[i].length() == 2) {
				avstr = vestr[i];
			}
			else {
				return false;
			}
			idx++;
		}
		else if (idx == 1) {
			if (vestr[i].length() > 7) {
				return false;
			}

			std::string::size_type pos = vestr[i].find_first_of(pnum);
			if (pos != std::string::npos) {

				if (!IsFlightNum(vestr[i].c_str())) {
					return false;
				}
				info.type = en_Avh_Type_Flight;

				strcpy(info.flight.avstr, avstr.c_str());

				strcpy(info.flight.flight, vestr[i].c_str());
			}
			else if (vestr[i] == "RA") {
				info.type = en_Avh_Type_ReturnA;
			}
			else {
				if (vestr[i].length() == 6) {
				
				}
				else if (vestr[i].length() == 1) {
					avstr += vestr[i];
					continue;
				}
				else if (vestr[i].length() == 7) {
					if(vestr[i].c_str()[6] == '+') {
						offday = 1;
					}	
					else if(vestr[i].c_str()[6] == '-') {
						offday = -1;
					}
					else {
						return false;
					}
				}
				else {
					return false;
				}
				info.type = en_Avh_Type_Qurey;
				strcpy(info.qurey.avstr, avstr.c_str());

				strncpy(info.qurey.citystart, vestr[i].c_str(), 3);
				strncpy(info.qurey.cityend, vestr[i].c_str()+3, 3);
			}
			idx++;
		}
		else if (idx == 2) {
			std::string str = "";
			bool bdata = OffsetEtermData(vestr[i], offday, str);
			if (info.type == en_Avh_Type_Flight && bdata) {
				strcpy(info.flight.strdate, str.c_str());
			}
			else if (info.type == en_Avh_Type_Qurey 
					|| info.type == en_Avh_Type_ReturnA) {
				if (bdata) {
					strcpy(info.qurey.strdate, str.c_str());
				}
				else {
					i--;
				}
			}
			else if (IsNumStr(str.c_str())) {
				i--;
				idx++;
				continue;
			}
			else {
				return false;
			}
			idx++;
		}
		else if (idx == 3) {
			if (vestr[i].find_first_not_of(pnum) != std::string::npos) {
				i--;
				idx++;
				continue;
			}
			if (info.type == en_Avh_Type_Flight) {
				strncpy(info.flight.offset, vestr[i].c_str(), 3);
			}
			else if (info.type == en_Avh_Type_Qurey
					|| info.type == en_Avh_Type_ReturnA) {
				if (vestr[i].length() != 4)
					return false;
				strcpy(info.qurey.strtime, vestr[i].c_str());
			}
			idx++;
		}
		else if (idx == 4) {
			if (info.type != en_Avh_Type_Qurey
				&& info.type != en_Avh_Type_ReturnA) {
				return false;
			}
			if (vestr[i].length() != 2) {
				i--;
				idx++;
				continue;
			}
			strcpy(info.qurey.strcom, vestr[i].c_str());
			idx++;
		}
		else if (idx == 5) {
			if (vestr[i].length() != 1) {
				return false;
			}
			strcpy(info.qurey.strlimit, vestr[i].c_str());
			idx++;
		}
		else {
			return false;
		}
	}
	if (info.qurey.strdate[0] == '\0' 
			&& (info.type == en_Avh_Type_Qurey || info.type == en_Avh_Type_ReturnA)) {
		int year = 0, month = 0, day = 0;
		GetLocalTimeInfo(&year, &month, &day);
		char buf[16] = {0};
		sprintf(buf, "%d%s%d", day, s_month[month], year%100);
		std::string str;
		OffsetEtermData(buf, offday, str);
		strcpy(info.qurey.strdate, str.c_str());
	}
	return true;
}

void PerDealCmd::SpliteCmd(const std::string& strcmd, std::vector<std::string>& veout, const char* pkey/* = "/: "*/) {
	veout.clear();
	std::string::size_type head = 0, tail = 0;
	while(head != std::string::npos) {
		tail = strcmd.find_first_of(pkey, head);
		std::string str = strcmd.substr(head, tail-head);
		if (str.length() != 0)
			veout.push_back(str);
		if (tail == std::string::npos) {
			break;
		}
		head = tail+1;
	}
}

// info.type == en_Avh_Type_Qurey or en_Avh_Type_Flight
bool PerDealCmd::DealAvhCmdByRes(const std::string& strcmd, const StAvCmdInfo& info, const std::string& strres, StAvCmdInfo& out) {

	std::string scmd(strcmd);
	_trimstdstring(scmd);

	if (info.type == en_Avh_Type_Qurey) {
		if (scmd == "PN") {
            const char* pstr = strres.c_str();
            char dep[4] = {0}, des[4] = {0};
            int offset = 0;
            if (CETermString::_avhgetdepdes(pstr, dep, des)) {
                char buf[4096] = {0};
                offset = CETermString::_getOneLine(pstr, buf, sizeof(buf));
            }
            else
            {
                return false;
            }
            if(strcmp(info.qurey.avstr, "AVH") == 0) {
                avhtravelInfo** pinfo = NULL;
                int pagetype = en_page_single;

                int res = CETermString::DealAVHStr(pstr, &pinfo, NULL, NULL, &pagetype);
                if (res <= 0)
                    return false;


                std::string strtime =  pinfo[res-1]->pinfo[0].timestart;
                std::string strout = "";
                bool btom = false;
                if (!OffsetEtermTime(strtime, 25, strout, btom)) {

                    return false;
                }

                memcpy(&out, &info, sizeof(info));
                strcpy(out.qurey.strtime, strout.c_str());

                CETermString::FreeAVHRes(pinfo, res);

                return true;
            }
            else {
                avtravelInfo** pinfo = NULL;
                int pagetype = en_page_single;

                int res = CETermString::DealAVStr(pstr+offset, &pinfo, NULL, NULL, &pagetype);
                if (res <= 0)
                    return false;

                std::string strtime = pinfo[res-1]->pinfo[0].timestart;
                std::string strout = "";
                bool btom = false;
                MSGOUT(en_Msg_Debug, "%s", strtime.c_str());
                if (!OffsetEtermTime(strtime, 25, strout, btom)) {
                    return false;
                }

                memcpy(&out, &info, sizeof(info));
                strcpy(out.qurey.strtime, strout.c_str());

                CETermString::FreeAVRes(pinfo, res);
                
                return true;
            }
			return true;
		}
		else {
			StAvCmdInfo temp = {0};
			if(GetAvhCmdInfo(strcmd, temp))
			{
				if (temp.type != en_Avh_Type_ReturnA) {
					return false;
				}
				char tarea[4] = {0};
				memcpy(&out, &info, sizeof(StAvCmdInfo));
				out.type = en_Avh_Type_Qurey;
				strcpy(tarea, out.qurey.citystart);
				strcpy(out.qurey.citystart, out.qurey.cityend);
				strcpy(out.qurey.cityend, tarea);
				return true;
			}
			else {
				std::string tstr = strcmd;
				replace_all(tstr, "+", "/+");
				replace_all(tstr, "-", "/-");
				std::vector<std::string> vestr;
				SpliteCmd(tstr, vestr);

				if (vestr.size() != 2)
					return false;

				if (vestr[0].compare(0, 2, "AV") != 0)
					return false;

				const char* pstr = vestr[1].c_str();

				if (pstr[0] != '-' && pstr[0] != '+') {
					return false;
				}

				if (!IsNumStr(pstr+1)) {
					return false;
				}
				int i = atoi(pstr);

				std::string strdate;
				if (!OffsetEtermData(info.qurey.strdate, i, strdate))
					return false;

				memcpy(&out, &info, sizeof(StAvCmdInfo));
				strcpy(out.qurey.strdate, strdate.c_str());
				
				return true;
			}
		}
	}
	else if (info.type == en_Avh_Type_Flight) {
		if (scmd == "PN") {

			char fnum[8] = {0};
			char date[8] = {0};
			if (!CETermString::_getavflightinfo(strres.c_str(), fnum, date)) {
				return false;
			}
			std::string strdate;
			if (!OffsetEtermData(date, 1, strdate)) {
				return false;
			}
			out.type = en_Avh_Type_Flight;
			strcpy(out.flight.flight, fnum);
			strcpy(out.flight.strdate, strdate.c_str());
			strcpy(out.flight.offset, "6");

			return true;
		}
		else {
			return false;		
		}
	}
	else {
		return false;
	}	
}

std::string& PerDealCmd::replace_all(std::string& str, const std::string& old_value, const std::string& new_value) {     
	std::string::size_type idx = 0;
	while(true) {     
		std::string::size_type pos = 0;
		if((pos=str.find(old_value, idx)) != std::string::npos) {
			str.replace(pos,old_value.length(),new_value);
			 idx = pos + old_value.length() + 1;
		}
		else
			break;     
	}     
	return str;     
}

bool PerDealCmd::IsNumStr(const char* str) {
	for(unsigned int i = 0; i < strlen(str); i++) {
		if(isdigit(str[i]) == 0)
			return false;
	}
	return true;
}

std::string PerDealCmd::FormatAvStr(const StAvCmdInfo& info) {
	std::string strres = "";
	if(info.type == en_Avh_Type_Qurey) {
		if(strlen(info.qurey.avstr) > 0) {
			strres = info.qurey.avstr;
		}
		else {
			return "";
		}
		if(strlen(info.qurey.citystart) > 0 && strlen(info.qurey.cityend) > 0) {
			strres = strres + "/" + info.qurey.citystart + info.qurey.cityend;
		}
		else {
			return "";
		}
		if(strlen(info.qurey.strdate) > 0) {
			strres = strres + "/" + info.qurey.strdate;
		}
		if(strlen(info.qurey.strtime) > 0) {
			strres = strres + "/" + info.qurey.strtime;
		}
		if(strlen(info.qurey.strcom) > 0) {
			strres = strres + "/" + info.qurey.strcom;
		}
		if(strlen(info.qurey.strlimit) > 0) {
			strres = strres + "/" + info.qurey.strlimit;
		}
	}
	else if (info.type == en_Avh_Type_Flight) {
		if(strlen(info.flight.avstr) > 0) {
			strres = info.flight.avstr;
		}
		if(strlen(info.flight.flight) > 0) {
			strres = strres + "/" + info.flight.flight;
		}
		if(strlen(info.flight.strdate) > 0) {
			strres = strres + "/" + info.flight.strdate;
		}
		if(strlen(info.flight.offset) > 0) {
			strres = strres + "//" + info.flight.offset;
		}
	}
	return strres;
}

bool PerDealCmd::IsFlightNum(const char* pstr) {

	const char* pvalue = "0123456789QWERTYUIOPASDFGHJKLZXCVBNM";
	if (pstr == NULL || strlen(pstr) < 5) {
		return false;
	}

	std::string str = pstr;
	if (str.find_first_not_of(pvalue) != std::string::npos) {
		return false;
	}

	str = str.substr(0, 2);
	if (IsNumStr(str.c_str())) {
		return false;
	}

	if (!IsNumStr(pstr+2)) {
		return false;
	}

	return true;
}

void PerDealCmd::splitchinese(const char* pstr, unsigned int ulen, std::vector<std::string>& vecstring) {
    vecstring.clear();
    for (unsigned int i = 0; i < ulen; i++) {
        std::string strtemp = "";
        if ((unsigned char)pstr[i] < 0x80)
        {
            strtemp = pstr[i];
        }
        else
        {
            strtemp = strtemp + pstr[i] + pstr[i+1];
            i++;
        }	
        vecstring.push_back(strtemp);
    }
}

int PerDealCmd::code_convert(const char *from_charset, const char *to_charset, const char *inbuf, size_t inlen, char *outbuf, size_t outlen)
{
    iconv_t cd;
    char* pcin = (char*)malloc(inlen+1);
    memset(pcin, 0, inlen+1);
    memcpy(pcin, inbuf, inlen);

    char* ptmp = pcin;
    char **pin = &ptmp;
    char **pout = &outbuf;
    cd = iconv_open(to_charset,from_charset);
    if (cd == 0) {
        free(pcin);
        return -1;
    }
    memset(outbuf,0,outlen);
    if (iconv(cd, pin, &inlen, pout, &outlen) == (unsigned int)-1) {
        free(pcin);
        return -1;
    }
    iconv_close(cd);
    free(pcin);
    return 0;
}

void PerDealCmd::EnCodeChineseStr(const char* pin, int inlen, std::string& strres) {
    char chead[3] = {0x1B, 0x0E};
    char ctail[3] = {0x1B, 0x0F};
    strres = "";
    std::vector<std::string> vecstr;
    splitchinese(pin, inlen, vecstr);

    for (unsigned int i = 0; i < vecstr.size(); i++) {
        if (s_mapzh.find(vecstr[i]) != s_mapzh.end()) {
            strres += chead;
            while (1) {
                if (i >= vecstr.size()) {
                    strres += ctail;
                    break;
                }
                else if (s_mapzh.find(vecstr[i]) == s_mapzh.end()) {
                    strres += ctail;
                    strres += vecstr[i];
                    break;
                }
                else {
                    char buf[3] = {0};
                    buf[0] = s_mapzh[vecstr[i]]/256;
                    buf[1] = s_mapzh[vecstr[i]]%256;
                    strres += buf;
                }
                i++;
            }
        }
        else {
            strres += vecstr[i];	
        }
    }
}

bool PerDealCmd::InitGB2312() {

    FILE* pf = fopen("gb2312.txt", "r");
    while(!feof(pf)) {
        char buf[12] = {0};
        fgets(buf, sizeof(buf), pf);
        std::string str = buf;
        std::string::size_type pos = str.find(",");
        if (pos == std::string::npos)
            continue;

        std::string strzh = str.substr(0, pos);
        std::string strnum = str.substr(pos+1, str.length()-2-pos);
        s_mapzh[strzh] = atoi(strnum.c_str());
		s_mapnum[atoi(strnum.c_str())] = strzh;
    }
    fclose(pf);
    return true;
}

bool PerDealCmd::FormatEtermRes( const char* pstr, int id, char* pout, unsigned int* plen, int msgtype /*= en_Eterm_Msg_Normal*/ )
{
    char out[4096] = {0};
    int res = code_convert("utf-8", "gbk", pstr, strlen(pstr), out, sizeof(out));
    if (res == -1) {
        MSGOUT(en_Msg_Error, "convert to gbk error!!!");
        return false;
    }
    std::string strmsg;
    EnCodeChineseStr(out, strlen(out), strmsg);
    if (msgtype == en_Eterm_Msg_Normal) {
        char head[19] = {0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x01, 0x00, 0x00, 0x70, 0x02, 0x1b, 0x0b,
            0x20, 0x20, 0x0f, 0x1b, 0x4d};
        char tail[5] = {0x0d, 0x1e, 0x1b, 0x62, 0x03};
        char buf[4096] = {0};
        unsigned int len = 0;
        head[8] = (unsigned char)(id&0xff);
        head[9] = (unsigned char)(id>>8);
        memcpy(buf+len, head, sizeof(head));
        len += sizeof(head);                                                                                                
        memcpy(buf+len, strmsg.c_str(), strmsg.length());
        len += strmsg.length();
        memcpy(buf+len, tail, sizeof(tail));
        len += sizeof(tail);

        buf[3] = len%256;
        buf[2] = len/256;
        if (len > *plen)
            return false;
        
        memcpy(pout, buf, len);
        *plen = len;
        return true;
    }
    else if (msgtype == en_Eterm_Msg_Msgbox) {
        char buff[4096] = {0x01, (char)0xf8};
        memcpy(buff+4, out, strlen(out));
        unsigned int len = 4 + strlen(out);
        buff[3] = len%256;
        buff[2] = len/256;

        if (len > *plen)
            return false;

        memcpy(pout, buff, len);
        *plen = len;
        return true;
    }
    else {
        MSGOUT(en_Msg_Error, "msg type error!!!");
        return false;
    }
}

bool PerDealCmd::GetPNRFromCmd( const char* pstr, std::string& strPNR )
{
    strPNR = "";

    return true;
}

bool PerDealCmd::GetStrFromEtermData(void* pdata, unsigned int ulen, std::string& strout)
{
    unsigned int ustart = 0, len = 0;
    if (!GetEtermStrPos(pdata, ulen, &ustart, &len)) {
        return false;
    }

    char* pData = (char*)pdata + ustart;

    const char p[] = {0x1B, 0x62};

    char* szResult = (char*)malloc(len + 1);
    memset(szResult, 0, len + 1);
    for(unsigned int i = 0; i < len; ++i)
    {
        char ch = pData[i];
        if( ch == 0x1D || ch == 0x1C )
        {
            szResult[i] = ' ';
        }
        else
        {
            szResult[i] = ch;
        }

        if(i >= 1 && ch == p[1] && pData[i-1] == p[0])
        {
            szResult[i] = ' ';
            szResult[i - 1] = ' ';
        }
    }
    if (len > 0)
        DecodeChineseStr(szResult, len, strout);

    free(szResult);
    return true;
}

void PerDealCmd::DecodeChineseStr( const char* pstr, unsigned int ulen, std::string& strout )
{
    char cStart[2] = {0x1B, 0x0E};
    char cEnd[2] = {0x1B, 0x0F};

    int nstart = -1;
    int nend = -1;
    char *pcompare = cStart;

    strout = "";

    char* preturn = (char*)malloc(ulen+1);
    memset(preturn, 0, ulen+1);
    unsigned int returnpos = 0;
    unsigned int strpos = 0;

    for (unsigned int i = 0; i < ulen-1; i++)
    {
        if (pstr[i] == pcompare[0] && pstr[i+1] == pcompare[1])
        {
            if (pcompare == cStart)
            {
                pcompare = cEnd;
                nstart = i;
                i++;
            }
            else
            {
                nend = i;
                char *ptemp = (char*)malloc(nend-nstart-1);
                memset(ptemp, 0, nend-nstart-1);
                memcpy(ptemp, pstr+nstart+2, nend-nstart-2);

                DecodeChinese(ptemp, nend-nstart-2);

                memcpy(preturn+returnpos, pstr+strpos, nstart-strpos);
                returnpos += nstart-strpos;

                memcpy(preturn+returnpos, ptemp, nend-nstart-2);
                free(ptemp);
                returnpos += nend-nstart-2;

                strpos = nend+2;

                nstart = -1;
                nend = -1;

                pcompare = cStart;
                i++;
            }
        }
    }

    if (strpos < ulen)
    {
        memcpy(preturn+returnpos, pstr+strpos, ulen-strpos);
    }

    strout = preturn;
    free(preturn);
}


void PerDealCmd::DecodeChinese(char* pstr, unsigned int ulen) {
	for (unsigned int i = 0; i < ulen; i += 2)
	{	
		int num = ((int)pstr[i])*256 + pstr[i+1];
		std::string str = s_mapnum[num];
		if (str != "") {
			const char* p = str.c_str();
			pstr[i] = p[0];
			pstr[i+1] = p[1];
		}
		else {
			char byteArr[2] = {0};
			byteArr[0] = pstr[i];
			byteArr[1] = pstr[i+1];
							
			unsigned char first = (unsigned char)((unsigned char)byteArr[0] + 0x72);
			if (first >= (unsigned char)0x24)
			{
				first += 0xe;
				pstr[i] = (char)first;
			}
			
			unsigned char second = (unsigned char)((unsigned char)byteArr[1] + 0x80);
			pstr[i+1] = second;
			if (second >= (unsigned char)0x2f)
			{
				if (second <= 0x32)
				{
					second -= 0xa;
					pstr[i+1] = pstr[i];
					pstr[i] = (char)second;
				}
			}
		}
	}
}

bool PerDealCmd::TransformSdCmd(const char* psdcmd, const char* pavres, std::string& strout) {

	if (psdcmd == NULL || pavres == NULL) {
		return false;
	}
	int idx = 0;
	int count = 0;
	char seat = 0;
	char tempbuf[12] = {0};
	WipeoffString(psdcmd, tempbuf, sizeof(tempbuf));
	if (strlen(tempbuf) < 5) {
		return false;
	}

	idx = atoi(tempbuf+2);
	if (idx > 100 || idx <= 0) {
		return false;
	}
	if (idx > 10) {
		seat = tempbuf[4];
		count = atoi(tempbuf+5);
	}
	else {
		seat = tempbuf[3];
		count = atoi(tempbuf+4);
	}
	if (count <= 0 || seat > 'Z' || seat < 'A') {
		return false;
	}

	int res = 0;
	char dep[4] = {0}, des[4] = {0};
	if (CETermString::_avhgetdepdes(pavres, dep, des)) {
		avhtravelInfo** p = NULL;
		int pagetypa = en_page_single;
		res = CETermString::DealAVHStr(pavres, &p, dep, des, &pagetypa);
		if (res == -1)
			return false;
		if (res == 0) {
			avtravelInfo** p = NULL;
			res = CETermString::DealAVStr(pavres, &p, dep, des, &pagetypa);
			if (res <= -1)
				return false;
			char buf[4096] = {0};
			for (int i = 0; i < res; i++) {
				if (p[i]->count > 0 && p[i]->pinfo[0].idx == idx) {
					for (int j = 0; j < p[i]->count; j++) {

						strcat(buf, "SS:");
						strcat(buf, p[i]->pinfo[j].aircompany);
						strcat(buf, p[i]->pinfo[j].airnumber);
						sprintf(buf + strlen(buf), " %c ", seat);
						char date[8] = {0};


						if (p[i]->pinfo[j].timestart[4] == '+') {
							std::string str;
							if (!OffsetEtermData(p[i]->pinfoex[j].date, 1, str)) {
								return false;
							}
							strncpy(date, str.c_str(), 5);
						}
						else if (p[i]->pinfo[j].timestart[4] == '-') {
							std::string str;
							if (!OffsetEtermData(p[i]->pinfoex[j].date, -1, str)) {
								return false;
							}
							strncpy(date, str.c_str(), 5);
						}
						else {
							strcpy(date, p[i]->pinfoex[j].date);
						}
						strcat(buf, date);
						strcat(buf, " ");
						strcat(buf, p[i]->pinfo[j].areastart);
						strcat(buf, p[i]->pinfo[j].areaend);
						sprintf(buf+strlen(buf), " %d/", count);
						strncat(buf, p[i]->pinfo[j].timestart, 4);
						strcat(buf, " ");
						strncat(buf, p[i]->pinfo[j].timeend, 4);
						strcat(buf, "\r");
					}
					strout = buf;
					break;
				}
			}
			CETermString::FreeAVRes(p, res);
		}
		else {
			char buf[4096] = { 0 };
			for (int i = 0; i < res; i++) {
				if (p[i]->count > 0 && p[i]->pinfo[0].idx == idx) {
					for (int j = 0; j < p[i]->count; j++) {
						strcat(buf, "SS:");
						strcat(buf, p[i]->pinfo[j].aircompany);
						strcat(buf, p[i]->pinfo[j].airnumber);
						sprintf(buf + strlen(buf), " %c ", seat);

						char date[8] = { 0 };

						if (p[i]->pinfo[j].timestart[4] == '+') {
							std::string str;
							if (!OffsetEtermData(p[i]->pinfoex[j].date, 1, str)) {
								return false;
							}
							strncpy(date, str.c_str(), 5);
						} else if (p[i]->pinfo[j].timestart[4] == '-') {
							std::string str;
							if (!OffsetEtermData(p[i]->pinfoex[j].date, -1, str)) {
								return false;
							}
							strncpy(date, str.c_str(), 5);
						} else {
							strcpy(date, p[i]->pinfoex[j].date);
						}
						strcat(buf, date);
						strcat(buf, " ");
						strcat(buf, p[i]->pinfo[j].areastart);
						strcat(buf, p[i]->pinfo[j].areaend);
						sprintf(buf + strlen(buf), " %d/", count);
						strncat(buf, p[i]->pinfo[j].timestart, 4);
						strcat(buf, " ");
						strncat(buf, p[i]->pinfo[j].timeend, 4);
						strcat(buf, "\r");
					}
					strout = buf;
					break;
				}
			}
			CETermString::FreeAVHRes(p, res);
		}
		return true;
	}
	else {
		return false;
	}
}

// SS:CA1351 Y 1OCT PEKCAN
bool PerDealCmd::GetSSSeatInfo(const char* pstrcmd, StSSSeatInfo* pssinfo) {
	if (pstrcmd == NULL || pssinfo == NULL) {
		return false;
	}
    enum {
        _en_ss_company,
        _en_ss_planenum,
        _en_ss_seat,
        _en_ss_date,
        _en_ss_start,
        _en_ss_end,
        _en_ss_code,
        _en_ss_count,
        _en_ss_tstart,
        _en_ss_tend,
        _en_ss_null,
    };
	//char pstrcmd[4096] = {0};
	//WipeoffString(pstrcmd, buf, sizeof(buf));
	//fprintf(stderr, "out string : %s\n", buf);
	if (strlen(pstrcmd) < 18) {
		return false;
	}
    int status = _en_ss_company;
	int startpos = 2;
    bool bset = false;
    for (unsigned int i = startpos; i <= strlen(pstrcmd); i++) {  
        MSGOUT(en_Msg_Debug, "status: %d, str: %s", status, pstrcmd+startpos);
        if (status == _en_ss_company) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;
            if (bset) {
                strncpy(pssinfo->strcom, pstrcmd+startpos, 2);
                i += 1;
                startpos = i;
                bset = false;
            }
            status = _en_ss_planenum;
        }
		else if (status == _en_ss_planenum) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            } 
            if (!bset) {
                startpos = i;
            }
            bset = true;
            
            while ((pstrcmd[i] <= '9' && pstrcmd[i] >= '0')) {
                strncpy(pssinfo->strplannum+i-startpos, pstrcmd+i, 1);
                i++;
            } 
            if (i - startpos > 4 || i -startpos <= 2) {
                MSGOUT(en_Msg_Debug, "false 1 pos : %d, i : %d\n", startpos, i);
                return false;
            }
            i--;
            startpos = i;
            bset = false;
            
			status = _en_ss_seat;
		}
        else if (status == _en_ss_seat) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;

            if (pstrcmd[i] <= '9' && pstrcmd[i] >= '0') { 
                MSGOUT(en_Msg_Debug, "false 2 pos : %d, i : %d\n", startpos, i);
                return false;
            }
            strncpy(pssinfo->strseat, pstrcmd+startpos, 1);
            startpos = i;
            bset = false;
            status = _en_ss_date;
        }
        else if (status == _en_ss_date) {  
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;

			if (pstrcmd[i] >= '0' && pstrcmd[i] <= '9') {
                continue;
			}
			else {
				if (i - startpos > 2 || i - startpos <= 0) {
					MSGOUT(en_Msg_Debug, "false 3 pos : %d, i : %d\n", startpos, i);
					return false;
				}
				strncpy(pssinfo->strdate, pstrcmd+startpos, i-startpos+3);
				i += 2;
				startpos = i;
                bset = false;
			}
			status = _en_ss_start;
		}
        else if (status == _en_ss_start) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;
            strncpy(pssinfo->strstart, pstrcmd+startpos, 3);
            i += 2;
            startpos = i;
            bset = false;
            status = _en_ss_end;
        }
        else if (status == _en_ss_end) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;
            strncpy(pssinfo->strend, pstrcmd+startpos, 3);
            i += 2;
            startpos = i;
            bset = false;
            status = _en_ss_code;
        }
        else if (status == _en_ss_code) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;
            if (pstrcmd[i] >= '0' && pstrcmd[i] <= '9') {
                
            }
            else {
                strncpy(pssinfo->strcode, pstrcmd+startpos, 2);
                i += 2;
            } 
            i--;
            startpos = i;
            bset = false;
            status = _en_ss_count;
        }                                                                   
        else if (status == _en_ss_count) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;
            while (pstrcmd[i] >= '0' && pstrcmd[i] <= '9') {
                i++;
            } 
            if (i - startpos <= 0 || i-startpos >= 3) {
                MSGOUT(en_Msg_Debug, "false 4 pos : %d, i : %d\n", startpos, i);
                return false;
            }
            strncpy(pssinfo->strnum, pstrcmd+startpos, i-startpos);
            i--;
            startpos = i;
            bset = false;
            status = _en_ss_tstart;
        }
        else if (status == _en_ss_tstart) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;
            while (pstrcmd[i] >= '0' && pstrcmd[i] <= '9') {
                i++;
            } 
            if (i - startpos < 3 || i-startpos > 4) {
                MSGOUT(en_Msg_Debug, "false 6 pos : %d, i : %d\n", startpos, i);
                return false;
            }
            strncpy(pssinfo->strtstart, pstrcmd+startpos, i-startpos);
            
            i--;
            startpos = i;
            bset = false;
            status = _en_ss_tend;
        }
        else if (status == _en_ss_tend) {
            if (!IsNormalWord(pstrcmd[i])) {
                if (bset) {
                    return false;
                }
                continue;
            }
            if (!bset) {
                startpos = i;
            }
            bset = true;
            while (pstrcmd[i] >= '0' && pstrcmd[i] <= '9') {
                i++;
            } 
            if (i - startpos < 3 || i-startpos > 4) {
                MSGOUT(en_Msg_Debug, "false 7 pos : %d, i : %d\n", startpos, i);
                return false;
            }
            strncpy(pssinfo->strtend, pstrcmd+startpos, i-startpos);
            
            i--;
            startpos = i;
            bset = false;
            status = _en_ss_null;
        }
	}
	return true;
}

void PerDealCmd::WipeoffString(const char* pstr, char* pout, unsigned int uoutlen) {
	unsigned int pos = 0;
	memset(pout, 0, uoutlen);
	for (unsigned int i = 0; i < strlen(pstr) && pos+1 <= strlen(pstr); i++) {
		if ((pstr[i] >= 'A' && pstr[i] <= 'Z') || (pstr[i] >= '0' && pstr[i] <= '9') || (pstr[i] >= 'a' && pstr[i] <= 'z')) {
			pout[pos++] = pstr[i];
		}
	}
}

bool PerDealCmd::GetPNRStrFromCmd(const char* pstr, std::string& strout) {

	std::vector<std::string> vecstr;
	SpliteCmd(pstr, vecstr);
	if (vecstr.size() != 2 && vecstr.size() != 3) {
		return false;
	}
	else {
		strout = vecstr[vecstr.size()-1];
		if (strout.length() != 6) {
			strout = "";
			return false;
		}
		return true;
	}
}

void PerDealCmd::GetNameFromNMCmd(const char* pstr, std::vector<std::string>& vecname) {
	vecname.clear();

	int start = 0;
	for(unsigned int i = 0; i < strlen(pstr)+1; i++) {
		if ((pstr[i] >= '0' && pstr[i] <= '9') || pstr[i] == '\0') {
			if (start == 0) {
				start = i;
			}
			else {
				std::string str(pstr, start, i-start);
				vecname.push_back(str);
				start = i;
			}
			while((pstr[i] >= '0' && pstr[i] <= '9') && pstr[i] != '\0') {
				i++;
				start = i;
			}
		}
	}
}

void PerDealCmd::GetLineFromeCmd(const char* pstr, std::vector<std::string>& vecline) {
	vecline.clear();
	int pos = 0;
	for(unsigned int i = 0; i < strlen(pstr)+1; i++) {
		if (pstr[i] == '\n' || pstr[i] == '\r' || pstr[i] == '\0') {
			if (i - pos <= 0) {
				pos = i+1;
			}
			else {
				std::string str(pstr, pos, i-pos);
				_trimstdstring(str);
				if (str[0] == '-') {
					std::string strtemp = vecline.at(vecline.size()-1);
					vecline.pop_back();
					str = str.substr(1);
					vecline.push_back(strtemp+str);
				}
				else {
					vecline.push_back(str);
				}
				pos = i+1;
			}
		}
	}
}

void PerDealCmd::_trimstdstring(std::string& str) {
	std::string::size_type head = str.find_first_not_of(" ");
	if (head == std::string::npos) {
		str = "";
		return;
	}
	std::string::size_type tail = str.find_last_not_of(" ");
	str = str.substr(head, tail-head+1);
}

void PerDealCmd::_trimcharstring(char* pstr) {
	if (pstr == NULL || strlen(pstr) == 0)
		return;
	unsigned int head = 0;
	for( ; head < strlen(pstr); head++) {
		if (pstr[head] != ' ')
			break;
	}
	if (strlen(pstr) == head) {
		pstr[head] = '\0';
		return;
	}
	unsigned int tail = strlen(pstr)-1;
	for( ; tail >= 0; tail--) {
		if (pstr[tail] != ' ')
			break;
	}
	int i = 0;
	for(; tail >= head; head++) {
		pstr[i++] = pstr[head];
	}
	pstr[i] = '\0';
}

bool PerDealCmd::GetCompanyBigCode(const char* pstr, std::string& strbigcode) {

	std::vector<std::string> vecstr;
	PerDealCmd::SpliteCmd(pstr, vecstr);
	if (vecstr.size() == 4 && vecstr.at(2) == "D") {
		strbigcode = vecstr.at(3);
		return true;
	}
	else if(vecstr.size() == 5 && vecstr.at(2) == "V") {
		strbigcode = vecstr.at(2);
		return true;
	}
	return false;
}

bool PerDealCmd::GetPNRStringFromCmd(const char* pstr, std::string& strPNR) {
	std::vector<std::string> vecstr;
	PerDealCmd::SpliteCmd(pstr, vecstr);
	if (vecstr.size() <= 1 || vecstr.size() > 3) {
		return false;
	}
	strPNR = vecstr.at(vecstr.size()-1);
	if (strPNR.length() != 6) {
		strPNR = "";
		return false;
	}
	return true;
}

time_t PerDealCmd::GetTimeFromEtermStr(const char* pstr) {

	if (pstr == NULL) {
		return -1;
	}

	std::string strdata = pstr;
	const char* pnum = "0123456789";
	const char* pword = "QWERTYUIOPLKJHGFDSAZXCVBNM";
	if (isdigit(strdata.c_str()[0]) == 0)
		return -1;

	std::string::size_type pos = strdata.find_first_not_of(pnum);
	if (pos == std::string::npos)
		return -1;

	int day = atoi(strdata.substr(0, pos).c_str());
	if (day <= 0 || day > 31)
		return -1;

	std::string::size_type postemp = strdata.find_first_not_of(pword, pos);
	std::string strmonth = strdata.substr(pos, postemp - pos);
	if (strmonth.length() != 3)
		return -1;

	int month = 0;
	for (int i = 0; i < 13; i++) {
		if (i == 12)
			return -1;
		if (strmonth == s_month[i]) {
			month = i;
			break;
		}
	}

	int year = 0;

	if(postemp == std::string::npos) {
		GetLocalTimeInfo(&year);
		year -= 2000;
	}
	else {
		pos = strdata.find_first_not_of(pnum, postemp);
		if (pos != std::string::npos)
			return -1;
		year = atoi(strdata.substr(postemp, -1).c_str());
	}

	struct tm stm;
	memset(&stm, 0, sizeof(stm));
	stm.tm_year = 100 + year;
	stm.tm_mon = month;
	stm.tm_mday = day;
	time_t ttemp = mktime(&stm);

	fprintf(stderr, "year: %d, month: %d, day: %d\n", year, month, day);

	return ttemp;
}

void PerDealCmd::ToUpperStr( std::string& str )
{
    std::transform(str.begin(), str.end(), str.begin(), toupper);
}

void PerDealCmd::ToUpperStrPtr( char* pstr )
{
    if (pstr == NULL)
        return;
    unsigned int ulen = strlen(pstr);
    for (unsigned int i = 0; i < ulen; i++) {
        pstr[i] = toupper(pstr[i]);
    }
}

bool PerDealCmd::AddEnterToEtermRetStr( char* pdata, unsigned int ulen, char** pout, unsigned int* plen )
{
    if (pout == NULL || plen == NULL) {
        return false;
    }
    *pout = NULL;
    *plen = 0;

    unsigned int ustart = 0, len = 0;
    if (!GetEtermStrPos(pdata, ulen, &ustart, &len)) {
        return false;
    }
    int count = 0;
    unsigned int uidx = ustart;
    char* ptemp = (char*)malloc(ulen+30);
    for (unsigned int i = ustart; i < len+ustart; ) {
        if (pdata[i] == '\r') {
            ptemp[uidx++] = pdata[i++];  
            count = 0;
        }
        if (count == 80) {
            ptemp[uidx++] = '\r';
            MSGOUT(en_Msg_Debug, "Add enter: %d", uidx-1);
            count = 0;
        }
        else {
            ptemp[uidx++] = pdata[i++];
        }
        count++;
    }
    uidx--;

    unsigned int flen = uidx-ustart+1+(ulen-len);

    memcpy(ptemp, pdata, ustart);
    memcpy(ptemp+uidx, pdata+ustart+len, ulen-ustart-len);

    ptemp[3] = flen%256;
    ptemp[2] = flen/256;

    *pout = ptemp;
    *plen = flen;

    return true;
}

bool PerDealCmd::GetEtermStrPos( void* pdata, unsigned int ulen, unsigned int* pstart, unsigned int* plen )
{

    char* pd = (char*)pdata;
    int nstart = -1;
    if(ulen >= 19)
    {
        int n = ulen > 25 ? 25 : ulen;
        for(int i = 2; i < n; ++i)
        {
            if(pd[i - 1] == 0x1B && pd[i] == 0x4D && pd[i - 2] == 0x0F)
                nstart = i + 1;
            else if (pd[i - 1] == 0x0F && pd[i] == 0x02)
                nstart = i + 1;                                  
            else if (pd[i - 1] == 0x1B && pd[i] == 0x4B && pd[i - 2] == 0x0F) 
                nstart = i + 1;
        }
    }
    if (nstart == -1)
        return false;

    const char* pData = pd + nstart;
    unsigned int uLen = ulen - nstart;

    const char pEnd[] = {0x1E, 0x1B, 0x62, 0x03};
   // const char p[] = {0x1B, 0x62};                              
    const char pEnd2[] = {0x1B, 0x0B, 0x00, 0x21, 0x0F, 0x03};

    if( strncmp(pData+uLen-4, pEnd, 4) == 0 )
    {
        uLen -= 4;
    }
    if( memcmp(pData+uLen-6, pEnd2, 2) == 0 && memcmp(pData+uLen-3, pEnd2+3, 3) == 0)
    {
        uLen -= 6;
    }

    if (uLen <= 0) {
        return false;
    }

    *pstart = nstart;
    *plen = uLen;

    return true;
}

bool PerDealCmd::IsNormalWord( const char c )
{
    if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z')) {
        return true;
    }
    return false;
}






//void PerDealCmd::SplteString(const char* pstr, std::vector<std::string>& vecstr) {
//	vecstr.clear();
//	if (pstr == NULL)
//		return;
//
//	int pos = 0;
//	for(unsigned int i = 0; i < strlen(pstr)+1; i++) {
//		if ((pstr[i] < 'A' || pstr[i] > 'Z') && (pstr[i] < '0' || pstr[i] > '9')) {
//			fprintf(stderr,"i: %d, pos: %d, str: %s\n", i, pos, pstr+pos);
//			if (i - pos <= 0) {
//				pos = i+1;
//			}
//			else {
//				std::string str(pstr, pos, i-pos);
//				vecstr.push_back(str);
//				pos = i+1;
//			}
//		}
//	}
//}
