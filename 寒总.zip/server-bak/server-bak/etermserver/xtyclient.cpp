/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-08-29 16:02:23
# LastModified : 2014-10-27 17:58:34
# FileName     : xtyclient.cpp
# Description  : 
 ******************************************************************************/
#include <string.h>
#include "xtyclient.h"
#include "etermloop.h"
#include "showmsg.h"
#include "scprotocol.h"
#include "dealnetdata.h"
#include "dbdefine.h"

// m_ploop->DealXTYRet(const char* name, const char* pwd, int id, const char* pip, int port, int errtype);
// senddata(char *, unsigned int len);
// closeconnect()
// MSGOUT(en_Msg_Debug, "%s %d", char*, int);
/*struct NetSocketHead {
	unsigned int uMainCmd;
	unsigned int uSubCmd;
	unsigned int uHelpCmd;
	unsigned int uLen;
	unsigned int uReserv2;
};*/
/*
char buf[4096] = {0};
NetSocketHead* phead = (NetSocketHead*)buf;
phead->uMainCmd = XTYSVR_CLIENT_TYPE;
phead->uSubCmd = XC_VERIFY_KEYWORD;

StCompanyInfo* pdata = (StCompanyInfo*)(phead+1);
pdata->idx = 10021;
...

phead->uLen = sizeof(NetSocketHead) + sizeof(StCompanyInfo);
senddata(buf, phead->uLen);
*/
/*
struct StXTYNetAccontInfo {
	char    name[16];
	char    pwd[16];
	int     id;
	char    re[8];
};

struct StXTYEtermAccontInfo {
	char    name[16];
	char    pwd[16];
	char    ip[16];
	int     port;
	int     id;
	int     err;
	char    re[8];
};
*/
bool XTYClient::_start_server(void* pdata, ISvrCallback* pcb) {

	m_ploop = (EtermSvrLoop*)pdata;
	
	return CenterSocket::_start_server(NULL, pcb);
}
// recv server data
bool XTYClient::OnRecvData(char* pdata, unsigned int len) {

	NetSocketHead* phead = (NetSocketHead*)pdata;
    MSGOUT(en_Msg_Debug, "length : %d", len);

	if (phead->uMainCmd != XTYSVR_CLIENT_TYPE)                                           
		return false;

	switch(phead->uSubCmd) {
		case XC_VERIFY_KEYWORD:
		{
			
		}
		break;
		case XC_XTY_ACCONT_INFO:
		{
            if (phead->uLen != HEAD_SIZE+sizeof(StXTYEtermAccontInfo)) {
                MSGOUT(en_Msg_Debug, "error len");
                return false;
            }
            StXTYEtermAccontInfo* account = (StXTYEtermAccontInfo*)(phead+1);
            if (phead->uHelpCmd != 1) {
                MSGOUT(en_Msg_Debug, "password error!!! id: %d, error code: %d", account->sysid, phead->uHelpCmd);
            }
            else {  
                MSGOUT(en_Msg_Debug, "sysid: %d, companyid: %d, name: %s, pwd: %s", account->sysid, account->companyid, account->name, account->pwd);
                m_ploop->PostEtermResult(DB_ETERM_ADDXTYACCONT, account, sizeof(StXTYEtermAccontInfo), 0);
            }
		}
		break;
		default:
			return false;
	}
	return true;
}

void XTYClient::OnClose() {
 
}

// 客户端帐号密码ID
void XTYClient::DealXTYAccont(StXTYEtermAccontInfo* pxtyinfo) {
		
	char buf[4096] = {0};
	NetSocketHead* phead = (NetSocketHead*)buf;
	phead->uMainCmd = XTYSVR_CLIENT_TYPE;

	phead->uSubCmd = XC_XTY_ACCONT_INFO;
	phead->uLen = sizeof(NetSocketHead) + sizeof(StXTYEtermAccontInfo);

	StXTYEtermAccontInfo* account = (StXTYEtermAccontInfo*)(phead+1);

    memcpy(account, pxtyinfo, sizeof(StXTYEtermAccontInfo));

	senddata(buf,phead->uLen);
}

void XTYClient::OnConnectOK(bool bok) {
	if(bok)
	{  
        m_ploop->GetXTYAccount();
	}
    else {
		//connect faild..	
	}
}
