/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-26 18:11:23
# LastModified : 2014-08-31 19:47:40
# FileName     : svrloop.h
# Description  : 
 ******************************************************************************/
#ifndef _SVRLOOP_H
#define _SVRLOOP_H

#include <string>
#include <vector>
#include <set>

#include "serverset.h"
#include "etermloop.h"

struct _StConnectData
{
    int     companyid;
};

#define TIME_ETERM_SIPID       (10*1000)
#define TIMER_ETERM_SIPID       1

class ServerMain : public ServerSet {
public:
	virtual bool OnSocketRead(int fd, void* pdata, unsigned int ulen);
	virtual bool OnSocketConnect(int fd, struct sockaddr_in* paddr);
	virtual void OnSocketClose(int fd);
	virtual void OnEventTimer(unsigned int uid);
	virtual void SettleDBResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
	virtual void _stop();
	virtual bool _start();
	virtual void _end_callback(const char* pstr, void* pdata, int ntype);
protected:  
    EtermSvrLoop            m_eternIns;
	std::map<int, void*>	m_mapfd;
	int						m_nsvrid;
    std::set<int>           m_mmainsvrfd;
    time_t 					m_lastsiTime;
public:
	bool DealClientData(int fd, void* pdata, unsigned int ulen);
protected:

};

#endif // _SVRLOOP_H
