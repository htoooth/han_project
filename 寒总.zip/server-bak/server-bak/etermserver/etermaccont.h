#ifndef _ETERMACCONT_H
#define _ETERMACCONT_H

#include <map>
#include <string>
#include <stdio.h>

#include "perdealcmd.h"

enum _en_Eterm_UserType {
    en_Eterm_Type_Normal = 0,
    en_Eterm_Type_TravelSky,    //SSL connect
    en_Eterm_Type_Original,  // SSL connect
// 
//     en_Eterm_Type_CityPair = 300,
//     en_Eterm_Type_PlaneNum,
};

struct StEtermLimitInfo
{
	int		sysid;
    int     companyid;
	int		type;
	char	key[12];
    time_t 	tstart;
    time_t  tend;
    char   	seat[28];
};


class EtermAccont
{
public:
    EtermAccont(void);
    virtual ~EtermAccont(void);                                                                                                               

    void InitAccontInfo(int companyid, int etermsysid);

    void AddAllowInfo(StEtermLimitInfo* pinfo, int count);

    void AddForbidInfo(StEtermLimitInfo* pinfo, int count);

    // return value: 1 allow; -1 forbid; 0 didn't have
    int TestSSCmdInfo(StSSSeatInfo* pinfo);

    void ClearInfo();

    int GetCompanyID();

    int GetEtermID();

private:
    // map < companycode+citypair, info > or <flight num, info>
    std::map<std::string, StEtermLimitInfo*>   m_allowinfo;
    std::map<std::string, StEtermLimitInfo*>   m_forbidinfo;

    int     m_companyid;
    int     m_etermsysid;
};

#endif // _ETERMACCONT_H
