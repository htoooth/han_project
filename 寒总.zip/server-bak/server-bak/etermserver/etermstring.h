/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-10-09 20:01:02
# LastModified : 2014-10-09 20:07:41
# FileName     : etermstring.h
# Description  : 
 ******************************************************************************/
// ETermString.h: interface for the CETermString class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ETERMSTRING_H__E755A53C_9C46_4AFF_84A9_DB562B612D6F__INCLUDED_)
#define AFX_ETERMSTRING_H__E755A53C_9C46_4AFF_84A9_DB562B612D6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>

enum _turnpagetype {
	en_page_single	= 0x00000000,			// single page
	en_page_next	= 0x00000001,			// can turn to page next
	en_page_before	= 0x00000002,			// can turn to page before
};

#pragma pack(4)
/**************************AVH**************************/
struct avhInfo
{
	int		idx;
	char	aircompany[4];		// aircompany two code
	char	airnumber[8];		// airline number
	char	aircompanysh[4];	// share aircompany two code
	char	airnumbersh[8];		// share airline number
	char	areastart[4];		// three code of the depature city 
	char	timestart[8];		// airline start time
	char	stationstart[4];	// start airstation info
	char	areaend[4];			// three code of the destination city
	char	timeend[8];			// airline end time 
	char	stationend[4];		// depature airstation info
	char	planetype[8];		// airplane type
	char	staycount[4];		// stay city count
	char	dinerinfo[4];		// provide diner info
	char	totaltime[8];		// total travel time
};

struct avhInfoEx {
	char	timeflag[4];		// change time flag
	char	date[8];			// travel date info
	int		count;				// seat count
	char	detail[26][2];		// detail seat info	
};

struct avhtravelInfo {
	char		depature[4];		// depature area three code
	char		destination[4];		// destination area three code
	int			count;				// info count
	avhInfo*	pinfo;				// basice info (will not change normally
	avhInfoEx*	pinfoex;			// info will changed by time
};
/**************************AVH**************************/

/**************************AV**************************/
struct avInfo
{
    int    	idx;
	char	aircompany[4];		// aircompany two code
	char	airnumber[8];		// airline number
	char	areastart[4];		// three code of the depature city 
	char	timestart[8];		// airline start time
	char	areaend[4];			// three code of the destination city
	char	timeend[8];			// airline end time 
	char	planetype[8];		// airplane type
	char	staycount[4];		// stay city count
	char	dinerinfo[4];		// provide diner info
};

struct avInfoEx {
	char	timeflag[4];		// change time flag
	char	date[8];			// travel date info
	int		count;				// seat count
	char	detail[26][2];		// detail seat info	
};

struct avtravelInfo {
	char		depature[4];		// depature area three code
	char		destination[4];		// destination area three code
	int			count;				// info count
	avInfo*		pinfo;				// basice info (will not change normally
	avInfoEx*	pinfoex;			// info will changed by time
};
/**************************AV**************************/

/**************************NFD**************************/
struct nfdpriceinfo {
	char		depature[4];		// depature area three code
	char		destination[4];		// destination area thr ee code
	char		aircompany[4];		// airlines company two code
	int			owprice;			// one way price
	int			rtprice;			// round trip price
	char		seattype[4];		// seat type
	char		startdata[8];		// validity date start
	char		enddata[8];			// validity date end
	char		advanceday;			// advance days	
};
/**************************NFD**************************/


/**************************FD**************************/
struct fdpriceinfo {
    char		depature[4];		// depature area three code
    char		destination[4];		// destination area three code
    char		aircompany[4];		// airlines company two code
    int			owprice;			// one way price
    int			rtprice;			// round trip price
    char		seattype[4];		// seat type
    char        physeat[4];        // physical seat type  
    char		startdata[8];		// validity date start
    char		enddata[8];		    // validity date end
    char        pricecal[8];
    int			distance;			// distance
};
/**************************FD**************************/

/**************************FSQ**************************/
struct fsqlinedata {
	char	areastart[4];
	char	areaend[4];
	char	datanvb[8];
	char	datanva[8];
	char	packageinfo[4];
	char	seattype[4];
};

struct fsqpricedata {
	char	areastart[4];
	char	areaend[4];
	int		price;
};

struct fsqpriceinfo {
	int				itprice;	// include all price 
	int				taxprice;	// not include Q price
	int				qprice;		// Q value info
	int				linecount;	// line count
	char			valdata[8];	// price value data
	char			valtime[8];	// price value time
	fsqlinedata*	pline;		// line info
	int				pricecount;	// price count
	fsqpricedata*	pprice;		// price info
};
/**************************FSQ**************************/

/**************************PAT**************************/
struct patpriceinfo {
	int		total;
	int		fare;
	int		tax;
};
/**************************PAT**************************/

/**************************DETR**************************/
struct detrtripstatus {
	char	depature[4];
	char	destination[4];
	char	company[4];
	char	airnum[8];
	char	seattype[4];
	char	startdata[8];
	char	starttime[8];
	char	package[4];
	char	ticstatus[16];
};

struct detrtripinfo {
	char			ticketnum[16];
	char			changenum[16];
	char			tickettype[8];
	char			passengername[32];
	char			pnrnum[8];
	char			aircomnum[8];
	int				count;
	detrtripstatus*	pstatus;
};

/**************************DETR**************************/

#pragma pack()

class CETermString
{
public:
	CETermString();
	virtual ~CETermString();
public:
	static int DealReturnStr(const char* pstr);

	// include "\n"
	static int _getOneLine(const char* pin, char* pout, unsigned int outlen);
	// return token offset 
	static int _readOneToken(const char* pin, char* pout, unsigned int outlen);

//protected:
	static void _freerecords(char** p, int count);
/***********************************************AVH***********************************************/
public:
	enum _avh_status {
		en_avh_number = 0,
		en_avh_airnumber,
		en_avh_timeflag,
		en_avh_seatstatus,
		en_avh_citypair,
		en_avh_starttime,
		en_avh_endtime,
		en_avh_planetype,
		en_avh_staydiner,
		en_avh_eleticket,
		en_avh_startstation,
		en_avh_endstation,
		en_avh_totaltime,
		en_avh_null,
	};

	struct _st_av_record_info
	{
		char	date[8];
		char*	pstr;
	};

	static int DealAVHStr(const char* pstr, avhtravelInfo*** pinfo, const char* pdep, const char* pdes, int *pagetype);
	
	static void FreeAVHRes(avhtravelInfo** pinfo, int count);

	// get depature and destination
	static bool _avhgetdepdes(const char* pstr, char* dep, char* des, char* date = NULL);

	static std::string _perdealavhstr(const char* pstr);

	// return -1 false; return 0 success; return 1 share airline
	static int _avhfirstline(const char* pstr, avhInfo* pinfo, avhInfoEx* pinfoE);
	// return -1 false;
	static int _avhsecondline(const char* pstr, bool bshare, avhInfo* pinfo, avhInfoEx* pinfoE);

	// return plane count ; -1 false
	static int _avhgetrecords(const char* pstr, _st_av_record_info*** pone, int* pagetype);

	static int _avhdealonrecord(_st_av_record_info* pstr, avhtravelInfo* pinfo);

	static void _avhfreerecords(_st_av_record_info** precord, int count);
/***********************************************AVH***********************************************/
	
/***********************************************AVH***********************************************/
	// return 0 success ; -1 failed
	static int _avdealonrecord(_st_av_record_info* pstr, avtravelInfo* pinfo);

	// return 0 success ; -1 failed
	static int _avfirstline(const char* pstr, avInfo* pinfo, avInfoEx* pinfoE);
	
	// return plane count ; -1 false
	static int _avgetrecords(const char* pstr, _st_av_record_info*** pone, int* pagetype);

	static int DealAVStr(const char* pstr, avtravelInfo*** pinfo, const char* pdep, const char* pdes, int *pagetype);

	static void FreeAVRes(avtravelInfo** pinfo, int count);

/***********************************************AVH***********************************************/

/***********************************************NFD***********************************************/
protected:
public:
	enum _nfd_status {
		en_nfd_linenu = 0,
		en_nfd_company,
		en_nfd_onewaypr,
		en_nfd_roundtpr,
		en_nfd_fbc_tc,
		en_nfd_seattype,
		en_nfd_minmax,
		en_nfd_trvdate,
		en_nfd_rule,
		en_nfd_end,
	};
	static int DealNFDStr(const char* pstr, nfdpriceinfo*** pinfo, const char* pdep, const char* pdes, int *pagetype);
	
	static void FreeNFDRes(nfdpriceinfo** pinfo, int count);

	static bool _nfdgettablepos(const char* pstr, int* arr, int size);
	static int _nfdgetrecords(const char* pstr, char*** pone, int* pagetype);
	static int _nfddealonerecord(const char* pstr, nfdpriceinfo* pinfo, int* pos );
	
	static bool _nfdgetdepdes(const char* pstr, char* pdep, char* pdes);
/***********************************************NFD***********************************************/

/***********************************************FD***********************************************/
protected:
	enum _fd_status {
        en_fd_linenu = 0,
        en_fd_company,
        en_fd_null1,
        en_fd_owprice,
        en_fd_rtprice,
        en_fd_seattype,
        en_fd_null2,
        en_fd_null3,
        en_fd_start,
        en_fd_end,
        en_fd_pricecal,
        en_fd_null,
	};
	
	static int DealFDStr(const char* pstr, fdpriceinfo*** pinfo, const char* pdep, const char* pdes, int distance, int *pagetype);
	
	static void FreeFDRes(fdpriceinfo** pinfo, int count);
	
	static int _fdgetrecords(const char* pstr, char*** pone, int* pagetype);

	static int _fddealonerecord(const char* pstr, fdpriceinfo* pinfo);
	
	static bool _fdgetdepdes(const char* pstr, char* pdep, char* pdes, int* pdistance);
/***********************************************FD***********************************************/

/***********************************************FSI***********************************************/
	enum _fsi_status {
		en_fsi_sword = 0,
		en_fsi_company,
		en_fsi_airnumber,
		en_fsi_start,
		en_fsi_end,
		en_fsi_plane,
		en_fsi_null,
	};

	static int DealFSIStr(const char* pstr, fsqpriceinfo* pinfo);

	static int DealFSQStr(const char* pstr, fsqpriceinfo* pinfo);
	
	static void FreeFSIRes(fsqpriceinfo* pinfo);

	// plinebegin useful infomation start line
	static bool _fsijudgement(const char* pstr, int* plinebegin);
	static bool _fsiadapterinfo(const char* pstr);

	// return 1: can resolve the price info; -1 error ; 0 no price  
	static int _fsigetrestype(const char* pstr);

	static int _fsqgettripinfo(const char* pstr, fsqpriceinfo* pinfo);

	static int _fsqgetpriceinfo(const char* pstr, fsqpriceinfo* pinfo);

	static int _fdqcalculateinfo(const char* pstr, fsqpriceinfo* pinfo);

	static int _floataddone(float f);

	static int _intaddten(int n);

	enum _fsq_status {
		en_fsq_area = 0,
		en_fsq_seat,
		en_fsq_nvb,
		en_fsq_nva,
		en_fsq_package,

		en_fsq_fare,
		en_fsq_tax,
		en_fsq_total,
		en_fsq_cale,
		en_fsq_rate,
		en_fsq_value,
		en_fsq_null,
	};

	static int _fsqdeal2type(const char* pstr, fsqpriceinfo* pinfo);

	// return -1 error; 1 start new line; 2 end by before
	static int _fsqgetilinetype(const char* pstr);

	// *ATTN PRICED ON 08MAY14*1105
	static bool _fsipriceflag(const char* pstr);
	
/***********************************************FSI***********************************************/
	
/***********************************************PAT***********************************************/
	enum _pat_status {
		en_pat_num = 0,
		en_pat_seat,
		en_pat_fare,
		en_pat_tax,
		en_pat_yq,
		en_pat_total,
		en_pat_null,
	};
	static bool _patjudgement(const char* pstr);

	static int DealPatStr(const char* pstr, patpriceinfo** pinfo);

	static void FreePatRes(patpriceinfo* pinfo);
/***********************************************PAT***********************************************/

/***********************************************DETR***********************************************/
	enum _detr_status {
		en_detr_ticnum = 0,
		en_detr_issued,
		en_detr_e_r,
		en_detr_tcode,
		en_detr_passenger,
		en_detr_exch,
		en_detr_trip,
		en_detr_fc,
		en_detr_fare,
		en_detr_tax,
		en_detr_total,

		en_detr_timeflag,
		en_detr_des,
		en_detr_company1,
		en_detr_company2,
		en_detr_planenum,
		en_detr_seattype,
		en_detr_startdata,
		en_detr_starttime,
		en_detr_ok,
		en_detr_seatdetail,
		en_detr_valuedata,
		en_detr_package,
		en_detr_status,

		en_detr_airstation1,
		en_detr_airstation2,
		en_detr_pnr,
		en_detr_comnum,
		
		en_detr_null,
	};
	static bool _detrjudgement(const char* pstr);

	static int DealDetrStr(const char* pstr, detrtripinfo* pinfo);

	static int _detrgettripinfp(const char* pstr, detrtripinfo* pinfo);

	static int _detrfirstline(const char* pstr, detrtripinfo* pinfo);

	static int _detrsecondline(const char* pstr, detrtripinfo* pinfo);

	static void FreeDetrRes(detrtripinfo* pinfo);

/***********************************************DETR***********************************************/

/***********************************************DA***********************************************/
 public:
    static bool GetDAInfo(const char* pstr);
/***********************************************DA***********************************************/

/***********************************************AVFLIGHT***********************************************/
public:
	static bool _getavflightinfo(const char* pstr, char* fno, char* timeend);
/***********************************************AVFLIGHT***********************************************/

public:
	static bool GetPNRCode(const char* pstr, char* strout, unsigned int ulen);
private:
	static bool _is_number(char ch);
	static bool _is_word(char ch);

	static bool _is_number(const char* str);
	static bool _is_word(const char* str); 
	static bool _is_return(char ch);
	static bool _is_flightnum(const char* pstr);

	static void trimleft(char* pstr);
	static void trimright(char* pstr);
public:
	static const char*	s_mouth[12];
	static const char*	s_week3[7];
	static const char*	s_week2[7];
};

#endif // !defined(AFX_ETERMSTRING_H__E755A53C_9C46_4AFF_84A9_DB562B612D6F__INCLUDED_)
