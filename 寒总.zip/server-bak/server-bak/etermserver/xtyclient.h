/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-08-29 11:20:44
# LastModified : 2014-09-10 18:10:59
# FileName     : xtyclient.h
# Description  : 
 ******************************************************************************/
#ifndef _XTYCLIENT_H
#define _XTYCLIENT_H

#include "evcenter.h"
#include "scstructdef.h"

enum {
	en_XTYErr_Unknow = 0,	// unknow error
	en_XTYErr_Null,			// success
	en_XTYErr_PwdErr,		// passwd error
	en_XTYErr_WebErr,		// website error
	en_XTYErr_CodeErr,		// Verify Code error
};

class EtermSvrLoop;

class XTYClient : public CenterSocket
{
public:
	bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual bool OnRecvData(char* pdata, unsigned int len);
	virtual void OnClose();
public:
	void DealXTYAccont(StXTYEtermAccontInfo* pxtyinfo);
	void OnConnectOK(bool bok);
protected:
	EtermSvrLoop*	m_ploop;
};

#endif // _XTYCLIENT_H
