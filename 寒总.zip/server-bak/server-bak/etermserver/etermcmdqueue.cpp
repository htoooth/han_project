/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-12-09 13:42:42
# LastModified : 2014-12-09 13:43:20
# FileName     : etermcmdqueue.cpp
# Description  : 
 ******************************************************************************/
#include <string.h>
#include <stdlib.h>

#include "etermcmdqueue.h"

EtermCmdQueue::EtermCmdQueue()
{
    m_phead = NULL;

    m_ptail = NULL;

    m_nsize = 0;
}

EtermCmdQueue::~EtermCmdQueue()
{
    CleanAll();
}

void EtermCmdQueue::CleanAll()
{
    while (PopCurItem(m_phead));
}

void EtermCmdQueue::PushEtermCmd( StEtermRequest* pcmd, int* arreterm, unsigned int arrsize )
{
    if (pcmd == NULL)
        return;
    StEtermCmdTask* ptemp = (StEtermCmdTask*)malloc(sizeof(StEtermCmdTask));
    memset(ptemp, 0, sizeof(StEtermCmdTask));
    memcpy(&ptemp->request, pcmd, sizeof(StEtermRequest));
    if (arreterm != NULL && arrsize != 0) {
        ptemp->petermarr = (int*)malloc(arrsize*sizeof(int));
        memcpy(ptemp->petermarr, arreterm, arrsize*sizeof(int));
        ptemp->arrsize = arrsize;
    }
    if (m_nsize == 0) {
        m_phead = ptemp;
        m_ptail = ptemp;
    }
    else
    {
        m_ptail->pnext = ptemp;
        ptemp->pprev = m_ptail;
        m_ptail = ptemp;
    }
    ++m_nsize;
}

bool EtermCmdQueue::PopCurItem( StEtermCmdTask* pitem )
{
    if (pitem == NULL || m_nsize <= 0)
        return false;

    if (pitem->pnext != NULL) {
        pitem->pnext->pprev = pitem->pprev;
    }
    else {
        m_ptail = pitem->pprev;
    }
    if (pitem->pprev != NULL) {
        pitem->pprev->pnext = pitem->pnext;
    }else {
        m_phead = pitem->pnext;
    }
    if (pitem->petermarr)
        free(pitem->petermarr);
    free(pitem);
    --m_nsize;
    return true;
}

StEtermCmdTask* EtermCmdQueue::GetHeadItem()
{
    return m_phead;
}

StEtermCmdTask* EtermCmdQueue::GetNextItem( StEtermCmdTask* pcur )
{
    if (pcur == NULL) {
        return NULL;
    }
    return pcur->pnext; 
}

int EtermCmdQueue::GetSize()
{
     return m_nsize;
}