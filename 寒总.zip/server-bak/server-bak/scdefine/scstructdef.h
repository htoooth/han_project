/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-01 14:52:49
# LastModified : 2014-09-03 15:40:27
# FileName     : scstructdef.h
# Description  : 
 ******************************************************************************/
#ifndef _SCSTRUCTDEF_H
#define _SCSTRUCTDEF_H
#include <vector>
#include <stdlib.h>
#pragma pack(4)

// login struct (login server & client)
struct StLoginInfo {
	char	name[40];		// user name
	char	passwd[36];		// password (md5)
	char	mac[16];		// MAC address
	int		version;		// client version
	char	logintype;		// login type see LOGIN_TYPE_XXX
	char	re[3];			
	char	re2[16];
};

// login success return 
struct StCompanyInfo {
	int		idx;				// idx
	char	nickname[40];		// nick name
	int		unitid;				// unit id
	char	unitname[60];		// unit name
	int		companyid;			// company id
	char	companyname[100];	// company name
	char    account[40];        // account
	char    sessionid[36];   //session id
};

struct StVerifyPasswd {
	int		idx;			// idx
	int		pwdtype;		// password type see VERIFY_TYPE_XXX
	char	passwd[36];		// password (MD5)
	char	mac[16];		// MAC address
	char	logintype;		// login type
	char	re[3];
	char	re2[8];
};
struct StFlightInfo{
    int id;
    int isdirectfly;//0:not direct fly 1:direct fly
    int duration;//duration minutes
    int persontype;//person type like chl adl
    int type;//0:single trip -1:go trip -2:return trip
    float discount;//discount percentage less than 1
    float insurance;//insurance
    float airrax;//airrax
    float oil;//oil fee
    float rebate;//rebate float
    float price;// price without tax
    float tax;//tax
    char website[100];//source website
    char aircompany[4];//two code
    char aircompanypicpath[100];//local relative path 
    char flightno[8];//flight no. without two code
    char fromthreeword[4];//from three word
    char frompinyin[24];//from pin yin
    char fromchines[24];// from chinese
    char fromterminal[4];//from terminal
    char tothreeword[4];//to three word
    char topinyin[24];//to pin yin	
    char tochines[24];// to chinese
    char toterminal[4];//to terminal
    char flydate[12];//fly date like 2012-02-11
    char arrivedate[12];//arrive date like 2012-02-11
    char planetype[8];// plane type like A320
    char seattype[4];//cabin type
    char backchangepolicy[1024];//back change policy
    char luggagepolicy[1024];//luggage policy	
    char grade[4];//like cabin level
    char airportfrom[24];//airport from chinese
    char airportto[24];//airport to chinese

};
struct StPassenger
{
	int ptype;		//inland or internate
    int type;		//passenger type 0-N
    int sex;		//sexual
    int idtype;		// id type 0-N
    char name[20];	//passenger name  should be like this firstname/secondname all are English
    char nationality[8]; // nationality
    char issueplace[8];// always same to nationality
    char idnumber[20];// id number
    char validdate[12];//valid date of the id card
    char birthday[12];// birth of the passenger
    char phonenumber[12];//phone number of the passenger
};
struct StInvoice{
	int sendtype;//0:ƽ��,1:���?
	int sum;//default 1200
	char receiver[20]; // receiver
	char tel[12]; // mobile phone
	char addr[120];// address
};
struct StContactor
{
    char name[20];
    char phonenumber[12];
    char email[40];
};
struct StFlightSegment{
    int price;              //price of this segment
    int ticketprice;		//fd/qte/qtb price
	char	cityfrom[4];	//segment from
    char	cityto[4];		//segment to
    char	flightno[8];	//mu1234
    char aircompany[4];	//mu
    char	flydate[8];		//05SEP
    char flytime[8];        //0000
    char	flydate1[12];		//2014-12-19
    char flytime1[12];		//09:55:18
    char cabin[4];      //Y
};
struct StFlightTrip
{
    time_t tripid;            //trip id
    int totalprice;         //all segments' price
    int ourprice;			// our price
    int taxfee;           //all tax fee
    int oilfee;             //all oil fee
    int triptype;			//trip type,0:inland-st 1:inland-rt 2:inland-mt 3:internate-st 4:internate-rt 5:internate-mt
    int segscount;          //count of segs
    char cityfrom[4];    //this first trip city
    char cityto[4];    //this last trip city
    char depaturedate[8];    //the  first trip city flydate  05SEP
    char depaturetime[8];    //the  first trip city flytime 0000
    char depaturedate1[12];    //the  first trip city flydate 2014-12-19
    char depaturetime1[12];    //the  first trip city flytime 09:55:18
    StFlightSegment segs[20];   //less than 20 segs,or not will be error
};
struct StOrderRequest{
    int 	passengercount; // count of passengers
    int	isInvoice;//0:no, 1: yes
    time_t timestamp;	//00212212121
    char	flydate[8];		//05SEP
    char 	tktldate[8];	//05SEP
	char	flytime[8];		//1200
	char 	tktltime[8];	//1200
	char 	officeno[8];	//sh
	char 	submitDate[12];	//2014-12-27
    StContactor contactor;//ticket contactor
    StInvoice invoice;// invoice info
    StFlightTrip trip;			//trips
    StPassenger passengers[20]; // passengers
};

struct StOrderConfirm{
	int oldprice;		//the price before order
	int newprice;		//the price now 
	int basicprice;		//the  ticket price
	char tips[255];		//may be some notice info
};
struct StFlightSearchRequest{
	int type;//single trip, return trip or more trip
	int count;//count of flights
	StFlightInfo flightinfo[10];//flights spider submit
};

struct StOrderResult{
	int idx;		//client id
	int status;	    //order status 1:order success else failed
	int originprice;//origin price
	int ourprice;	//if status = 1, this params is depressed
	char tips[255];
};



struct StClientInfo{
	int idx;//id
	int companyId; // company id
};


enum SearchType{
        SINGLE_INLAND,//inland single trip
        RETURN_INLAND,//inland return trip
        MORE_INLAND,//inland more trip
        SINGLE_FOREING,//foreing single trip
        RETURN_FOREING,//foreing return trip
        MORE_FOREING,//foreing more trip
};

struct StLowerCabinsRequest
{
    char flightNo[8];//ca1234
    char airCompany[4];//CA
    char currentCabin[4];//Y
    char date[8];//05NOV
};
struct StLowerCabinsResponse
{
    int lowerCabinCount;
    char flightNo[8];//ca1234
    char lowerCabins[26];//ABCD...Z
};
struct StNetAddrInfo {
	int		id;
	char	ip[16];
	int		port;
};

struct StNotifyMsg {
	int		ntype;			// msg type see __NOTIFY_MSG_TYPE
	char	head[32];		// head text
	char	msg[256];		// msg text
};

struct StXTYEtermAccontInfo {
	char	name[16];
	char	pwd[16];
	char	ip[16];
	int		port;
	int		sysid;
	int		companyid;
	char	re[8];
};
enum SpecialCommunity
{
    SC_IN , //baby
    SC_CH, //children
    SC_STU, //student
    SC_TEA,//teacher
    SC_EMI, //�����ۿ�                                          
    SC_YTR,// �����ۿ�                                                    
    SC_VFR ,//̽��Ʊ��
    SC_SEA ,//��Ա�ۿ�                                                    
    SC_CMA,//����������/�����
    SC_CMP ,//����������/�����                                                    
    SC_ADT,//����
    SC_CNN,//��ͯ(������С�Ŷ��˼�) 

};
struct StPrice
{
    int total;
    int fare;
    int tax;
};
struct StTraveler
{
    char name[24];
    int sex;    //0:male 1:female
    SpecialCommunity type;
};
struct StSeg
{
    char from[4];    //PEK
    char to[4];         //HKG
    char date[8];   //20FEB
    char time[8];   //0010
    char flightNo[8];   //CA4419
    char currentCabin[4];   //Y
    char availableLowerCabin[12];   //YZ...
    int type;   //0:inland  1:internate
    char dateFormat[12];    //2015-02-02
};
struct StSegs
{
    int segCount;   //max=5
    char from[4];    //PEK
    char to[4];         //PAR
    char aircompany[4] ;    //CA 
    char date[8];   //20FEB
    char time[8];   //0010    
    int type;   //0:inland  1:internate 2:mix
    StSeg segs[5];
};
struct StTrip
{
    int passengerCount; //max = 10
    int segsCount;//max = 5
    int priceInfoCount;
    int type;   //0:inland  1:internate
    StPrice priceInfo[10];
    StTraveler travler[10];
    StSegs segss[5];
};
#pragma pack()
#endif // _PUBDEFINE_H
