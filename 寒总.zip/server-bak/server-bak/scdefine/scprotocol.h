/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-01 16:25:15
# LastModified : 2014-09-03 15:40:28
# FileName     : scprotocol.h
# Description  : 
 ******************************************************************************/
#ifndef _SCPROTOCOL_H
#define _SCPROTOCOL_H

// uMaincmd
enum __CS_MAIN_CMD {
	LOGINSVR_CLIENT_TYPE = 10,
	MAINSVR_CLIENT_TYPE,

	XTYSVR_CLIENT_TYPE = 1000,
};

//uSubcmd LOGINSVR_CLIENT_TYPE
enum __LOGINSVR_CLIENT_TYPE_ {
	LC_VERIFY_USER_PASSWD = 1,
	LC_NOTIFY_SYS_MSG,			// get some message
	LC_MAINSVR_ADDR,			// get main server addr info
	LC_GET_GROUPINFO,			// user company info
};

//uSubcmd MAINSVR_CLIENT_TYPE
enum __MAINSVR_CLIENT_TYPE_ {
	MC_VERIFY_LOGIN_PASSWD = 1,
	MC_FLIGHT_SEARCH_REQUEST,	
    MC_ORDER_REQUEST_RESULT,
    MC_FLIGHT_QUERY_RESULT,
    MC_ORDER_RESULT,
    MC_ORDER_PRICE_DIFF,
    MC_TICKET_PRICE_REQUEST,
    MC_TICKET_PRICE_RESULT,
    MC_LOWER_CABIN_REQUEST,
	MC_LOWER_CABIN_RESULT,
    MC_BEST_CABIN_PRICE,
};

//uSubcmd XTYSVR_CLIENT_TYPE
enum __XTYCVR_CLIENT_TYPE_ {
	XC_VERIFY_KEYWORD = 1,
	XC_XTY_ACCONT_INFO,
};

//verify error code
enum __VERIFY_ERROR_TYPE {
	VERIFY_ERROR_NULL = 1,		// success
	VERIFY_ERROR_NAME,			// name error
	VERIFY_ERROR_PWD,			// passwd error
	VERIFY_ERROR_MAC,			// mac error
	VERIFY_ERROR_VER,			// version error must setup
	VERIFY_ERROR_LOGINED,		// aready login 
	VERIFY_ERROR_UNKNOW = 250,	// unknow error
};

enum __VERIFY_PWD_TYPE {
	VERIFY_TYPE_LOGINPWD = 1,
};

enum __LOGIN_TYPE {
	LOGIN_TYPE_COMPUTER = 1,
	LOGIN_TYPE_ANDROID,
	LOGIN_TYPE_IPHONE,
};

enum __NOTIFY_MSG_TYPE {
	MSG_TYPE_MSGBOX = 0,
};

#endif // _SCPROTOCOL_H
