/*
 * InternateEtermCommandProcessor.h
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#ifndef INTERNATEETERMCOMMANDPROCESSOR_H_
#define INTERNATEETERMCOMMANDPROCESSOR_H_

#include "LowerCabinScanTask.h"

class InternateEtermCommandProcessor: public LowerCabinScanTask
{
public:
	InternateEtermCommandProcessor();
	virtual ~InternateEtermCommandProcessor();
	virtual void doWork();
	int getCmdId() const;
	void setCmdId(int cmdId);

private:
	int cmdId;
};

#endif /* INTERNATEETERMCOMMANDPROCESSOR_H_ */
