/*
 * CommonLib.h
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#ifndef COMMONLIB_H_
#define COMMONLIB_H_
#include <string>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
//#include <>
enum TYPEFORMAT
{
	YYMMDDTOHHMMSS_NO = 0, // 2015-01-08 00:00:00->145121245
	NO_TOYYMMDDHHMMSS, // 145121245->2015-01-08 00:00:00
	MMDD_TOYYMMDD, // 05APR -> 2015-04-05
	YYDDMMTO_MMDD, // 2015-04-05 -> 05APR
	TIMETO_TM, // 1233 -> 12:33
	TM_TOTIME // 12:33 -> 1233
};
class CommonLib
{
public:
	CommonLib();
	virtual ~CommonLib();
	//fetch current timestamp (s not ms)
	static time_t currentTimeStamp();
	static std::string currentDate();
	// date format time_t
	static time_t dateFromatTime(const char*str);
	// time_ format date
	static std::string timeFromatDate(time_t time);
	// day month format year month day
	static std::string dayMonthFormatDate(const char*str);
	// year month day format day month
	static std::string DateFormatdayMonth(const char*str);
	// MMSS format MM:SS
	static std::string timeFormatTimePointTime(const char*str);
	// MM:SS format MMSS
	static std::string timePointTimeFormatTime(const char*str);
	//generate a randomized number between min and max
	static int randomizeNumber(int max,int min);
    //'0'---->0
    static int charToNumber(char src);
    //"s qw r"----->"sqwr"
    static void removeAllBlank(char *src);
    //0-9------>'0'-'9'
    static char integerToChar(int i);
};

#endif /* COMMONLIB_H_ */
