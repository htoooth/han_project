/*
* InternateScanTask.cpp
*
*  Created on: 2015年1月15日
*      Author: Administrator
*/

#include "InternateScanTask.h"
#include "svrloop.h"

InternateScanTask::InternateScanTask()
{
    // TODO Auto-generated constructor stub

}

InternateScanTask::~InternateScanTask()
{
    // TODO Auto-generated destructor stub
}

void InternateScanTask::doWork()
{
    MSGOUT(en_Msg_Debug,"InternateScanTask::doWork in=============================================thread id:%lu", pthread_self());
    if (data->status == SCANSTATUS_PROCESSING)
    {
        LowerCabinOrderData *orderData = data->orderData;
        std::vector<FlightSegment> trips = orderData->trips;
        if(trips.size() < 0)
        {
            MSGOUT(en_Msg_Debug,"seg count error,order id:%d,seg counts:%d",orderData->orderId,trips.size());
            return;
        }
        for (unsigned int i = 0; i < trips.size(); ++i)
        {
            FlightSegment seg = trips[i];
            bool isOk = false;
            //here different with inland av
            std::string strpair = "";
            strpair.append(seg.depature).append(seg.arrival);
            StCommand savCommand = CommandGenerator::generateAv(isOk, seg.flydate,strpair,"H",seg.flytime,seg.aircompany);
            if (!isOk)
            {
                MSGOUT(en_Msg_Debug,"Generate av command error.");
            }
            savCommand.result = NULL;
            savCommand.type = LCAVH;
            StCommands *cmdPatch = new StCommands;
            cmdPatch->clientid = orderData->clientId;
            cmdPatch->identifiers = ServerMain::generateContextKey(data);
            cmdPatch->count = 1;
            cmdPatch->current = 0;
            cmdPatch->commands.push_back(savCommand);
            //send the commands to the ETERM sender app
            printCommands(cmdPatch);
            sendCommands(cmdPatch);
        }
    }
    MSGOUT(en_Msg_Debug,"InternateScanTask::doWork out=============================================thread id:%lu", pthread_self());
}
