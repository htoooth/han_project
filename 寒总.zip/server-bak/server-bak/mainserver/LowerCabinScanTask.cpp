/*
 * LowerCabinScanTask.cpp
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#include "LowerCabinScanTask.h"
#include "svrloop.h"
const std::string LowerCabinScanTask::availableCabinFlags = "ASC0123456789";
const std::string LowerCabinScanTask::commandSpliter = " /:";
const std::string LowerCabinScanTask::paramsSpliter= "/";
int LowerCabinScanTask::uid = 0;

LowerCabinScanTask::LowerCabinScanTask()
:data(NULL),handle(NULL)
{
	// TODO Auto-generated constructor stub

}

LowerCabinScanTask::~LowerCabinScanTask()
{
	// TODO Auto-generated destructor stub
}

LowerCabinScannerData* LowerCabinScanTask::getData() const
{
	return data;
}

void LowerCabinScanTask::setData(LowerCabinScannerData* data)
{
	this->data = data;
}

ServerMain* LowerCabinScanTask::getHandle() const
{
	return handle;
}

void LowerCabinScanTask::setHandle(ServerMain* handle)
{
	this->handle = handle;
}

void LowerCabinScanTask::sendCommands(StCommands* cmdPatch)
{

	//TODO:send eterm command
	MSGOUT(en_Msg_Debug,	"LowerCabinScanTask::sendCommands in========commands identifier:%s,commands size:%d=========",cmdPatch->identifiers.c_str(),cmdPatch->commands.size());
	if(handle != NULL)
	{
        printCommands(cmdPatch);
		handle->PostEventResult(DB_SEND_LOWERCABIN_COMMAND,0,&cmdPatch,sizeof(cmdPatch),NULL);
	}
	else
	{
		MSGOUT(en_Msg_Debug,	"LowerCabinScanTask::sendCommands handle is NULL");
	}
	MSGOUT(en_Msg_Debug,	"LowerCabinScanTask::sendCommands out====================================");
}

StCommand* LowerCabinScanTask::getCommandByCmdId(int cmdId)
{
	StCommand *cRet = NULL;
	std::vector<StCommand *> results= data->recvCommandData;
	int count =results.size();
	if(count > 0)
	{
		for (int i = count-1; i >= 0 ; --i)
		{
			cRet = results[i];
			if(cRet->identifyId == cmdId)
			{
				break;
			}
			else
			{
				cRet = NULL;
			}
		}
	}
	return cRet;
}

LowerCabinFlightCabins LowerCabinScanTask::getFlightCabinSettingByFlightNo(
		std::string flightNo,std::vector<LowerCabinFlightCabins> cabins)
{
	LowerCabinFlightCabins cabinSetting;
	int count = cabins.size();
	for (int i = 0; i < count; ++i)
	{
		if(flightNo.compare(cabins[i].flightNo) == 0)
		{
			cabinSetting = cabins[i];
			break;
		}
	}
	return cabinSetting;
}

std::string LowerCabinScanTask::getFlightNoFromAVSCommand(
		std::string avsCommand)
{
	std::string sRet = "";
	int firstSpliterIndex = avsCommand.find_first_of(commandSpliter);
	std::string cmdContent =  avsCommand.substr(firstSpliterIndex+1);
	firstSpliterIndex = cmdContent.find_first_of(commandSpliter);
	sRet = cmdContent.substr(0,firstSpliterIndex-1);
	return sRet;
}

std::map<char, char> LowerCabinScanTask::generateCabinMap(avscabin scabins)
{
	std::map<char, char> cabinMap;
	for (int i = 0; i < scabins.cabincount; ++i)
	{
		cabinMap[scabins.cabins[i][0]] =scabins.cabins[i][1] ;
	}
	return cabinMap;
}

std::map<char,char> LowerCabinScanTask::generateCabinMap( AvhResults* avhResult ,std::string flightNo)
{
    std::map<char, char> cabinMap;
    AvhResults*current = avhResult;
    while (current != NULL)
    {
        avhtravelInfo *avhInfo = current->avhInfo;
        if (std::string(avhInfo->pinfo->airnumber).compare(flightNo) == 0)
        {
            //find the matched flight
            avhInfoEx* infoex= avhInfo->pinfoex;
            for (int i = 0 ; i < infoex->count ; ++i)
            {
                cabinMap[infoex->detail[i][0]] = infoex->detail[i][1];
            }
            break;
        }
        
        current = current->next;
    }
    return cabinMap;
}

std::string LowerCabinScanTask::cityPairFromAvhCommand( std::string avhCommand )
{
    std::string sRet = "";
    int firstSpliterIndex = avhCommand.find_first_of("/");
    std::string cmdContent =  avhCommand.substr(firstSpliterIndex+1);
    firstSpliterIndex = cmdContent.find_first_of("/");
    sRet = cmdContent.substr(0,firstSpliterIndex-1);
    return sRet;
}

AvhResults * LowerCabinScanTask::makeAvhInfos( avhtravelInfo** avhResult, int count )
{
    AvhResults *header = NULL;
    AvhResults *current = NULL;
    for (int i = 0 ; i < count ; ++i)
    {
        avhtravelInfo* info = new avhtravelInfo;
        memcpy(info,avhResult[i],sizeof(avhtravelInfo));
        AvhResults *result = new AvhResults;
        result->avhInfo = info;
        result->next = NULL;
        if (header == NULL)
        {
             header = result;
             current = result;
        }
        else
        {
            current->next = result;
            current = current->next;
        }
    }
    return header;
}

PatResults * LowerCabinScanTask::makePatInfos( patpriceinfo** patResult,int count )
{
    PatResults *header = NULL;
    PatResults *current = NULL;
    for (int i = 0 ; i < count ; ++i)
    {
        patpriceinfo* info = new patpriceinfo;
        memcpy(info,patResult[i],sizeof(patpriceinfo));
        PatResults *result = new PatResults;
        result->patInfo = info;
        result->next = NULL;
        if (header == NULL)
        {
            header = result;
            current = result;
        }
        else
        {
            current->next = result;
            current = current->next;
        }
    }
    return header;
}

int LowerCabinScanTask::getUid()
{
    pthread_mutex_lock(&ServerMain::uidMutex);
    int id = ++LowerCabinScanTask::uid;
    pthread_mutex_unlock(&ServerMain::uidMutex);
    return id;
}

void LowerCabinScanTask::printCommands( StCommands * commands )
{
    for (int i = 0 ; i < commands->count ; ++i)
    {
        StCommand &command = commands->commands[i];
        MSGOUT(en_Msg_Debug,"ptr:%p, commands status: %d current: %d, command: %d content: %s,status: %d,type: %d",
            commands, commands->status, commands->current, i, command.content, command.status, command.type);
    }
}


