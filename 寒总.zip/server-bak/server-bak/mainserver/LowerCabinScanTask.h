/*
 * LowerCabinScanTask.h
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#ifndef LOWERCABINSCANTASK_H_
#define LOWERCABINSCANTASK_H_
#include "structs.h"
#include "showmsg.h"
#include "CommandGenerator.h"
#include "dbdefine.h"
#include <map>
class ServerMain;
class LowerCabinScanTask
{
public:
	LowerCabinScanTask();
	virtual ~LowerCabinScanTask();
	//handle task
	virtual void doWork() = 0;
	LowerCabinScannerData* getData() const;
	void setData(LowerCabinScannerData* data);
	void sendCommands(StCommands *cmdPatch);

	ServerMain* getHandle() const;
	void setHandle(ServerMain* handle);
    static AvhResults *makeAvhInfos(avhtravelInfo** avhResult, int count);
    static PatResults *makePatInfos(patpriceinfo** patResult,int count);
    static int uid;
    static int getUid();
protected:
	StCommand *getCommandByCmdId(int cmdId);
	LowerCabinFlightCabins getFlightCabinSettingByFlightNo(std::string flightNo,std::vector<LowerCabinFlightCabins> cabins);
	std::string getFlightNoFromAVSCommand(std::string avsCommand);
	std::map<char,char> generateCabinMap(avscabin scabins);
    std::map<char,char> generateCabinMap(AvhResults* avhResult,std::string flightNo);
    std::string cityPairFromAvhCommand(std::string avhCommand);
    void printCommands(StCommands * commands);
protected:
	LowerCabinScannerData *data;
	ServerMain *handle;
	static  const std::string availableCabinFlags;
	static  const std::string commandSpliter;
	static const std::string paramsSpliter;
};

#endif /* LOWERCABINSCANTASK_H_ */
