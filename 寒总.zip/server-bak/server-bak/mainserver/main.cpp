/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-26 17:53:54
# LastModified : 2014-11-04 16:18:30
# FileName     : main.cpp
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

#include "showmsg.h"
#include "readconf.h"
#include "svrloop.h"
#include "dbevent.h"
#include "CommonLib.h"

int main(int argc, char *argv[]) {

	/*std::string todayFrom = CommonLib::currentDate().append(" 00:00:00");
	msgOut(en_Msg_Error, "%ld,%s",CommonLib::dateFromatTime(todayFrom.c_str()),todayFrom.c_str());
	return 0;*/
	ReadConf cf;
	cf.readfile("server.conf");

	char buf[40] = {0};
	cf.getvalue("bindport", buf, sizeof(buf));
	short port = atoi(buf);
	if(port <= 0) {
		msgOut(en_Msg_Error, "main readconf bind port error!!!");
		return 1;
	}

	memset(buf, 0, sizeof(buf));
	cf.getvalue("dbthread", buf, sizeof(buf));
	unsigned int n = atoi(buf);
	if(n <=0 )
		n = 2;

	memset(buf, 0, sizeof(buf));
	cf.getvalue("logfile", buf, sizeof(buf));

	FILE* pf = NULL;
	if(strcmp(buf, "stderr") != 0) {
		pf = fopen(buf, "ab");
		if(pf != NULL)
			setWriteFile(pf);
	}

	msgOut(en_Msg_Normal, "<-----------------start---------------->");

	ServerMain svr;
	MysqlHandle sql;
	if(!svr.StartServer(&sql, port, en_Server_Connect, n)) {
		svr.StopServer();
	}

	if(pf != NULL)
		fclose(pf);

	msgOut(en_Msg_Normal, "<-----------------end---------------->");
	
	return 0;
}
