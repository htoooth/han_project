/*******************************************************************************
 # Author       : zenghao
 # Email        : zenghao.1989@163.com
 # CreateTime   : 2014-12-26 16:51:09
 # LastModified : 2014-12-26 16:57:25
 # FileName     : dbevent.h
 # Description  :
 ******************************************************************************/
/*******************************************************************************
 # Author       : zenghao
 # Email        : zenghao.1989@163.com
 # CreateTime   : 2014-03-25 15:31:43
 # LastModified : 2014-04-15 11:21:28
 # FileName     : dbevent.h
 # Description  :
 ******************************************************************************/
#ifndef _DBEVENT_H
#define _DBEVENT_H
#include <pthread.h>
#include <semaphore.h>
#include <queue>
#include <list>
#include <map>
#include "baseserver.h"
#include "queuebase.h"
#include "mysqlmgr.h"
#include "readconf.h"
#include "scstructdef.h"
#include "ssstructdef.h"
#include "ETermString.h"
#include "CommandGenerator.h"
#include <string>
#include "CommonLib.h"
#include "LowerCabinScanTask.h"
#include "InlandScanTask.h"
#include "InternateScanTask.h"
#include "InlandEtermCommandProcessor.h"
#include "InternateEtermCommandProcessor.h"
#include "svrloop.h"
#define MAX_DIFF_PRICE 100
#define MAX_THREAD_COUNT 10
class MysqlHandle: public QueueEventModule
{
public:
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual void SettleQueueEvent(int maincmd, int assistcmd, void* pdata,
			unsigned int ulen, void* pclient);
	MysqlHandle();
	//send lower cabin ETERM commands
	void sendCommands(StCommands *cmdPatch);
protected:
	DataBaseClass* m_psqlmgr;
	CETermString sEterm;
protected:
	void verifyloginpwd(MYSQL* psql, int maincmd, int assistcmd, void* pdata,unsigned int ulen, void* pclient);
	void readyverifykey(MYSQL* psql, int maincmd, int assistcmd, void* pdata,unsigned int ulen, void* pclient);
	void dealorderrequest(MYSQL* psql, int maincmd, int assistcmd, void* pdata,unsigned int ulen, void* pclient);
	void dealflightsearchrequest(MYSQL* psql, int maincmd, int assistcmd,	void* pdata, unsigned int ulen, void* pclient);
	void dealcommandresult(MYSQL* psql, int maincmd, int assistcmd, void* pdata,	unsigned int ulen, void* pclient);
	void dealcabinpricerequest(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient);
	void dealorderpnrresult(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient);
	void dealorderfdresult(MYSQL* psql, int maincmd, int assistcmd, void* pdata,	unsigned int ulen, void* pclient);
	void dealticketpricerequest(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient);
	void deallowercabinsrequest(MYSQL* psql, int maincmd, int assistcmd,	void* pdata, unsigned int ulen, void* pclient);
	void deallowercabinsresult(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient);
    void deallowercabinpatresult(MYSQL* psql, int maincmd, int assistcmd,  void* pdata, unsigned int ulen, void* pclient);
    void dealorderfsdresult( MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient );
    void dealbestcabinpriceresult( MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient );
	void singletriprequest(StFlightInfo &flightinfo, SearchType type);
	void returntriprequest(StFlightInfo &flightinfo, SearchType type);
	void moretriprequest(StFlightInfo &flightinfo, SearchType type);
	void unknowntriprequest(StFlightInfo &flightinfo, SearchType type);
	void generateOrderCommand(StOrderRequest * orderReqest,StCommands *commands);
	void sendCommands(StCommands *cmdPatch, int fd);
	void sendData(char *data, int len, int fd);
	/**
	 * @function 获取舱位价格信息
	 * @params triptype: 0: single trip 1:return trip
	 * @return less than 0:no valid price
	 */
    int getInlandCabinPrice(MYSQL* psql, std::string aircompany, std::string citypair,std::string date, std::string cabin,int triptype=0);
    int getInternateCabinPrice(MYSQL* psql, std::string aircompany, std::string citypair,std::string date, std::string cabin,int triptype=0);
	void saveCabinPriceInfo(MYSQL* psql, fdpriceinfo *priceInfo);
    void saveCabinPriceInfo(MYSQL* psql, fsdpriceinfo_s *priceInfo);
	/**
	 * @function 获取政策后的价格
	 * @params trip:已经有面价的航程信息
	 * @return null
	 */
	void pricePolicyFilters(StFlightTrip *trip);
	/**
	 * @function 保存PNR结果
	 * @params orderRequest:订单请求的详细信息 result:订单PNR结果
	 * @return null
	 */
	void saveOrderInfo(MYSQL* psql, StOrderRequest * orderRequest,	OrderResultInfo *result, int clientId, bool &isOk);
	/**
	 * @function 更新订单中的发票信息
	 * @params invoiceInfo:订单发票信息 hasInvoice:是否需要发票
	 * @return null
	 */
	void saveOrderInvoiceInfo(MYSQL* psql, StInvoice invoiceInfo,	int hasInvoice, int orderId, bool &isOk);
	/**
	 * @function 更新订单中的政策和退改签等信息
	 * @params tripInfo:行程信息
	 * @return null
	 */
	void saveOrderTypeOtherInfo(MYSQL* psql, StFlightTrip tripInfo, int orderId,	bool &isOk);
	/**
	 * @function 更新订单价格信息
	 * @params order:订单请求信息
	 * @return int
	 */
	int saveOrderPriceInfo(MYSQL* psql, StOrderRequest* order,OrderResultInfo* result, int orderId, bool &isOk);
	/**
	 * @function 更新订单票信息
	 * @params order:订单请求信息
	 * @return int
	 */
	int saveOrderTicketInfo(MYSQL* psql, StOrderRequest* order,OrderResultInfo* result, int orderId, int passengerId, int priceId,
			bool &isOk);
	/**
	 * @function 更新订单票对应的乘客信息
	 * @params passenger:订单乘客信息
	 * @return int
	 */
	int saveOrderPassengerInfo(MYSQL* psql, StPassenger passenger, int orderId,int clientId, bool &isOk);
	/**
	 * @function 更新订单票对应的航班信息
	 * @params segment:订单结果
	 * @return int
	 */
	int saveOrderFlightInfo(MYSQL* psql, FlightSegment segment, int orderId,	int clientId, bool &isOk);
	/**
	 * @function 更新订单票编号信息
	 * @params date:订单日期 type:订单类型
	 * @return int
	 */
	void saveOrderSeriaNoInfo(MYSQL* psql, int orderId, const char *date,	const char *type, bool &isOk);

	void generateInlandSCommand(StOrderRequest * orderReqest,	StCommands *commands);
	void generateInlandRCommand(StOrderRequest * orderReqest,	StCommands *commands);
	void generateInlandMCommand(StOrderRequest * orderReqest,StCommands *commands);
	void generateInternateSCommand(StOrderRequest * orderReqest,StCommands *commands);
	void generateInternateRCommand(StOrderRequest * orderReqest,	StCommands *commands);
	void generateInternateMCommand(StOrderRequest * orderReqest,StCommands *commands);

	std::string generateFixLengthString(long source, int len = 8);
	//load lower cabin order data
	LowerCabinScannerData* loadLowerCabinOrderData(MYSQL* psql,int count = -1);

	/*********test**********/
	LowerCabinOrderData* initOrderData();
	LowerCabinSettings * initSettingData();
	LowerUserData * initUserData();
    void loadAirCompanyCabinMap(MYSQL* psql);

    /*********test**********/

};

#endif // _DBEVENT_H
