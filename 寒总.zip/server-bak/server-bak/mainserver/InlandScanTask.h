/*
 * InlandScanTask.h
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#ifndef INLANDSCANTASK_H_
#define INLANDSCANTASK_H_

#include "LowerCabinScanTask.h"

class InlandScanTask: public LowerCabinScanTask
{
public:
	InlandScanTask();
	virtual ~InlandScanTask();
	virtual void doWork();
};

#endif /* INLANDSCANTASK_H_ */
