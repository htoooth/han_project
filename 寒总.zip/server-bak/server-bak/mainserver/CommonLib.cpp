/*
 * CommonLib.cpp
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#include "CommonLib.h"

CommonLib::CommonLib()
{
	// TODO Auto-generated constructor stub

}

CommonLib::~CommonLib()
{
	// TODO Auto-generated destructor stub
}

time_t CommonLib::currentTimeStamp()
{
	time_t timestamp = 0;
	struct timeval tp;
	struct timezone tz;
	gettimeofday(&tp, &tz);
	timestamp = tp.tv_sec;
	return timestamp;
}
std::string CommonLib::currentDate()
{
	std::string sRet = "";
	char buf[30];
	memset(buf, 0, sizeof(buf) * sizeof(char));
	time_t tt = time(NULL);
	tm* t = localtime(&tt);
	sprintf(buf, "%d-%d-%d", t->tm_year + 1900, t->tm_mon + 1, t->tm_mday);
	sRet = sRet.append(buf);
	return sRet;
}
time_t CommonLib::dateFromatTime(const char*str)
{

	if (str == NULL)
	{
		return -1;
	}

	struct tm tm1;
	memset(&tm1,0,sizeof(tm1));
	if (-1
			== sscanf(str, "%d-%d-%d %d:%d:%d", &tm1.tm_year, &tm1.tm_mon,
					&tm1.tm_mday, &tm1.tm_hour, &tm1.tm_min, &tm1.tm_sec))
		return -1;
	tm1.tm_year -= 1900;
	tm1.tm_mon -= 1;
	time_t timet = mktime(&tm1);
	return timet;

}
std::string CommonLib::timeFromatDate(time_t time)
{
	struct tm *local =
	{ 0 };
	local = localtime(&time);
	char buf[128] =
	{ 0 };
	sprintf(buf, "%d-%d-%d %d:%d:%d", local->tm_year + 1900, local->tm_mon + 1,
			local->tm_mday, local->tm_hour, local->tm_min, local->tm_sec);
	return buf;
}
std::string CommonLib::dayMonthFormatDate(const char*str)
{

	if (strlen(str) == 0)
	{
		return "";
	}
	const char *pMonth[12] =
	{ "JAN", "FEB", "MAR", "ARI", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT",
			"NOV", "DEC" };

	std::string strDate(str);
	if (strDate.length() < 6)
	{
		std::string strDay = strDate.substr(0, 2);
		std::string strMont = strDate.substr(2, 3);
		struct tm *local =
		{ 0 };
		time_t timetm = time(NULL);
		local = localtime(&timetm);
		char year[10] =
		{ 0 };
		int nMonth = -1;
		sprintf(year, "%d", local->tm_year + 1900);
		for (int i = 0; i < 12; i++)
		{
			if (pMonth[i] == strMont)
			{
				nMonth = i + 1;
				break;
			}
		}
		if (nMonth == -1)
		{
			return "";
		}
		char buf[128] =
		{ 0 };
		sprintf(buf, "%s-%02d-%s", year, nMonth, strDay.c_str());
		return buf;
	}
	else
	{
		return "";
	}

}
std::string CommonLib::DateFormatdayMonth(const char*str)
{

	if (strlen(str) == 0)
	{
		return "";
	}
	const char *pMonth[12] =
	{ "JAN", "FEB", "MAR", "ARI", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT",
			"NOV", "DEC" };

	std::string strDate(str);
	strDate = strDate + " 00:00:00";
    struct tm tm1 ;
    memset(&tm1,0,sizeof(tm1));
	int year, mon, mday, hour, min, sec;
	if (-1
			== sscanf(strDate.c_str(), "%d-%d-%d %d:%d:%d", &year, &mon, &mday,
					&hour, &min, &sec))
		return NULL;
	tm1.tm_year = year - 1900;

	std::string strMonth = "";
	strMonth = pMonth[mon - 1];
	char buf[128] =
	{ 0 };
	sprintf(buf, "%d%s", mday, strMonth.c_str());
	return buf;

}
std::string CommonLib::timeFormatTimePointTime(const char*str)
{
	std::string strDate(str);
	if (strlen(str) != 4)
	{
		return "";
	}
	std::string strMin = strDate.substr(0, 2);
	std::string strSec = strDate.substr(2, 2);
	char buf[128] =
	{ 0 };
	sprintf(buf, "%s:%s", strMin.c_str(), strSec.c_str());
	return buf;
}
std::string CommonLib::timePointTimeFormatTime(const char*str)
{

	std::string strDate(str);

	if (strlen(str) != 5)
	{
		return "";
	}
	std::string strMin = strDate.substr(0, 2);
	std::string strSec = strDate.substr(3, 2);
	char buf[128] =
	{ 0 };
	sprintf(buf, "%s%s", strMin.c_str(), strSec.c_str());
	return buf;
}

int CommonLib::randomizeNumber(int max, int min)
{
	int iRet = 0;
	srand((unsigned)time(0));
	iRet = rand() % max +min;
	return iRet;
}

int CommonLib::charToNumber( char src )
{
    int iRet = -1;
    if (src >= 30 && src <= 39)
    {
        iRet = src -30;
    }
    return iRet;
}

void CommonLib::removeAllBlank( char *src )
{
    int len = strlen(src);
    char *buf = new char(len+1);
    memset(buf,0,len+1);
    strcpy(buf,src);
    memset(src,0,len);
    int current = 0;
    for (int i = 0 ; i < len ; ++i)
    {
        if (buf[i] != ' ' && buf[i] != '\r' && buf[i] != '\n' && buf[i] != '\t')
        {
            src[current] = buf[i];
            ++current;
        }
    }
}

char CommonLib::integerToChar( int i )
{
    char cRet = '\0';
    cRet = i+30;
    return cRet;
}
