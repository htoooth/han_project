/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-01 18:13:23
# LastModified : 2014-06-25 19:50:40
# FileName     : dbdefine.h
# Description  : 
 ******************************************************************************/
#ifndef _DBDEFINE_H
#define _DBDEFINE_H

enum {
	DB_VERIFY_LOGINPWD = 1,	// normal user login
	DB_LOGINSVR_READY,		// ready login loginserver
	DB_LOGINSVR_RECON,		// re connect login loginserver
	DB_LOGIN_LOGINSVROK,	// login login server success
	DB_ORDER_REQUEST, 		//order request
	DB_FLIGHT_SEARCH_REQUEST,// flight search request
	DB_COMMAND_RESULT, // eterm command result
	DB_LOWERCABIN_COMMAND_RESULT,//lower cabin eterm command result
	DB_CABINPRICE_REQUEST, //look cabin price from db
	DB_CABINPRICE_FROMETERM_REQUEST,//fetch cabin price from eterm
	DB_CABINPRICE_FROMETERM_FD,	//cabin price from eterm fd
    DB_CABINPRICE_FROMETERM_FSD,	//cabin price from eterm fSd

	DB_ORDER_PNR_RESULT,	//order result
	DB_TICKET_PRICE_REQUEST, //ticket price request
	DB_LOWER_CABIN_REQUEST, //lower cabin request

	DB_SEND_DATA,			//send data from db
	DB_SEND_COMMAND,		//send command from db
	DB_SEND_LOWERCABIN_COMMAND, //send lower cabin command from db

	DB_LOWERCABIN_SETTINGAV_RESULT,//lower cabin setting av result
    DB_LOWERCABIN_PAT_RESULT,// lower cabin pad result

	DB_START_LOWER_CABIN_SCANNER,//signal to start lower cabin scanner
	DB_LC_SAV_RESULT,	//lower cabin sav result
	DB_LC_AV_RESULT,	//lower cabin av result

    DB_BEST_CABIN_PRICE_REQUEST,                            

    DB_LOAD_CABIN_MAP,

    DB_ETERMSVR_RECON,		// re connect login loginserver
};

enum {
	DB_ERROR_PARAMERR = 1,
	DB_ERROR_PROCERR,
};

#endif // _DBDEFINE_H
