#include "CommandGenerator.h"
#include "scstructdef.h"

#include "showmsg.h"

CommandGenerator::CommandGenerator(void)
{
	///
}

CommandGenerator::~CommandGenerator(void)
{
}

StCommand CommandGenerator::generateAb(bool &isOk, std::string date,	std::string citypair/*=","*/, std::string cabin /*= ","*/,std::string aircompany /*=""*/)
{
	isOk = true;
	StCommand ab;
	ab.status = WAITING;
	ab.type = AB;
	if (date.length() != 5)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "AB:";
		content.append(date).append("/").append(citypair).append("/").append(
				cabin);
		if (aircompany.length() > 0)
		{
			content.append("/").append(aircompany);
		}
		//copy command to stcommand
		strcpy(ab.content, content.c_str());
	}
	return ab;
}

StCommand CommandGenerator::generateAsr(bool &isOk, std::string segno,std::string citypair, std::string seatno)
{
	isOk = true;
	StCommand asr;
	asr.status = WAITING;
	asr.type = ASR;
	if (segno.length() <= 0 || citypair.length() <= 0 || seatno.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "ASR:";
		content.append(segno).append("/").append(citypair).append("/").append(
				seatno);
		//copy command to stcommand
		strcpy(asr.content, content.c_str());
	}
	return asr;
}

StCommand CommandGenerator::generateAv(bool &isOk, std::string date,std::string citypair, std::string showparams /*= ""*/,std::string dtime /*= ""*/, std::string aircompany/*=""*/,std::string limits/*=""*/)
{
	isOk = true;
	StCommand av;
	av.status = WAITING;
	av.type = AV;
	if (date.length() != 5 || citypair.length() != 6)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "AV:";
		content.append(showparams).append("/").append(citypair).append("/").append(	date);
		if (dtime.length() > 0)
		{
			content.append("/").append(dtime);
		}
		if (aircompany.length() > 0)
		{
			content.append("/").append(aircompany);
		}
		if (limits.length() > 0)
		{
			content.append("/").append(limits);
		}
		//copy command to stcommand
		strcpy(av.content, content.c_str());
	}
	return av;
}

StCommand CommandGenerator::generateDstr(bool &isOk, std::string type,std::string extra)
{
	isOk = true;
	StCommand dstr;
	dstr.status = WAITING;
	dstr.type = DSTR;
	if (type.length() <= 0 || extra.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "DSTR:";
		content.append(type).append("/").append(extra);
		//copy command to stcommand
		strcpy(dstr.content, content.c_str());
	}
	return dstr;
}

StCommand CommandGenerator::generateOrderFd(bool &isOk, std::string date,	std::string citypair, std::string aircompany)
{
	isOk = true;
	StCommand fd;
	fd.status = WAITING;
	fd.type = ORDERFD;
	if (date.length() <= 0 || citypair.length() <= 0
			|| aircompany.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "FD:";
		content.append(citypair).append("/").append(date).append("/").append(
				aircompany);
		//copy command to stcommand
		strcpy(fd.content, content.c_str());
	}
	return fd;
}

StCommand CommandGenerator::generateFf(bool &isOk, std::string flightno,	std::string date)
{
	isOk = true;
	StCommand ff;
	ff.status = WAITING;
	ff.type = FF;
	if (flightno.length() <= 0 || date.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "FF:";
		content.append(flightno).append("/").append(date);
		//copy command to stcommand
		strcpy(ff.content, content.c_str());
	}
	return ff;
}

StCommand CommandGenerator::generateFv(bool &isOk, std::string date,std::string citypair, std::string showparams /*= "H"*/,std::string dtime /*= ""*/, std::string aircompany/*=""*/,	std::string limits/*=""*/)
{
	isOk = true;
	StCommand fv;
	fv.status = WAITING;
	fv.type = FV;
	if (date.length() != 5 || citypair.length() != 6)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "FV:";
		content.append(showparams).append("/").append(citypair).append("/").append(
				date);
		if (dtime.length() > 0)
		{
			content.append("/").append(dtime);
		}
		if (aircompany.length() > 0)
		{
			content.append("/").append(aircompany);
		}
		if (limits.length() > 0)
		{
			content.append("/").append(limits);
		}
		//copy command to stcommand
		strcpy(fv.content, content.c_str());
	}
	return fv;
}

StCommand CommandGenerator::generateMl(bool &isOk, std::string options,std::string flightno, std::string date, std::string pnr/*=""*/)
{
	isOk = true;
	StCommand ml;
	ml.status = WAITING;
	ml.type = MI;
	if (flightno.length() <= 0 || date.length() <= 0 || options.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "MI:";
		content.append(options);
		if (pnr.length() > 0)
		{
			content.append("/").append(pnr);
		}
		content.append("/").append(flightno).append("/").append(date);
		//copy command to stcommand
		strcpy(ml.content, content.c_str());
	}
	return ml;
}

StCommand CommandGenerator::generateNfd(bool &isOk, std::string citypair,std::string aircompany)
{
	isOk = true;
	StCommand nfd;
	nfd.status = WAITING;
	nfd.type = NFD;
	if (citypair.length() <= 0 || aircompany.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "NFD:";
		content.append(citypair).append("/").append(aircompany);
		//copy command to stcommand
		strcpy(nfd.content, content.c_str());
	}
	return nfd;
}

StCommand CommandGenerator::generatePat(bool &isOk,std::string options /*= "A"*/, std::string count /*=""*/)
{
	isOk = true;
	StCommand pat;
	pat.status = WAITING;
	pat.type = PAT;
	if (options.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "PAT:";
		content.append(options).append("/").append(count);
		//copy command to stcommand
		strcpy(pat.content, content.c_str());
	}
	return pat;
}

StCommand CommandGenerator::generatePb(bool &isOk, std::string count /*= "1"*/)
{
	isOk = true;
	StCommand pb;
	pb.status = WAITING;
	pb.type = PB;
	if (count.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "PB:";
		content.append(count);
		//copy command to stcommand
		strcpy(pb.content, content.c_str());
	}
	return pb;
}

StCommand CommandGenerator::generatePf(bool &isOk, std::string count /*= "1"*/)
{
	isOk = true;
	StCommand pf;
	pf.status = WAITING;
	pf.type = PB;
	if (count.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "PB:";
		content.append(count);
		//copy command to stcommand
		strcpy(pf.content, content.c_str());
	}
	return pf;
}

StCommand CommandGenerator::generateQtb(bool &isOk, std::string aircompany,	std::string cabintype /*= ""*/)
{
	isOk = true;
	StCommand qtb;
	qtb.status = WAITING;
	qtb.type = QTB;
	if (aircompany.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "QTB:/";
		content.append(aircompany);
		if (cabintype.length() > 0)
		{
			content.append("/").append(cabintype);
		}
		//copy command to stcommand
		strcpy(qtb.content, content.c_str());
	}
	return qtb;
}

StCommand CommandGenerator::generateQte(bool &isOk, std::string options)
{
	isOk = true;
	StCommand qte;
	qte.status = WAITING;
	qte.type = QTE;
	std::string content = "";
	content = "QTE/";
	if (options.length() > 0)
	{
		content.append(options);
	}
	//copy command to stcommand
	strcpy(qte.content, content.c_str());
	return qte;
}

StCommand CommandGenerator::generateSk(bool &isOk, std::string date,std::string citypair, std::string showparams /*= "H"*/,std::string dtime /*= ""*/, std::string aircompany/*=""*/,	std::string cabin/*=""*/)
{
	isOk = true;
	StCommand sk;
	sk.status = WAITING;
	sk.type = SK;
	if (date.length() != 5 || citypair.length() != 6)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "SK:";
		content.append(showparams).append("/").append(citypair).append("/").append(
				date);
		if (dtime.length() > 0)
		{
			content.append("/").append(dtime);
		}
		if (aircompany.length() > 0)
		{
			content.append("/").append(aircompany);
		}
		if (cabin.length() > 0)
		{
			content.append("/").append(cabin);
		}
		//copy command to stcommand
		strcpy(sk.content, content.c_str());
	}
	return sk;
}

StCommand CommandGenerator::generateTktv(bool &isOk,std::string passengercount/*=""*/, std::string aircompany/*=""*/,	std::string passengertype/*=""*/)
{
	isOk = true;
	StCommand tktv;
	tktv.status = WAITING;
	tktv.type = TKTV;
	std::string content = "";
	content = "TKTV:1";

	if (passengercount.length() > 0)
	{
		content.append("/p").append(passengercount);
	}
	if (aircompany.length() > 0)
	{
		content.append("/").append(aircompany);
	}
	if (passengertype.length() > 0)
	{
		content.append("/").append(passengertype);
	}
	//copy command to stcommand
	strcpy(tktv.content, content.c_str());
	return tktv;
}

StCommand CommandGenerator::generateTol(bool &isOk,std::string options /*= ""*/)
{
	isOk = true;
	StCommand tol;
	tol.status = WAITING;
	tol.type = TOL;
	std::string content = "";
	content = "TOL:";
	if (options.length() < 0)
	{
		content.append(options);
	}
	//copy command to stcommand
	strcpy(tol.content, content.c_str());
	return tol;
}

StCommand CommandGenerator::generateTpr(bool &isOk, std::string printno,std::string date, std::string options /*= ""*/,	std::string options1 /*= ""*/)
{
	isOk = true;
	StCommand tpr;
	tpr.status = WAITING;
	tpr.type = TPR;
	if (date.length() <= 0 || printno.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "TPR:";

		if (options.length() > 0)
		{
			content.append(options);
			content.append("/").append(printno).append("/").append(date);
		}
		else
		{
			content.append(printno).append("/").append(date);
		}
		if (options1.length() > 0)
		{
			content.append("/").append(options1);
		}
		//copy command to stcommand
		strcpy(tpr.content, content.c_str());
	}
	return tpr;
}

StCommand CommandGenerator::generateXsfsd(bool &isOk, std::string citypair,std::string aircompany)
{
	isOk = true;
	StCommand xsfsd;
	xsfsd.status = WAITING;
	xsfsd.type = XSFSD;
	if (citypair.length() <= 0 || aircompany.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "XS FSD ";
		content.append(citypair).append("/").append(aircompany);
		//copy command to stcommand
		strcpy(xsfsd.content, content.c_str());
	}
	return xsfsd;
}

StCommand CommandGenerator::generateXsfsg(bool &isOk, std::string sno,std::string pos /*= ""*/)
{
	isOk = true;
	StCommand xsfsg;
	xsfsg.status = WAITING;
	xsfsg.type = XSFSG;
	if (sno.length() <= 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "XS FSG ";
		content.append(sno);
		if (pos.length() > 0)
			content.append("/").append(pos);
		//copy command to stcommand
		strcpy(xsfsg.content, content.c_str());
	}
	return xsfsg;
}

StCommand CommandGenerator::generatePn()
{
	StCommand pn;
	pn.status = WAITING;
	pn.type = PN;
	strcpy(pn.content, "pn");
	return pn;
}

StCommand CommandGenerator::generateXsfspn()
{
	StCommand xsfspn;
	xsfspn.status = WAITING;
	xsfspn.type = XSFSPN;
	strcpy(xsfspn.content, "xs fspn");
	return xsfspn;
}

StCommand CommandGenerator::generateSpecialAv(bool &isOk, std::string flightno,	std::string date)
{
	isOk = true;
	StCommand sav;
	sav.status = WAITING;
	sav.type = SPECIALAV;
	if (flightno.length() < 0 || date.length() < 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "AV:";
		content.append(flightno).append("/").append(date);
		strcpy(sav.content, content.c_str());
    }
    MSGOUT(en_Msg_Debug, "create Cmd: %s", sav.content);
	return sav;
}

StCommand CommandGenerator::generateFd(bool& isOk, std::string citypair,	std::string date, std::string aircompany)
{
	isOk = true;
	StCommand fd;
	fd.status = WAITING;
	fd.type = FD;
	if (citypair.length() < 0 || date.length() < 0 ||aircompany.length() < 0)
	{
		isOk = false;
	}
	else
	{
		std::string content = "";
		content = "FD:";
		content.append(citypair).append("/").append(date).append("/").append(aircompany);
		strcpy(fd.content, content.c_str());
	}
	return fd;
}

StCommand CommandGenerator::generateRt( std::string pnr )
{
    StCommand rt;
    rt.type = RT;
    rt.status = WAITING;
    std::string content = "";
    content = "RT:";
    content.append(pnr);
    strcpy(rt.content, content.c_str());
    return rt;
}
