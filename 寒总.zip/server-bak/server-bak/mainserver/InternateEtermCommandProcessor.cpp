/*
* InternateEtermCommandProcessor.cpp
*
*  Created on: 2015年1月15日
*      Author: Administrator
*/

#include "InternateEtermCommandProcessor.h"
#include "svrloop.h"

InternateEtermCommandProcessor::InternateEtermCommandProcessor()
    :cmdId(-1)
{
    // TODO: Auto-generated constructor stub

}

InternateEtermCommandProcessor::~InternateEtermCommandProcessor()
{
    // TODO: Auto-generated destructor stub
}

void InternateEtermCommandProcessor::doWork()
{
    StCommand* command = getCommandByCmdId(cmdId);
    if (command != NULL)
    {
        std::vector<LowerCabinFlightCabins> cabins = data->settings->cabins;
        std::string cmdFlightNo = getFlightNoFromAVSCommand(command->content);
        LowerCabinFlightCabins cabinSet = getFlightCabinSettingByFlightNo(cmdFlightNo,cabins);
        switch (command->type)
        {
        case LCSAV:
            {
                MSGOUT(en_Msg_Debug,"InternateEtermCommandProcessor::doWork LCSAV in");
                avSpecialInfo *result = (avSpecialInfo *)command->formartedresult;
                avscabin asc = result->cabins;
                std::map<char,char> cabinMap = generateCabinMap(asc);
                int acl = cabinSet.availableCabin.length();
                bool hasLowerCabin = false;
                for (int i = 0; i < acl; ++i)
                {
                    if(cabinMap.count(cabinSet.availableCabin[i]) > 0)
                    {
                        //find the cabin, then test the cabin status
                        char cabinStatus =cabinMap[cabinSet.availableCabin[i]];
                        unsigned int ret= availableCabinFlags.find(cabinStatus);
                        if(ret != std::string::npos )
                        {
                            LowerCabinOrderData *orderData = data->orderData;
                            //the cabin is valid
                            hasLowerCabin = true;
                            StCommand rtCommand = CommandGenerator::generateRt(orderData->pnr);
                            rtCommand.result = NULL;
                            bool isOk = false;
                            StCommand qteCommand = CommandGenerator::generateQte(isOk,"");
                            qteCommand.result = NULL;
                            StCommands *cmdPatch = new StCommands;
                            cmdPatch->clientid = orderData->clientId;
                            cmdPatch->identifiers = ServerMain::generateContextKey(data);
                            cmdPatch->count = 2;
                            cmdPatch->current = 0;
                            cmdPatch->commands.push_back(rtCommand);
                            cmdPatch->commands.push_back(qteCommand);
                            //send the commands to the ETERM  sender app
                            sendCommands(cmdPatch);
                        }
                    }
                }
                //no lower cabins
                if (!hasLowerCabin)
                {
                    data->status = SCANSTATUS_WAITTING; 
                }
                MSGOUT(en_Msg_Debug,"InternateEtermCommandProcessor::doWork LCSAV out");
            }
            break;
        case LCAVH:
            {
                MSGOUT(en_Msg_Debug,"InternateEtermCommandProcessor::doWork LCAVH in");
                AvhResults * result = (AvhResults *)command->formartedresult;
                std::map<char,char> cabinMap = generateCabinMap(result,cmdFlightNo);
                int acl = cabinSet.availableCabin.length();
                bool hasLowerCabin = false;
                for (int i = 0; i < acl; ++i)
                {
                    if(cabinMap.count(cabinSet.availableCabin[i]) > 0)
                    {
                        //find the cabin, then test the cabin status
                        char cabinStatus =cabinMap[cabinSet.availableCabin[i]];
                        unsigned int ret= availableCabinFlags.find(cabinStatus);
                        if(ret != std::string::npos )
                        {
                            LowerCabinOrderData *orderData = data->orderData;
                            //the cabin is valid
                            hasLowerCabin = true;
                            StCommand rtCommand = CommandGenerator::generateRt(orderData->pnr);
                            rtCommand.result = NULL;
                            bool isOk = false;
                            StCommand qteCommand = CommandGenerator::generateQte(isOk,"");
                            qteCommand.result = NULL;
                            StCommands *cmdPatch = new StCommands;
                            cmdPatch->clientid = orderData->clientId;
                            cmdPatch->identifiers = ServerMain::generateContextKey(data);
                            cmdPatch->count = 2;
                            cmdPatch->current = 0;
                            cmdPatch->commands.push_back(rtCommand);
                            cmdPatch->commands.push_back(qteCommand);
                            //send the commands to the ETERM  sender app
                            sendCommands(cmdPatch);
                        }
                    }
                }
                //no lower cabins
                if (!hasLowerCabin)
                {
                    data->status = SCANSTATUS_WAITTING; 
                }
                MSGOUT(en_Msg_Debug,"InternateEtermCommandProcessor::doWork LCAVH out");
            }
            break;
        case QTE:
            {
                MSGOUT(en_Msg_Debug,"InternateEtermCommandProcessor::doWork QTE in");
                MSGOUT(en_Msg_Debug,"InternateEtermCommandProcessor::doWork QTE out");
            }
            break;
        default:
            break;
        }
    }
    else
    {
        MSGOUT(en_Msg_Debug, "this task is invalid.");
    }
}

int InternateEtermCommandProcessor::getCmdId() const
{
    return cmdId;
}

void InternateEtermCommandProcessor::setCmdId(int cmdId)
{
    this->cmdId = cmdId;
}
