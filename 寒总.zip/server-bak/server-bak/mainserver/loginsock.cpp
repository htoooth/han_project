/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-11 19:50:41
# LastModified : 2014-07-23 16:37:59
# FileName     : loginsock.cpp
# Description  : 
 ******************************************************************************/
#include "loginsock.h"
#include "dealnetdata.h"
#include "ssprotocol.h"
#include "scprotocol.h"
#include "showmsg.h"
#include "dbdefine.h"

bool LoginSvrSocket::_start_server(void* pdata, ISvrCallback* pcb) {
	
	m_pevent = (QueueEventModule*)pdata;

	return CenterSocket::_start_server(NULL, pcb);
}

LoginSvrSocket::LoginSvrSocket() {
	m_bok = false;
	m_pevent = NULL;
}

bool LoginSvrSocket::isok() {
	return m_bok;
}

bool LoginSvrSocket::OnRecvData(char* pdata, unsigned int ulen) {
	if (pdata == NULL || ulen < HEAD_SIZE)
		return false;

	NetSocketHead* phead = (NetSocketHead*)pdata;
    if (phead->uMainCmd == SYSTEM_PROTOCOL_TYPE) {
        switch(phead->uSubCmd) {
        case SP_LOGINMAIN_VERIFY_KEYWORD: 
            {
                if (phead->uHelpCmd != VERIFY_ERROR_NULL) {
                    MSGOUT(en_Msg_Error, "LoginSvrSocket::OnRecvData login loginserver failed!!!");
                    return false;
                }
                MSGOUT(en_Msg_Normal, "LoginSvrSocket::OnRecvData login loginserver ok!");
                m_bok = true;
                PostDBRequest(DB_LOGIN_LOGINSVROK, 0, NULL, 0, NULL);
            }
            break;
        default:
            MSGOUT(en_Msg_Warning, "LoginSvrSocket::OnRecvData unknow cmd, maincmd:%d, subcmd:%d, pdata:%p, len:%u", phead->uMainCmd, phead->uSubCmd, pdata, ulen);
            return false;
        }
        return true;
    }

	if (phead->uMainCmd != MAINSVR_LOGINSVR_TYPE)
		return false;

/*
	switch(phead->uSubCmd) {
		case ML_VERIFY_KEYWORD: 
		{
			if (phead->uHelpCmd != VERIFY_ERROR_NULL) {
				MSGOUT(en_Msg_Error, "LoginSvrSocket::OnRecvData login loginserver failed!!!");
				return false;
			}
			MSGOUT(en_Msg_Normal, "LoginSvrSocket::OnRecvData login loginserver ok!");
			m_bok = true;
			PostDBRequest(DB_LOGIN_LOGINSVROK, 0, NULL, 0, NULL);
		}
		break;
		default:
			MSGOUT(en_Msg_Warning, "LoginSvrSocket::OnRecvData unknow cmd, maincmd:%d, subcmd:%d, pdata:%p, len:%u", phead->uMainCmd, phead->uSubCmd, pdata, ulen);
	}
*/
	return true;
}

void LoginSvrSocket::OnClose() {
	MSGOUT(en_Msg_Normal, "LoginSvrSocket::OnClose close");
	m_bok = false;
	PostDBRequest(DB_LOGINSVR_RECON, 0, NULL, 0, NULL);
}

bool LoginSvrSocket::PostDBRequest(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	if (m_pevent == NULL)
		return false;

	return m_pevent->PostQueueEvent(maincmd, assistcmd, pdata, ulen, pclient); 
}