/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-12-26 16:49:34
# LastModified : 2014-12-26 17:56:41
# FileName     : dbevent.cpp
# Description  :
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-12-26 16:49:34
# LastModified : 2014-12-26 17:33:06
# FileName     : dbevent.cpp
# Description  :
******************************************************************************/
/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-25 15:38:07
# LastModified : 2014-11-13 14:13:05
# FileName     : dbevent.cpp
# Description  :
******************************************************************************/
#include <stdlib.h>
#include <string.h>

#include "dbevent.h"
#include "dbdefine.h"
#include "showmsg.h"
#include "scprotocol.h"
#include "ETermString.h"
#include "dealnetdata.h"
bool MysqlHandle::_start_server(void* pdata, ISvrCallback* pcb)
{
    ReadConf cf;
    if (-1 == cf.readfile("server.conf"))
    {
        MSGOUT(en_Msg_Error, "MysqlHandle::_start_server server.conf error!!!");
    }
    _mysql_param param =
    {
        { 0 } };
    do
    {
        if (!cf.getvalue("mysql_dbname", param.dbname, sizeof(param.dbname)))
            break;
        if (!cf.getvalue("mysql_username", param.username,
            sizeof(param.username)))
            break;
        if (!cf.getvalue("mysql_passwd", param.passwd, sizeof(param.passwd)))
            break;
        if (!cf.getvalue("mysql_addr", param.addr, sizeof(param.addr)))
            break;
        if (!cf.getvalue("mysql_charset", param.charset, sizeof(param.charset)))
            break;

        char buf[10] =
        { 0 };
        if (!cf.getvalue("mysql_port", buf, sizeof(buf)))
            break;
        param.port = atoi(buf);
        if (param.port <= 0)
            break;
        m_psqlmgr = new MySqlMgr();
        if (!m_psqlmgr->_start_server(&param, NULL))
        {
            MSGOUT(en_Msg_Error,
                "MysqlHandle::_start_server mysql _start_server error!!!");
            break;
        }

        return QueueEventModule::_start_server(pdata, pcb);
    } while (false);

    MSGOUT(en_Msg_Error, "MysqlHandle::_start_server mysql conf error!!!");
    return false;
}

void MysqlHandle::_stop_server()
{
    QueueEventModule::_stop_server();
    m_psqlmgr->_stop_server();
    delete (MySqlMgr*) m_psqlmgr;
    m_psqlmgr = NULL;
}

void MysqlHandle::SettleQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient)
{
    MYSQL* psql = (MYSQL*) m_psqlmgr->GetIdleDB();
    if (psql == NULL)
    {
        psql = (MYSQL*) m_psqlmgr->NewIdleDB();
        if (psql == NULL)
        {
            MSGOUT(en_Msg_Error,
                "MysqlHandle::SettleQueueEvent (2) connect mysql failed!!!");
            return;
        }
    }
    try
    {
        switch (maincmd)
        {
        case DB_VERIFY_LOGINPWD:
            {
                verifyloginpwd(psql, maincmd, assistcmd, pdata, ulen, pclient);
            }
            break;
        case DB_LOGINSVR_READY:
        case DB_LOGINSVR_RECON:
        case DB_LOGIN_LOGINSVROK:
        case DB_ETERMSVR_RECON:
            {
                PostQueueResult(maincmd, assistcmd, pdata, ulen, pclient);
            }
            break;
        case DB_ORDER_REQUEST:
            {
                dealorderrequest(psql, maincmd, assistcmd, pdata, ulen, pclient);
            }
            break;
        case DB_FLIGHT_SEARCH_REQUEST:
            {
                dealflightsearchrequest(psql, maincmd, assistcmd, pdata, ulen,
                    pclient);
            }
            break;
        case DB_COMMAND_RESULT:
            {
                dealflightsearchrequest(psql, maincmd, assistcmd, pdata, ulen,
                    pclient);
            }
            break;
        case DB_CABINPRICE_REQUEST:
            {
                dealcabinpricerequest(psql, maincmd, assistcmd, pdata, ulen,
                    pclient);
            }
            break;
        case DB_ORDER_PNR_RESULT:
            {
                dealorderpnrresult(psql, maincmd, assistcmd, pdata, ulen, pclient);
            }
            break;
        case DB_CABINPRICE_FROMETERM_FD:
            {
                dealorderfdresult(psql, maincmd, assistcmd, pdata, ulen, pclient);
            }
            break;
        case DB_CABINPRICE_FROMETERM_FSD:
            {
                dealorderfsdresult(psql, maincmd, assistcmd, pdata, ulen, pclient);
            }
            break;
        case DB_TICKET_PRICE_REQUEST:
            {
                dealticketpricerequest(psql, maincmd, assistcmd, pdata, ulen, pclient);
            }
            break;
        case DB_START_LOWER_CABIN_SCANNER:
            {
                MSGOUT(en_Msg_Debug, "DB_START_LOWER_CABIN_SCANNER");
                LowerCabinScannerData* orderData =  loadLowerCabinOrderData(psql);
                PostQueueResult(DB_START_LOWER_CABIN_SCANNER,0,&orderData,sizeof(orderData),NULL);
                /*std::list<LowerCabinScannerData*>::iterator it;

                //读取需要监控的订单
                for (it = orderData.begin(); it != orderData.end(); ++it)
                {
                / *LowerCabinScannerData * scannerData = new LowerCabinScannerData;
                scannerData->mysqlHandler = this;
                scannerData->orderData = *it;
                scannerData->commands = NULL;* /
                LowerCabinScannerData * scannerData = *it;
                std::string key = generateContextKey(scannerData);
                bool isActive = isInActiveTimeZone(scannerData->settings);
                bool isActiveToday = isInActiveTimeZoneToday(
                scannerData->settings);
                if (isActiveToday || isActive)
                {
                if (isActive)
                {
                scannerData->status = SCANSTATUS_PROCESSING;
                //this task should be active now
                LowerCabinScanTask *task = generateTaskByType(
                scannerData);
                pthread_mutex_lock(&rtMutex);
                tasks.push(task);
                pthread_mutex_unlock(&rtMutex);
                }
                pthread_mutex_lock(&rcMutex);
                lowerCabinContext[key] = scannerData;
                pthread_mutex_unlock(&rcMutex);
                sem_post(&semRc);
                }
                else
                {
                //TODO:this order don't active scanner today,give it back to db

                }
                }*/

            }
            break;
        case DB_LOWER_CABIN_REQUEST:
            {
                deallowercabinsrequest(psql, maincmd, assistcmd, pdata, ulen,
                    pclient);
            }
            break;
        case DB_LOWERCABIN_SETTINGAV_RESULT:
            {
                deallowercabinsresult(psql, maincmd, assistcmd, pdata, ulen,pclient);
            }
            break;
        case DB_LC_AV_RESULT:
            {
                MSGOUT(en_Msg_Debug,"DB_LC_AV_RESULT");
                /*deallcavresult(psql, maincmd, assistcmd, pdata, ulen,
                pclient);*/
            }
            break;
        case DB_LC_SAV_RESULT:
            {
                MSGOUT(en_Msg_Debug,"DB_LC_SAV_RESULT");
                /*deallcsavresult(psql, maincmd, assistcmd, pdata, ulen,
                pclient);*/
            }
            break;
        case DB_LOWERCABIN_PAT_RESULT:
            {
                //get pat result
            }
            break;
        case DB_BEST_CABIN_PRICE_REQUEST:
            {
                MSGOUT(en_Msg_Debug,"DB_BEST_CABIN_PRICE_REQUEST");
                dealbestcabinpriceresult(psql, maincmd, assistcmd, pdata, ulen,pclient);
            }
            break;
        case DB_LOAD_CABIN_MAP:
            {
                MSGOUT(en_Msg_Debug,"DB_LOAD_CABIN_MAP");
                loadAirCompanyCabinMap(psql);
            }
            break;
        default:
            MSGOUT(en_Msg_Normal,"MysqlHandle::SettleQueueEvent unknow cmd maincmd:%d, assistcmd:%d, pdata:%p, len:%u", maincmd, assistcmd, pdata, ulen);
            break;
        }
        m_psqlmgr->SaveIdleDB(psql);
    } catch (...)
    {
        if (m_psqlmgr != NULL && psql != NULL)
        {
            MSGOUT(en_Msg_Error,"MysqlHandle::SettleQueueEvent maincmd:%d, assistcmd:%d, pdata:%p, len:%u, errstr:%s", maincmd, assistcmd, pdata, ulen, mysql_error(psql));
            m_psqlmgr->FreeConnect(psql);
        }
    }
}

void MysqlHandle::verifyloginpwd(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient)
{

    if (ulen != sizeof(StVerifyPasswd) || pdata == NULL)
        throw DB_ERROR_PARAMERR;

    const char *proc = "proc_simpleverifypwd";
    StVerifyPasswd* p = (StVerifyPasswd*) pdata;
    char buf[4096] =
    { 0 };
    sprintf(buf, "call %s (%d, '%s', %d, '%s', '%s');", proc, p->idx, p->passwd,
        p->logintype, p->mac, p->mac);

    MSGOUT(en_Msg_Debug, "%s", buf);

    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    int ret = VERIFY_ERROR_UNKNOW;
    StClientInfo *clientInfo = (StClientInfo *) malloc(sizeof(StClientInfo));
    memset(clientInfo, 0, sizeof(StClientInfo));
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {
            if (res->row_count == 1)
            {
                MYSQL_ROW row = mysql_fetch_row(res);
                if (row == NULL)
                {
                    mysql_free_result(res);
                    break;
                }
                ret = VERIFY_ERROR_NULL;
                clientInfo->idx = atoi(row[0]);
                clientInfo->companyId = atoi(row[1]);
            }
            else
            {
                ret = VERIFY_ERROR_PWD;
            }
            mysql_free_result(res);
        }
    } while (!mysql_next_result(psql));
    PostQueueResult(maincmd, ret, &clientInfo, sizeof(StClientInfo*), pclient);
    MSGOUT(en_Msg_Debug, "login ret : %d", ret);
}

void MysqlHandle::dealorderfdresult(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient)
{
    StCommands *commands = *((StCommands **) pdata);
    StCommand &command = commands->commands[commands->current];
    StFlightTrip *flightTrip = (StFlightTrip *) commands->context;
    if (command.type == ORDERFD && command.result != NULL)
    {
        fdpriceinfo *fdpInfo = (fdpriceinfo *) malloc(sizeof(fdpriceinfo));
        memset(fdpInfo, 0, sizeof(fdpriceinfo));
        int res = 0, distance = 0;
        char dep[4] = { 0 }, des[4] = { 0 };
        char buf[4096] = { 0 };
        int pos = 0;
        sEterm._fdgetdepdes((const char *) command.result, dep, des, &distance);
        int offset = sEterm._getOneLine((const char *) command.result, buf, sizeof(buf));
        pos += offset;
        offset = sEterm._getOneLine((const char *) command.result + pos, buf, sizeof(buf));
        pos += offset;

        fdpriceinfo** p = NULL;
        int pagetype = en_page_single;
        res = sEterm.DealFDStr((const char *) command.result + pos, &p, dep, des, distance, &pagetype);
        if (res == -1)
        {
            MSGOUT(en_Msg_Error,"MysqlHandle::dealorderfdresult fd data format error!!!");
        }
        else
        {
            //把fd结果写入数据库
            for (int i = 0; i < res; ++i)
            {
                //find the same cabin and duibi the price
                fdpriceinfo* tmp = p[i];
                saveCabinPriceInfo(psql, tmp);
            }
            command.status = COMPLETE;
            free(command.result);
            command.result = NULL;
            commands->current++;
            if (pagetype & en_page_next)
            {
                //继续翻页
                StCommands *cmdBatch = new StCommands;
                StCommand pnCommand = CommandGenerator::generatePn();
                pnCommand.type = ORDERFD;
                cmdBatch->clientid = commands->clientid;
                cmdBatch->context = flightTrip;
                cmdBatch->status = WAITING;
                cmdBatch->current = 0;
                cmdBatch->ishog = true;
                cmdBatch->commands.push_back(pnCommand);
                cmdBatch->current = 1;
                sendCommands(cmdBatch, (int) (long) pclient);
            }
            else
            {
                MSGOUT(en_Msg_Debug,"MysqlHandle::dealorderfdresult tripaddr:%p trip type: %d,segs:%d", flightTrip, flightTrip->triptype,flightTrip->segscount);
                switch (flightTrip->triptype)
                {
                case 0:
                case 1:
                    {
                        //inland-srt
                        dealticketpricerequest(psql, maincmd, 1, flightTrip, sizeof(StFlightTrip *), pclient);
                    }
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
                }
            }
        }

    }
}

void MysqlHandle::dealorderfsdresult( MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient )
{
    StCommands *commands = *((StCommands **) pdata);
    StCommand &command = commands->commands[commands->current];
    StFlightTrip *flightTrip = (StFlightTrip *) commands->context;
    if (command.type == ORDERFSD && command.result != NULL)
    {
        fsdpriceinfo_s *fsdpInfo = (fsdpriceinfo_s *) malloc(sizeof(fsdpriceinfo_s));
        memset(fsdpInfo, 0, sizeof(fsdpriceinfo_s));
        MSGOUT(en_Msg_Debug,"dealorderfsdresult:::%s-----",(char *)command.result);

        std::string tmp = (char *)command.result;
        int res = sEterm.DealFsdStr(tmp,fsdpInfo);
        if (res == -1)
        {
            MSGOUT(en_Msg_Error,"MysqlHandle::dealorderfdresult fsd data format error!!!");
        }
        else
        {
            //把fsd结果写入数据库
            saveCabinPriceInfo(psql, fsdpInfo);
            command.status = COMPLETE;
            free(command.result);
            command.result = NULL;
            commands->current++;
            //FSD  only has one page?
            {
                MSGOUT(en_Msg_Debug, "MysqlHandle::dealorderfdresult tripaddr:%p trip type: %d,segs:%d", flightTrip, flightTrip->triptype,flightTrip->segscount);
                switch (flightTrip->triptype)
                {
                case 0:
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    {
                        //internate-st
                        dealticketpricerequest(psql, maincmd, 1, flightTrip,sizeof(StFlightTrip *), pclient);
                    }
                    break;
                case 4:
                    break;
                case 5:
                    break;
                }
            }
        }

    }
}

void MysqlHandle::dealorderpnrresult(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient)
{
    //deal order command result
    StCommands *commands = *((StCommands **) pdata);
    StCommand &command = commands->commands[commands->current];
    StOrderRequest *orderRequest = (StOrderRequest *) commands->context;
    if (command.type == ORDERTICKET && command.result != NULL)
    {
        std::string sRet((const char *) command.result);
        OrderResultInfo *orInfo = (OrderResultInfo *) malloc(sizeof(OrderResultInfo));
        memset(orInfo, 0, sizeof(OrderResultInfo));
        sEterm.DealOrderResultStr(sRet, orInfo);
        bool isOk = false;
        saveOrderInfo(psql, orderRequest, orInfo, commands->clientid, isOk);
        StOrderResult orderResult;
        memset(&orderResult, 0, sizeof(StOrderResult));
        int fd = (int) (long) pclient;
        int resultSize = sizeof(StOrderResult);
        int totalSize = sizeof(NetSocketHead) + resultSize;
        char *buf = (char *) malloc(totalSize);
        NetSocketHead* phead = (NetSocketHead *) buf;
        phead->uMainCmd = MAINSVR_CLIENT_TYPE;
        phead->uSubCmd = MC_ORDER_RESULT;
        phead->uLen = totalSize;
        unsigned int len = phead->uLen;
        StOrderResult *pOrderResult = (StOrderResult *) (phead + 1);
        orderResult.idx = commands->clientid;
        orderResult.originprice = orderRequest->trip.totalprice;
        orderResult.ourprice = orderRequest->trip.ourprice;
        if (isOk)
        {
            orderResult.status = 1;
            strcpy(orderResult.tips, "order success!");
        }
        else
        {
            orderResult.status = -1;
            strcpy(orderResult.tips, "order failed");
        }
        memcpy(pOrderResult, &orderResult, resultSize);
        sendData(buf, len, fd);
        free(buf);
    }
}

void MysqlHandle::dealorderrequest(MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::dealorderrequest in===========");
    int fd = (int) (long) pclient;
    StOrderRequest *orderRequest = (StOrderRequest*) pdata;
    StCommands *commands = new StCommands;
    //memset(commands, 0, sizeof(StCommands));
    commands->status = WAITING;
    commands->current = 0;
    commands->ishog = true;
    if (commands != NULL)
    {
        generateOrderCommand(orderRequest, commands);
    }
    //set the order request object to the context
    commands->context = orderRequest;
    //send order command to the eterm
    sendCommands(commands, fd);
    MSGOUT(en_Msg_Debug, "MysqlHandle::dealorderrequest out===========");
}

void MysqlHandle::dealcommandresult(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient)
{
    /*_StEtermSvrResult *pRc = (_StEtermSvrResult*) pdata;
    char *cmdrst = (char *)(pRc+1);
    int _size = sizeof(int) + strlen(pRc->result) * sizeof(char);
    PostQueueResult(maincmd, assistcmd, pdata, _size, pclient);*/
}

void MysqlHandle::dealcabinpricerequest(MYSQL* psql, int maincmd, int assistcmd,void* pdata, unsigned int ulen, void* pclient)
{
    /*if (pdata == NULL)
    {
    MSGOUT(en_Msg_Normal,
    "MysqlHandle::dealcabinpricerequest commands is null,maybe some where occur error.");
    return;
    }
    StCommands *commands = *((StCommands **) pdata);
    StOrderRequest *orderRequest = (StOrderRequest *) commands->context;
    if (orderRequest == NULL)
    {
    MSGOUT(en_Msg_Normal,
    "MysqlHandle::dealcabinpricerequest order request is null,maybe some where occur error.");
    }
    const char *proc = "proc_searchcabinprice";
    char buf[4096] =
    { 0 };
    sprintf(buf, "call %s ('%s', '%s', '%s', '%s', '%s');", proc,
    orderRequest->flydate, orderRequest->aircompay,
    orderRequest->cityfrom, orderRequest->cityto, orderRequest->cabin);
    int owprice = 0, rtprice = 0;
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
    throw DB_ERROR_PROCERR;
    }
    int ret = VERIFY_ERROR_UNKNOW;
    do
    {
    MYSQL_RES *res = mysql_store_result(psql);
    if (res == NULL)
    {
    break;
    }
    else
    {
    if (res->row_count == 1)
    {
    MYSQL_ROW row = mysql_fetch_row(res);
    if (row == NULL)
    {
    mysql_free_result(res);
    break;
    }
    owprice = atoi(row[5]);
    rtprice = atoi(row[6]);
    }
    else
    {
    ret = VERIFY_ERROR_PWD;
    }
    mysql_free_result(res);
    }
    } while (!mysql_next_result(psql));
    switch (orderRequest->type)
    {
    case 0:
    {
    int *revers = (int *) malloc(sizeof(int));
    *revers = owprice;
    commands->revers = revers;
    PostQueueResult(maincmd, assistcmd, &commands, sizeof(StCommands *),
    pclient);
    }
    break;
    case 1:
    {
    int *revers = (int *) malloc(sizeof(int));
    *revers = rtprice;
    commands->revers = revers;
    PostQueueResult(maincmd, assistcmd, &commands, sizeof(StCommands *),
    pclient);
    }
    break;
    case 2:
    {

    }
    break;
    default:
    MSGOUT(en_Msg_Normal,
    "MysqlHandle::dealcabinpricerequest order request type is error.");
    }*/

}

void MysqlHandle::dealticketpricerequest(MYSQL* psql, int maincmd,int assistcmd, void* pdata, unsigned int ulen, void* pclient)
{
    StFlightTrip *trip = (StFlightTrip *) malloc(sizeof(*(StFlightTrip *) pdata));
    memcpy(trip, pdata, sizeof(*(StFlightTrip *) pdata));
    if (trip == NULL || trip->triptype < 0 || trip->segscount <= 0)
    {
        // no request data or trip data broken
        MSGOUT(en_Msg_Error,"MysqlHandle::dealticketpricerequest trip is null,maybe some where occur error.%p-%d-%d",trip, trip->triptype, trip->segscount);
        return;
    }
    MSGOUT(en_Msg_Debug,"MysqlHandle::dealticketpricerequest tripaddr:%p  type:%d,segcount:%d,citypair:%s%s,price:%d ",trip, trip->triptype, trip->segscount, trip->cityfrom, trip->cityto, trip->totalprice);
    switch (trip->triptype)
    {
    case 0:
        {
            MSGOUT(en_Msg_Debug,"inland-st procedure in.");
            //inland-st
            StFlightSegment &seg = trip->segs[0];
            //cabin info
            std::string citypair = trip->cityfrom;
            citypair.append(trip->cityto);
            //	std::string
            int cabinPrice = getInlandCabinPrice(psql, seg.aircompany, citypair,trip->depaturedate1, seg.cabin);
            if (cabinPrice <= 0 && assistcmd == 1)
            {
                MSGOUT(en_Msg_Debug,"MysqlHandle::dealticketpricerequest after fd no cabin avaliable yet:%d,%d", cabinPrice, trip->totalprice);
                cabinPrice = trip->totalprice;
            }
            if (cabinPrice > 0)
            {
                MSGOUT(en_Msg_Debug,"MysqlHandle::dealticketpricerequest find the cabin  cabinPrice:%d", cabinPrice);
                if ((cabinPrice - trip->totalprice) < MAX_DIFF_PRICE)
                {
                    seg.ticketprice = cabinPrice;
                    // match policy
                    pricePolicyFilters(trip);
                    int fd = (int) (long) pclient;
                    int resultSize = sizeof(StFlightTrip) - (sizeof(trip->segs) / sizeof(StFlightSegment) - trip->segscount) * sizeof(StFlightSegment);
                    int totalSize = sizeof(NetSocketHead) + resultSize;
                    char *buf = (char *) malloc(totalSize);
                    NetSocketHead* phead = (NetSocketHead *) buf;
                    phead->uMainCmd = MAINSVR_CLIENT_TYPE;
                    phead->uSubCmd = MC_TICKET_PRICE_RESULT;
                    phead->uLen = totalSize;
                    unsigned int len = phead->uLen;
                    StFlightTrip *pFlightTrip = (StFlightTrip *) (phead + 1);
                    memcpy(pFlightTrip, trip, resultSize);
                    sendData(buf, len, fd);
                    //TODO:free memery?
                    //free(buf);
                    /*PostQueueResult(maincmd, assistcmd, &trip,
                    sizeof(StFlightTrip *), pclient);*/
                }
                else
                {
                    //cabin price more than MAX_DIFF_PRICE
                    MSGOUT(en_Msg_Debug,"MysqlHandle::dealticketpricerequest maincmd:%d, assistcmd:%d, pdata:%p, len:%u", maincmd, assistcmd, pdata, ulen);
                }
            }
            else
            {
                //the db hasn't cabin price info,then send etern request
                int fd = (int) (long) pclient;
                //inland-St
                bool isOk = false;
                //params
                std::string citypair = trip->cityfrom, date = trip->depaturedate1,
                    aircompany = trip->segs[0].aircompany;
                citypair.append(trip->cityto);
                //construct fd command
                StCommand fdCommand = CommandGenerator::generateOrderFd(isOk, date,
                    citypair, aircompany);
                if (isOk)
                {
                    fdCommand.type = ORDERFD;
                    StCommands *cmdPatch = new StCommands;
                    cmdPatch->clientid = -1;
                    cmdPatch->context = trip;
                    cmdPatch->status = WAITING;
                    cmdPatch->current = 0;
                    cmdPatch->ishog = true;
                    cmdPatch->commands.push_back(fdCommand);
                    cmdPatch->count = 1;
                    sendCommands(cmdPatch, fd);
                }
                else
                {
                    MSGOUT(en_Msg_Debug,
                        "ServerMain::SettleDBResult fd command generate failed!!!!");
                }
                /*PostQueueResult(DB_CABINPRICE_FROMETERM_REQUEST, assistcmd,
                &trip, sizeof(StFlightTrip *), pclient);*/
            }
        }
        break;
    case 1:
        {
            MSGOUT(en_Msg_Debug,"inland-rt procedure in.");
        }
        break;
    case 2:
        {
            MSGOUT(en_Msg_Debug,"inland-mt procedure in.");
        }
        break;
    case 3:
        {
            MSGOUT(en_Msg_Debug,"internate-st procedure in.");
            StFlightSegment &seg = trip->segs[0];
            //cabin info
            std::string citypair = trip->cityfrom;
            citypair.append(trip->cityto);
            //	std::string
            int cabinPrice = getInternateCabinPrice(psql, seg.aircompany, citypair,trip->depaturedate1, seg.cabin);
            if (cabinPrice <= 0 && assistcmd == 1)
            {
                MSGOUT(en_Msg_Debug,"MysqlHandle::dealticketpricerequest after fsd no cabin avaliable yet:%d,%d", cabinPrice, trip->totalprice);
                cabinPrice = trip->totalprice;
            }
            if (cabinPrice > 0)
            {
                MSGOUT(en_Msg_Debug,"MysqlHandle::dealticketpricerequest find the cabin  cabinPrice:%d,segticket price:%d", cabinPrice,seg.price);
                if ((cabinPrice - trip->totalprice) < MAX_DIFF_PRICE)
                {
                    seg.ticketprice = cabinPrice;
                    // match policy
                    pricePolicyFilters(trip);
                    int fd = (int) (long) pclient;
                    int resultSize = sizeof(StFlightTrip) - (sizeof(trip->segs) / sizeof(StFlightSegment) - trip->segscount) * sizeof(StFlightSegment);
                    int totalSize = sizeof(NetSocketHead) + resultSize;
                    char *buf = (char *) malloc(totalSize);
                    NetSocketHead* phead = (NetSocketHead *) buf;
                    phead->uMainCmd = MAINSVR_CLIENT_TYPE;
                    phead->uSubCmd = MC_TICKET_PRICE_RESULT;
                    phead->uLen = totalSize;
                    unsigned int len = phead->uLen;
                    StFlightTrip *pFlightTrip = (StFlightTrip *) (phead + 1);
                    memcpy(pFlightTrip, trip, resultSize);
                    sendData(buf, len, fd);
                    //TODO:free memery?
                    //free(buf);
                    /*PostQueueResult(maincmd, assistcmd, &trip,
                    sizeof(StFlightTrip *), pclient);*/
                }
                else
                {
                    //cabin price more than MAX_DIFF_PRICE
                    MSGOUT(en_Msg_Debug,"MysqlHandle::dealticketpricerequest maincmd:%d, assistcmd:%d, pdata:%p, len:%u", maincmd, assistcmd, pdata, ulen);
                }
            }
            else
            {
                //the db hasn't cabin price info,then send ETERM request
                int fd = (int) (long) pclient;
                //internate-St
                bool isOk = false;
                //params
                std::string citypair = trip->cityfrom, date = trip->depaturedate1, aircompany = trip->segs[0].aircompany;
                citypair.append(trip->cityto);
                //construct fsd command
                StCommand fdCommand = CommandGenerator::generateXsfsd(isOk, citypair, aircompany);
                if (isOk)
                {
                    fdCommand.type = ORDERFSD;
                    StCommands *cmdPatch = new StCommands;
                    cmdPatch->clientid = -1;
                    cmdPatch->context = trip;
                    cmdPatch->status = WAITING;
                    cmdPatch->current = 0;
                    cmdPatch->ishog = true;
                    cmdPatch->commands.push_back(fdCommand);
                    cmdPatch->count = 1;
                    sendCommands(cmdPatch, fd);
                }
                else
                {
                    MSGOUT(en_Msg_Debug,"ServerMain::SettleDBResult fd command generate failed!!!!");
                }
            }
        }
        break;
    case 4:
        {
            MSGOUT(en_Msg_Debug,"internate-rt procedure in.");
        }
        break;
    case 5:
        {
            MSGOUT(en_Msg_Debug,"internate-mt procedure in.");
        }
        break;
    default:
        MSGOUT(en_Msg_Error,"MysqlHandle::dealticketpricerequest trip type is error,trip type id %d.", trip->triptype);
    }
}

void MysqlHandle::generateOrderCommand(StOrderRequest * orderReqest,StCommands *commands)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::generateOrderCommand in===========");
    StFlightTrip flightTrip = orderReqest->trip;
    switch (flightTrip.triptype)
    {
    case 0:
        //inland-rt
        generateInlandSCommand(orderReqest, commands);
        break;
    case 1:
        //inland-st
        generateInlandRCommand(orderReqest, commands);
        break;
    case 2:
        //inland-mt
        generateInlandRCommand(orderReqest, commands);
        break;
    case 3:
        //internate-st
        generateInternateSCommand(orderReqest, commands);
        break;
    case 4:
        //internate-rt
        generateInternateRCommand(orderReqest, commands);
        break;
    case 5:
        //internate-mt
        generateInternateMCommand(orderReqest, commands);
        break;
    }
    MSGOUT(en_Msg_Debug, "MysqlHandle::generateOrderCommand out===========");
}

void MysqlHandle::dealflightsearchrequest(MYSQL* psql, int maincmd,int assistcmd, void* pdata, unsigned int ulen, void* pclient)
{
    StFlightSearchRequest * flightSearchRequest = (StFlightSearchRequest*) pdata;
    int count = flightSearchRequest->count;
    for (int i = 0; i < count; ++i)
    {
        switch ((SearchType) flightSearchRequest->flightinfo[i].type)
        {
        case SINGLE_INLAND:
            singletriprequest(flightSearchRequest->flightinfo[i],
                (SearchType) flightSearchRequest->flightinfo[i].type);
            break;
        case RETURN_INLAND:
            returntriprequest(flightSearchRequest->flightinfo[i],
                (SearchType) flightSearchRequest->flightinfo[i].type);
            break;
        case MORE_INLAND:
            moretriprequest(flightSearchRequest->flightinfo[i],
                (SearchType) flightSearchRequest->flightinfo[i].type);
            break;
        case SINGLE_FOREING:
            singletriprequest(flightSearchRequest->flightinfo[i],
                (SearchType) flightSearchRequest->flightinfo[i].type);
            break;
        case RETURN_FOREING:
            returntriprequest(flightSearchRequest->flightinfo[i],
                (SearchType) flightSearchRequest->flightinfo[i].type);
            break;
        case MORE_FOREING:
            moretriprequest(flightSearchRequest->flightinfo[i],
                (SearchType) flightSearchRequest->flightinfo[i].type);
            break;
        default:
            {
                unknowntriprequest(flightSearchRequest->flightinfo[i],
                    (SearchType) flightSearchRequest->flightinfo[i].type);
            }
        }
    }
    int requestSize = sizeof(flightSearchRequest->count)
        + sizeof(flightSearchRequest->type)
        + flightSearchRequest->count * sizeof(StFlightInfo);
    PostQueueResult(maincmd, assistcmd, flightSearchRequest, requestSize,
        pclient);
}

void MysqlHandle::singletriprequest(StFlightInfo &flightinfo, SearchType type)
{
    flightinfo.price -= 1;
}

void MysqlHandle::returntriprequest(StFlightInfo &flightinfo, SearchType type)
{
    flightinfo.price -= 1;
}

void MysqlHandle::moretriprequest(StFlightInfo &flightinfo, SearchType type)
{
    flightinfo.price -= 1;
}

void MysqlHandle::unknowntriprequest(StFlightInfo &flightinfo, SearchType type)
{
    flightinfo.price -= 1;
}

void MysqlHandle::sendCommands(StCommands *cmdPatch, int fd)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::sendCommands fd:%d,commands size %d", fd, cmdPatch->count);
    PostQueueResult(DB_SEND_COMMAND, 0, &cmdPatch, sizeof(StCommands*),(void*) (long) fd);
}

void MysqlHandle::sendData(char *data, int len, int fd)
{
    PostQueueResult(DB_SEND_DATA, 0, data, len, (void*) (long) fd);
}

int MysqlHandle::getInlandCabinPrice( MYSQL* psql, std::string aircompany, std::string citypair,std::string date, std::string cabin,int triptype/*=0*/ )
{
    int iRet = 0;
    const char *proc = "proc_searchcabinprice";
    char buf[4096] = { 0 };
    //IN `searchdate` date,IN `aircompany` char(4),IN `depature` char(4),IN `arrival` char(4),IN `cabin` char(8)
    sprintf(buf, "call %s ('%s', '%s', '%s', '%s', '%s');", proc, date.c_str(), aircompany.c_str(), citypair.substr(0, 3).c_str(), citypair.substr(3, 3).c_str(), cabin.c_str());
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {
            if (res->row_count == 1)
            {
                MYSQL_ROW row = mysql_fetch_row(res);
                if (row == NULL)
                {
                    mysql_free_result(res);
                    break;
                }
                if (triptype == 0)
                {
                    iRet = atoi(row[5]);
                }
                else if (triptype == 1)
                {
                    iRet = atoi(row[6]);
                }
            }
            mysql_free_result(res);
        }
    } while (!mysql_next_result(psql));
    return iRet;
}

int MysqlHandle::getInternateCabinPrice( MYSQL* psql, std::string aircompany, std::string citypair,std::string date, std::string cabin,int triptype/*=0*/ )
{
    int iRet = 0;
    const char *proc = "proc_searchcabinprice";
    char buf[4096] = { 0 };
    //IN `searchdate` date,IN `aircompany` char(4),IN `depature` char(4),IN `arrival` char(4),IN `cabin` char(8)
    sprintf(buf, "call %s ('%s', '%s', '%s', '%s', '%s');", proc, date.c_str(), aircompany.c_str(), citypair.substr(0, 3).c_str(), citypair.substr(3, 3).c_str(), cabin.c_str());
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {
            if (res->row_count == 1)
            {
                MYSQL_ROW row = mysql_fetch_row(res);
                if (row == NULL)
                {
                    mysql_free_result(res);
                    break;
                }
                if (triptype == 0)
                {
                    iRet = atoi(row[5]);
                }
                else if (triptype == 1)
                {
                    iRet = atoi(row[6]);
                }
            }
            mysql_free_result(res);
        }
    } while (!mysql_next_result(psql));
    return iRet;
}

void MysqlHandle::saveCabinPriceInfo(MYSQL* psql, fdpriceinfo* priceInfo)
{
    const char *proc = "proc_savecabinprice";
    char buf[4096] =
    { 0 };
    //IN `airCompany` char(2),IN `departure` char(3),IN `arrival` char(3),
    //IN `stPrice` int,IN `rtPrice` int,IN `cabin` char(1),IN `subcabin` char(1),
    //IN `sValidDate` date,IN `eValidDate` date,IN `distance` int,IN `fareNote` varchar(10),IN `fareRule` varchar(10)
    sprintf(buf,
        "call %s ('%s', '%s', '%s', %d, %d, '%s', '%s', '%s', '%s', %d, '%s', '%s');",
        proc, priceInfo->aircompany, priceInfo->depature,
        priceInfo->destination, priceInfo->owprice, priceInfo->rtprice,
        priceInfo->seattype, "", priceInfo->startdata, "", 0, "", "");
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {
            mysql_free_result(res);
        }
    } while (!mysql_next_result(psql));
}

void MysqlHandle::saveCabinPriceInfo( MYSQL* psql, fsdpriceinfo_s *priceInfo )
{
    const char *proc = "proc_savecabinprice";
    char buf[4096] =  { 0 };
    std::string citypair = priceInfo->citypair;
    std::string depature="",arrival="";
    if (citypair.length() == 6)
    {
        depature = citypair.substr(0,3);
        arrival = citypair.substr(3,3);
    }
    //IN `airCompany` char(2),IN `departure` char(3),IN `arrival` char(3),
    //IN `stPrice` int,IN `rtPrice` int,IN `cabin` char(1),IN `subcabin` char(1),
    //IN `sValidDate` date,IN `eValidDate` date,IN `distance` int,IN `fareNote` varchar(10),IN `fareRule` varchar(10)
    for (int i = 0 ; i < priceInfo->linecount ; ++i)
    {
        fsdlinedata line =  priceInfo->lines[i];
        sprintf(buf,"call %s ('%s', '%s', '%s', %d, %d, '%s', '%s', '%s', '%s', %d, '%s', '%s');", proc, priceInfo->searchaircompany, depature.c_str(), arrival.c_str(), line.singletripprice, line.returntripprice, line.cabin, "", "", "", 0, "", "");
        MSGOUT(en_Msg_Debug, "%s", buf);
        int res = mysql_query(psql, buf);
        if (res != 0)
        {
            throw DB_ERROR_PROCERR;
        }
        do
        {
            MYSQL_RES *res = mysql_store_result(psql);
            if (res == NULL)
            {
                break;
            }
            else
            {
                mysql_free_result(res);
            }
        } while (!mysql_next_result(psql));
    }
}

void MysqlHandle::pricePolicyFilters(StFlightTrip* trip)
{
    trip->ourprice = trip->totalprice - 1;
    //匹配政策
    switch (trip->triptype)
    {
    case 0:
    case 1:
        {
            //inland-St
            //params
            std::string citypair = trip->cityfrom, date = trip->depaturedate,
                aircompany = trip->segs[0].aircompany;
            citypair.append(trip->cityto);
        }
        break;
    case 2:
        {
            //inland-Mt
        }
        break;
    case 3:
        {
            //internate-St
        }
        break;
    case 4:
        {
            //internate-Rt
        }
        break;
    case 5:
        {
            //internate-Mt
        }
        break;
    default:
        MSGOUT(en_Msg_Debug,
            "ServerMain::pricePolicyFilters trip type is error%d!!!!",
            trip->triptype);
    }
}

void MysqlHandle::saveOrderInfo(MYSQL* psql, StOrderRequest* orderRequest,OrderResultInfo* result, int clientId, bool &isOk)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderInfo in===========");
    int orderStatus = 0, orderId = -1;
    StContactor contactor = orderRequest->contactor;
    //TODO:保存订单数据
    if (strlen(result->pnr) <= 0 || result->segmentcount <= 0)
    {
        //order the ticket failed
        isOk = false;
    }
    else
    {
        //order the ticket success
        isOk = true;
        orderStatus = 1;
    }
    const char *proc = "proc_airline_order_insert_main_info";
    char buf[4096] = { 0 };
    //IN `clientId` int,IN `status` tinyint,IN `contactorname` varchar(40),IN `contactorphone` varchar(11),IN `contactoremail` varchar(50)
    sprintf(buf, "call %s (%d, %d, '%s', '%s', '%s');", proc, clientId,
        orderStatus, contactor.name, contactor.phonenumber,
        contactor.email);
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {
            if (res->row_count == 1)
            {
                MYSQL_ROW row = mysql_fetch_row(res);
                if (row != NULL)
                {
                    orderId = atoi(row[0]);
                }
            }
            mysql_free_result(res);
            //break;
        }
    } while (!mysql_next_result(psql));
    //订单数据存储成功，存储订单的其他关联信息
    if (orderId >= 0)
    {
        bool isOk = false;
        //our order id
        std::string date = "";
        std::string tmpdate = orderRequest->submitDate;
        if (tmpdate.length() == 10)
        {
            date.append(tmpdate.substr(2, 2));
            date.append(tmpdate.substr(5, 2));
            date.append(tmpdate.substr(8, 2));
        }
        else
        {

        }
        std::string type = orderRequest->trip.triptype < 4 ? "10" : "20";
        saveOrderSeriaNoInfo(psql, orderId, date.c_str(), type.c_str(), isOk);
        //invoice info
        saveOrderInvoiceInfo(psql, orderRequest->invoice, orderRequest->isInvoice, orderId, isOk);
        //types and other info
        isOk = false;
        saveOrderTypeOtherInfo(psql, orderRequest->trip, orderId, isOk);
        //price info
        isOk = false;
        saveOrderPriceInfo(psql, orderRequest, result, orderId, isOk);
        //save passenger and ticket info
        for (int i = 0; i < orderRequest->passengercount; ++i)
        {
            StPassenger passenger = orderRequest->passengers[i];
            //save passenger
            isOk = false;
            /*int pId = */saveOrderPassengerInfo(psql, passenger, orderId, clientId, isOk);
            if (isOk)
            {
                //TODO:save ticket info
            }
        }
        //save flight info
        for (int i = 0; i < result->segmentcount; ++i)
        {
            FlightSegment seg = result->segments[i];
            isOk = false;
            /*int fId = */saveOrderFlightInfo(psql, seg, orderId, clientId,isOk);
            if (isOk)
            {
                //TODO:Here may do something
            }
        }
    }
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderInfo out===========");
}

void MysqlHandle::generateInlandSCommand(StOrderRequest* orderReqest,StCommands* commands)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::generateInlandSCommand in===========");
    StFlightTrip flightTrip = orderReqest->trip;
    int commandCount = 0;
    StCommand orderCommand;
    orderCommand.subId = 1;
    orderCommand.isHog = 0;
    orderCommand.type = ORDERTICKET;
    orderCommand.status = WAITING;
    orderCommand.result = NULL;
    strcat(orderCommand.content, "SS:");
    strcat(orderCommand.content, flightTrip.segs[0].flightno);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, flightTrip.segs[0].cabin);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, flightTrip.depaturedate);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, flightTrip.cityfrom);
    strcat(orderCommand.content, flightTrip.cityto);
    strcat(orderCommand.content, "/");
    char buf[4];
    sprintf(buf, "%d", orderReqest->passengercount);
    strcat(orderCommand.content, buf);
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "OSI:");
    strcat(orderCommand.content, flightTrip.segs[0].aircompany);
    strcat(orderCommand.content, " CTCT");
    strcat(orderCommand.content, orderReqest->contactor.phonenumber);
    strcat(orderCommand.content, "\n");

    strcat(orderCommand.content, "NM:");
    for (int i = 0; i < orderReqest->passengercount; ++i)
    {
        strcat(orderCommand.content, " 1");
        strcat(orderCommand.content, orderReqest->passengers[i].name);
    }
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "CT:");
    strcat(orderCommand.content, orderReqest->contactor.phonenumber);
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "TKTL/");
    strcat(orderCommand.content, orderReqest->tktltime);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, orderReqest->tktldate);
    strcat(orderCommand.content, "\n");
    //ssr fsd/docs
    strcat(orderCommand.content, "@IOK");
    MSGOUT(en_Msg_Normal, "MysqlHandle::generateOrderCommand:%d, command:%s",
        commandCount, orderCommand.content);
    commands->commands.push_back(orderCommand);
    ++commandCount;
    commands->count = commandCount;

    MSGOUT(en_Msg_Debug, "MysqlHandle::generateInlandSCommand out===========");
}

void MysqlHandle::generateInlandRCommand(StOrderRequest* orderReqest,StCommands* commands)
{
    StFlightTrip flightTrip = orderReqest->trip;
    int commandCount = 0;
    //bool isOk = false;
    StCommand orderCommand;
    orderCommand.subId = 1;
    orderCommand.isHog = 0;
    orderCommand.type = ORDERTICKET;
    orderCommand.status = WAITING;
    orderCommand.result = NULL;
    for (int i = 0; i < 2; ++i)
    {
        strcat(orderCommand.content, "SS:");
        strcat(orderCommand.content, flightTrip.segs[i].flightno);
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, flightTrip.segs[i].cabin);
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, flightTrip.segs[i].flydate);
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, flightTrip.segs[i].cityfrom);
        strcat(orderCommand.content, flightTrip.segs[i].cityto);
        strcat(orderCommand.content, "/");
        char buf[4];
        sprintf(buf, "%d", orderReqest->passengercount);
        strcat(orderCommand.content, buf);
        strcat(orderCommand.content, "\n");
        strcat(orderCommand.content, "OSI:");
        strcat(orderCommand.content, flightTrip.segs[i].aircompany);
        strcat(orderCommand.content, " CTCT");
        strcat(orderCommand.content, orderReqest->contactor.phonenumber);
        strcat(orderCommand.content, "\n");
    }

    strcat(orderCommand.content, "NM:");
    for (int i = 0; i < orderReqest->passengercount; ++i)
    {
        strcat(orderCommand.content, " 1");
        strcat(orderCommand.content, orderReqest->passengers[i].name);
    }
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "CT:");
    strcat(orderCommand.content, orderReqest->contactor.phonenumber);
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "TKTL/");
    strcat(orderCommand.content, orderReqest->tktltime);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, orderReqest->tktldate);
    strcat(orderCommand.content, "\n");
    //ssr fsd/docs
    strcat(orderCommand.content, "@IOK");
    MSGOUT(en_Msg_Normal, "MysqlHandle::generateOrderCommand:%d, command:%s",
        commandCount, orderCommand.content);
    commands->commands.push_back(orderCommand);
    ++commandCount;
    commands->count = commandCount;
}

void MysqlHandle::generateInlandMCommand(StOrderRequest* orderReqest, StCommands* commands)
{
    StFlightTrip flightTrip = orderReqest->trip;
    int commandCount = 0;
    StCommand orderCommand;
    orderCommand.subId = 1;
    orderCommand.isHog = 0;
    orderCommand.type = ORDERTICKET;
    orderCommand.status = WAITING;
    orderCommand.result = NULL;
    for (int i = 0; i < flightTrip.segscount; ++i)
    {
        strcat(orderCommand.content, "SS:");
        strcat(orderCommand.content, flightTrip.segs[i].flightno);
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, flightTrip.segs[i].cabin);
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, flightTrip.segs[i].flydate);
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, flightTrip.segs[i].cityfrom);
        strcat(orderCommand.content, flightTrip.segs[i].cityto);
        strcat(orderCommand.content, "/");
        char buf[4];
        sprintf(buf, "%d", orderReqest->passengercount);
        strcat(orderCommand.content, buf);
        strcat(orderCommand.content, "\n");
        strcat(orderCommand.content, "OSI:");
        strcat(orderCommand.content, flightTrip.segs[i].aircompany);
        strcat(orderCommand.content, " CTCT");
        strcat(orderCommand.content, orderReqest->contactor.phonenumber);
        strcat(orderCommand.content, "\n");
    }

    strcat(orderCommand.content, "NM:");
    for (int i = 0; i < orderReqest->passengercount; ++i)
    {
        strcat(orderCommand.content, " 1");
        strcat(orderCommand.content, orderReqest->passengers[i].name);
    }
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "CT:");
    strcat(orderCommand.content, orderReqest->contactor.phonenumber);
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "TKTL/");
    strcat(orderCommand.content, orderReqest->tktltime);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, orderReqest->tktldate);
    strcat(orderCommand.content, "\n");
    //ssr fsd/docs
    strcat(orderCommand.content, "@IOK");
    MSGOUT(en_Msg_Normal, "MysqlHandle::generateOrderCommand:%d, command:%s",
        commandCount, orderCommand.content);
    commands->commands.push_back(orderCommand);
    ++commandCount;
    commands->count = commandCount;
}

void MysqlHandle::generateInternateSCommand(StOrderRequest* orderReqest,StCommands* commands)
{
    StFlightTrip flightTrip = orderReqest->trip;
    int commandCount = 0;
//    bool isOk = false;
    StCommand orderCommand;
    orderCommand.subId = 1;
    orderCommand.isHog = 0;
    orderCommand.type = ORDERTICKET;
    orderCommand.status = WAITING;
    orderCommand.result = NULL;
    for (int i = 0; i < flightTrip.segscount; ++i)
    {
        strcat(orderCommand.content, "SS:");
        strcat(orderCommand.content, "orderReqest->segments[i].flightno");
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, "orderReqest->cabin");
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, "orderReqest->segments[i].flydate");
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, "orderReqest->segments[i].cityfrom");
        strcat(orderCommand.content, "orderReqest->segments[i].cityto");
        strcat(orderCommand.content, "/");
        char buf[4];
        sprintf(buf, "%d", orderReqest->passengercount);
        strcat(orderCommand.content, buf);
        strcat(orderCommand.content, "\n");
        strcat(orderCommand.content, "OSI:");
        strcat(orderCommand.content, "orderReqest->aircompay");
        strcat(orderCommand.content, " CTCT");
        strcat(orderCommand.content, orderReqest->contactor.phonenumber);
        strcat(orderCommand.content, "\n");
    }

    strcat(orderCommand.content, "NM:");
    for (int i = 0; i < orderReqest->passengercount; ++i)
    {
        strcat(orderCommand.content, " 1");
        strcat(orderCommand.content, orderReqest->passengers[i].name);
    }
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "CT:");
    strcat(orderCommand.content, orderReqest->contactor.phonenumber);
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "TKTL/");
    strcat(orderCommand.content, orderReqest->tktltime);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, orderReqest->tktldate);
    strcat(orderCommand.content, "\n");
    //ssr fsd/docs
    strcat(orderCommand.content, "@IOK");
    MSGOUT(en_Msg_Normal, "MysqlHandle::generateOrderCommand:%d, command:%s",
        commandCount, orderCommand.content);
    commands->commands.push_back(orderCommand);
    ++commandCount;
    commands->count = commandCount;
}

void MysqlHandle::generateInternateRCommand(StOrderRequest* orderReqest,StCommands* commands)
{
    StFlightTrip flightTrip = orderReqest->trip;
    int commandCount = 0;
//    bool isOk = false;
    StCommand orderCommand;
    orderCommand.subId = 1;
    orderCommand.isHog = 0;
    orderCommand.type = ORDERTICKET;
    orderCommand.status = WAITING;
    orderCommand.result = NULL;
    for (int i = 0; i < flightTrip.segscount; ++i)
    {
        strcat(orderCommand.content, "SS:");
        strcat(orderCommand.content, "orderReqest->segments[i].flightno");
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, "orderReqest->cabin");
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, "orderReqest->segments[i].flydate");
        strcat(orderCommand.content, "/");
        strcat(orderCommand.content, "orderReqest->segments[i].cityfrom");
        strcat(orderCommand.content, "orderReqest->segments[i].cityto");
        strcat(orderCommand.content, "/");
        char buf[4];
        sprintf(buf, "%d", orderReqest->passengercount);
        strcat(orderCommand.content, buf);
        strcat(orderCommand.content, "\n");
        strcat(orderCommand.content, "OSI:");
        strcat(orderCommand.content, "orderReqest->aircompay");
        strcat(orderCommand.content, " CTCT");
        strcat(orderCommand.content, orderReqest->contactor.phonenumber);
        strcat(orderCommand.content, "\n");
    }

    strcat(orderCommand.content, "NM:");
    for (int i = 0; i < orderReqest->passengercount; ++i)
    {
        strcat(orderCommand.content, " 1");
        strcat(orderCommand.content, orderReqest->passengers[i].name);
    }
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "CT:");
    strcat(orderCommand.content, orderReqest->contactor.phonenumber);
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "TKTL/");
    strcat(orderCommand.content, orderReqest->tktltime);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, orderReqest->tktldate);
    strcat(orderCommand.content, "\n");
    //ssr fsd/docs
    strcat(orderCommand.content, "@IOK");
    MSGOUT(en_Msg_Normal, "MysqlHandle::generateOrderCommand:%d, command:%s",
        commandCount, orderCommand.content);
    commands->commands.push_back(orderCommand);
    ++commandCount;
    commands->count = commandCount;
}

void MysqlHandle::saveOrderInvoiceInfo(MYSQL* psql, StInvoice invoiceInfo,int hasInvoice, int orderId, bool &isOk)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderInvoiceInfo in===========");
    const char *proc = "proc_airline_order_update_invoice_info";
    char buf[4096] =
    { 0 };
    //IN `hasInvoice` int,IN `orderId` int,IN `sendtype` int,IN `sum` int,IN `receiver` char(20),IN `tel` char(12),IN `addr` char(120)
    sprintf(buf, "call %s (%d, %d, %d, %d, '%s', '%s', '%s');", proc,
        hasInvoice, orderId, invoiceInfo.sendtype, invoiceInfo.sum,
        invoiceInfo.receiver, invoiceInfo.tel, invoiceInfo.addr);
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
    } while (!mysql_next_result(psql));
    my_ulonglong row = mysql_affected_rows(psql);
    if (row > 0)
    {
        isOk = true;
    }
    else
    {
        isOk = false;
    }
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderInvoiceInfo out===========");
}

void MysqlHandle::saveOrderTypeOtherInfo(MYSQL* psql, StFlightTrip tripInfo,int orderId, bool& isOk)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderTypeOtherInfo in===========");
    const char *proc = "proc_airline_order_update_type_info";
    char buf[4096] =
    { 0 };
    //IN `orderId` int,IN `orderType` int,IN `tripType` int,IN `isAudult` int,IN `policyId` int,IN `policyType` int,IN `tgqRule` varchar(200)
    int orderType =
        tripInfo.triptype == 0 || tripInfo.triptype == 1
        || tripInfo.triptype == 2 ? 1 : 2;
    int tripType = tripInfo.triptype == 0 || tripInfo.triptype == 3 ? 1 :
        tripInfo.triptype == 1 || tripInfo.triptype == 4 ? 2 :
        tripInfo.triptype == 2 || tripInfo.triptype == 5 ? 3 : 0;
    sprintf(buf, "call %s (%d, %d,%d, %d, %d, %d,'%s');", proc, orderId,
        orderType, tripType, 0, 0, 0, "");
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
    } while (!mysql_next_result(psql));
    my_ulonglong row = mysql_affected_rows(psql);
    if (row > 0)
    {
        isOk = true;
    }
    else
    {
        isOk = false;
    }
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderTypeOtherInfo out===========");
}

int MysqlHandle::saveOrderPriceInfo(MYSQL* psql, StOrderRequest* order,OrderResultInfo* result, int orderId, bool& isOk)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderPriceInfo in===========");
    int iRet = -1;
    const char *proc = "proc_airline_order_price_insert_price";
    char buf[4096] =
    { 0 };
    //IN `orderId` int,IN `psgType` int,IN `psgCount` int,IN `totalCash` int,IN `ticketCash` int,
    //IN `oilCash` int,IN `taxCash` int,IN `discount` float,IN `rebate` int,IN `pnr` char(10),IN `policyId` int,IN `policyType` int
    int totalCash = 0, ticketCash = 0, oilCash = 0, taxCash = 0;
    ticketCash = order->trip.ourprice * order->passengercount;
    oilCash = order->trip.oilfee * order->passengercount;
    taxCash = order->trip.taxfee * order->passengercount;
    totalCash = ticketCash + oilCash + taxCash;
    sprintf(buf, "call %s (%d, %d,%d, %d,%d, %d,%d, %f,%d, '%s',%d, %d);", proc,
        orderId, order->passengercount, totalCash, ticketCash, oilCash,
        taxCash, 0, 0.0, 0, result->pnr, 0, 0);
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {
            if (res->row_count == 1)
            {
                MYSQL_ROW row = mysql_fetch_row(res);
                if (row != NULL)
                {
                    iRet = atoi(row[0]);
                }
            }
            mysql_free_result(res);
            //break;
        }
    } while (!mysql_next_result(psql));
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderPriceInfo out===========");
    return iRet;
}

int MysqlHandle::saveOrderTicketInfo(MYSQL* psql, StOrderRequest* order, OrderResultInfo* result, int orderId, int passengerId, int priceId,bool& isOk)
{
    int iRet = -1;
    //TODO:save ticket info
    return iRet;
}

int MysqlHandle::saveOrderPassengerInfo(MYSQL* psql, StPassenger passenger, int orderId, int clientId, bool& isOk)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderPassengerInfo in===========");
    int iRet = -1;
    isOk = false;
    const char *proc = "proc_airline_order_passenger_insert_passenger";
    char buf[4096] =
    { 0 };
    //IN `orderId` int,IN `pname` varchar(40),IN `ptype` int,IN `idType` int,IN `idNo` varchar(30),
    //IN `birth` varchar(12),IN `validDate` varchar(12),IN `sex` int,IN `guoji` varchar(2),IN `issuePlace` varchar(40),
    //IN `pphone` varchar(30),IN `docs` varchar(100),IN `userId` int
    sprintf(buf,
        "call %s (%d, '%s',%d, %d,  '%s', '%s', '%s',%d,  '%s', '%s', '%s','%s',%d);",
        proc, orderId, passenger.name, passenger.ptype, passenger.idtype,
        passenger.idnumber, passenger.birthday, passenger.validdate,
        passenger.sex, passenger.nationality, passenger.issueplace,
        passenger.phonenumber, "", clientId);
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {
            if (res->row_count == 1)
            {
                MYSQL_ROW row = mysql_fetch_row(res);
                if (row != NULL)
                {
                    iRet = atoi(row[0]);
                    isOk = true;
                }
            }
            mysql_free_result(res);
            //break;
        }
    } while (!mysql_next_result(psql));
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderPassengerInfo out===========");
    return iRet;
}

int MysqlHandle::saveOrderFlightInfo(MYSQL* psql, FlightSegment segment, int orderId, int clientId, bool& isOk)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderFlightInfo in===========");
    int iRet = -1;
    isOk = false;
    const char *proc = "proc_airline_order_flight_insert_flight";
    char buf[4096] =
    { 0 };
    //IN `orderId` int,IN `fIndex` int,IN `isDirectF` int,IN `airCraftType` varchar(50),IN `realFNo` varchar(10),
    //IN `realATWC` char(2),IN `saleFNo` varchar(10),IN `saleATWC` char(2),IN `startAName` varchar(40),
    //IN `gotoAName` varchar(40),IN `transferAName` varchar(40),IN `startACode` char(3),IN `gotoACode` char(3),
    //IN `transferACode` char(3),IN `startTName` char(4),IN `gotoTName` char(4),IN `transferTName` char(4),
    //IN `departureTimeS` bigint,IN `transferTimeS` bigint,IN `transferTimeSE` bigint,IN `arrivalTimeS` bigint,
    //IN `departureTime` varchar(12),IN `transferTime` varchar(12),IN `transferTimeE` varchar(12),IN `arrivalTime` varchar(12),IN `clientId` int
    sprintf(buf,
        "call %s (%d, %d, %d, '%s', '%s', '%s',  '%s', '%s', '%s','%s','%s', '%s', '%s','%s','%s', '%s', '%s',%d,%d,%d,%d ,'%s','%s','%s', '%s',%d);",
        proc, orderId, segment.segindex, 0, "", segment.flightno,
        segment.aircompany, "", "", "", "", "", segment.depature,
        segment.arrival, "", "", "", "", 0, 0, 0, 0, "", "", "", "",
        clientId);
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {
            if (res->row_count == 1)
            {
                MYSQL_ROW row = mysql_fetch_row(res);
                if (row != NULL)
                {
                    iRet = atoi(row[0]);
                    isOk = true;
                }
            }
            mysql_free_result(res);
            //break;
        }
    } while (!mysql_next_result(psql));
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderFlightInfo out===========");
    return iRet;
}

void MysqlHandle::saveOrderSeriaNoInfo(MYSQL* psql, int orderId, const char* date, const char* type, bool& isOk)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderSeriaNoInfo in===========");
    const char *proc = "proc_airline_order_update_orderid_info";
    char buf[4096] =
    { 0 };
    std::string serialNo = generateFixLengthString(orderId);
    std::string dateNo = date;
    std::string typeNo = type;
    sprintf(buf, "call %s ('%s', %d);", proc,
        dateNo.append(typeNo).append(serialNo).c_str(), orderId);
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
    } while (!mysql_next_result(psql));
    my_ulonglong row = mysql_affected_rows(psql);
    if (row > 0)
    {
        isOk = true;
    }
    else
    {
        isOk = false;
    }
    MSGOUT(en_Msg_Debug, "MysqlHandle::saveOrderSeriaNoInfo out===========");
}

void MysqlHandle::generateInternateMCommand(StOrderRequest* orderReqest, StCommands* commands)
{
    /*StFlightTrip flightTrip = orderReqest->trip;
    int commandCount = 0;
    bool isOk = false;
    StCommand orderCommand =
    { 0 };
    orderCommand.subId = 1;
    orderCommand.isHog = 0;
    orderCommand.type = ORDERTICKET;
    orderCommand.status = WAITING;
    orderCommand.result = NULL;
    for (int i = 0; i < 1orderReqest->segmentcount; ++i)
    {
    strcat(orderCommand.content, "SS:");
    strcat(orderCommand.content, "orderReqest->segments[i].flightno");
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, "orderReqest->cabin");
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, "orderReqest->segments[i].flydate");
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, "orderReqest->segments[i].cityfrom");
    strcat(orderCommand.content, "orderReqest->segments[i].cityto");
    strcat(orderCommand.content, "/");
    char buf[4];
    sprintf(buf, "%d", orderReqest->passengercount);
    strcat(orderCommand.content, buf);
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "OSI:");
    strcat(orderCommand.content, "orderReqest->aircompay");
    strcat(orderCommand.content, " CTCT");
    strcat(orderCommand.content, orderReqest->contactor.phonenumber);
    strcat(orderCommand.content, "\n");
    }

    strcat(orderCommand.content, "NM:");
    for (int i = 0; i < orderReqest->passengercount; ++i)
    {
    strcat(orderCommand.content, " 1");
    strcat(orderCommand.content, orderReqest->passengers[i].name);
    }
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "CT:");
    strcat(orderCommand.content, orderReqest->contactor.phonenumber);
    strcat(orderCommand.content, "\n");
    strcat(orderCommand.content, "TKTL/");
    strcat(orderCommand.content, orderReqest->tktltime);
    strcat(orderCommand.content, "/");
    strcat(orderCommand.content, orderReqest->tktldate);
    strcat(orderCommand.content, "\n");
    //ssr fsd/docs
    strcat(orderCommand.content, "@IOK");
    MSGOUT(en_Msg_Normal, "MysqlHandle::generateOrderCommand:%d, command:%s",
    commandCount, orderCommand.content);
    commands->commands.push_back(orderCommand);
    ++commandCount;
    commands->count = commandCount;*/
}

std::string MysqlHandle::generateFixLengthString(long source, int len)
{
    std::string sRet = "00000000";
    char sNum[10] =
    { 0 };
    sprintf(sNum, "%ld", source);
    sRet = sNum;
    int sLen = sRet.length();
    while (sLen > len)
    {
        sRet = sRet.substr(0, sLen - 2);
        --sLen;
    }
    while (sLen < len)
    {
        sRet.insert(0, "0");
        ++sLen;
    }
    return sRet;
}

void MysqlHandle::deallowercabinsrequest(MYSQL* psql, int maincmd,int assistcmd, void* pdata, unsigned int ulen, void* pclient)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::deallowercabinsrequest in===========");
    StLowerCabinsRequest *lowerCabinsRequest = (StLowerCabinsRequest *) malloc(
        sizeof(*(StLowerCabinsRequest *) pdata));
    memcpy(lowerCabinsRequest, pdata, sizeof(*(StLowerCabinsRequest *) pdata));
    if (strlen(lowerCabinsRequest->airCompany) <= 0)
    {
        lowerCabinsRequest->airCompany[0] = lowerCabinsRequest->flightNo[0];
        lowerCabinsRequest->airCompany[1] = lowerCabinsRequest->flightNo[1];
    }
    int fd = (int) (long) pclient;
    StCommands *commands = new StCommands;
    memset(commands, 0, sizeof(StCommands));
    commands->status = WAITING;
    commands->current = 0;
    commands->ishog = true;
    if (commands != NULL)
    {
        bool isOk = false;
        StCommand sAv = CommandGenerator::generateSpecialAv(isOk,
            lowerCabinsRequest->flightNo, lowerCabinsRequest->date);
        sAv.type = AVAILABLELOWERCABINAV;
        commands->commands.push_back(sAv);
        ++commands->count;
    }
    //set the lower cabins request object to the context
    commands->context = lowerCabinsRequest;
    //send order command to the eterm
    sendCommands(commands, fd);
    MSGOUT(en_Msg_Debug, "MysqlHandle::deallowercabinsrequest out===========");
}

void MysqlHandle::deallowercabinsresult(MYSQL* psql, int maincmd, int assistcmd,  void* pdata, unsigned int ulen, void* pclient)
{
    StCommands *commands = *((StCommands **) pdata);
    StCommand &command = commands->commands[commands->current];
    StLowerCabinsRequest *request = (StLowerCabinsRequest *) commands->context;
    if (command.type == AVAILABLELOWERCABINAV && command.result != NULL)
    {
        avSpecialInfo sAvResult;
        memset(&sAvResult, 0, sizeof(avSpecialInfo));
        sEterm.DealSpecialAvStr((char *) command.result, &sAvResult);
        std::vector<std::string> maybeExistLowerCabin, lowerCabin;
        maybeExistLowerCabin.clear();
        lowerCabin.clear();
        //TODO:根据现有舱位和航空公司找出可能更低的舱位
        //sAvResult.
        int lowerCabinsCount = maybeExistLowerCabin.size();
        for (int i = 0; i < lowerCabinsCount; ++i)
        {
            int availableCabinsCount = sAvResult.cabins.cabincount;
            for (int j = 0; j < availableCabinsCount; ++j)
            {
                //char cabin = sAvResult.cabins.cabins[j][0];
                char cabinStatus = sAvResult.cabins.cabins[j][1];
                if (maybeExistLowerCabin[i].compare(0, 1,
                    sAvResult.cabins.cabins[j]) == 0
                    && (cabinStatus == 'Q' || cabinStatus == 'A'))
                {
                    lowerCabin.push_back(maybeExistLowerCabin[i]);
                }
            }
        }
        //获取到可能放出的底舱了
        StLowerCabinsResponse lowerCabinResponse;
        memset(&lowerCabinResponse, 0, sizeof(StLowerCabinsResponse));
        strcpy(lowerCabinResponse.flightNo, request->flightNo);
        lowerCabinResponse.lowerCabinCount = lowerCabin.size();
        lowerCabinsCount = lowerCabin.size();
        std::string strLowerCabins = "";
        for (int i = 0; i < lowerCabinsCount; ++i)
        {
            strLowerCabins.append(lowerCabin[i]);
        }
        strcpy(lowerCabinResponse.lowerCabins, strLowerCabins.c_str());

        int fd = (int) (long) pclient;
        int resultSize = sizeof(StLowerCabinsResponse);
        int totalSize = sizeof(NetSocketHead) + resultSize;
        char *buf = (char *) malloc(totalSize);
        NetSocketHead* phead = (NetSocketHead *) buf;
        phead->uMainCmd = MAINSVR_CLIENT_TYPE;
        phead->uSubCmd = MC_LOWER_CABIN_RESULT;
        phead->uLen = totalSize;
        unsigned int len = phead->uLen;
        StLowerCabinsResponse *pLowerCabinResponse =
            (StLowerCabinsResponse *) (phead + 1);
        memcpy(pLowerCabinResponse, &lowerCabinResponse, resultSize);
        sendData(buf, len, fd);
    }
}

MysqlHandle::MysqlHandle()
{

}

LowerCabinScannerData* MysqlHandle::loadLowerCabinOrderData(MYSQL* psql, int count)
{
    MSGOUT(en_Msg_Debug,"MysqlHandle::loadLowerCabinOrderData in=================================");
    LowerCabinScannerData* header =NULL;
    LowerCabinScannerData*current = NULL;
    int i = 1;
    while (i--)
    {
        LowerCabinScannerData * scannerData = new LowerCabinScannerData;
        scannerData->next = NULL;
        //scannerData->mysqlHandler = NULL;
        scannerData->commands = NULL;
        /*LowerCabinOrderData*data = new LowerCabinOrderData;*/
        LowerCabinOrderData*data = initOrderData();
        scannerData->orderData = data;
        /*LowerCabinSettings *settings = new LowerCabinSettings;*/
        LowerCabinSettings *settings = initSettingData();
        scannerData->settings = settings;
        /*LowerUserData *userData = new LowerUserData;*/
        LowerUserData *userData = initUserData();
        scannerData->userData = userData;

        if (header == NULL)
        {
            header = scannerData;
            current = scannerData;
        }
        else
        {
            current->next = scannerData;
            current = current->next;
        }
    }
    MSGOUT(en_Msg_Debug, "MysqlHandle::loadLowerCabinOrderData out==================================");
    return header;
}

void MysqlHandle::sendCommands(StCommands* cmdPatch)
{
    MSGOUT(en_Msg_Debug, "MysqlHandle::sendCommands,commands size %d", cmdPatch->count);
    PostQueueResult(DB_SEND_LOWERCABIN_COMMAND, 0, &cmdPatch, sizeof(StCommands*), 0);
}

LowerCabinOrderData* MysqlHandle::initOrderData()
{
    LowerCabinOrderData* orderData = new LowerCabinOrderData;
    TripType tripTyps[2] = { TRIP_INLAND, TRIP_INTERNATE };
    /*int tripType = */CommonLib::randomizeNumber(3, 2);
    orderData->tripType = tripTyps[TRIP_INTERNATE];
    return orderData;
}

LowerCabinSettings* MysqlHandle::initSettingData()
{
    LowerCabinSettings* settings = new LowerCabinSettings;
    return settings;
}

LowerUserData* MysqlHandle::initUserData()
{
    LowerUserData* userData = new LowerUserData;
    return userData;
}

void MysqlHandle::deallowercabinpatresult( MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient )
{
    StCommand *patResult = *((StCommand **) pdata);
    MSGOUT(en_Msg_Debug,"context id:%s,command type:%d",patResult->identifiers.c_str(),patResult->type);
    if (patResult->type != PAT)
    {
        return;
    }
    //this trip generated by LowerCabinScannerData and pat
    StFlightTrip * trip = NULL;
    //match policy
    pricePolicyFilters(trip);
    if (true)
    {
        //new price lower than old price, here we should change the lower cabin to the target order
        pthread_mutex_lock(&ServerMain::rcMutex);
        LowerCabinScannerData* context = ServerMain::lowerCabinContext[patResult->identifiers];

        pthread_mutex_unlock(&ServerMain::rcMutex);
    }
    else
    {
        //new price equal or more than old price,
        pthread_mutex_lock(&ServerMain::rcMutex);
        LowerCabinScannerData*context = ServerMain::lowerCabinContext[patResult->identifiers];

        if (-- context->scanThreadCount <= 0)
        {
            context->status = SCANSTATUS_WAITTING;
        }
        pthread_mutex_unlock(&ServerMain::rcMutex);

    }

}

void MysqlHandle::dealbestcabinpriceresult( MYSQL* psql, int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient )
{
    /*StTrip *trip = (StTrip *) malloc(sizeof(*(StTrip *) pdata));
    memcpy(trip, pdata, sizeof(*(StTrip *) pdata));
    if (trip == NULL || trip->segsCount <= 0)
    {
    // no request data or trip data broken
    MSGOUT(en_Msg_Error,"MysqlHandle::dealticketpricerequest trip is null,maybe some where occur error.%p-%d-%d",trip, trip->triptype, trip->segscount);
    return;
    }*/

}

void MysqlHandle::loadAirCompanyCabinMap( MYSQL* psql )
{
    const char *proc = "proc_aircompany_cabin_type";
    char buf[4096] = { 0 };
    sprintf(buf, "call %s ();",proc);
    MSGOUT(en_Msg_Debug, "%s", buf);
    int res = mysql_query(psql, buf);
    if (res != 0)
    {
        throw DB_ERROR_PROCERR;
    }
    do
    {
        MYSQL_RES *res = mysql_store_result(psql);
        if (res == NULL)
        {
            break;
        }
        else
        {

            if (res->row_count > 0)
            {
                MYSQL_ROW row = mysql_fetch_row(res);
                while (row != NULL)
                {
                    PhysicalCabin cabin = {0};
                    cabin.firstClass=row[2] ==NULL?"":row[2];
                    cabin.bussinessClass=row[3] ==NULL?"":row[3];
                    cabin.economyClass=row[3] ==NULL?"":row[3];
                    cabin.superEconomyClass=row[3] ==NULL?"":row[3];
                    ServerMain::aircompanyCabinMap[std::string(row[1])]=cabin;
                    row = mysql_fetch_row(res);
                } 
                mysql_free_result(res);
            }
        }
    } while (!mysql_next_result(psql));

}
