/*******************************************************************************
 # Author       : humm
 # Email        : asok00000@qq.com
 # CreateTime   : 2014-12-16 16:50:05
 # LastModified : 2014-08-06 15:08:31
 # FileName     : structs.h
 # Description  :
 ******************************************************************************/
#ifndef _STRUCTS_H
#define _STRUCTS_H
#include <stddef.h>
#include <vector>
#include <string>
#include <string.h>
#include "ETermString.h"
enum CommandStatus
{
	WAITING, PROCESSING, COMPLETE
};
enum CommandType
{
	SPECIALAV,
	ORDERTICKET,
	ORDERFD,
    ORDERFSD,
	AB,
	AV,
	ASR,
	DSTR,
	FD,
	FF,
	FV,
	MI,
	NFD,
	PAT,
	PB,
	QTB,
	QTE,
	SK,
	TKTV,
	TOL,
	TPR,
	XSFSD,
	XSFSG,
	PN,
	XSFSPN,
	AVAILABLELOWERCABINAV,
	LCSAV,
	LCAVH,
    RT,
    BESTPRICE_SAV,
    BESTPRICE_AV,
    BESTPRICE_SS,
    BESTPRICE_PAT,
    BESTPRICE_QTE,
};
enum AvType{
    AVTYPE_SPECIAL = 0,
    AVTYPE_NORMAL,
    AVTYPE_H,
};
enum CommandsType
{
	ORDER_PATCH, //commands are order
};
enum LowerCabinNotifyType
{
	NOTYFY_NOTHING = 0, NOTIFY_CLIENT, NOTIFY_PHONE, NOTIFY_BOTH,
};
enum LowerCabinStatus
{
	SCANSTATUS_WAITTING = 0, SCANSTATUS_PROCESSING, SCANSTATUS_FINISH,
};
enum TripType
{
	TRIP_INLAND = 0, TRIP_INTERNATE,
};
enum FlightType
{
	FLIGHT_SINGLE = 0, FLIGHT_RETURN, FLIGHT_MORE
};
class  StCommand
{
public:
	int subId; //sub-command id
	int identifyId;//unique id  //  lbs of command
	int isHog; //is hog
	int timeout; //time out
    std::string identifiers;    //lbs of context
	CommandType type; //sub-command type
	CommandStatus status; //sub-command status
	char content[255]; //sub-command content
	void *result; // result
	void *formartedresult; //deal command result
    std::vector<std::string> targetFlightsNo;
    StCommand()
    {
        memset(content, 0, sizeof content);
        subId = -1;
        identifyId = -1;
        isHog = -1;
        timeout = -1;
        identifiers = "";
        type  = AV;
        status = WAITING;
        result = NULL;
        formartedresult = NULL;
    }
    StCommand(const StCommand &command)
    {
        this->clone(command);
    }
	void clone(const StCommand& command)
	{
		this->subId = command.subId;
		strcpy(this->content,command.content);
		this->formartedresult = command.formartedresult;
		this->isHog = command.isHog;
		this->result = command.result;
		this->status = command.status;
		this->timeout = command.timeout;
		this->type = command.type;
	};
    void setTargetFlights(std::vector<std::string> flights)
    {
        int count = flights.size();
        for (int i = 0 ; i < count ; ++i)
        {
            this->targetFlightsNo.push_back(flights[i]);
        }
    }
};
struct StCommands
{
	int id; //commands patch id
	int clientid; // owner id
	int timeout; //time out
	int count; // sub-commands' count
	int current; // current sub command index
	std::string identifiers;
	bool ishog; // is hog
	void *revers; //may be null,may be otherelse
	void *context; //may be null,may be otherelse
	CommandStatus status; //command patch status
	CommandsType type; // commands patch type
	std::vector<StCommand> commands; //commands
	StCommands()
	{
		id = 0;
		clientid = -1;
		timeout = -1;
		count = 0;
		current = -1;
		ishog = false;
		revers = NULL;
		context = NULL;
		status = WAITING;
		identifiers = "";
		commands.clear();
	}
};

struct LowerCabinOrderData
{
	int orderId;  //订单id，可能会取订单的一些数据
	int clientId;	//这个可能会用在发命令的地方
	int orderCabinId;// order cabin id situations:one order ,more than two pnr
	int segType;	//单航空，多航空，联运，共享航班
	int pType;	//成人，儿童，婴儿，留学生，劳工，新移民
	int seatType;	//头等舱，公务舱，超级经济舱，经济舱，混舱
	int passengerCount;	//passenger count bind with this bunk info
    std::string pnr;    //  pnr
	TripType tripType;	//inland,internate
	FlightType flightType;	//single,return,more
	std::vector<FlightSegment> trips;
	LowerCabinOrderData()
	{
		/*orderId = -1;
		 clientId = -1;
		 orderCabinId = -1;
		 segType = 0;
		 pType = 0;
		 seatType = 0;
		 passengerCount = 0;
		 tripType = TRIP_INLAND;
		 flightType = FLIGHT_SINGLE;
		 trips.clear();
         pnr = "";*/
		orderId = 100010;
		clientId = 100020;
		orderCabinId = 100030;
		segType = 0;
		pType = 0;
		seatType = 0;
		passengerCount = 0;
        pnr = "3HS42";
		tripType = TRIP_INLAND;
		flightType = FLIGHT_SINGLE;
		FlightSegment seg1;
		seg1.segindex = 1;
		trips.push_back(seg1);
		seg1.segindex = 2;
		trips.push_back(seg1);
	}
};
struct LowerTimePare
{
	std::string from;	//00:00:00
	std::string to;	//00:00:00
	int minPerTimes;	//10min/t
	time_t timestampFrom;	//timestamp
	time_t timestampTo;	//timestamp
	LowerTimePare()
	{
		/*from = "";
		 to = "";
		 minPerTimes = 0;*/
		from = "00:00:00";
		to = "23:59:59";
		timestampFrom = 0;
		timestampTo = 0;
		minPerTimes = 10;
	}
	;
};
struct LowerFrequence
{
	time_t timestampFrom; //2015-1-15 00:00:00's timestamp
	time_t timestampTo; //2015-1-18 23:59:59's timestamp
	std::string dateFrom; //2015-1-15
	std::string dateTo; //2015-1-15
	std::vector<LowerTimePare> timePares;
	LowerFrequence()
	{
		/*timestampFrom = 0;
		 timestampTo = 0;
		 dateFrom = "";
		 dateTo = "";
		 timePares.clear();*/
		timestampFrom = 0;
		timestampTo = 0;
		dateFrom = "2015-1-20";
		dateTo = "2015-2-20";
		LowerTimePare timePare;
		timePares.push_back(timePare);
	}
	;
};
struct LowerCabinFlightCabins
{
	bool swaped;
	std::string flightNo;
	std::string currentCabin;
	std::string availableCabin;
	LowerCabinFlightCabins()
	{
		swaped = false;
		flightNo = "CA4199";
		currentCabin = "Y";
		availableCabin = "ABCDEFGHIJKMLNOPQRSTUVWXYZ";
	}
};
//lower cabin scan settings
struct LowerCabinSettings
{
	LowerCabinNotifyType notyfyType;
	bool notifyAfterRR;
	bool notyfyLimitTimeLessThan12;
	int autoBuy;
	std::string phoneNumber;
	std::vector<LowerCabinFlightCabins> cabins;
	std::vector<LowerFrequence*> frequence;
	LowerFrequence*todayFrequence;
	LowerCabinSettings()
	{
		/*notyfyType = NOTYFY_NOTHING;
		 notifyAfterRR = true;
		 notyfyLimitTimeLessThan12 = true;
		 autoBuy = 100000;
		 phoneNumber = "";
		 flightNo = "";
		 currentCabin = "";
		 todayFrequence = NULL;
		 frequence.clear();*/
		notyfyType = NOTIFY_BOTH;
		notifyAfterRR = true;
		notyfyLimitTimeLessThan12 = true;
		autoBuy = 100000;
		phoneNumber = "15828513686";
		todayFrequence = NULL;
		LowerFrequence*frequences = new LowerFrequence;
		frequence.push_back(frequences);
		LowerCabinFlightCabins flightsCabin;
		cabins.push_back(flightsCabin);
	}
	;
};
//user data
struct LowerUserData
{
	int userId;	//user id
	LowerUserData()
	{
		/*userId = -1;*/
		userId = 100001;
	}
};
struct LowerAvResult
{
    AvType type;
    void *result;
};
//log data
struct LowerLogData
{
	enum LogType
	{
		LOWERLOG_NORMAL_OPERATION = 1, LOWERLOG_CLIENT_MSG, LOWERLOG_SHORT_MSG,
	};
	LogType type;
	int orderId; // the order ,which log belong
	std::string dateTime;		//log time
	std::string operateBy;	//default system
	std::string content;		//log content
	LowerLogData()
	{
		type = LOWERLOG_NORMAL_OPERATION;
		orderId = -1;
		dateTime = "1970-01-01 00:00:00";
		operateBy = "system";
		content = "";
	}
	;
};
struct LowerCabinScannerData
{
	StCommands *commands;

	int scantimes;		//times scanned
    int scanThreadCount;    //how many segs, how many count
	time_t lastscantimestamp;	//last scan timestamp
	LowerCabinStatus status;	//	scan status
	LowerCabinSettings *settings;	//store settings and the scan data
	LowerCabinOrderData *orderData;	// store order data
	LowerUserData *userData;	//user data
	std::vector<LowerLogData *> logData;//log data include operations on order and msg whitch will sent to client
	std::vector<StCommand *> recvCommandData;//work flow eterm command with result
	std::vector<StCommands *> sentCommandData;		// sent commands

    LowerCabinScannerData *next;
	LowerCabinScannerData()
	{
		/*scantimes = 0;
		 lastscantimestamp = -1;
		 status = SCANSTATUS_WAITTING;
		 settings = NULL;
		 orderData = NULL;
		 userData = NULL;
		 logData.clear();
		 recvCommandData.clear();
		 sentCommandData.clear();*/
		scantimes = 0;
        scanThreadCount = 0;
		lastscantimestamp = -1;
		status = SCANSTATUS_WAITTING;
		settings = NULL;
		orderData = NULL;
		userData = NULL;
		logData.clear();
		recvCommandData.clear();
		sentCommandData.clear();
	}
	;
};
struct AvhResults
{
    avhtravelInfo *avhInfo;
    AvhResults *next;
};
struct PatResults
{
    patpriceinfo *patInfo;
    PatResults *next;
};
struct PhysicalCabin
{
    std::string firstClass;
    std::string bussinessClass;
    std::string economyClass;
    std::string superEconomyClass;
};
#endif // _STRUCTS_H
