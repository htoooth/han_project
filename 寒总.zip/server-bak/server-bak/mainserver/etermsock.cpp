/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-11 19:50:41
# LastModified : 2015-02-12 17:08:18
# FileName     : etermsock.cpp
# Description  : 
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "etermsock.h"
#include "dealnetdata.h"
#include "ssprotocol.h"
#include "scprotocol.h"
#include "ssstructdef.h"
#include "showmsg.h"
#include "dbdefine.h"


bool EtermSvrSocket::_start_server(void* pdata, ISvrCallback* pcb) {

	m_pevent = (QueueEventModule*)pdata;

	return CenterSocket::_start_server(NULL, pcb);
}
EtermSvrSocket::EtermSvrSocket() {
	m_pevent = NULL;
}

bool EtermSvrSocket::OnRecvData(char* pdata, unsigned int ulen) {
	if (pdata == NULL || ulen < HEAD_SIZE)
		return false;

	NetSocketHead* phead = (NetSocketHead*)pdata;
	if (phead->uMainCmd != MAINSVR_ETERMSVR_TYPE)
		return false;

	switch(phead->uSubCmd) {
		case ME_TYPE_ETERMRESULT: 
		{
			_StEtermSvrResult* pres = (_StEtermSvrResult*)(phead+1);
			ulen -= sizeof(NetSocketHead);
			PostDBRequest(DB_COMMAND_RESULT, 0, pres, ulen, NULL);
		}
		break;
		default:
			MSGOUT(en_Msg_Warning, "EtermSvrSocket::OnRecvData unknow cmd, maincmd:%d, subcmd:%d, pdata:%p, len:%u", phead->uMainCmd, phead->uSubCmd, pdata, ulen);
			return false;
	}

	return true;
}

void EtermSvrSocket::OnClose() {
	MSGOUT(en_Msg_Normal, "EtermSvrSocket::OnClose close");
	PostDBRequest(DB_ETERMSVR_RECON, 0, NULL, 0, NULL);
}

bool EtermSvrSocket::PostDBRequest(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	if (m_pevent == NULL)
		return false;

	return m_pevent->PostQueueEvent(maincmd, assistcmd, pdata, ulen, pclient); 
}

int EtermSvrSocket::sendcommnad(const char* cmd, unsigned int len , int id, int type) {

	char buf[4096] = {0};
	NetSocketHead* phead = (NetSocketHead*)buf;
	phead->uMainCmd = MAINSVR_ETERMSVR_TYPE;
	phead->uSubCmd = ME_TYPE_ETERMRESULT;
	unsigned int ulen = sizeof(NetSocketHead);

	_StEtermSvrResult* pinfo = (_StEtermSvrResult*)(phead+1);
	pinfo->zhijianid = id;
	pinfo->cmdtype = type;
	ulen += sizeof(_StEtermSvrResult);

	char* pcmd = (char*)(pinfo+1);
	memcpy(pcmd, buf, strlen(cmd)+1);

	ulen += strlen(cmd)+1;

	return senddata(buf, ulen);
}
