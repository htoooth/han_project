/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-12-26 16:49:08
# LastModified : 2014-12-26 17:27:35
# FileName     : svrloop.cpp
# Description  :
******************************************************************************/
/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-27 14:36:25
# LastModified : 2014-11-12 19:15:47
# FileName     : svrloop.cpp
# Description  :
******************************************************************************/
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <sstream>

#include "svrloop.h"
#include "readconf.h"
#include "ssprotocol.h"
#include "ssstructdef.h"
#include "scstructdef.h"
#include "dbdefine.h"
#include "ETermString.h"

enum
{
    TIMER_RECONNECT_LOGINSVR = 1,
    TIMER_UPDATAUSER,
    TIMER_COMMANDSENDER,
    TIMER_RECONNECT_ETERMSVR,
    TIMER_LOADLOWERCABINORDER,
};

#define TIME_RECONNECT_LOGINSVR	    (10*1000)
#define TIME_UPDATAUSER		(180*1000)
#define TIME_RELOADLOWERCABINORDER (1000*60*1000)
#define TIME_RECONNECT_ETERMSVR     (1000*10)


std::queue<LowerCabinScanTask*> ServerMain::tasks;
std::map<std::string, LowerCabinScannerData*> ServerMain::lowerCabinContext;
std::map<std::string,LowerAvResult> ServerMain::lowerAvResuts;
std::map<std::string,PhysicalCabin> ServerMain::aircompanyCabinMap;
pthread_mutex_t ServerMain::rcMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t ServerMain::rtMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t ServerMain::avResultMutex= PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t ServerMain::uidMutex = PTHREAD_MUTEX_INITIALIZER;
sem_t ServerMain::semRc;


bool ServerMain::OnSocketRead(int fd, void* pdata, unsigned int ulen)
{

    if (m_mapfd.find(fd) == m_mapfd.end() || pdata == NULL
        || ulen < sizeof(NetSocketHead))
        return false;

    NetSocketHead* p = (NetSocketHead*) pdata;

    switch (p->uMainCmd)
    {
    case SYSTEM_PROTOCOL_TYPE:
        {

        }
        break;
    case MAINSVR_CLIENT_TYPE:
        return DealClientData(fd, p->uHelpCmd, pdata, ulen);
    }

    return false;
}

bool ServerMain::OnSocketConnect(int fd, struct sockaddr_in* paddr)
{

    _StConnectInfo* p = (_StConnectInfo*) malloc(sizeof(_StConnectInfo));
    memset(p, 0, sizeof(_StConnectInfo));
    p->fd = fd;

    strcpy(p->ip, inet_ntoa(paddr->sin_addr));
    p->port = ntohs(paddr->sin_port);
    m_mapfd[fd] = p;

    MSGOUT(en_Msg_Normal, "ServerMain::OnSocketRead connect fd:%d, ip:%s", fd,
        inet_ntoa(paddr->sin_addr));

    return true;
}

void ServerMain::OnSocketClose(int fd)
{

    _StConnectInfo* p = (_StConnectInfo*) m_mapfd[fd];
    StClientInfo *pClientInfo = (StClientInfo *) p->pdata;
    if (pClientInfo != NULL)
    {
        //clear client's commands
        std::map<int, std::queue<StCommands*> >::iterator iter =
            m_commands.find(pClientInfo->idx);
        if (iter != m_commands.end())
        {
            std::queue<StCommands*> commands = iter->second;

            while (!commands.empty())
            {
                StCommands* command = commands.front();
                if (command != NULL)
                    delete command;
                commands.pop();
            }
            m_commands.erase(pClientInfo->idx);
        }

    }
    if (p != NULL)
    {
        if (p->pdata != NULL)
        {
            free(p->pdata);
        }
        free(p);
        p = NULL;
    }
    m_mapfd.erase(fd);

    MSGOUT(en_Msg_Normal, "ServerMain::OnSocketClose fd:%d", fd);
}

void ServerMain::OnEventTimer(unsigned int uid)
{
    switch (uid)
    {
    case TIMER_RECONNECT_LOGINSVR:
        {
            if (connectloginsvr()) {
                addmodule();
            }
            else {
                settimer(TIMER_RECONNECT_LOGINSVR, TIME_RECONNECT_LOGINSVR);
            }
            MSGOUT(en_Msg_Debug, "reconnect loginsvr!");
        }
        break;
    case TIMER_UPDATAUSER:
        {
            sendusercount();
            settimer(TIMER_UPDATAUSER, TIME_UPDATAUSER);
        }
        break;
    case TIMER_COMMANDSENDER:
        {
            //firecommandsender();
        }
        break;
    case TIMER_RECONNECT_ETERMSVR:
        {
            if (connectetermsvr()) {
                addmodule();
            }
            else {
                settimer(TIMER_RECONNECT_ETERMSVR, TIME_RECONNECT_ETERMSVR);
            }
        }
        break;
    case TIMER_LOADLOWERCABINORDER:
        {
            startLowerCabinScanner();
        }
        break;
    }
}

void ServerMain::SettleDBResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient)
{
    switch (maincmd)
    {
    case DB_VERIFY_LOGINPWD:
        {
            int fd = (int) (long) pclient;
            _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
            StClientInfo *pClientInfo = *((StClientInfo **) pdata);
            pinfo->pdata = pClientInfo;
            if (pinfo == NULL)
                return;
            char buf[4096] = { 0 };
            NetSocketHead* phead = (NetSocketHead*) buf;

            phead->uMainCmd = MAINSVR_LOGINSVR_TYPE;
            phead->uSubCmd = MC_VERIFY_LOGIN_PASSWD;
            phead->uHelpCmd = assistcmd;
            phead->uLen = HEAD_SIZE;
            unsigned int len = phead->uLen;
            senddata(pinfo->fd, buf, len);

            if (assistcmd != VERIFY_ERROR_NULL)
            {
                MSGOUT(en_Msg_Debug, "login mainserver failed, fd : %d", fd);
                closeconnect(pinfo->fd);
            }
            else
            {
                pinfo->contype = CON_TYPE_CLIENT_COM;
            }

            MSGOUT(en_Msg_Debug, "ServerMain::SettleDBResult send!!!!");
        }
        break;
    case DB_FLIGHT_SEARCH_REQUEST:
        {
            int fd = (int) (long) pclient;
            _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
            if (pinfo == NULL)
                return;
            StFlightSearchRequest *response = (StFlightSearchRequest *) pdata;
            char buf[4096 * 10] ={ 0 };
            NetSocketHead* phead = (NetSocketHead *) buf;
            phead->uMainCmd = MAINSVR_CLIENT_TYPE;
            phead->uSubCmd = MC_FLIGHT_SEARCH_REQUEST;
            int requestSize = sizeof(response->count) + sizeof(response->type) + response->count * sizeof(StFlightInfo);
            phead->uLen = sizeof(NetSocketHead) + requestSize;
            unsigned int len = phead->uLen;
            StFlightSearchRequest *pFlightSearchRequestData = (StFlightSearchRequest *) (phead + 1);
            memcpy(pFlightSearchRequestData, response, requestSize);
            senddata(pinfo->fd, buf, len);
            MSGOUT(en_Msg_Debug, "ServerMain::SettleDBResult send[flight search result]!!!!");
        }
        break;
    case DB_LOGINSVR_READY:
        {
            verifykeyword();
        }
        break;
    case DB_ORDER_REQUEST:
        {
            int fd = (int) (long) pclient;
            _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
            if (pinfo == NULL)
                return;
            StCommands *commands = *((StCommands **) pdata);
            StClientInfo *pClientInfo = (StClientInfo *) pinfo->pdata;
            std::map<int, std::queue<StCommands*> >::iterator iter =
                m_commands.find(pClientInfo->idx);
            if (iter == m_commands.end())
                m_commands[pClientInfo->idx] = std::queue<StCommands*>();
            std::queue<StCommands*> &cmds = m_commands[pClientInfo->idx];
            commands->clientid = pClientInfo->idx;
            commands->current = 0;
            cmds.push(commands);
            //trige command sender
            firecommandsender(commands->clientid);
        }
        break;
    case DB_LOGINSVR_RECON:
        {
            settimer(TIMER_RECONNECT_LOGINSVR, TIME_RECONNECT_LOGINSVR);
        }
        break;
    case DB_LOGIN_LOGINSVROK:
        {
            sendsvraddr();
            settimer(TIMER_UPDATAUSER, TIME_UPDATAUSER);
        }
        break;
    case DB_COMMAND_RESULT:
        {
            _StEtermSvrResult *pResult = (_StEtermSvrResult *) pdata;
            int clientId = pResult->zhijianid;
            std::queue<StCommands*> &userCommands = m_commands[clientId];
            StCommands *&currentCommands = userCommands.front();
            if (currentCommands->current < currentCommands->count)
            {
                //processcommandresult(currentCommands->commands[currentCommands->current],pResult);
                int iRet = processcommandresult(currentCommands, pResult);
                if (iRet == 0)
                {
                    currentCommands->commands[currentCommands->current].status = COMPLETE;
                    if (currentCommands->current + 1 < currentCommands->count)
                    {
                        currentCommands->current = currentCommands->current + 1;
                    }
                    else
                    {
                        //commands exec complete, remove it from the queue
                        currentCommands->status = COMPLETE;
                        userCommands.pop();
                    }
                    //fire the user commands sender
                    firecommandsender(currentCommands->clientid);
                }
                else
                {
                    //here we do nothing?
                    /*currentCommands->commands[currentCommands->current].status = COMPLETE;
                    if(currentCommands->current+1 < currentCommands->count)
                    {
                    currentCommands->current = currentCommands->current+1;
                    //fire the user commands sender
                    firecommandsender(currentCommands->clientid);
                    }*/
                }
            }
            /*free(cmdres);*/
        }
        break;
    case DB_CABINPRICE_REQUEST:
        {
            MSGOUT(en_Msg_Normal, "MysqlHandle::DB_CABINPRICE_REQUEST in!!!");
            int fd = (int) (long) pclient;
            _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
            if (pinfo == NULL)
                return;
            //db cabin price search result
            /*StCommands *commands = *((StCommands **) pdata);
            StOrderRequest *orderRequest = (StOrderRequest *) commands->context;*/
            /*switch (orderRequest->type)
            {
            case 0:
            {
            if (commands->revers != NULL)
            {
            int owprice = *(int *) commands->revers;
            delete (int *) commands->revers;
            commands->revers = NULL;
            if (owprice == 0)
            {
            bool isOk = false;
            char citypair[10] = "";
            strcat(citypair, orderRequest->cityfrom);
            strcat(citypair, orderRequest->cityto);
            //can't find the cabin price from db
            StCommand lookupPriceCommand =
            CommandGenerator::generateOrderFd(isOk, citypair,
            orderRequest->flydate,
            orderRequest->aircompay);
            if (!isOk)
            MSGOUT(en_Msg_Normal,
            "MysqlHandle::DB_CABINPRICE_REQUEST generate fd commands error.");
            //insert fd to current position of the  commands
            commands->commands.insert(
            commands->commands.begin() + commands->current,
            lookupPriceCommand);
            commands->count += 1;
            firecommandsender(commands->clientid);
            }
            else
            {
            //find the cabin price from db
            if (orderRequest->ticketprice == owprice)
            {
            //price equal
            //continue to sent the rest commands
            firecommandsender(commands->clientid);
            }
            else
            {
            //price not equal
            StOrderConfirm orderConfirm =
            { 0 };
            orderConfirm.oldprice = orderRequest->price;
            orderConfirm.newprice = owprice;
            orderConfirm.basicprice = orderRequest->ticketprice;
            strcpy(orderConfirm.tips, "just test!");
            char buf[1024] =
            { 0 };
            NetSocketHead* phead = (NetSocketHead *) buf;
            phead->uMainCmd = MAINSVR_CLIENT_TYPE;
            phead->uSubCmd = MC_ORDER_PRICE_DIFF;
            phead->uLen = sizeof(NetSocketHead)
            + sizeof(StOrderConfirm);
            StOrderConfirm *pOrderConfirm =
            (StOrderConfirm *) (phead + 1);
            memcpy(pOrderConfirm, &orderConfirm,
            sizeof(StOrderConfirm));
            senddata(pinfo->fd, buf, phead->uLen);
            MSGOUT(en_Msg_Debug,
            "ServerMain::SettleDBResult send[order confirm result]!!!!");
            }
            }
            }

            }
            break;
            case 1:
            break;
            case 2:
            break;
            default:
            MSGOUT(en_Msg_Normal,
            "MysqlHandle::dealcabinpricerequest order request type is error.");
            }*/
        }
        break;
    case DB_ORDER_PNR_RESULT:
        {
            /*int fd = (int) (long) pclient;
            _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
            if (pinfo == NULL)
            return;
            StCommands *commands = *((StCommands **) pdata);
            StOrderRequest *orderRequest = (StOrderRequest *) commands->context;
            char buf[1024] =
            { 0 };
            NetSocketHead* phead = (NetSocketHead *) buf;
            phead->uMainCmd = MAINSVR_CLIENT_TYPE;
            phead->uSubCmd = MC_ORDER_RESULT;
            StOrderResult orderResult =
            { 0 };
            orderResult.status = 1;
            orderResult.originprice = orderRequest->price;
            orderResult.newprice = orderRequest->price;
            phead->uLen = sizeof(NetSocketHead) + sizeof(StOrderResult);
            unsigned int len = phead->uLen;
            StOrderResult *pOderResultData = (StOrderResult *) (phead + 1);
            memcpy(pOderResultData, &orderResult, sizeof(StOrderResult));
            senddata(pinfo->fd, buf, len);*/
            MSGOUT(en_Msg_Debug,"ServerMain::SettleDBResult send[order success result]!!!!");
        }
        break;
        /*case DB_CABINPRICE_FROMETERM_REQUEST:
        {
        MSGOUT(en_Msg_Debug,
        "ServerMain::SettleDBResult cabin price from eterm!!!!");
        int fd = (int) (long) pclient;
        _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];

        if (pinfo == NULL)
        return;
        StClientInfo* pClientInfo = (StClientInfo*) pinfo->pdata;
        std::queue<StCommands*>& commandQueue = m_commands[pClientInfo->idx];
        StFlightTrip *flightTrip = *((StFlightTrip **) pdata);
        switch (flightTrip->triptype)
        {
        case 0:
        case 1:
        {
        //inland-St
        bool isOk = false;
        //params
        std::string citypair = flightTrip->cityfrom, date =
        flightTrip->depaturedate, aircompany =
        flightTrip->segs[0].aircompany;
        citypair.append(flightTrip->cityto);
        //construct fd command
        StCommand fdCommand = CommandGenerator::generateOrderFd(isOk, date,
        citypair, aircompany);
        if (isOk)
        {
        fdCommand.type = ORDERFD;
        StCommands *cmdPatch = new StCommands;
        cmdPatch->clientid = pClientInfo->idx;
        cmdPatch->context = flightTrip;
        cmdPatch->status = WAITING;
        cmdPatch->current = 0;
        cmdPatch->ishog = true;
        cmdPatch->commands.push_back(fdCommand);
        cmdPatch->current = 1;
        commandQueue.push(cmdPatch);
        //trige command sender
        firecommandsender(cmdPatch->clientid);
        }
        else
        {
        MSGOUT(en_Msg_Debug,
        "ServerMain::SettleDBResult fd command generate failed!!!!");
        }
        }
        break;
        case 2:
        {
        //inland-Mt
        }
        break;
        case 3:
        {
        //internate-St
        }
        break;
        case 4:
        {
        //internate-Rt
        }
        break;
        case 5:
        {
        //internate-Mt
        }
        break;
        default:
        MSGOUT(en_Msg_Debug,
        "ServerMain::SettleDBResult trip type is error%d!!!!",
        flightTrip->triptype);
        }
        StOrderRequest *orderRequest = (StOrderRequest *)commands->context;
        switch(orderRequest->type)
        {
        case 0:
        {
        int owprice  = *(int *)commands->revers;
        delete (int *)commands->revers;
        commands->revers = NULL;
        if(orderRequest->ticketprice == owprice)
        {
        //price equal
        //continue to sent the rest commands
        firecommandsender(commands->clientid);
        }
        else
        {
        //price not equal
        StOrderConfirm orderConfirm = {0};
        orderConfirm.oldprice = orderRequest->price;
        orderConfirm.newprice = owprice;
        orderConfirm.basicprice = orderRequest->ticketprice;
        strcpy(orderConfirm.tips , "just test!");
        char buf[1024] = {0};
        NetSocketHead* phead = (NetSocketHead *)buf;
        phead->uMainCmd = MAINSVR_CLIENT_TYPE;
        phead->uSubCmd = MC_ORDER_PRICE_DIFF;
        phead->uLen =sizeof(NetSocketHead) + sizeof(StOrderConfirm);
        StOrderConfirm *pOrderConfirm = (StOrderConfirm *)(phead + 1);
        memcpy(pOrderConfirm,&orderConfirm,sizeof(StOrderConfirm));
        senddata(pinfo->fd, buf, phead->uLen);
        MSGOUT(en_Msg_Debug, "ServerMain::SettleDBResult send[order confirm result]!!!!");
        }

        }
        break;
        case 1:
        break;
        case 2:
        break;
        default:
        MSGOUT(en_Msg_Normal, "MysqlHandle::dealcabinpricerequest order request type is error.");
        }
        }
        break;*/
    case DB_SEND_DATA:
        {
            int fd = (int) (long) pclient;
            senddata(fd, (char*) pdata, ulen);
            //free(pdata);
        }
        break;
    case DB_SEND_COMMAND:
        {
            int fd = (int) (long) pclient;
            _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
            if (pinfo == NULL)
                return;
            StCommands *commands = *((StCommands **) pdata);
            StClientInfo *pClientInfo = (StClientInfo *) pinfo->pdata;

            std::map<int, std::queue<StCommands*> >::iterator iter = m_commands.find(pClientInfo->idx);
            if (iter == m_commands.end())
                m_commands[pClientInfo->idx] = std::queue<StCommands*>();
            std::queue<StCommands*> &cmds = m_commands[pClientInfo->idx];
            commands->clientid = pClientInfo->idx;
            commands->current = 0;
            cmds.push(commands);
            MSGOUT(en_Msg_Debug,"ServerMain::SettleDBResult DB_SEND_COMMAND id:%d,commands size %d", pClientInfo->idx, commands->count);
            //trige command sender
            firecommandsender(commands->clientid);
        }
        break;
    case DB_TICKET_PRICE_REQUEST:
        {

        }
        break;
    case DB_SEND_LOWERCABIN_COMMAND:
        {
            StCommands *commands = *((StCommands **) pdata);
            m_attachedcommand.push(commands);
            MSGOUT(en_Msg_Debug,"push element from m_attachedcommand.");
            printCommands(commands);
            //trig command sender
            firecommandsender();
        }
        break;
    case DB_LOWERCABIN_COMMAND_RESULT:
        {
            _StEtermSvrResult *pResult = (_StEtermSvrResult *) pdata;
            //int clientId = pResult->zhijianid;
            StCommands *&currentCommands = m_attachedcommand.front();
            if (currentCommands->current < currentCommands->count)
            {
                //processcommandresult(currentCommands->commands[currentCommands->current],pResult);
                int iRet = processcommandresult(currentCommands, pResult);
                if (iRet == 0)
                {
                    currentCommands->commands[currentCommands->current].status = COMPLETE;
                    currentCommands->current++;
                    if (currentCommands->current >= currentCommands->count)
                    {
                        //this command patch exec completed
                        //commands exec complete, remove it from the queue
                        currentCommands->status = COMPLETE;
                        m_attachedcommand.pop();
                        MSGOUT(en_Msg_Debug,"pop element from m_attachedcommand.");
                        printCommands(currentCommands);
                    }
                    //fire the user commands sender
                    firecommandsender();
                }
                else
                {
                    //here we do nothing?
                    /*currentCommands->commands[currentCommands->current].status = COMPLETE;
                    if(currentCommands->current+1 < currentCommands->count)
                    {
                    currentCommands->current = currentCommands->current+1;
                    //fire the user commands sender
                    firecommandsender(currentCommands->clientid);
                    }*/
                }
            }
        }
        break;
    case DB_START_LOWER_CABIN_SCANNER:
        {
            LowerCabinScannerData *commands = *((LowerCabinScannerData **) pdata);
            LowerCabinScannerData *current = commands;
            while (current != NULL)
            {
                LowerCabinScannerData * scannerData = current;
                std::string key = ServerMain::generateContextKey(scannerData);
                bool isActive = isInActiveTimeZone(scannerData->settings);
                bool isActiveToday = isInActiveTimeZoneToday(scannerData->settings);
                if (isActiveToday || isActive)
                {
                    if (isActive)
                    {
                        scannerData->status = SCANSTATUS_PROCESSING;
                        //this task should be active now
                        LowerCabinScanTask *task = generateTaskByType(scannerData);
                        pthread_mutex_lock(&rtMutex);
                        tasks.push(task);
                        pthread_mutex_unlock(&rtMutex);
                        sem_post(&semRc);
                    }
                    pthread_mutex_lock(&rcMutex);
                    lowerCabinContext[key] = scannerData;
                    pthread_mutex_unlock(&rcMutex);

                }
                else
                {
                    //TODO:this order don't active scanner today,give it back to db

                }
                current = current->next;
            }
        }
        break;
    case DB_ETERMSVR_RECON:
        {
            settimer(TIMER_RECONNECT_ETERMSVR, TIME_RECONNECT_ETERMSVR);
        }
        break;
    default:
        return;
    }
}

int ServerMain::processcommandresult(StCommands *&commands, _StEtermSvrResult *pResult)
{
    MSGOUT(en_Msg_Debug, "ServerMain::processcommandresult in!!!!");
    StCommand &command = commands->commands[commands->current];
    char *cmdres = (char *)(pResult+1);
    if (pResult == NULL || cmdres == NULL)
        return 0;
    switch (command.type)
    {
    case SPECIALAV:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult specialav command procedure,result:%s!!!!",cmdres);
            CETermString sEterm;
            std::string sRet(cmdres);
            avSpecialInfo *avsInfo = (avSpecialInfo *) malloc(sizeof(avSpecialInfo));
            memset(avsInfo, 0, sizeof(avSpecialInfo));
            sEterm.DealSpecialAvStr(sRet, avsInfo);
            command.result = avsInfo;
            if (commands->context == NULL)
                return 0;
            command.status = COMPLETE;
            commands->current += 1;	//here we can't plus 1,because of the firecommandsender function added it
            int fd = fetchfdfromclientid(commands->clientid);
            if (fd != -1)
                PostDBRequest(DB_CABINPRICE_REQUEST, 0, &commands,
                sizeof(StCommands *), (void*) (long) fd);

            else
                MSGOUT(en_Msg_Debug,
                "ServerMain::processcommandresult specialav command procedure,can't find the fd,client id is %d!!!!",
                commands->clientid);
            return 1;
        }
        break;
    case ORDERFD:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult orderfd command procedure,result:%s!!!!", cmdres);
            command.result = cmdres;
            int fd = fetchfdfromclientid(commands->clientid);
            PostDBRequest(DB_CABINPRICE_FROMETERM_FD, 0, &commands, sizeof(StCommands *), (void*) (long) fd);
        }
        break;
    case ORDERFSD:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult orderfsd command procedure,result:%s!!!!", cmdres);
            command.result = cmdres;
            int fd = fetchfdfromclientid(commands->clientid);
            PostDBRequest(DB_CABINPRICE_FROMETERM_FSD, 0, &commands, sizeof(StCommands *), (void*) (long) fd);
        }
        break;
    case ORDERTICKET:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult orderticket command procedure,result:%s!!!!",cmdres);
            command.result = cmdres;
            int fd = fetchfdfromclientid(commands->clientid);
            PostDBRequest(DB_ORDER_PNR_RESULT, 0, &commands, sizeof(StCommands *),(void*) (long) fd);
        }
        break;
    case AVAILABLELOWERCABINAV:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult lowercabins av command procedure,result:%s!!!!", cmdres);
            command.result = cmdres;
            int fd = fetchfdfromclientid(commands->clientid);
            PostDBRequest(DB_LOWERCABIN_SETTINGAV_RESULT, 0, &commands, sizeof(StCommands *), (void*) (long) fd);
        }
        break;
    case LCAVH:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult lowercabin scan av command procedure,result:%s!!!!",cmdres);
            command.result = cmdres;
            int res = 0;//, distance = 0;
            //int line = 0;
            char dep[4] = {0};
            char des[4] = {0};
            if (sEterm._avhgetdepdes((char *)command.result, dep, des)) 
            {
                avhtravelInfo** p = NULL;
                int pagetypa = en_page_single;
                res = sEterm.DealAVHStr((char *)command.result, &p, dep, des, &pagetypa);
                if (res == -1)
                    return -1;
                AvhResults *results = LowerCabinScanTask::makeAvhInfos(p,res);
                //sEterm.FreeAVHRes(p, res);
                command.formartedresult = results;
                LowerAvResult avResult;
                avResult.type = AVTYPE_H;
                avResult.result = results;
                pthread_mutex_lock(&avResultMutex);
                lowerAvResuts[command.content] = avResult;
                pthread_mutex_unlock(&avResultMutex);

                LowerCabinScannerData*context = lowerCabinContext[commands->identifiers];
                StCommand *tmp = new StCommand;
                tmp->clone(command);
                context->recvCommandData.push_back(tmp);
                LowerCabinScanTask* task = generateTaskByType(context,1);
                pthread_mutex_lock(&rtMutex);
                tasks.push(task);
                pthread_mutex_unlock(&rtMutex);
                sem_post(&semRc);
            }
        }
        break;
    case LCSAV:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult lowercabin  scan sav command procedure,result:%s!!!!",cmdres);
            command.result = cmdres;
            avSpecialInfo *sAvResult = new avSpecialInfo;
            memset(sAvResult, 0, sizeof(avSpecialInfo));
            sEterm.DealSpecialAvStr((char *) command.result, sAvResult);
            command.formartedresult = sAvResult;
            LowerAvResult avResult;
            avResult.type = AVTYPE_SPECIAL;
            avResult.result = sAvResult;
            pthread_mutex_lock(&avResultMutex);
            lowerAvResuts[command.content] = avResult;
            pthread_mutex_unlock(&avResultMutex);

            LowerCabinScannerData*context = lowerCabinContext[commands->identifiers];
            StCommand *tmp = new StCommand;
            tmp->clone(command);
            context->recvCommandData.push_back(tmp);
            LowerCabinScanTask* task = generateTaskByType(context,1);
            pthread_mutex_lock(&rtMutex);
            tasks.push(task);
            pthread_mutex_unlock(&rtMutex);
            sem_post(&semRc);
        }
        break;
    case PAT:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult lowercabin  scan PAT command procedure,result:%s!!!!",cmdres);
            command.result = cmdres;
            int res = 0;
            if (sEterm._patjudgement((char *)command.result)) 
            {
                patpriceinfo *patResult = NULL;
                char buf[4096] = {0};
                int offset = sEterm._getOneLine((char *)command.result, buf, sizeof(buf));
                res = sEterm.DealPatStr((char *) command.result+offset, &patResult);
                if (res == -1)
                {
                    return -1;
                }
                PatResults *patResults = LowerCabinScanTask::makePatInfos(&patResult,res);
                command.formartedresult = patResults;
                //sEterm.FreePatRes(patResult);
                LowerCabinScannerData*context = lowerCabinContext[commands->identifiers];
                StCommand *tmp = new StCommand;
                tmp->clone(command);
                //post the result to db
                PostDBRequest(DB_LOWERCABIN_PAT_RESULT,0,&tmp,sizeof(tmp),0);
                context->recvCommandData.push_back(tmp);
                LowerCabinScanTask* task = generateTaskByType(context,1);
                pthread_mutex_lock(&rtMutex);
                tasks.push(task);
                pthread_mutex_unlock(&rtMutex);
                sem_post(&semRc);
            }     
        }
        break;
    case QTE:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult lowercabin  scan QTE command procedure,result:%s!!!!",cmdres);
            command.result = cmdres;
            int pos = 0;int line = 0;
            if (sEterm._fsijudgement((char *) command.result, &line))
            {
                while(line--) 
                {
                    char buf[4096] = {0};
                    int offset = sEterm._getOneLine((char *) command.result+pos, buf, sizeof(buf));
                    pos += offset;
                }

                fsqpriceinfo *info = new fsqpriceinfo;
                int res = sEterm.DealFSIStr((char *) command.result+pos, info);

                if (res == -1)
                    return res;
                sEterm.DealFSIStr((char *) command.result, info);
                command.formartedresult = info;
                LowerCabinScannerData*context = lowerCabinContext[commands->identifiers];
                StCommand *tmp = new StCommand;
                tmp->clone(command);
                context->recvCommandData.push_back(tmp);
                LowerCabinScanTask* task = generateTaskByType(context,1);
                pthread_mutex_lock(&rtMutex);
                tasks.push(task);
                pthread_mutex_unlock(&rtMutex);
                sem_post(&semRc);
            }
        }
        break;
    case RT:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult RT command!!!!");
        }
        break;
    case BESTPRICE_AV:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult BESTPRICE_AV command!!!!");
            StTrip *trip = (StTrip *)commands->context;
            StSegs& segs =  trip->segss[command.subId];
            if (segs.segCount != 1)
            {
                //this segs only have one flight
                commands->current ++;
                firecommandsender();
                return 0;
            }
            command.result = cmdres;
            int res = 0;//, distance = 0;
            //int line = 0;
            char dep[4] = {0};
            char des[4] = {0};
            if (sEterm._avhgetdepdes((char *)command.result, dep, des) && command.targetFlightsNo.size() > 0) 
            {
                avhtravelInfo** p = NULL;
                int pagetypa = en_page_single;
                res = sEterm.DealAVHStr((char *)command.result, &p, dep, des, &pagetypa);
                if (res == -1)
                    return -1;
                AvhResults *results = LowerCabinScanTask::makeAvhInfos(p,res);
                AvhResults *index = kmpFind(results,segs);
                if (index != NULL)
                {
                    //find the matched segment
                    for (int i = 0 ; i < segs.segCount ; ++i)
                    {
                        StSeg &seg = segs.segs[i];
                        avhtravelInfo *avi = index->avhInfo;
                        std::map<char,char> cabinMap;
                        avhInfoEx *seatInfo = avi->pinfoex;
                        //make cabin map of the result
                        for (int j = 0 ; j < seatInfo->count ; ++j)
                        {
                            cabinMap[seatInfo->detail[j][0]] = seatInfo->detail[j][1];
                        }
                        //remove all unavailable lower cabin
                        for (unsigned int i = 1 ; i < strlen(seg.availableLowerCabin) ; ++i)
                        {
                            if (cabinMap.count(seg.availableLowerCabin[i]) > 0)
                            {
                                char status = cabinMap[seg.availableLowerCabin[i]];
                                if (status == 'A')
                                {
                                    continue;
                                }
                                if (CommonLib::charToNumber(status) >= trip->passengerCount)
                                {
                                    continue;
                                }
                                seg.availableLowerCabin[i] = ' ';
                            }
                        }
                        CommonLib::removeAllBlank(seg.availableLowerCabin);
                        index = index->next;
                    }

                }
            }
            if (commands->current >= commands->count)
            {
                //all av commands returned and all available lower cabin set
                //here we should generate SS commands patch with the lower cabin of all segments
                StCommands *cmdPatch = new StCommands;
                cmdPatch->clientid = commands->clientid;
                cmdPatch->status = WAITING;
                cmdPatch->context = trip;
                std::string ssCommandString = "";
                for (int i = 0 ; i < trip->segsCount ; ++i)
                {
                    StSegs &segs = trip->segss[i];
                    for (int j = 0 ; j <  segs.segCount; ++j)
                    {
                        std::string ss = "SS:";
                        ss.append(segs.segs[j].flightNo);
                        ss.append(" ");
                        std::string lowerCabin = segs.segs[j].availableLowerCabin;
                        std::string lowerestCabin = "";
                        if (lowerCabin.length()>0)
                        {
                            std::stringstream  sss;
                            sss<<lowerCabin.at(lowerCabin.length()-1);
                            sss>>lowerestCabin;
                        } 
                        else
                        {
                            lowerestCabin.append(segs.segs[j].currentCabin);
                        }
                        ss.append(lowerestCabin.c_str());
                        ss.append(" ");
                        ss.append(segs.segs[j].date);
                        ss.append(" ");
                        ss.append(segs.segs[j].from);
                        ss.append(segs.segs[j].to);
                        ss.append(" NN");
                        std::stringstream  sss;
                        sss<<CommonLib::integerToChar(trip->passengerCount);
                        sss>>ss;
                        ss.append("\n");
                    }   
                }
                StCommand ssCommand;
                ssCommand.result = NULL;
                strcpy(ssCommand.content ,ssCommandString.c_str());
                ssCommand.status = WAITING;
                ssCommand.type = BESTPRICE_SS;
                cmdPatch->commands.push_back(ssCommand);
                cmdPatch->count ++;
                int fd = fetchfdfromclientid(commands->clientid);
                PostEventResult(DB_SEND_COMMAND, 0, cmdPatch, sizeof(StCommands*),(void*) (long) fd);
            } 
        }
        break;
    case BESTPRICE_SAV:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult BESTPRICE_SAV command!!!!");
            StTrip *trip = (StTrip *)commands->context;
            StSegs& segs =  trip->segss[command.subId];
            if (segs.segCount != 1)
            {
                //this segs only have one flight
                commands->current ++;
                firecommandsender();
                return 0;
            }
            StSeg &seg = segs.segs[0];
            command.result = cmdres;
            avSpecialInfo *sAvResult = new avSpecialInfo;
            memset(sAvResult, 0, sizeof(avSpecialInfo));
            sEterm.DealSpecialAvStr((char *) command.result, sAvResult);
            if (strcmp(sAvResult->flightNo,seg.flightNo) == 0)
            {
                avscabin cabins =  sAvResult->cabins;
                std::map<char,char> cabinMap;
                //make cabin map of the result
                for (int i = 0 ; i < cabins.cabincount ; ++i)
                {
                    cabinMap[cabins.cabins[i][0]] = cabins.cabins[i][1];
                }
                //remove all unavailable lower cabin
                for (unsigned int i = 1 ; i < strlen(seg.availableLowerCabin) ; ++i)
                {
                    if (cabinMap.count(seg.availableLowerCabin[i]) > 0)
                    {
                        char status = cabinMap[seg.availableLowerCabin[i]];
                        if (status == 'A')
                        {
                            continue;
                        }
                        if (CommonLib::charToNumber(status) >= trip->passengerCount)
                        {
                            continue;
                        }
                        seg.availableLowerCabin[i] = ' ';
                    }
                }
                CommonLib::removeAllBlank(seg.availableLowerCabin);
            }
            if (commands->current >= commands->count)
            {
                //all av commands returned and all available lower cabin set
                //here we should generate SS commands patch with the lower cabin of all segments
                StCommands *cmdPatch = new StCommands;
                cmdPatch->clientid = commands->clientid;
                cmdPatch->status = WAITING;
                cmdPatch->context = trip;
                std::string ssCommandString = "";
                for (int i = 0 ; i < trip->segsCount ; ++i)
                {
                    StSegs &segs = trip->segss[i];
                    for (int j = 0 ; j <  segs.segCount; ++j)
                    {
                        std::string ss = "SS:";
                        ss.append(segs.segs[j].flightNo);
                        ss.append(" ");
                        std::string lowerCabin = segs.segs[j].availableLowerCabin;
                        std::string lowerestCabin = "";
                        if (lowerCabin.length()>0)
                        {
                            std::stringstream  sss;
                            sss<<lowerCabin.at(lowerCabin.length()-1);
                            sss>>lowerestCabin;
                        } 
                        else
                        {
                            lowerestCabin.append(segs.segs[j].currentCabin);
                        }
                        ss.append(lowerestCabin.c_str());
                        ss.append(" ");
                        ss.append(segs.segs[j].date);
                        ss.append(" ");
                        ss.append(segs.segs[j].from);
                        ss.append(segs.segs[j].to);
                        ss.append(" NN");
                        std::stringstream  sss;
                        sss<<CommonLib::integerToChar(trip->passengerCount);
                        sss>>ss;
                        ss.append("\n");
                    }   
                }
                StCommand ssCommand;
                ssCommand.result = NULL;
                strcpy(ssCommand.content ,ssCommandString.c_str());
                ssCommand.status = WAITING;
                ssCommand.type = BESTPRICE_SS;
                cmdPatch->commands.push_back(ssCommand);
                cmdPatch->count ++;
                int fd = fetchfdfromclientid(commands->clientid);
                PostEventResult(DB_SEND_COMMAND, 0, cmdPatch, sizeof(StCommands*),(void*) (long) fd);
            } 
        }
        break;
    case BESTPRICE_SS:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult BESTPRICE_SS command!!!!");
            StTrip *trip = (StTrip *)commands->context;
            command.result = cmdres;
            StCommands *cmdPatch =  new StCommands;
            cmdPatch->status = WAITING;
            cmdPatch->count = 0;
            cmdPatch->current = 0;
            bool isOk = false;
            if (trip->type == 0)
            {
                //inland
                StCommand pat = CommandGenerator::generatePat(isOk);
                pat.type = BESTPRICE_PAT;
                cmdPatch->commands.push_back(pat);
            }
            else if(trip->type == 1)
            {
                //internate
                StCommand qte = CommandGenerator::generateQte(isOk,"A");
                qte.type = BESTPRICE_QTE;
                cmdPatch->commands.push_back(qte);
            }
            int fd = fetchfdfromclientid(commands->clientid);
            PostEventResult(DB_SEND_COMMAND, 0, cmdPatch, sizeof(StCommands*),(void*) (long) fd);
        }
        break;
    case BESTPRICE_PAT:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult BESTPRICE_PAT command!!!!");
            StTrip *trip = (StTrip *)commands->context;
            command.result = cmdres;
            patpriceinfo ** p = NULL; 
            char buf[4096] = {0};
            int offset = sEterm._getOneLine(cmdres, buf, sizeof(buf));
            int res =sEterm.DealPatStr(cmdres+offset,p);
            if (res == -1)
                return res;
            for (int i = 0 ; i < res ; ++i)
            {
                patpriceinfo *priceInfo = p[i];
                trip->priceInfo[trip->priceInfoCount].total = priceInfo->total;
                trip->priceInfo[trip->priceInfoCount].fare = priceInfo->fare;
                trip->priceInfo[trip->priceInfoCount].tax = priceInfo->tax;
                ++trip->priceInfoCount;
            }
            //here we get the best price,throw to client
            StTrip *response = (StTrip *) trip;
            memset(buf,0,sizeof(buf));
            NetSocketHead* phead = (NetSocketHead *) buf;
            phead->uMainCmd = MAINSVR_CLIENT_TYPE;
            phead->uSubCmd = MC_BEST_CABIN_PRICE;
            int requestSize = sizeof(StTrip) - (sizeof(response->segss)/sizeof(StSegs)-response->segsCount)*sizeof(StSegs);
            phead->uLen = sizeof(NetSocketHead) + requestSize;
            unsigned int len = phead->uLen;
            StTrip *pBestPriceResponseData = (StTrip *) (phead + 1);
            memcpy(pBestPriceResponseData, response, requestSize);
            int fd = fetchfdfromclientid(commands->clientid);
            senddata(fd, buf, len);
        }
        break;
    case BESTPRICE_QTE:
        {
            MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult BESTPRICE_QTE command!!!!");
            StTrip *trip = (StTrip *)commands->context;
            command.result = cmdres;
            //fsqpriceinfo ** p = NULL; 
            char buf[4096] = {0};
            int pos = 0;int line = 0;
            if (sEterm._fsijudgement((char *) command.result, &line))
            {
                while(line--) 
                {
                    char buf[4096] = {0};
                    int offset = sEterm._getOneLine((char *) command.result+pos, buf, sizeof(buf));
                    pos += offset;
                }

                fsqpriceinfo info = {0};
                int res = sEterm.DealFSIStr((char *) command.result+pos, &info);
                if (res == -1)
                    return res;
                trip->priceInfo[trip->priceInfoCount].total = info.itprice;
                trip->priceInfo[trip->priceInfoCount].fare = info.qprice;
                trip->priceInfo[trip->priceInfoCount].tax = info.taxprice;
                trip->priceInfoCount += 1;
                sEterm.FreeFSIRes(&info);
                //here we get the best price,throw to client
                StTrip *response = (StTrip *) trip;
                memset(buf,0,sizeof(buf));
                NetSocketHead* phead = (NetSocketHead *) buf;
                phead->uMainCmd = MAINSVR_CLIENT_TYPE;
                phead->uSubCmd = MC_BEST_CABIN_PRICE;
                int requestSize = sizeof(StTrip) - (sizeof(response->segss)/sizeof(StSegs)-response->segsCount)*sizeof(StSegs);
                phead->uLen = sizeof(NetSocketHead) + requestSize;
                unsigned int len = phead->uLen;
                StTrip *pBestPriceResponseData = (StTrip *) (phead + 1);
                memcpy(pBestPriceResponseData, response, requestSize);
                int fd = fetchfdfromclientid(commands->clientid);
                senddata(fd, buf, len);
            }
        }
        break;
    default:
        MSGOUT(en_Msg_Debug,"ServerMain::processcommandresult unknown command!!!!");
    }
    MSGOUT(en_Msg_Debug, "ServerMain::processcommandresult out!!!!");
    return 0;
}

bool ServerMain::verifyuserpwd(int fd, int wndid, StVerifyPasswd *pdata, unsigned int len)
{
    if (len != sizeof(StVerifyPasswd) || pdata == NULL)
    {
        return false;
    }
    if (pdata->pwdtype != VERIFY_TYPE_LOGINPWD)
        return false;
    PostDBRequest(DB_VERIFY_LOGINPWD, wndid, pdata, len, (void*) (long) fd);
    return true;
}

bool ServerMain::dealorderrequest(int fd, int wndid, StOrderRequest *pdata, unsigned int len)
{
    /*MSGOUT(en_Msg_Debug, "dealorderrequest passenger count:%d subcmd:%s",
    pdata->passengercount, pdata->flightno);*/
    //TODO:deal order data
    /*_StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
    StClientInfo *pClientInfo = (StClientInfo *) pinfo->pdata;*/
    //m_commands[pClientInfo->idx];
    PostDBRequest(DB_ORDER_REQUEST, wndid, pdata, len, (void*) (long) fd);
    return true;
}

bool ServerMain::dealflightsearchrequest(int fd, int wndid,StFlightSearchRequest *pdata, unsigned int len)
{
    if (pdata == NULL || pdata->count <= 0)
    {
        return false;
    }
    MSGOUT(en_Msg_Warning, "dealorderrequest cmd, flight type:%d item count:%d",
        pdata->type, pdata->count);
    PostDBRequest(DB_FLIGHT_SEARCH_REQUEST, wndid, pdata, len,
        (void*) (long) fd);
    return true;
}

bool ServerMain::_start()
{

    ReadConf conf;
    conf.readfile("server.conf");
    char buf[64] = { 0 };

    if (!conf.getvalue("server_id", buf, sizeof(buf)))
        return false;
    m_addrself.id = atoi(buf);
    if (m_addrself.id <= 0)
        return false;

    if (!conf.getvalue("bindip", m_addrself.ip, sizeof(m_addrself.ip)))
        return false;

    memset(buf, 0, sizeof(buf));
    if (!conf.getvalue("bindport", buf, sizeof(buf)))
        return false;
    m_addrself.port = atoi(buf);
    if (m_addrself.port <= 0)
        return false;

    memset(buf, 0, sizeof(buf));
    if (!conf.getvalue("loginsvr_port", buf, sizeof(buf)))
        return false;
    m_addrlogin.port = atoi(buf);
    if (m_addrlogin.port <= 0)
        return false;

    if (!conf.getvalue("loginsvr_ip", m_addrlogin.ip, sizeof(m_addrlogin.ip)))
        return false;

    MSGOUT(en_Msg_Debug,
        "ServerMain::_start connect login server ip:%s, port:%d",
        m_addrlogin.ip, m_addrlogin.port);

    memset(buf, 0, sizeof(buf));
    if (!conf.getvalue("etermsvr_port", buf, sizeof(buf)))
        return false;
    m_addretern.port = atoi(buf);
    if (m_addrlogin.port <= 0)
        return false;

    if (!conf.getvalue("etermsvr_ip", m_addretern.ip, sizeof(m_addretern.ip)))
        return false;

    if (!m_sologin._start_server(m_pDB, this))
        return false;

    if (!m_soeterm._start_server(m_pDB, this))
        return false;

    MSGOUT(en_Msg_Debug,
        "ServerMain::_start connect etern server ip:%s, port:%d",
        m_addretern.ip, m_addretern.port);
    //start command sender timer
    //settimer(TIMER_COMMANDSENDER, TIMER_COMMANDSENDER);

    settimer(TIMER_RECONNECT_LOGINSVR, 1000/*TIME_RECONNECT_LOGINSVR*/);

    settimer(TIMER_RECONNECT_ETERMSVR, 1000/*TIME_RECONNECT_ETERMSVR*/);

    //启动底舱监控
    //startLowerCabinScanner();

    //PostDBRequest(DB_LOAD_CABIN_MAP,0,NULL,0,NULL);
    return true;
}

void ServerMain::_stop()
{

    std::map<int, void*>::iterator it = m_mapfd.begin();
    for (; it != m_mapfd.end(); it++)
    {
        void* p = it->second;
        free(p);
    }
    m_mapfd.clear();

    m_sologin._stop_server();
    m_soeterm._stop_server();

    MSGOUT(en_Msg_Debug, "stop~~~~~~~~~~~~~~~~~~~~");
}

bool ServerMain::DealClientData(int fd, int wndid, void* pdata,  unsigned int ulen)
{

    _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
    if (pinfo == NULL || pdata == NULL || ulen < HEAD_SIZE)
        return false;

    NetSocketHead* phead = (NetSocketHead*) pdata;

    if (phead->uSubCmd != MC_VERIFY_LOGIN_PASSWD)
    {
        if (pinfo->contype != CON_TYPE_CLIENT_COM)
        {
            MSGOUT(en_Msg_Debug, "error connect fd : %d", fd);
            return false;
        }
    }

    switch (phead->uSubCmd)
    {
    case MC_VERIFY_LOGIN_PASSWD:
        {
            return verifyuserpwd(fd, wndid, (StVerifyPasswd*) (phead + 1),
                ulen - HEAD_SIZE);
        }
    case MC_ORDER_REQUEST_RESULT:
        {
            return dealorderrequest(fd, wndid, (StOrderRequest*) (phead + 1),
                ulen - HEAD_SIZE);
        }
    case MC_FLIGHT_SEARCH_REQUEST:
        {
            return dealflightsearchrequest(fd, wndid,
                (StFlightSearchRequest*) (phead + 1), ulen - HEAD_SIZE);
        }
    case MC_FLIGHT_QUERY_RESULT:
        {
            return true;
        }
    case MC_ORDER_PRICE_DIFF:
        {
            return dealpriceconfirmrequest(fd, wndid, (int*) (phead + 1),ulen - HEAD_SIZE);
        }
    case MC_TICKET_PRICE_REQUEST:
        {
            MSGOUT(en_Msg_Debug, "ServerMain::OnSocketRead rvclen:%d,objsize:%d", ulen - HEAD_SIZE, sizeof(StFlightTrip));
            return dealticketpricerequest(fd, wndid, (StFlightTrip*) (phead + 1), ulen - HEAD_SIZE);
        }
    case MC_LOWER_CABIN_REQUEST:
        {
            MSGOUT(en_Msg_Debug, "ServerMain::MC_LOWER_CABIN_REQUEST");
            return deallowercabinsrequest(fd, wndid,(StLowerCabinsRequest*) (phead + 1), ulen - HEAD_SIZE);
        }
    case MC_BEST_CABIN_PRICE:
        {
            MSGOUT(en_Msg_Debug, "ServerMain::MC_BEST_CABIN_PRICE");
            return dealbestcabinpricerequest(fd, wndid,(StTrip*) (phead + 1), ulen - HEAD_SIZE);
        }
    default:
        MSGOUT(en_Msg_Warning,"ServerMain::OnSocketRead unknow cmd, maincmd:%d subcmd:%d", phead->uMainCmd, phead->uSubCmd);
        return false;
    }
    return false;
}

bool ServerMain::verifykeyword()
{
    if (m_sologin._is_end())
        return false;

    char buf[MAX_BUFFSIZE] =
    { 0 };
    NetSocketHead* phead = (NetSocketHead*) buf;
    phead->uMainCmd = SYSTEM_PROTOCOL_TYPE;
    phead->uSubCmd = SP_LOGINMAIN_VERIFY_KEYWORD;
    phead->uLen = HEAD_SIZE + strlen(__key_mainsvr_loginsvr__) + 1;
    memcpy(phead + 1, __key_mainsvr_loginsvr__, strlen(__key_mainsvr_loginsvr__) + 1);
    /*
    phead->uLen = HEAD_SIZE + strlen("__key_word__")+1;
    memcpy(phead+1, __key_word__, strlen("__key_word__")+1);
    */
    int res = m_sologin.senddata(buf, phead->uLen);

    MSGOUT(en_Msg_Debug,
        "ServerMain::verifykeyword verify key word send res:%d", res);

    return true;
}

bool ServerMain::connectloginsvr()
{

    if (!m_sologin.connectsocket(m_addrlogin.ip, m_addrlogin.port,
        en_Server_Connect))
    {
        MSGOUT(en_Msg_Debug, "settimer reconnect loginserver");
        return false;
    }

    MSGOUT(en_Msg_Debug, "ServerMain::connectloginsvr connect ok!");

    if (m_sologin._is_end())
        return false;
    char buf[MAX_BUFFSIZE] =
    { 0 };
    NetSocketHead* phead = (NetSocketHead*) buf;
    phead->uMainCmd = SYSTEM_PROTOCOL_TYPE;
    phead->uSubCmd = SP_LOGINSVR_SET_DEALDATAPTR;
    phead->uLen = HEAD_SIZE;

    m_sologin.senddata(buf, phead->uLen);

    PostDBRequest(DB_LOGINSVR_READY, 0, NULL, 0, NULL);

    return true;
}

bool ServerMain::connectetermsvr()
{
    if (!m_soeterm.connectsocket(m_addretern.ip, m_addretern.port,
        en_Normal_Connect))
    {
        MSGOUT(en_Msg_Debug, "settimer reconnect etermserver, ip: %s, port: %d", m_addretern.ip, m_addretern.port);
        return false;
    }

    MSGOUT(en_Msg_Debug, "ServerMain::connecteternsvr connect ok!");
    
    char buf[4096] = {0};

    NetSocketHead* phead = (NetSocketHead*)buf;
    phead->uMainCmd = SYSTEM_PROTOCOL_TYPE;
    phead->uSubCmd = SP_ETERMMAIN_VERIFY_KEYWORD;
    phead->uLen = sizeof(NetSocketHead) + strlen(__key_mainsvr_etermsvr__);

    char* pstr = (char*)(phead+1);
    strcpy(pstr, __key_mainsvr_etermsvr__);

    m_soeterm.senddata(buf, phead->uLen);

    return true;
}

bool ServerMain::sendusercount()
{
    if (!m_sologin.isok())
    {
        settimer(TIMER_RECONNECT_LOGINSVR, TIME_RECONNECT_LOGINSVR);
        return true;
    }

    char buf[MAX_BUFFSIZE] =
    { 0 };
    NetSocketHead* phead = (NetSocketHead*) buf;
    phead->uMainCmd = MAINSVR_LOGINSVR_TYPE;
    phead->uSubCmd = ML_UPDATA_SVRUSER;
    phead->uLen = HEAD_SIZE + sizeof(_StMainSvrUpUser);

    _StMainSvrUpUser* puser = (_StMainSvrUpUser*) (phead + 1);
    puser->usercount = m_mapfd.size();

    MSGOUT(en_Msg_Debug, "ServerMain::sendusercount count:%d",
        puser->usercount);

    m_sologin.senddata(buf, phead->uLen);

    return true;
}

bool ServerMain::sendsvraddr()
{

    char buf[MAX_BUFFSIZE] =
    { 0 };
    NetSocketHead* phead = (NetSocketHead*) buf;
    phead->uMainCmd = MAINSVR_LOGINSVR_TYPE;
    phead->uSubCmd = ML_MAINSVR_INFO;
    phead->uLen = HEAD_SIZE + sizeof(StNetAddrInfo);

    memcpy(phead + 1, &m_addrself, sizeof(m_addrself));
    m_sologin.senddata(buf, phead->uLen);

    MSGOUT(en_Msg_Debug,
        "ServerMain::sendsvraddr send main server ip port info");

    return true;
}

bool ServerMain::firecommandsender(int idx)
{
    MSGOUT(en_Msg_Debug, "ServerMain::firecommandsender start!!!");
    std::map<int, std::queue<StCommands*> >::iterator it = m_commands.find(idx);
    if (it != m_commands.end())
    {

        //if the commands queue is not empty
        if (!it->second.empty())
        {
            StCommands *&commands = it->second.front();
            MSGOUT(en_Msg_Debug, "ServerMain::firecommandsender find idx in command map:%d,commands size:%p,count:%d!!!",idx, it->second.size(), commands->count);
            //find the unhandled command queue
            if (commands->count > 0 && (commands->status == WAITING || commands->status == PROCESSING))
            {
                //fire it
                commands->status = PROCESSING;
                char buf[2048] = { 0 };
                strcpy(buf, commands->commands[commands->current].content);
                bool findWaitingCommands = false;
                while (commands->current < commands->count)
                {
                    if (commands->commands[commands->current].status == PROCESSING)
                    {
                        //some command is waiting for result, then hang up all commands after he
                        return true;
                    }
                    if (commands->commands[commands->current].status != WAITING)
                        commands->current += 1;
                    else
                    {
                        findWaitingCommands = true;
                        break;
                    }
                }
                if (findWaitingCommands)
                {
                    MSGOUT(en_Msg_Debug, "ServerMain::firecommandsender current:%d,total:%d!", commands->current, commands->count);
                    //TODO:send the command
                    //m_soeterm.sendcommnad(buf, strlen(buf), commands->clientid);
                    commands->commands[commands->current].status = PROCESSING;
                    simulatecommandresult(commands);
                }
                else
                {
                    MSGOUT(en_Msg_Debug, "ServerMain::firecommandsender this commands have finished,idx:!", idx);
                }

            }
            else
            {
                MSGOUT(en_Msg_Debug, "ServerMain::firecommandsender no commands waiting,idx:%d!", idx);

            }
        }
    }
    MSGOUT(en_Msg_Debug, "ServerMain::firecommandsender end !!!");
    return true;
}

void ServerMain::simulatecommandresult(StCommands *&commands)
{
    StCommand &command = commands->commands[commands->current];
    int clientId = commands->clientid;
    char buff[4096] = {0};
    _StEtermSvrResult *result =(_StEtermSvrResult *)buff;
    char *prs = (char *) (result+1);
    result->zhijianid = clientId;
    switch (command.type)
    {
    case LCSAV:
    case SPECIALAV:
        {
            MSGOUT(en_Msg_Debug, "ServerMain::simulatecommandresult SPECIALAV!");
            const char* buf =
                " AV:HU7608/22NOV                                                                \n\
                DEP TIME   ARR TIME   WEEK FLY   GROUND TERM  TYPE MEAL  DISTANCE               \n\
                SHA 1055   PEK 1310   SAT  2:15         T2/T1 333  L     1076                   \n\
                TOTAL JOURNEY TIME   2:15                                                       \n\
                SHAPEK FA ZA P2 AA YA BA HA KA LA MA QA XA UQ EQ TQ V3 WQ GQ OQ                 \n\
                SA\n";
            strcpy(prs, buf);
        }
        break;
    case LCAVH:
        {
            MSGOUT(en_Msg_Debug, "ServerMain::simulatecommandresult AV!");
            const char* buf =" 14MAY(WED) ICNBJS FROM KE                                                      \n\
                             1   KE5803      JC CC YC BC MC HC EC KC        ICNPEK 0810   0910   321 0       \n\
                             2   CA4199      P6 A2 J9 C9 D9 I9 Z3 Y9 B9 M9  GMPPEK 0920   1030   772 0       \n\
                             >               H9 E9 K9 Q9 TL GL                                               \n\
                             3   KE855       P4 A2 J9 C9 D9 I9 Z5 Y9 B9 M9  ICNPEK 1105   1210   773 0       \n\
                             >               H9 E9 K9 Q9 T9 G9                                               \n\
                             4   KE5801      JC CC YC BC MC HC EC KC        GMPPEK 1230   1325   321 0       \n\
                             5   KE853       RL AL JL CL DL IL ZL YL BL ML  ICNPEK 1900   2005   772 0       \n\
                             >               HL EL KL QL TL GL                                               \n\
                             6   KE1223      C9 Z9 O9 Y9 G9 T9              GMPCJU 1330   1435   744 0       \n\
                             KE879       P5 A2 J9 C9 D8 I8 Z2 Y9 B9 M9     PEK 1550   1725   333 0       \n\
                             >               H9 E9 K9 Q9 T9 G9                                               \n\
                             7+  KE1221      C9 Z9 O9 Y9 G9 T9              GMPCJU 1215   1320   744 0       \n\
                             KE879       P5 A2 J9 C9 D8 I8 Z2 Y9 B9 M9     PEK 1550   1725   333 0       \n\
                             >               H9 E9 K9 Q9 T9 G9                                         ";
            strcpy(prs, buf);
        }
        break;
    case ORDERTICKET:
        {
            MSGOUT(en_Msg_Debug, "ServerMain::simulatecommandresult ORDERTICKET!");
            const char* buf =
                "HSM12Y -EOT SUCCESSFUL, BUT ASR UNUSED FOR 1 OR MORE SEGMENTS                   \n\
                HU7608  Y SA22NOV  SHAPEK DK1   1055 1310                                     \n\
                ���չ�˾ʹ���Զ���Ʊʱ��, ����PNR                                           \n\
                *** Ԥ���Ƶ�ָ��HC, ����  HC:HELP   ***\n";
            strcpy(prs, buf);
        }
        break;
    case ORDERFD:
        {
            MSGOUT(en_Msg_Debug, "ServerMain::simulatecommandresult ORDERFD!");
            const char* buf =
                ">PFDSHAPEK/22NOV14/HU\n	FD:SHAPEK/22NOV14/HU                   /CNY /TPM  1178/                         \n\
                01 HU/F     / 3280.00= 6560.00/F/F/  /   .   /29OCT14        /HU10  PFN:01     \n\
                02 HU/F1    / 2830.00= 5660.00/F/F/  /   .   /29OCT14        /HU10  PFN:02     \n\
                03 HU/C     / 1810.00= 3620.00/C/C/  /   .   /26JUL13        /HU11  PFN:03     \n\
                04 HU/C1    / 1470.00= 2940.00/C/C/  /   .   /26JUL13        /HU11  PFN:04     \n\
                05 HU/Y     / 1130.00= 2260.00/Y/Y/  /   .   /26JUL13        /HU11  PFN:05     \n\
                06 HU/B     / 1020.00= 2040.00/B/Y/  /   .   /26JUL13        /HU12  PFN:06     \n\
                07 HU/H     /  960.00= 1920.00/H/Y/  /   .   /26JUL13        /HU12  PFN:07     \n\
                08 HU/K     /  900.00= 1800.00/K/Y/  /   .   /26JUL13        /HU12  PFN:08     \n\
                09 HU/L     /  850.00= 1700.00/L/Y/  /   .   /26JUL13        /HU12  PFN:09     \n\
                10 HU/M     /  790.00= 1580.00/M/Y/  /   .   /26JUL13        /HU12  PFN:10     \n\
                11 HU/M1    /  730.00= 1460.00/M/Y/  /   .   /26JUL13        /HU12  PFN:11     \n\
                12 HU/Q     /  680.00= 1360.00/Q/Y/  /   .   /26JUL13        /HU12  PFN:12     \n\
                13 HU/Q1    /  620.00= 1240.00/Q/Y/  /   .   /26JUL13        /HU12  PFN:13     \n\
                14 HU/X     /  570.00= 1140.00/X/Y/  /   .   /26JUL13        /HU12  PFN:14     \n\
                15 HU/U     /  510.00= 1020.00/U/Y/  /   .   /26JUL13        /HU12  PFN:15     \n\
                16 HU/E     /  450.00=  900.00/E/Y/  /   .   /10NOV13        /HU12  PFN:16     \n\
                \n\
                PAGE 1/1\n";
            strcpy(prs, buf);
        }
        break;
    case ORDERFSD:
        {
            MSGOUT(en_Msg_Debug, "ServerMain::simulatecommandresult ORDERFSD!");
            const char *buf = "FSD CTULHR/BA/CNY \n\
                              SEE 3U  9W  AA  AB  AC  AF  AI  AM  AR  AY  AZ  BD  BI  BR                     \n\
                              BT  CA  CI  CO  CX  CZ  DE  DL  EI  EK  ET  EY  FM  HM                  \n\
                              HO  HU  HX  IB  JJ  JL  KA  KE  KL  KQ  LA  LH  LO  LT                  \n\
                              LX  MA  MF  MH  MI  MP  MU  NH  NW  NZ  OS  OZ  PK  PR          \n\
                              QF  QR  RG  S3  SA  SC  SK  SN  SQ  SU  TG  UA  UL  UO              \n\
                              US  V3  VA  VN  VS  XG  XQ  YY  ZH              \n\
                              1 NUC = 6.120290 CNY ROUNDING UP TO 10.00 CNY               \n\
                              21JUL13*21JUL13/BA   CTULON/TS/      /TPM 5143/MPM 7256/CNY\n\
                              01 D2OWBA3  /    29320          /D*   .12M/           /5520R\n\
                              02 R2OWBA2  /    23990          /R*   .12M/           /5622R\n\
                              03 I2OWBA2  /    19690          /I*   .12M/           /5622R\n\
                              04 D2RTBA3  /              45100/D*   .12M/           /5520R                   \n\
                              05 R2RTBA2  *              36900/R*   .12M/           /5622R\n\
                              06 KHRCEA   /ADVP 5D       14280/K/6D . 3M/15JUL 31AUG\n";
            strcpy(prs, buf);
        }
        break;
    case RT:
        {
            const char *buf = "     0.11JUNSHASM/INC NM11 HPJKF2   \n\
                              12.  KE896  G   TU18NOV  PVGICN HK11  0850 1155          E  \n\
                              13.  KE2815 G   SA22NOV  GMPSHA HK11  1555 1700          E  \n\
                              14.SHA/T SHA/T021-62490199/SHANGHAI JUNZHI TICKET SERVICE CO.,LTD/JIANG JUN \n\
                              ABCDEFG  \n\
                              15.REM 1031 1017 JUNZHI010 13611765267  \n\
                              16.60255381LEE  \n\
                              17.TL/0650/18NOV/SHA366 \n\
                              18.SSR OTHS 1E ADV NAME TO BE 2300/04NOV/SEL     \n\
                              19.SSR OTHS 1E ASP AVBL WITHIN 90DAYS FOR TKTD PAX  \n\
                              20.SSR OTHS 1E CHECK SPECIAL MEAL AND ADVANCE SEATING   \n\
                              21.SSR OTHS 1E KE RSVN IS 1822-3270 \n ";
            strcpy(prs, buf);
        }
        break;
    case PAT:
        {
            const char * buf = ">PAT:A  \n\
                               01 Y FARE:CNY810.00 TAX:CNY50.00 YQ:CNY70.00  TOTAL:930.00  \n\
                               SFC:01    SFN:01   \n\
                               25DEC(THU) SHAOKA \n\
                               1-  MU287   PVGOKA 1340   1640   320 0^L  E   DS# J6 C4 D2 IS YA BA MA EA HA KA*\n\
                               2  *JL5634  PVGOKA 1340   1640   320 0    E   DS* JA CA DC XC IC YA BA HA KC MC*\n\
                               3   HO1331  PVGOKA 1500   1800   320 0^S  E   DS# C6 D4 O2 YA BA LS MA TS EA HS*\n\
                               4   KA857   PVGHKG 0730   1015   320 0^B  E   DS! J6 C6 D6 I6 Y9 B9 H9 K9 M9 L9*\n\
                               KA378      OKA 1200   1520   333 0^L  E   DS! Y9 B9 H9 K9 M9 L9 V9 S9 N9 Q5*\n\
                               5   HX235   PVGHKG 0755   1040   332 0^B  E   DS# CA DA JA Z4 IQ YA BA HA KA LA*\n\
                               HX682      OKA 0725+1 1055+1 33V 0^C  E   DS# CA D5 J4 Z3 IQ YA BA HA KA LA*\n\
                               6+  KA871   PVGHKG 0825   1110   320 0^B  E   DS! J6 C6 D6 I6 Y9 B9 H9 K9 M9 L9*\n\
                               KA378      OKA 1200   1520   333 0^L  E   DS! Y9 B9 H9 K9 M9 L9 V9 S9 N9 QC*\n";
            strcpy(prs, buf);
        }
        break;
    case QTE:
        {
            const char * buf =">qte:/mu\n\
                              FSI/MU                                                                          \n\
                              S MU   523N26OCT PVG0910 1250NRT0S    332                                       \n\
                              01 NSRWCJ               3195 CNY                    INCL TAX                    \n\
                              *SYSTEM DEFAULT-CHECK OPERATING CARRIER                                         \n\
                              *ATTN PRICED ON 23OCT14*1418                                                    \n\
                              SHA                                                                            \n\
                              TYO NSRWCJ          NVB26OCT NVA26OCT 2PC                                      \n\
                              FARE  CNY    2600                                                               \n\
                              TAX   CNY     90CN CNY    505YQ                                                 \n\
                              TOTAL CNY    3195                                                               \n\
                              26OCT14SHA MU TYO423.65NUC423.65END ROE6.137080                                 \n\
                              ENDOS *NON-END/NONREF AFT DEP.                                                  \n\
                              ENDOS *CHG FEE CNY300.                                                          \n\
                              ENDOS *REF FEE CNY300 BEF DEP.                                                  \n\
                              *AUTO BAGGAGE INFORMATION AVAILABLE - SEE FSB                                   \n\
                              RFSONLN/1E /EFEP_6/FCC=T/   \n";
            strcpy(prs, buf);
        }
        break;
    case BESTPRICE_AV:
        {
            const char* buf =" 14MAY(WED) ICNBJS FROM KE                                                      \n\
                             1   KE5803      JC CC YC BC MC HC EC KC        ICNPEK 0810   0910   321 0       \n\
                             2   CA4199      P6 A2 J9 C9 D9 I9 Z3 Y9 B9 M9  GMPPEK 0920   1030   772 0       \n\
                             >               H9 E9 K9 Q9 TL GL                                               \n\
                             3   KE855       P4 A2 J9 C9 D9 I9 Z5 Y9 B9 M9  ICNPEK 1105   1210   773 0       \n\
                             >               H9 E9 K9 Q9 T9 G9                                               \n\
                             4   KE5801      JC CC YC BC MC HC EC KC        GMPPEK 1230   1325   321 0       \n\
                             5   KE853       RL AL JL CL DL IL ZL YL BL ML  ICNPEK 1900   2005   772 0       \n\
                             >               HL EL KL QL TL GL                                               \n\
                             6   KE1223      C9 Z9 O9 Y9 G9 T9              GMPCJU 1330   1435   744 0       \n\
                             KE879       P5 A2 J9 C9 D8 I8 Z2 Y9 B9 M9     PEK 1550   1725   333 0       \n\
                             >               H9 E9 K9 Q9 T9 G9                                               \n\
                             7+  KE1221      C9 Z9 O9 Y9 G9 T9              GMPCJU 1215   1320   744 0       \n\
                             KE879       P5 A2 J9 C9 D8 I8 Z2 Y9 B9 M9     PEK 1550   1725   333 0       \n\
                             >               H9 E9 K9 Q9 T9 G9                                         ";
            strcpy(prs, buf);
        }
        break;
    case BESTPRICE_SAV:
        {
            const char* buf =
                " AV:HU7608/22NOV                                                                \n\
                DEP TIME   ARR TIME   WEEK FLY   GROUND TERM  TYPE MEAL  DISTANCE               \n\
                SHA 1055   PEK 1310   SAT  2:15         T2/T1 333  L     1076                   \n\
                TOTAL JOURNEY TIME   2:15                                                       \n\
                SHAPEK FA ZA P2 AA YA BA HA KA LA MA QA XA UQ EQ TQ V3 WQ GQ OQ                 \n\
                SA\n";
            strcpy(prs, buf);
        }
        break;
    case BESTPRICE_SS:
        {
            const char* buf =
                "SS:MU5138 Y  23FEB  PEKSHA NN2                                                    \n\
                1.  CA1858 Y   FR20FEB  SHAPEK DK2   0750 1020          73K B 0  R E T2T3      \n\
                2.  MU5138 Y   MO23FEB  PEKSHA DK2   0700 0915          333 S 0  R E T2T2      \n\
                3.SHA/T SHA/T31001823/SHANGHAI LERAN AVIATION SERVICE CO.,LTD/HUANG CHUAN      \n\
                BING ABCDEFG                                                               \n\
                4.SHA521\n";
            strcpy(prs, buf);
        }
        break;
    case BESTPRICE_PAT:
        {
            const char * buf = ">PAT:A  \n\
                               01 Y FARE:CNY810.00 TAX:CNY50.00 YQ:CNY70.00  TOTAL:930.00  \n\
                               SFC:01    SFN:01   \n\
                               25DEC(THU) SHAOKA \n\
                               1-  MU287   PVGOKA 1340   1640   320 0^L  E   DS# J6 C4 D2 IS YA BA MA EA HA KA*\n\
                               2  *JL5634  PVGOKA 1340   1640   320 0    E   DS* JA CA DC XC IC YA BA HA KC MC*\n\
                               3   HO1331  PVGOKA 1500   1800   320 0^S  E   DS# C6 D4 O2 YA BA LS MA TS EA HS*\n\
                               4   KA857   PVGHKG 0730   1015   320 0^B  E   DS! J6 C6 D6 I6 Y9 B9 H9 K9 M9 L9*\n\
                               KA378      OKA 1200   1520   333 0^L  E   DS! Y9 B9 H9 K9 M9 L9 V9 S9 N9 Q5*\n\
                               5   HX235   PVGHKG 0755   1040   332 0^B  E   DS# CA DA JA Z4 IQ YA BA HA KA LA*\n\
                               HX682      OKA 0725+1 1055+1 33V 0^C  E   DS# CA D5 J4 Z3 IQ YA BA HA KA LA*\n\
                               6+  KA871   PVGHKG 0825   1110   320 0^B  E   DS! J6 C6 D6 I6 Y9 B9 H9 K9 M9 L9*\n\
                               KA378      OKA 1200   1520   333 0^L  E   DS! Y9 B9 H9 K9 M9 L9 V9 S9 N9 QC*\n";
            strcpy(prs, buf);
        }
        break;
    case BESTPRICE_QTE:
        {
            const char * buf =">qte:/mu\n\
                              FSI/MU                                                                          \n\
                              S MU   523N26OCT PVG0910 1250NRT0S    332                                       \n\
                              01 NSRWCJ               3195 CNY                    INCL TAX                    \n\
                              *SYSTEM DEFAULT-CHECK OPERATING CARRIER                                         \n\
                              *ATTN PRICED ON 23OCT14*1418                                                    \n\
                              SHA                                                                            \n\
                              TYO NSRWCJ          NVB26OCT NVA26OCT 2PC                                      \n\
                              FARE  CNY    2600                                                               \n\
                              TAX   CNY     90CN CNY    505YQ                                                 \n\
                              TOTAL CNY    3195                                                               \n\
                              26OCT14SHA MU TYO423.65NUC423.65END ROE6.137080                                 \n\
                              ENDOS *NON-END/NONREF AFT DEP.                                                  \n\
                              ENDOS *CHG FEE CNY300.                                                          \n\
                              ENDOS *REF FEE CNY300 BEF DEP.                                                  \n\
                              *AUTO BAGGAGE INFORMATION AVAILABLE - SEE FSB                                   \n\
                              RFSONLN/1E /EFEP_6/FCC=T/   \n";
            strcpy(prs, buf);
        }
        break;
    default:
        MSGOUT(en_Msg_Debug,"ServerMain::simulatecommandresult unhandled command !!!");
    }
    int len = sizeof(_StEtermSvrResult)+strlen(prs)+1;
    if (command.type == LCAVH || command.type == LCSAV || command.type == PAT || command.type == QTE|| command.type == RT|| command.type == BESTPRICE_AV|| command.type == BESTPRICE_SAV)
    {
        PostEventResult(DB_LOWERCABIN_COMMAND_RESULT, 0, buff, len, NULL);
        return;
    }
    //send the simulate command result back to svrloop
    PostEventResult(DB_COMMAND_RESULT, 0, buff, len, NULL);
}

int ServerMain::fetchfdfromclientid(int clientid)
{
    int iRet = -1;
    std::map<int, void*>::iterator it;
    for (it = m_mapfd.begin(); it != m_mapfd.end(); ++it)
    {
        _StConnectInfo* pinfo = (_StConnectInfo*) it->second;
        if (pinfo == NULL)
        {
            continue;
        }
        StClientInfo *pClientInfo = (StClientInfo*) pinfo->pdata;
        if (pClientInfo == NULL)
        {
            continue;
        }
        if (pClientInfo->idx == clientid)
        {
            //find the clientid's fd
            iRet = it->first;
            break;
        }
    }
    return iRet;
}

bool ServerMain::dealpriceconfirmrequest(int fd, int wndid, int *pdata,unsigned int len)
{
    _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
    StClientInfo *pClientInfo = (StClientInfo *) pinfo->pdata;
    std::queue<StCommands *> &commands = m_commands[pClientInfo->idx];

    StCommands *currentCommands = commands.front();
    //current command should be fd
    StCommand &currentCommand =
        currentCommands->commands[currentCommands->current];
    currentCommand.status = COMPLETE;
    if (*pdata == 1)
    {
        //drop it
        if (currentCommands->current + 1 == currentCommands->count)
        {
            //no more command should be exec,always
            delete currentCommands;
            commands.pop();
        }
        //fire the command sender again
        firecommandsender(pClientInfo->idx);
    }
    return true;
}

bool ServerMain::dealticketpricerequest(int fd, int wndid, StFlightTrip *pdata, unsigned int len)
{
    if (pdata == NULL || pdata->segscount <= 0)
    {
        return false;
    }
    MSGOUT(en_Msg_Warning, "dealticketpricerequest cmd, trip type:%d segment count:%d", pdata->triptype, pdata->segscount);
    PostDBRequest(DB_TICKET_PRICE_REQUEST, wndid, pdata, len,(void*) (long) fd);
    return true;
}

bool ServerMain::dealbestcabinpricerequest( int fd, int wndid, StTrip *pdata, unsigned int len )
{
    if (pdata == NULL || pdata->segss <= 0)
    {
        return false;
    }
    _StConnectInfo* pinfo = (_StConnectInfo*) m_mapfd[fd];
    if (pinfo == NULL)
        return false;
    StTrip *trip = new StTrip;
    memset(trip,0,sizeof(StTrip));
    memcpy(trip,pdata,sizeof(StTrip));
    StCommands *cmdPatch = new StCommands;
    // memset(cmdPatch,0,sizeof(StCommands));
    cmdPatch->clientid = pinfo->id;
    cmdPatch->context = trip;
    cmdPatch->current = 0 ;
    cmdPatch->count = 0;
    cmdPatch->ishog = true;
    cmdPatch->status = WAITING;
    for (int i = 0 ; i < pdata->segsCount ; ++i)
    {
        StSegs &segs = pdata->segss[i];
        //init all segment's lower cabin info
        bool hasLowerCabin = false;
        std::vector<std::string> flights;
        for (int j = 0 ; j <  segs.segCount; ++j)
        {
            StSeg &seg = segs.segs[j];
            flights.push_back(seg.flightNo);
            if (strcmp(seg.availableLowerCabin,"") != 0)
            {
                memset(seg.availableLowerCabin,0,sizeof(seg.availableLowerCabin));
            }
            strcpy(seg.availableLowerCabin,seg.currentCabin);
            std::string aircompany = seg.flightNo;
            aircompany = aircompany.substr(0,2);
            if (aircompanyCabinMap.count(aircompany) > 0)
            {
                PhysicalCabin &cabinMap = aircompanyCabinMap[aircompany];
                std::string::size_type index =  cabinMap.superEconomyClass.find(seg.currentCabin);
                if (index != std::string::npos)
                {
                    std::string lowerCabins = cabinMap.superEconomyClass.substr(index+1,cabinMap.superEconomyClass.length()-1);
                    lowerCabins = lowerCabins.append(seg.availableLowerCabin);
                    strcpy(seg.availableLowerCabin,lowerCabins.c_str());
                    if (strcmp(seg.currentCabin,seg.availableLowerCabin) != 0)
                    {
                        hasLowerCabin = true;
                    }  
                    continue;
                }   
                index =  cabinMap.economyClass.find(seg.currentCabin);
                if (index != std::string::npos)
                {
                    std::string lowerCabins = cabinMap.economyClass.substr(index+1,cabinMap.economyClass.length()-1);
                    lowerCabins = lowerCabins.append(seg.availableLowerCabin);
                    strcpy(seg.availableLowerCabin,lowerCabins.c_str());
                    if (strcmp(seg.currentCabin,seg.availableLowerCabin) != 0)
                    {
                        hasLowerCabin = true;
                    }
                    continue;
                }
                index =  cabinMap.bussinessClass.find(seg.currentCabin);
                if (index != std::string::npos)
                {
                    std::string lowerCabins = cabinMap.bussinessClass.substr(index+1,cabinMap.bussinessClass.length()-1);
                    lowerCabins = lowerCabins.append(seg.availableLowerCabin);
                    strcpy(seg.availableLowerCabin,lowerCabins.c_str());
                    if (strcmp(seg.currentCabin,seg.availableLowerCabin) != 0)
                    {
                        hasLowerCabin = true;
                    }
                    continue;
                }
                index =  cabinMap.firstClass.find(seg.currentCabin);
                if (index != std::string::npos)
                {
                    std::string lowerCabins = cabinMap.firstClass.substr(index+1,cabinMap.firstClass.length()-1);
                    lowerCabins = lowerCabins.append(seg.availableLowerCabin);
                    strcpy(seg.availableLowerCabin,lowerCabins.c_str());
                    if (strcmp(seg.currentCabin,seg.availableLowerCabin) != 0)
                    {
                        hasLowerCabin = true;
                    }
                    continue;
                }
            }
        }
        //generate AV command
        //if no lower cabin we will don't  generate av command
        if (segs.segCount == 1 /*&& hasLowerCabin*/)
        {
            bool isOk =false;
            //no married segments
            StCommand sav = CommandGenerator::generateSpecialAv(isOk,segs.segs[0].flightNo,segs.segs[0].date);
            sav.type = BESTPRICE_SAV;
            sav.setTargetFlights(flights);
            sav.subId = i;//signed with segs index
            cmdPatch->commands.push_back(sav);
            cmdPatch->count ++;
        }
        else if(segs.segCount>1 /*&& hasLowerCabin*/)
        {
            //married segments
            bool isOk =false;
            std::string cityPair = segs.from;
            cityPair = cityPair.append(segs.to);
            StCommand av = CommandGenerator::generateAv(isOk,segs.date,cityPair,"H",segs.time,segs.aircompany);
            av.type = BESTPRICE_AV;
            av.setTargetFlights(flights);
            av.subId = i;//signed with segs index
            cmdPatch->commands.push_back(av);
            cmdPatch->count ++;
        }
    }
    printCommands(cmdPatch);
    PostEventResult(DB_SEND_LOWERCABIN_COMMAND, 0, &cmdPatch, sizeof(StCommands*),(void*) (long) fd);
    return true;
}

bool ServerMain::dealistpricerequest(int fd, int wndid, void *pdata, unsigned int len)
{
    StFlightTrip *pFlightTrip = (StFlightTrip*) pdata;
    if (pFlightTrip->segscount <= 0)
        return false;
    _StConnectInfo* p = (_StConnectInfo*) m_mapfd[fd];
    StClientInfo *pClientInfo = (StClientInfo *) p->pdata;
    std::map<int, std::queue<StCommands*> >::iterator iter = m_commands.find(
        pClientInfo->idx);
    if (iter == m_commands.end())
        m_commands[pClientInfo->idx] = std::queue<StCommands*>();
    //	std::queue<StCommands*> &cmds = m_commands[pClientInfo->idx];

    bool isOk = false;
    std::string cityPair = "";
    cityPair.append(pFlightTrip->cityfrom);
    cityPair.append(pFlightTrip->cityto);
    if (strlen(pFlightTrip->segs[0].cabin) <= 0)
    {
        //no cabin, avh flightno/date
        StCommand avsCommand = CommandGenerator::generateSpecialAv(isOk,
            pFlightTrip->segs[0].flightno, pFlightTrip->depaturedate);
        //avsCommand.dealfunction = &ServerMain::dealistpricerequest;
        StCommands cmdpatch;
        cmdpatch.clientid = pClientInfo->idx;
        cmdpatch.commands.push_back(avsCommand);
        cmdpatch.count = 1;
        cmdpatch.current = 0;
        cmdpatch.context = pdata;
        //cmds.push(cmdpatch);
        //trige command sender
        firecommandsender(cmdpatch.clientid);
        return true;
    }
    else if (pFlightTrip->segs[0].ticketprice <= 0)
    {
        //no cabin price
        StCommand fdCommand = CommandGenerator::generateOrderFd(isOk,
            pFlightTrip->depaturedate, cityPair,
            pFlightTrip->segs[0].aircompany);
        //fdCommand.dealfunction = &ServerMain::dealistpricerequest;
        StCommands cmdpatch;
        cmdpatch.clientid = pClientInfo->idx;
        cmdpatch.commands.push_back(fdCommand);
        cmdpatch.count = 1;
        cmdpatch.current = 0;
        cmdpatch.context = pdata;
        //cmds.push(cmdpatch);
        //trige command sender
        firecommandsender(cmdpatch.clientid);
        return true;
    }
    else if (pFlightTrip->ourprice <= 0)
    {
        //here we get the ticket price,filter it by policy
        return true;
    }

    char buf[1024] =
    { 0 };
    NetSocketHead* phead = (NetSocketHead *) buf;
    phead->uMainCmd = MAINSVR_CLIENT_TYPE;
    phead->uSubCmd = MC_TICKET_PRICE_RESULT;

    int realSize = sizeof(StFlightTrip)
        - (sizeof(pFlightTrip->segs) / sizeof(StFlightSegment)
        - pFlightTrip->segscount) * sizeof(StFlightSegment);
    int nSize = sizeof(NetSocketHead) + realSize;
    phead->uLen = nSize;
    StFlightTrip *ppFlightTrip = (StFlightTrip *) (phead + 1);
    memcpy(ppFlightTrip, pFlightTrip, sizeof(StFlightTrip));
    senddata(fd, buf, phead->uLen);
    return true;
}
bool ServerMain::dealirtpricerequest(int fd, int wndid, void *pdata, unsigned int len)
{
    //StCommand avsCommand = CommandGenerator::generateSpecialAv(isOk, pdata->segs[0],pdata->depaturedate);
    return true;
}
bool ServerMain::dealimtpricerequest(int fd, int wndid, void *pdata, unsigned int len)
{

    return true;
}
bool ServerMain::dealfstpricerequest(int fd, int wndid, void *pdata, unsigned int len)
{

    return true;
}
bool ServerMain::dealfrtpricerequest(int fd, int wndid, void *pdata, unsigned int len)
{

    return true;
}
bool ServerMain::dealfmtpricerequest(int fd, int wndid, void *pdata, unsigned int len)
{

    return true;
}

void * ServerMain::clientFdCommandHandler(void *context, void *result)
{
    return NULL;
}

bool ServerMain::deallowercabinsrequest(int fd, int wndid,StLowerCabinsRequest* pdata, unsigned int len)
{
    if (pdata == NULL || strlen(pdata->flightNo) <= 0
        || strlen(pdata->currentCabin) <= 0)
    {
        return false;
    }
    MSGOUT(en_Msg_Warning,"deallowercabinsrequest cmd, flightNo:%s Current cabin:%s",pdata->flightNo, pdata->currentCabin);
    PostDBRequest(DB_LOWER_CABIN_REQUEST, wndid, pdata, len, (void*) (long) fd);
    return true;
}

bool ServerMain::firecommandsender()
{
    bool bRet = false;
    MSGOUT(en_Msg_Debug, "ServerMain::firecommandsender start!!!");
    if(m_attachedcommand.size() <=0 )
        return true;
    StCommands *commands = m_attachedcommand.front();

    //find the unhandled command queue
    if (commands->count > 0 && (commands->status == WAITING || commands->status == PROCESSING))
    {
        printCommands(commands);
        //fire it
        commands->status = PROCESSING;
        char buf[2048] = { 0 };
        strcpy(buf, commands->commands[commands->current].content);
        bool findWaitingCommands = false;
        while (commands->current < commands->count)
        {
            if (commands->commands[commands->current].status == PROCESSING)
            {
                //some command is waiting for result, then hang up all commands after he
                return true;
            }
            if (commands->commands[commands->current].status != WAITING)
                commands->current += 1;
            else
            {
                findWaitingCommands = true;
                break;
            }
        }
        if (findWaitingCommands)
        {
            MSGOUT(en_Msg_Debug,"ServerMain::firecommandsender current:%d,total:%d,current command type:%d!", commands->current, commands->count,commands->commands[commands->current].type);
            if (commands->commands[commands->current].type == LCAVH || commands->commands[commands->current].type == LCSAV)
            {
                pthread_mutex_lock(&avResultMutex);
                int count = lowerAvResuts.count(commands->commands[commands->current].content);
                if (count >0 )
                {
                    //find result in buffer,then use it directly
                    LowerAvResult avResult = lowerAvResuts[commands->commands[commands->current].content];
                    commands->commands[commands->current].formartedresult = avResult.result;
                    LowerCabinScannerData*context = lowerCabinContext[commands->identifiers];
                    StCommand *tmp = new StCommand;
                    tmp->clone(commands->commands[commands->current]);
                    commands->commands[commands->current].status = COMPLETE;
                    context->recvCommandData.push_back(tmp);
                    LowerCabinScanTask* task = generateTaskByType(context,1);
                    pthread_mutex_lock(&rtMutex);
                    tasks.push(task);
                    pthread_mutex_unlock(&rtMutex);
                    sem_post(&semRc);
                    commands->current+=1;
                    pthread_mutex_unlock(&avResultMutex);
                    firecommandsender();
                    return bRet;
                }
                pthread_mutex_unlock(&avResultMutex);
            }
            //TODO:send the command
            //m_soeterm.sendcommand(buf, strlen(buf), commands->identifiers.c_str());
            commands->commands[commands->current].status = PROCESSING;
            simulatecommandresult(commands);
        }
        else
        {
            MSGOUT(en_Msg_Debug,"ServerMain::firecommandsender this commands have finished,idx:!");
            commands->status = COMPLETE;
            firecommandsender();
        }
    }
    else
    {
        MSGOUT(en_Msg_Debug,"ServerMain::firecommandsender no commands waiting,remove it");
        printCommands(commands);
        m_attachedcommand.pop();
    }
    MSGOUT(en_Msg_Debug, "ServerMain::firecommandsender end !!!");

    return bRet;
}

void ServerMain::startLowerCabinScanner()
{
    MSGOUT(en_Msg_Debug, "startLowerCabinScanner");
    PostDBRequest(DB_START_LOWER_CABIN_SCANNER, 0, 0, 0, 0);
}

std::string ServerMain::generateContextKey( LowerCabinScannerData * scannerData )
{
    std::string sRet = "";
    char buf[1024];
    memset(buf, 0, sizeof(buf) * sizeof(char));
    sprintf(buf, "%d|%d|%d", scannerData->userData->userId,scannerData->orderData->orderId,scannerData->orderData->orderCabinId);
    sRet = sRet.append(buf);
    return sRet;
}

bool ServerMain::isInActiveTimeZone( LowerCabinSettings * scannerSettings )
{
    bool isInZone = false;
    time_t currentTimeStamp = CommonLib::currentTimeStamp();
    std::vector<LowerFrequence*> frequences = scannerSettings->frequence;
    int count = frequences.size();
    for (int i = 0; i < count; ++i)
    {
        LowerFrequence* frequence = frequences[i];
        if (frequence->timestampFrom <= 0)
            frequence->timestampFrom = CommonLib::dateFromatTime(frequence->dateFrom.append(" 00:00:00").c_str());
        if (frequence->timestampTo <= 0)
            frequence->timestampTo = CommonLib::dateFromatTime(frequence->dateTo.append(" 23:59:59").c_str());
        if (currentTimeStamp > frequence->timestampFrom && currentTimeStamp < frequence->timestampTo)
        {
            isInZone = true;
            break;
        }
    }
    return isInZone;
}

bool ServerMain::isInActiveTimeZoneToday( LowerCabinSettings * scannerSettings )
{
    bool isInZone = false;
    std::string todayFrom = CommonLib::currentDate().append(" 00:00:00");
    std::string todayTo = CommonLib::currentDate().append(" 23:59:59");
    time_t todayFromTimestamp = 0, todayToTimestamp = 0;
    todayFromTimestamp = CommonLib::dateFromatTime(todayFrom.c_str());
    todayToTimestamp = CommonLib::dateFromatTime(todayTo.c_str());
    std::vector<LowerFrequence*> frequences = scannerSettings->frequence;
    int count = frequences.size();
    for (int i = 0; i < count; ++i)
    {
        LowerFrequence* frequence = frequences[i];
        if (frequence->timestampFrom <= 0)
            frequence->timestampFrom = CommonLib::dateFromatTime(frequence->dateFrom.append(" 00:00:00").c_str());
        if (frequence->timestampTo <= 0)
            frequence->timestampTo = CommonLib::dateFromatTime(frequence->dateTo.append(" 23:59:59").c_str());
        if (todayFromTimestamp >= frequence->timestampFrom && todayToTimestamp <= frequence->timestampTo)
        {
            //setting the frequence of today
            scannerSettings->todayFrequence = frequence;
            int tmp = frequence->timePares.size();
            for (int j = 0; j < tmp; ++j)
            {
                frequence->timePares[j].timestampFrom = CommonLib::dateFromatTime(CommonLib::currentDate().append(" ").append(frequence->timePares[j].from).c_str());
                frequence->timePares[j].timestampTo = CommonLib::dateFromatTime(CommonLib::currentDate().append(" ").append(frequence->timePares[j].to).c_str());
                time_t currentTimeStamp = CommonLib::currentTimeStamp();
                if (currentTimeStamp >= frequence->timePares[j].timestampFrom && currentTimeStamp <= frequence->timePares[j].timestampTo)
                {
                    isInZone = true;
                    break;
                }
            }
            break;
        }
    }
    return isInZone;
}

LowerCabinScanTask * ServerMain::generateTaskByType( LowerCabinScannerData * scannerData, int step /*=0 */ )
{
    switch (step)
    {
    case 0:
        {
            if (scannerData->orderData->tripType == TRIP_INLAND)
            {
                InlandScanTask *inlandTask = new InlandScanTask();
                inlandTask->setData(scannerData);
                inlandTask->setHandle(this);
                return inlandTask;
            }
            else
            {
                InternateScanTask *internateTask = new InternateScanTask();
                internateTask->setData(scannerData);
                internateTask->setHandle(this);
                return internateTask;
            }
        }
    case 1:
        {
            if (scannerData->orderData->tripType == TRIP_INLAND)
            {
                InlandEtermCommandProcessor *inlandTask =  new InlandEtermCommandProcessor();
                inlandTask->setData(scannerData);
                inlandTask->setHandle(this);
                inlandTask->setCmdId(scannerData->recvCommandData.front()->identifyId);
                return inlandTask;
            }
            else
            {
                InternateEtermCommandProcessor *internateTask =  new InternateEtermCommandProcessor();
                internateTask->setData(scannerData);
                internateTask->setHandle(this);
                internateTask->setCmdId(scannerData->recvCommandData.front()->identifyId);
                return internateTask;
            }
        }
    }
    return NULL;
}

void ServerMain::startWorkThread( ServerMain* param , int count )
{
    pthread_t id;
    for (int i = 0; i < count; ++i)
    {
        pthread_create(&id, NULL, workThread, param);
        pthread_detach(id);
    }
}

void * ServerMain::workThread( void *params )
{
    MSGOUT(en_Msg_Debug, "workThread started, thread id:%lu", pthread_self());
    if (params == NULL)
        return NULL;
    ServerMain *handler = (ServerMain *) params;
    while (true)
    {
        sem_wait(&semRc);
        pthread_mutex_lock(&rtMutex);
        //waiting4handling.push(scannerData);
        LowerCabinScanTask *task = tasks.front();
        tasks.pop();
        pthread_mutex_unlock(&rtMutex);
        task->setHandle(handler);
        task->doWork();
    }
    return NULL;
}

ServerMain::ServerMain()
{
    pthread_mutex_init(&rcMutex, NULL);
    pthread_mutex_init(&rtMutex, NULL);
    pthread_mutex_init(&avResultMutex, NULL);
    pthread_mutex_init(&uidMutex, NULL);

    sem_init(&semRc, 0, 0);
//    startWorkThread(this,1);
}

AvhResults * ServerMain::kmpFind( AvhResults *avhiLink,StSegs &segs )
{
    AvhResults *current = avhiLink;
    AvhResults *avrRet = NULL;
    while (current != 0 )
    {
        std::string flightNo = current->avhInfo->pinfo->aircompany;
        flightNo = flightNo.append(current->avhInfo->pinfo->airnumber);
        int i = 0;
        bool isMatched = true;
        if (flightNo.compare(segs.segs[i].flightNo) == 0)
        {
            //first node matched 
            AvhResults *tmp = current->next;
            ++i;
            int idx = current->avhInfo->pinfo->idx;
            while (tmp != NULL && i < segs.segCount)
            {
                std::string flightNo = tmp->avhInfo->pinfo->aircompany;
                flightNo = flightNo.append(tmp->avhInfo->pinfo->airnumber);
                if (flightNo.compare(segs.segs[i].flightNo) != 0 || idx != tmp->avhInfo->pinfo->idx)
                {
                    isMatched = false;
                    break;
                }
                tmp = tmp->next;
                ++i;
            }
        }
        else
        {
            isMatched = false;
        }
        if (isMatched)
        {
            avrRet = current;
            break;
        } 
        current = current->next;
    }
    return avrRet;
}

void ServerMain::printCommands( StCommands * commands )
{
    for (int i = 0 ; i < commands->count ; ++i)
    {
        StCommand &command = commands->commands[i];
        MSGOUT(en_Msg_Debug,"ptr:%p, commands status: %d current: %d, command: %d content: %s,status: %d,type: %d",
            commands, commands->status, commands->current, i, command.content, command.status, command.type);
    }
}










