/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-12-26 17:14:41
# LastModified : 2014-12-26 17:21:13
# FileName     : ETermString.cpp
# Description  : 
 ******************************************************************************/
// ETermString.cpp: implementation of the CETermString class.
//
//////////////////////////////////////////////////////////////////////

#include "ETermString.h"
#include <string.h>
#include <stdio.h>
#include <vector>
#include <list>
#include <string>
#include<stdlib.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const char* CETermString::s_week3[7] = {
	"MON","TUE","WED","THU","FRI","SAT","SUN"
};

const char* CETermString::s_week2[7] = {
	"MO","TU","WE","TH","FR","SA","SU"
};

const char* CETermString::s_mouth[12] = {
	"JAN","FEB","MAR","APR",
	"MAY","JUN","JUL","AUG",
    "SEP","OCT","NOV","DEC"
};

CETermString::~CETermString()
{

}

int CETermString::_getOneLine( const char* pin, char* pout, unsigned int outlen )
{
	if (strlen(pin) == 0)
		return -1;

	memset(pout, 0, outlen);
	unsigned int len = strlen(pin);
	for (unsigned int i= 0; i < len; i++) {
		if (i > outlen)
			return -1;

		if (_is_return(pin[i])) {
			memcpy(pout, pin, i+1);
			return i+1;
		}
	}	

	memcpy(pout, pin, strlen(pin));
	return strlen(pin);
}

CETermString::CETermString()
{
	
}

int CETermString::_avhgetrecords( const char* pstr, char*** pone, int *pagetype )
{
    *pagetype = en_page_single;
    int index = 0;
    std::vector<std::string> strvec;
//    int count = 0;
    std::string strtemp = "";
    while(1) {
        char temp[4096] = {0};
        int i = _getOneLine(pstr+index, temp, sizeof(temp));
        if (i == -1)
            break;
        index += i;

        if (temp[0] >= '1' && temp[0] <= '9') {
            if (strtemp != "") {
                strvec.push_back(strtemp);
            }
            if (temp[1] == '-') {
                *pagetype |= en_page_before;
            }
            if (temp[1] == '+') {
                *pagetype |= en_page_next;
            }
            strtemp = "";
        }
        else if (temp[0] == ' ' || temp[0] == '\t' || _is_return(temp[0])) {
            char token[4096] = {0};
            i = _readOneToken(temp, token, sizeof(token));
            if (i == -1)
            {
                continue;
            }
            if (token[0] == '*') {
                continue;
            }
            char dep[4] = {0};
            char des[4] = {0};
            if (_avhgetdepdes(temp, dep, des)) {
                continue;
            }
        }
        else if (temp[0] == '>')
        {
        }
        else
        {
            continue;
        }
        strtemp += temp;
    }

    if (strtemp != "")
    {
        strvec.push_back(strtemp);
    }

    *pone = (char**)malloc(sizeof(void*)*strvec.size());
    for (unsigned int i = 0; i < strvec.size(); i++)
    {
        (*pone)[i] = (char*)malloc(strvec[i].length()+1);
        strcpy((*pone)[i], strvec[i].c_str());
    }

    return strvec.size();
}

int CETermString::_readOneToken( const char* pin, char* pout, unsigned int outlen )
{
   unsigned int i = 0, j = 0;
// 	if (strlen(pin) <= 0)
// 		return -1;
	while(i <= strlen(pin)) {
		if (pin[i] != ' ' && pin[i] != '\t' && !_is_return(pin[i]))
			break;
		i++;
	}
	if (i == strlen(pin))
		return -1;

	for (j = i; j < strlen(pin); j++) {
		if (pin[j] == ' ' || pin[j] == '\t' || _is_return(pin[j]))
			break;
	}
	if (j-i > outlen)
		return -1;

	memset(pout, 0, outlen);
	memcpy(pout, pin+i, j-i);
	return i;
}

void CETermString::_freerecords( char** p, int count )
{
	if (p == NULL)
		return;
	for (int i = 0; i < count; i++) {
		if (p[i] != NULL)
			free(p[i]);
	}
	free(p);
}

int CETermString::_avhfirstline( const char* pstr, avhInfo* pinfo, avhInfoEx* pinfoE)
{
	int  index = 0;
	_avh_status status = en_avh_number;
	bool bshare = false;
	while (1) {
		char token[4096] = {0};
		int res = _readOneToken(pstr+index, token, sizeof(token));
		if (strlen(token) == 0)
			break;

		if (status == en_avh_number) {
			if (strlen(token) >= 5)
			{
				int nstart = 0;
				if (token[0] == '*') {
					bshare = true;
					nstart = 1;
				}
				if (token[3] == '*') {
					bshare = true;
					nstart = 4;
				}
				strncpy(pinfo->aircompany, token+nstart, 2);
				strcpy(pinfo->airnumber, token+2+nstart);
				status = en_avh_timeflag;
			}
			else {
				status = en_avh_airnumber;
			}
		}
		else if (status == en_avh_airnumber) {
			if (strlen(token) < 5)
				return -1;

			int nstart = 0;
			if (token[0] == '*') {
				bshare = true;
				nstart = 1;
			}
			strncpy(pinfo->aircompany, token+nstart, 2);
			strcpy(pinfo->airnumber, token+2+nstart);
			status = en_avh_timeflag;
		}
		else if (status == en_avh_timeflag) {
			if (res > 4) {
				status = en_avh_seatstatus;
				continue;
			}
			if (strlen(token) != 3)
				return -1;

			strcpy(pinfoE->timeflag, token);

			status = en_avh_seatstatus;
		}
		else if (status == en_avh_seatstatus) {
			if (strlen(token) != 2) {
				status = en_avh_citypair;
				continue;
			}
			memcpy(&pinfoE->detail[pinfoE->count][0], token, 2);
			pinfoE->count++;
		}
		else if (status == en_avh_citypair) {
			if (strlen(token) == 6) {
				memcpy(pinfo->areastart, token, 3);
				memcpy(pinfo->areaend, token+3, 3);
				status = en_avh_starttime;
			}
			else if (strlen(token) == 3) {
				memcpy(pinfo->areaend, token, 3);
				status = en_avh_starttime;
			}
		}
		else if (status == en_avh_starttime) {
			if (strlen(token) != 4 && strlen(token) != 6)
				return -1;

			memcpy(pinfo->timestart, token, strlen(token));

			status = en_avh_endtime;
		}
		else if (status == en_avh_endtime) {
			if (strlen(token) != 4 && strlen(token) != 6)
				return -1;
			
			memcpy(pinfo->timeend, token, strlen(token));
			
			status = en_avh_planetype;
		}
		else if (status == en_avh_planetype) {
			if (strlen(token) != 3)
				return -1;
			
			memcpy(pinfo->planetype, token, strlen(token));

			status = en_avh_staydiner;
		}
		else if (status == en_avh_staydiner) {
			if (strlen(token) > 3 || strlen(token) < 1)
				return -1;

			memcpy(pinfo->staycount, token, 1);
			if (strlen(token) > 1) {
				memcpy(pinfo->dinerinfo, token+2, 1);
			}

			status = en_avh_eleticket;
		}
		else if (status == en_avh_eleticket) {
			
		}

		index += res + strlen(token);
	}
	if (bshare)
		return 1;
	return 0;
}

int CETermString::_avhsecondline( const char* pstr, bool bshare, avhInfo* pinfo, avhInfoEx* pinfoE )
{
	int  pos = 0;
	_avh_status status = en_avh_seatstatus;
	if (bshare)
		status = en_avh_airnumber;

	while (1) {
		char token[4096] = {0};
		int res = _readOneToken(pstr+pos, token, sizeof(token));
		if (strlen(token) == 0)
			break;

		if (strcmp(token, ">") == 0) {
			pos += res + strlen(token);
			continue;
		}
		
		if (status == en_avh_airnumber) {
			if (strlen(token) >= 5)
			{
				strncpy(pinfo->aircompanysh, token, 2);
				strcpy(pinfo->airnumbersh, token+2);
				status = en_avh_seatstatus;
			}
			else
				return -1;
		}
		else if (status == en_avh_seatstatus) {
			if (strlen(token) != 2 || pos+res > 65) {
				status = en_avh_startstation;
				continue;
			}
			memcpy(&pinfoE->detail[pinfoE->count][0], token, 2);
			pinfoE->count++;
		}
		else if (status == en_avh_startstation) {
			if (strlen(token) > 2 || strlen(token) < 1)
				return -1;

			memcpy(pinfo->stationstart, token, strlen(token));
			status = en_avh_endstation;
		}
		else if (status == en_avh_endstation) {
			if (strlen(token) > 2 || strlen(token) < 1)
				return -1;
			
			memcpy(pinfo->stationend, token, strlen(token));
			status = en_avh_totaltime;
		}
		else if (status == en_avh_totaltime) {
			if (strlen(token) > 6 || strlen(token) < 4)
				return -1;

			memcpy(pinfo->totaltime, token, strlen(token));
			status = en_avh_null;
		}

		pos += res + strlen(token);
	}

	return 0;
}

int CETermString::DealAVHStr( const char* pstr, avhtravelInfo*** pinfo, const char* pdep, const char* pdes, int *pagetype )
{
	std::string str = _perdealachstr(pstr);
	
	char** precord = NULL;
	int count = _avhgetrecords(str.c_str(), &precord, pagetype);
	if (count == 0)
		return -1;
	
	*pinfo = (avhtravelInfo**)malloc(sizeof(avhtravelInfo*)*count);
	memset(*pinfo, 0, sizeof(avhtravelInfo*)*count);
	
	int idx = 0;

	for (int i = 0; i < count; i++) {
		(*pinfo)[idx] = (avhtravelInfo*)malloc(sizeof(avhtravelInfo));
		memset((*pinfo)[idx], 0, sizeof(avhtravelInfo));
		if (-1 == _avhdealonrecord(precord[idx], (*pinfo)[idx])) {
			free((*pinfo)[idx]);
			(*pinfo)[idx] = NULL;
		}
		else {
			idx++;
		}
	}

	_freerecords(precord, count);

    if (idx == 0) {
        free(*pinfo);
        *pinfo = NULL;
    }
	
	return idx;
}

std::string CETermString::_perdealachstr( const char* pstr )
{
	std::string str = pstr;
	
	std::string::size_type pos = 0;
	char seastr[] = {0x1d, 'A', 'S', '#', 0x1c, 0x00};
	bool breplace = false;
	while ( (pos = str.find(seastr, pos)) != std::string::npos ) {
		str.replace(pos, strlen(seastr), " AS# ");
		pos++;
		breplace = true;
	}

	pos = 0;
	if (!breplace) {
		char tempstr[] = "AS#";
		while ( (pos = str.find(tempstr, pos)) != std::string::npos ) {
			str.replace(pos, strlen(tempstr), " AS# ");
			pos+=2;
		}
	}

	return str;
}

int CETermString::_avhdealonrecord( const char* pstr, avhtravelInfo* pinfo )
{
    int pos = 0;
    int idx = 0;
    while (1) {
        char buf[4096] = {0};
        int offSet = 0;
        offSet = _getOneLine(pstr+pos, buf, sizeof(buf));
        if (offSet == -1) {
            if (strlen(pinfo->destination) == 0 && pinfo->count > 0)
            {
                strcpy(pinfo->destination, (pinfo->pinfo+pinfo->count-1)->areaend);
            }
            break;
        }
        pos += offSet;

        pinfo->pinfo = (avhInfo*)realloc(pinfo->pinfo , sizeof(avhInfo)*(pinfo->count+1));
        memset(pinfo->pinfo+pinfo->count, 0, sizeof(avhInfo));
        pinfo->pinfoex = (avhInfoEx*)realloc(pinfo->pinfoex, sizeof(avhInfoEx)*(pinfo->count+1));
        memset(pinfo->pinfoex+pinfo->count, 0, sizeof(avhInfoEx));

        if (_is_return(buf[strlen(buf)-1])) {
            buf[strlen(buf)-1] = 0;
        }
        int res = _avhfirstline(buf, pinfo->pinfo+pinfo->count, pinfo->pinfoex+pinfo->count);
        if (res == -1)
        {
            free(pinfo->pinfo);
            free(pinfo->pinfoex);
            return -1;
        }
        if (buf[0] >= '0' && buf[0] <= '9') {
            idx = atoi(buf);
        }
        (pinfo->pinfo+pinfo->count)->idx = idx;

        if (strlen(pinfo->depature) == 0) {
            strcpy(pinfo->depature, (pinfo->pinfo+pinfo->count)->areastart);
        }
        if (strlen((pinfo->pinfo+pinfo->count)->areastart) == 0 && pinfo->count > 0) {
            strcpy((pinfo->pinfo+pinfo->count)->areastart, (pinfo->pinfo+pinfo->count-1)->areaend);
        }

        memset(buf, 0, sizeof(buf));
        offSet = _getOneLine(pstr+pos, buf, sizeof(buf));
        if (offSet == -1) {
            pinfo->count++;
            continue;
        }
        pos += offSet;
        if (_is_return(buf[strlen(buf)-1])) {
            buf[strlen(buf)-1] = 0;
        }

        _avhsecondline(buf, res==1, pinfo->pinfo+pinfo->count, pinfo->pinfoex+pinfo->count);

        pinfo->count++;
    }
    return pinfo->count;
}

bool CETermString::_avhgetdepdes( const char* pstr, char* dep, char* des )
{
	char buf[4096] = {0};
	int res = _getOneLine(pstr, buf, sizeof(buf));
	if (res == -1)
		return false;

	if (_is_return(buf[strlen(buf)-1]))
		buf[strlen(buf)-1] = 0;

	char token[4096] = {0};
	res =  _readOneToken(buf, token, sizeof(token));
	if (res == -1)
		return false;

	if (token[0] < '0' || token[0] > '9' || token[1] < '0' || token[1] > '9' || token[5] != '(' || token[9] != ')')
		return false;

	unsigned int i = 0;
	for (i = 0; i < sizeof(s_mouth)/sizeof(s_mouth[0]); i++) {
		if (strncmp(s_mouth[i], token+2, 3) == 0)
			break;
	}
	if (i == sizeof(s_mouth)/sizeof(s_mouth[0]))
		return false;

	
	for (i =0; i < sizeof(s_week3)/sizeof(s_week3[0]); i++) {
		if (strncmp(s_week3[i], token+6, 3) == 0)
			break;
	}

	if (i == sizeof(s_week3)/sizeof(s_week3[0]))
		return false;
	
	res += strlen(token);
	memset(token, 0, sizeof(token));
	res = _readOneToken(buf+res, token, sizeof(token));
	if (res == -1)
		return false;

	if (strlen(token) != 6)
		return false;

	memcpy(dep, token, 3);
	memcpy(des, token+3, 3);

	return true;
}

int CETermString::DealReturnStr( const char* pstr )
{
	int res = 0, distance = 0;
	int line = 0;
	char dep[4] = {0}, des[4] = {0};
	if (_avhgetdepdes(pstr, dep, des)) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr, buf, sizeof(buf));
		avhtravelInfo** p = NULL;
		int pagetypa = en_page_single;
		res = DealAVHStr(pstr+offset, &p, dep, des, &pagetypa);
		if (res == -1)
			return -1;
		if (res == 0) {
			avtravelInfo** p = NULL;
			res = DealAVStr(pstr+offset, &p, dep, des, &pagetypa);
			FreeAVRes(p, res);
		}
		else {
			FreeAVHRes(p, res);
		}
		return res;
	}
	else if (_nfdgetdepdes(pstr, dep, des)) {
		char buf[4096] = {0};
		int pos = 0;
		int offset = _getOneLine(pstr, buf, sizeof(buf));
		pos += offset;
		offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		pos += offset;
		offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		pos += offset;

		nfdpriceinfo** p = NULL;
		int pagetype = en_page_single;
		res = DealNFDStr(pstr+pos, &p, dep, des, &pagetype);
		if (res == -1)
			return -1;

		FreeNFDRes(p, res);
		return res;
	}
	else if (_fdgetdepdes(pstr, dep, des, &distance)){
		char buf[4096] = {0};
		int pos = 0;
		int offset = _getOneLine(pstr, buf, sizeof(buf));
		pos += offset;
		offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		pos += offset;

		fdpriceinfo** p = NULL;
		int pagetype = en_page_single;
		res = DealFDStr(pstr+pos, &p, dep, des, distance, &pagetype);
		if (res == -1)
			return res;

		FreeFDRes(p, res);
		return res;
	}
	else if (_fsijudgement(pstr, &line)) {

		int pos = 0;
		while(line--) {
			char buf[4096] = {0};
			int offset = _getOneLine(pstr+pos, buf, sizeof(buf));
			pos += offset;
		}

		fsqpriceinfo info = {0};
		int res = DealFSIStr(pstr+pos, &info);

		if (res == -1)
			return res;

		FreeFSIRes(&info);
		return res;
	}
	else if (_patjudgement(pstr)) {

		char buf[4096] = {0};
		int offset = _getOneLine(pstr, buf, sizeof(buf));

		patpriceinfo* pinfo = NULL;
		res = DealPatStr(pstr+offset, &pinfo);
		if (res == -1)
			return res;

		FreePatRes(pinfo);
	}
	else if (_detrjudgement(pstr)) {
		detrtripinfo info = {{0}};

		DealDetrStr(pstr, &info);
		FreeDetrRes(&info);
	}
	return res;
}

void CETermString::FreeAVHRes( avhtravelInfo** pinfo, int count )
{
	for (int i = 0; i < count; i++) {
		if (pinfo[i]->pinfo != NULL) {
			free(pinfo[i]->pinfo);
			pinfo[i]->pinfo = NULL;
		}
		if (pinfo[i]->pinfoex != NULL) {
			free(pinfo[i]->pinfoex);
			pinfo[i]->pinfoex = NULL;
		}
		free(pinfo[i]);
		pinfo[i] = NULL;
	}
	free(pinfo);
}


bool CETermString::_nfdgettablepos( const char* pstr, int* arr, int size )
{
	memset(arr, 0, sizeof(int)*size);
	_nfd_status status = en_nfd_linenu;

	int pos = 0;
	while(1) {
		char token[4096] = {0};
		int offset = _readOneToken(pstr+pos, token, sizeof(token));

		if (offset == -1)
			break;

		switch (status) {
		case en_nfd_linenu:
			{
				if (strcmp("LN", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_company;
			}
			break;
		case en_nfd_company:
			{				
				if (strcmp("CXR", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_onewaypr;
			}
			break;
		case en_nfd_onewaypr:
			{
				if (strcmp("OW", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_roundtpr;
			}
			break;
		case en_nfd_roundtpr:
			{
				if (strcmp("RT", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_fbc_tc;
			}
			break;
		case en_nfd_fbc_tc:
			{
				if (strcmp("FBC/TC", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_seattype;
			}
			break;
		case en_nfd_seattype:
			{
				if (strcmp("RBD", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_minmax;
			}
			break;
		case en_nfd_minmax:
			{
				if (strcmp("MIN/MAX", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_trvdate;
			}
			break;
		case en_nfd_trvdate:
			{
				if (strcmp("TRVDATE", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_rule;
			}
			break;
		case en_nfd_rule:
			{
				if (strcmp("R", token) != 0)
					return false;
				pos += offset;
				arr[status] = pos;
				status = en_nfd_end;
			}
			break;
		default:
			pos += offset;
		}
		pos += strlen(token);
	}
	return true;
}

int CETermString::_nfdgetrecords( const char* pstr, char*** pone, int* pagetype )
{
    *pagetype = en_page_single;
    int index = 0;
    std::vector<std::string> strvec;
//    int count = 0;
    std::string strtemp = "";
    while(1) {
        char temp[4096] = {0};
        int offset = _getOneLine(pstr+index, temp, sizeof(temp));
        if (offset == -1)
            break;
        index += offset;

        if (temp[0] >= '0' && temp[0] <= '9' && temp[1] >= '0' && temp[1] <= '9') {
            strtemp += temp;
            strvec.push_back(strtemp);
            strtemp = "";
            continue;
        }
        else if (temp[0] == ' ' || _is_return(temp[0]))
        {
            char token[4096] = {0};
            if (_is_return(temp[strlen(temp)-1])) {
                temp[strlen(temp)-1] = 0;
            }
            int res = _readOneToken(temp, token, sizeof(token));
            if (res == -1) {
                if (strtemp != "") {
                    strvec.push_back(strtemp);
                    strtemp = "";
                }

                memset(temp, 0, sizeof(temp));
                // PAGE xx/xx
                offset = _getOneLine(pstr+index, temp, sizeof(temp));
                if (offset == -1)
                    return -1;
                memset(token, 0, sizeof(token));
                offset = _readOneToken(temp, token, sizeof(token));
                if (strcmp("PAGE", token) != 0)
                    return -1;
                offset += strlen(token);
                memset(token, 0, sizeof(token));
                offset = _readOneToken(temp+offset, token, sizeof(token));
                if (offset == -1)
                    return -1;

                // xx/xx
                unsigned int i = 0;
                for (i = 0; i < strlen(token); i++) {
                    if (token[i] == '/') {
                        break;
                    }
                }
                if (i == strlen(token))
                    return -1;

                token[i] = 0;
                int curpage = atoi(token);
                int topage = atoi(token+i+1);

                if (curpage > 1 && topage > curpage)
                    *pagetype |= en_page_before;

                if (topage > curpage)
                    *pagetype |= en_page_next;

                break;
            }
        }
        strtemp += temp;
    }

    if (strtemp != "")
    {
        strvec.push_back(strtemp);
    }

    *pone = (char**)malloc(sizeof(void*)*strvec.size());
    for (unsigned int i = 0; i < strvec.size(); i++)
    {
        (*pone)[i] = (char*)malloc(strvec[i].length()+1);
        strcpy((*pone)[i], strvec[i].c_str());
    }

    return strvec.size();
}

int CETermString::_nfddealonerecord( const char* pstr, nfdpriceinfo* pinfo, int* pos )
{
	char buf[4096] = {0};
	int offset = _getOneLine(pstr, buf, sizeof(buf));
	if (_is_return(buf[strlen(buf)-1]))
		buf[strlen(buf)-1] = 0;

    if (offset != -1) {
        if (_is_return(buf[strlen(buf)-1]))
            buf[strlen(buf)-1] = 0;

        char token[4096] = {0};
        /*int res =*/ _readOneToken(buf, token, sizeof(token));
        if (strncmp(token, "AP", 2) == 0) {
            pinfo->advanceday = atoi(token+2);

            memset(buf, 0, sizeof(buf));
            offset = _getOneLine(pstr+offset, buf, sizeof(buf));
        }
    }

	for (int i = 0; i < 9; i++) {
		char token[4096] = {0};
		int res = _readOneToken(buf+pos[i], token, sizeof(token));
		if (res != 0)
			continue;

		if (i == 1)
			strcpy(pinfo->aircompany, token);
		else if (i == 2)
			pinfo->owprice = atoi(token);
		else if (i == 3)
			pinfo->rtprice = atoi(token);
		else if (i == 5)
			strcpy(pinfo->seattype, token);
		else if (i == 7) {
			token[7] = 0;
			strcpy(pinfo->startdata, token);
			strcpy(pinfo->enddata, token+8);
		}
	}

	return 0;
}

bool CETermString::_nfdgetdepdes( const char* pstr, char* pdep, char* pdes )
{
	int pos = 0;
	char buf[4096] = {0};
	int offset = _getOneLine(pstr, buf, sizeof(buf));
	if (offset == -1)
		return false;

	char token[4096] = {0};
	int res = _readOneToken(buf, token, sizeof(token));
	if (strncmp(">NFD", token, 4) != 0)
		return false;

	pos += offset;
	memset(buf, 0, sizeof(buf));
	offset = _getOneLine(pstr+pos, buf, sizeof(buf));

	int tpos = 0;
	memset(token, 0, sizeof(token));
	res = _readOneToken(buf, token, sizeof(token));
	if (res == -1 || strcmp("NETT", token) != 0)
		return false;

	tpos += res + strlen(token);
	
	memset(token, 0, sizeof(token));
	res = _readOneToken(buf+tpos, token, sizeof(token));
	if (res == -1 || strcmp("FARE", token) != 0)
		return false;

	tpos += res + strlen(token);
	
	memset(token, 0, sizeof(token));
	res = _readOneToken(buf+tpos, token, sizeof(token));
	if (res == -1 || strcmp("-", token) != 0)
		return false;

	tpos += res + strlen(token);
	
	memset(token, 0, sizeof(token));
	res = _readOneToken(buf+tpos, token, sizeof(token));
	if (strlen(token) != 6)
		return false;

	memcpy(pdep, token, 3);
	memcpy(pdes, token+3, 3);

	return true;
}

int CETermString::DealNFDStr( const char* pstr, nfdpriceinfo*** pinfo, const char* pdep, const char* pdes, int *pagetype )
{
	char buf[4096] = {0};
	int offset = _getOneLine(pstr, buf, sizeof(buf));
	
	int pos[9] = {0};
	if (!_nfdgettablepos(buf, pos, 9)) 
		return -1;

	char** precord = NULL;
	int count = _nfdgetrecords(pstr+offset, &precord, pagetype);
	if (count <= 0)
		return -1;

	*pinfo = (nfdpriceinfo**)malloc(sizeof(nfdpriceinfo*)*count);
	memset(*pinfo, 0, sizeof(nfdpriceinfo*)*count);

	for (int i = 0; i < count; i++) {
		(*pinfo)[i] = (nfdpriceinfo*)malloc(sizeof(nfdpriceinfo));
		memset((*pinfo)[i], 0, sizeof(nfdpriceinfo));
		memcpy((*pinfo)[i]->depature, pdep, 3);
		memcpy((*pinfo)[i]->destination, pdes, 3);
		_nfddealonerecord(precord[i], (*pinfo)[i], pos);
	}

	_freerecords(precord, count);

	return count;
}

void CETermString::FreeNFDRes( nfdpriceinfo** pinfo, int count )
{
	for (int i = 0; i < count; i++) {
		if (pinfo[i] != NULL) {
			free(pinfo[i]);
			pinfo[i] = NULL;
		}
	}
	free(pinfo);
}

int CETermString::_fdgetrecords( const char* pstr, char*** pone, int* pagetype )
{
	*pagetype = en_page_single;
	int index = 0;
	std::vector<std::string> strvec;
//	int count = 0;
	std::string strtemp = "";
	while(1) {
		char temp[4096] = {0};
		int offset = _getOneLine(pstr+index, temp, sizeof(temp));
		if (offset == -1)
			break;
		index += offset;
		
		if (temp[0] >= '0' && temp[0] <= '9' && temp[1] >= '0' && temp[1] <= '9') {
			if (strtemp != "") {
				strvec.push_back(strtemp);
				strtemp = "";
			}
		}
		else if (temp[0] == ' ' || _is_return(temp[0]))
		{
			char token[4096] = {0};
			if (_is_return(temp[strlen(temp)-1])) {
				temp[strlen(temp)-1] = 0;
			}
			int res = _readOneToken(temp, token, sizeof(token));
			if (res == -1) {
                if (strtemp != "") {
				    strvec.push_back(strtemp);
				    strtemp = "";
                }
				
				memset(temp, 0, sizeof(temp));
				// PAGE xx/xx
				offset = _getOneLine(pstr+index, temp, sizeof(temp));
				if (offset == -1)
					return -1;
				memset(token, 0, sizeof(token));
				offset = _readOneToken(temp, token, sizeof(token));
				if (strcmp("PAGE", token) != 0)
					return -1;
				offset += strlen(token);
				memset(token, 0, sizeof(token));
				offset = _readOneToken(temp+offset, token, sizeof(token));
				if (offset == -1)
					return -1;
				
				// xx/xx
				unsigned int i = 0;
				for (i = 0; i < strlen(token); i++) {
					if (token[i] == '/') {
						break;
					}
				}
				if (i == strlen(token))
					return -1;
				
				token[i] = 0;
				int curpage = atoi(token);
				int topage = atoi(token+i+1);
				
				if (curpage > 1 && topage > curpage)
					*pagetype |= en_page_before;
				
				if (topage > curpage)
					*pagetype |= en_page_next;
				
				break;
			}
		}
		strtemp += temp;
	}
	
	if (strtemp != "")
	{
		strvec.push_back(strtemp);
	}
	
	*pone = (char**)malloc(sizeof(void*)*strvec.size());
	for (unsigned int i = 0; i < strvec.size(); i++)
	{
		(*pone)[i] = (char*)malloc(strvec[i].length()+1);
		strcpy((*pone)[i], strvec[i].c_str());
	}
	
	return strvec.size();
}

int CETermString::_fddealonerecord( const char* pstr, fdpriceinfo* pinfo )
{
	char buf[4096] = {0};
	strcpy(buf, pstr);

	if (_is_return(buf[strlen(buf)-1]))
		buf[strlen(buf)-1] = 0;

	int pos = 0;
	_fd_status status = en_fd_linenu;
	while(1) {
		char token[4096] = {0};
		int offset = _readOneToken(buf+pos, token, sizeof(token)); 
		if (offset == -1)
			break;

		switch(status) {
		case en_fd_linenu:
			{
				if (token[0] < '0' || token[0] > '9' || token[1] < '0' || token[1] > '9')
					return -1;
				status = en_fd_company;
			}
			break;
		case en_fd_company:
			{
				if (strlen(token) < 4)
					return -1;
				memcpy(pinfo->aircompany, token, 2);
				//strcpy(pinfo->seattype, token+3);
				status = en_fd_null1;
			}
			break;
		case en_fd_null1:
			{
				if (strncmp(token, "/", 1) != 0)
					return -1;

                status = en_fd_owprice;

                if (strlen(token) > 2) {
                    token[1] = 0;
                }

                char temp[4096] = {0};
                int res = _readOneToken(buf+pos+offset+strlen(token), temp, sizeof(temp));
                if (res > 4)
                    status = en_fd_rtprice;
			}
			break;
		case en_fd_owprice:
			{
                if (strlen(token) > 8) {
                    for (unsigned int i = 0; i < strlen(token); i++)
                    {
                        if (token[i] == '=') {
                            token[i] = 0;
                            break;
                        }
                    }
                }
				pinfo->owprice = atoi(token);
				status = en_fd_rtprice;
			}
			break;
		case en_fd_rtprice:
			{
				pinfo->rtprice = atoi(token);	
				status = en_fd_seattype;
                for(unsigned int i = 0; i < strlen(token); i++) {
                    if (token[i] == '/') {
                        token[i] = 0;
                        break;
                    }
                }
			}
			break;
        case en_fd_seattype:
            {
                 if (strlen(token) != 5) {
                     return -1;
                 }
                 strncpy(pinfo->seattype, token+1, 1);
                 strncpy(pinfo->physeat, token+3, 1);
                 status = en_fd_null2;
            }
            break;
		case en_fd_null2:
			{
				if (strcmp(token, "/") != 0)
					return -1;
				status = en_fd_null3;
			}
			break;
		case en_fd_null3:
			{
				if (strcmp(token, ".") != 0)
					return -1;
				status = en_fd_start;
			}
			break;
		case en_fd_start:
			{
				if (strlen(token) != 8)
					return -1;
				strcpy(pinfo->startdata, token+1);
				status = en_fd_end;
			}
			break;
        case en_fd_end:
            {
                if (offset > 2) {
                    token[0] = 0;
                }
                else {
                    strncpy(pinfo->enddata, token, 7);
                    token[7] = 0;
                }
                status = en_fd_pricecal;
            }
            break;
        case en_fd_pricecal:
            {
                if (strlen(token) > 2 && strlen(token) < 7) {
                    strcpy(pinfo->pricecal, token+1);
                }
                else {
                    return -1;
                }
                status = en_fd_null;
            }
            break;
		default:
			{
			}
		}
		offset += strlen(token);
		pos += offset;
	}
	return 0;
}

bool CETermString::_fdgetdepdes( const char* pstr, char* pdep, char* pdes, int* pdistance )
{
	int pos = 0;
	char buf[4096] = {0};
	int offset = _getOneLine(pstr, buf, sizeof(buf));
	if (offset == -1)
		return false;

	char token[4096] = {0};
	int res = _readOneToken(buf, token, sizeof(token));
	if (res == -1)
		return false;

	if (strncmp(">PFD", token, 4) != 0)
		return false;

	pos += offset;
	memset(buf, 0, sizeof(buf));
	offset = _getOneLine(pstr+offset, buf, sizeof(buf));
	if (offset == -1)
		return false;

	pos = 0;
	memset(token, 0, sizeof(token));
	offset = _readOneToken(buf, token, sizeof(token));
	if (offset == -1)
		return false;
	offset += strlen(token);
	pos += offset;

	if (strncmp("FD:", token, 2) != 0)
		return false;

	memcpy(pdep, token+3, 3);
	memcpy(pdes, token+6, 3);

	memset(token, 0, sizeof(token));
	offset = _readOneToken(buf+pos, token, sizeof(token));
	if (offset == -1)
		return false;
	offset += strlen(token);
	pos += offset;

	if (strcmp("/CNY", token) != 0)
		return false;
	
	memset(token, 0, sizeof(token));
	offset = _readOneToken(buf+pos, token, sizeof(token));
	if (offset == -1)
		return false;
	offset += strlen(token);
	pos += offset;
	
	if (strcmp("/TPM", token) != 0)
		return false;

	memset(token, 0, sizeof(token));
	offset = _readOneToken(buf+pos, token, sizeof(token));
	if (offset == -1)
		return false;
	offset += strlen(token);
	pos += offset;
	
	*pdistance = atoi(token);

	return true;
}

int CETermString::DealFDStr( const char* pstr, fdpriceinfo*** pinfo, const char* pdep, const char* pdes, int distance, int *pagetype )
{
	char** precord = NULL;
	int count = _fdgetrecords(pstr, &precord, pagetype);
	if (count <= 0)
		return -1;
	
	*pinfo = (fdpriceinfo**)malloc(sizeof(fdpriceinfo*)*count);
	memset(*pinfo, 0, sizeof(fdpriceinfo*)*count);
	
	for (int i = 0; i < count; i++) {
		(*pinfo)[i] = (fdpriceinfo*)malloc(sizeof(fdpriceinfo));
		memset((*pinfo)[i], 0, sizeof(fdpriceinfo));
		memcpy((*pinfo)[i]->depature, pdep, 3);
		memcpy((*pinfo)[i]->destination, pdes, 3);
		(*pinfo)[i]->distance = distance;
		if (-1 == _fddealonerecord(precord[i], (*pinfo)[i])) {
            _freerecords(precord, i+1);
            return -1;
        }
	}
	
	_freerecords(precord, count);
	
	return count;
}

void CETermString::FreeFDRes( fdpriceinfo** pinfo, int count )
{
	for (int i = 0; i < count; i++) {
		if (pinfo[i] != NULL) {
			free(pinfo[i]);
			pinfo[i] = NULL;
		}
	}
	free(pinfo);
}

bool CETermString::_fsijudgement( const char* pstr, int* plinebegin )
{
	int pos = 0;
	int offset = 0;
	char buf[4096] = {0};
	offset = _getOneLine(pstr, buf, sizeof(buf));
	if (offset == -1) {
		return false;
	}
	pos += offset;
	char token[4096] = {0};
	offset = _readOneToken(buf, token, sizeof(token));
	if (offset == -1) {
		return false;
	}
	if (strncmp("FSI/", token, 4) != 0)
		return false;

	int lineidx = 1;
	while (1) {
		memset(buf, 0, sizeof(buf));
		offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		if (offset == -1)
			break;
		if (!_fsiadapterinfo(buf))
			break;
		pos += offset;
		lineidx++;
	}

	if (lineidx == 1)
	{
		*plinebegin = 0;
		return false;
	}

	*plinebegin = lineidx;

	return true;	
}

//S CA   175L24JUL PVG1935>0810SYD0X    330
bool CETermString::_fsiadapterinfo( const char* pstr )
{
	int pos = 0;
	_fsi_status status = en_fsi_sword;
	while(1) {
		char token[4096] = {0};
		int offset = _readOneToken(pstr+pos, token, sizeof(token));
		if (offset == -1)
			break;

		switch(status) {
		case en_fsi_sword:
			{
				if (strcmp("S", token) != 0)
					return false;
				status = en_fsi_company;
			}
			break;
		case en_fsi_company:
			{
				if (strlen(token) != 2)
					return false;
				status = en_fsi_airnumber;
			}
			break;
		case en_fsi_airnumber:
			{
				if (strlen(token) < 9)
					return false;
				status = en_fsi_start;
			}
			break;
		case en_fsi_start:
			{
				if (strlen(token) == 17)
					status = en_fsi_plane;
				else if (strlen(token) == 7)
					status = en_fsi_end;
				else
					return false;					
			}
			break;
		case en_fsi_end:
			{
				if (strlen(token) != 9)
					return false;
				status = en_fsi_plane;
			}
			break;
		case en_fsi_plane:
			{
				if (strlen(token) != 3)
					return false;
				status = en_fsi_null;
			}
			break;
		default:
			{
			}
		}

		pos += offset+strlen(token);
	}
	return true;
}

int CETermString::_fsigetrestype( const char* pstr )
{
	int ret = -1;
	int pos = 0;
	while (1) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr + pos, buf, sizeof(buf));
		if (offset == -1) {
			break;
		}
		
		char token[4096] = {0};
		/*int res =*/ _readOneToken(buf, token, sizeof(token));
		if (strlen(token) != 2 || token[0] < '0' || token[0] > '9' || token[1] < '0' || token[1] > '9') {
			if (strcmp("*NO", token) == 0)
				ret = 0;			
			break;
		}

		ret = atoi(token);

		pos += offset;
	}
	return ret;
}

int CETermString::_fsqgettripinfo( const char* pstr, fsqpriceinfo* pinfo )
{
	int pos = 0;
	// line information
	while (1) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		if (offset == -1)
			break;
		
		if (_is_return(buf[strlen(buf)-1]))
			buf[strlen(buf)-1] = 0;
		
		int res = _fsqgetilinetype(buf);
		if (res == -1)
			break;

		if (res == 1) {
			char token[4096] = {0};
			_readOneToken(buf, token, sizeof(token));
			pinfo->pline = (fsqlinedata*)realloc(pinfo->pline, ++pinfo->linecount * sizeof(fsqlinedata));
			memset(pinfo->pline+pinfo->linecount-1, 0, sizeof(fsqlinedata));
			strncpy(pinfo->pline[pinfo->linecount-1].areastart, token, 3);
		}
		else if (res == 2) {
			if (-1 == _fsqdeal2type(buf, pinfo))
				return -1;
		}
		
		pos += offset;
	}
	
	return pos;	
}

bool CETermString::_fsipriceflag( const char* pstr )
{
	int pos = 0;
	while(1) {
		char token[4096] = {0};
		int offset = _readOneToken(pstr+pos, token, sizeof(token));
		if (offset == -1)
		{
			return false;
		}
		pos += offset+strlen(token);
		if (strcmp(token, "*ATTN") == 0) {
			/*int offpos = strlen(token) + offset;*/
			memset(token, 0, sizeof(token));
			offset = _readOneToken(pstr+pos, token, sizeof(token));
			if (offset == -1)
			{
				return false;
			}
			if (strcmp(token, "PRICED") == 0) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	return false;
}

// return -1 error; 1 start new line; 2 end by before
int CETermString::_fsqgetilinetype( const char* pstr )
{
	int pos = 0;

	char token[4096] = {0};
	int offset = _readOneToken(pstr, token, sizeof(token));
	
	if (offset == -1)
		return -1;

	int type = 0;

	if (strlen(token) == 4) {
		if (token[0] != 'X')
			return -1;
		type = 1;
	}
	else {
		if (strlen(token) != 3) {
			return -1;
		}
	}

	if (strcmp("FARE", token) == 0)
	{
		return -1;
	}

	pos += offset + strlen(token);

	memset(token, 0, sizeof(token));
	offset = _readOneToken(pstr+pos, token, sizeof(token));

	if (offset == -1 && type != 1)
		return 1;
	else if (offset == -1)
		return -1;

	if (strncmp(pstr+pos+offset, "S U R F A C E", 13) == 0)
		return 1;

	pos += offset + strlen(token);
	memset(token, 0, sizeof(token));
	offset = _readOneToken(pstr+pos, token, sizeof(token));

	if (offset == -1)
		return -1;

	if (strncmp("NVB", token, 3) != 0)
		return -1;
	
	pos += offset + strlen(token);
	memset(token, 0, sizeof(token));
	offset = _readOneToken(pstr+pos, token, sizeof(token));
	
	if (offset == -1)
		return -1;
	
	if (strncmp("NVA", token, 3) != 0)
		return -1;

	return 2;
}

// XATL QKWTZMAR        NVB10MAY NVA10MAY 2PC                                      
//  BOS QKWTZMAR        NVB10MAY NVA10MAY 2PC
int CETermString::_fsqdeal2type( const char* pstr, fsqpriceinfo* pinfo )
{
	int pos = 0;
	_fsq_status status = en_fsq_area;
	while (1) {
		char token[4096] = {0};
		int offset = _readOneToken(pstr+pos, token, sizeof(token));
		if (offset == -1) {
			if (status != en_fsq_null && status != en_fsq_seat)
				return -1;
			else
				break;
		}
		switch(status) {
		case en_fsq_area:
			{
				int start = 0;
				if (strlen(token) == 4) {
					if (token[0] != 'X')
						return -1;
					start = 1;
				}
				else {
					if (strlen(token) != 3) {
						return -1;
					}
				}
				if (pinfo->linecount < 1)
				{
					return -1;
				}
				if (strlen(pinfo->pline[pinfo->linecount-1].areaend) != 0) {
					pinfo->pline = (fsqlinedata*)realloc(pinfo->pline, ++pinfo->linecount * sizeof(fsqlinedata));
					memset(pinfo->pline+pinfo->linecount-1, 0, sizeof(fsqlinedata));
					strcpy(pinfo->pline[pinfo->linecount-1].areastart, pinfo->pline[pinfo->linecount-2].areaend);
					strncpy(pinfo->pline[pinfo->linecount-1].areaend, token+start, 3);
				}
				else {
					strncpy(pinfo->pline[pinfo->linecount-1].areaend, token+start, 3);
				}
				status = en_fsq_seat;
			}
			break;
		case en_fsq_seat:
			{
				strncpy(pinfo->pline[pinfo->linecount-1].seattype, token, 1);
				status = en_fsq_nvb;
			}
			break;
		case en_fsq_nvb:
			{
				if (strlen(token) != 3 && strlen(token) != 8)
					return -1;
				strcpy(pinfo->pline[pinfo->linecount-1].datanvb, token+3);
				status = en_fsq_nva;
			}
			break;
		case en_fsq_nva:
			{	
				if (strlen(token) != 3 && strlen(token) != 8)
					return -1;
				strcpy(pinfo->pline[pinfo->linecount-1].datanva, token+3);
				status = en_fsq_package;
			}
			break;
		case en_fsq_package:
			{
				if (strlen(token) != 0 && strlen(token) != 3)
					return -1;
				strcpy(pinfo->pline[pinfo->linecount-1].packageinfo, token);
				status = en_fsq_null;
			}
			break;
		default:
			{
			}
		}
		pos += offset + strlen(token);
	}
	return 0;
}

int CETermString::_fsqgetpriceinfo( const char* pstr, fsqpriceinfo* pinfo )
{
	int pos = 0;

//	int total = 0;
//	int tax	= 0;
//	int qvalue = 0;
	int status = en_fsq_fare;
	bool bother = false;
//	int oprice = 0;
	bool bitfare = false;
	int price = 0;

	while(1) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		if (offset == -1)
			break;

		if (_is_return(buf[strlen(buf)-1])) {
			buf[strlen(buf)-1] = 0;
		}
		
		switch (status)
		{
		case en_fsq_fare:
			{
				char token[4096] = {0};
				int tpos = 0;
				int toff = _readOneToken(buf, token, sizeof(token));
				if (toff == -1)
					return -1;

				if (strcmp("FARE", token) != 0)
					return -1;

				tpos += strlen(token)+toff;
				memset(token, 0, sizeof(token));
				toff = _readOneToken(buf+tpos, token, sizeof(token));
				if (toff == -1)
				{
					return -1;
				}
				if (strcmp(token, "CNY") != 0) {
					if (strlen(token) != 3)
						return -1;
					bother = true;
				}

				if (bother){
					tpos += strlen(token)+toff;
					memset(token, 0, sizeof(token));
					toff = _readOneToken(buf+tpos, token, sizeof(token));
					if (toff == -1 || atoi(token) <= 0)
					{
						return -1;
					}
					
					tpos += strlen(token)+toff;
					memset(token, 0, sizeof(token));
					toff = _readOneToken(buf+tpos, token, sizeof(token));
					if (toff == -1 || strcmp(token, "EQUIV") != 0)
						return -1;

					tpos += strlen(token)+toff;
					memset(token, 0, sizeof(token));
					toff = _readOneToken(buf+tpos, token, sizeof(token));
					if (toff == -1 || strcmp(token, "CNY") != 0)
						return -1;

				}
				tpos += strlen(token)+toff;
				memset(token, 0, sizeof(token));
				toff = _readOneToken(buf+tpos, token, sizeof(token));
				if (toff == -1)
				{
					return -1;
				}
				
				price = atoi(token);
				if (price <= 0)
					return -1;
				
				tpos += strlen(token)+toff;
				memset(token, 0, sizeof(token));
				toff = _readOneToken(buf+tpos, token, sizeof(token));
				if (toff == -1)
				{
					status = en_fsq_tax;
					break;
				}
				if (strncmp(buf+toff+tpos, "*IT FARE*", 9) == 0)
				{
					bitfare = true;
					pinfo->itprice = price;
				}
				else
					return -1;

				status = en_fsq_tax;
			}
			break;
		case en_fsq_tax:
			{
				pinfo->taxprice = 0;

				char token[4096] = {0};
				int tpos = 0;
				int toff = _readOneToken(buf, token, sizeof(token));
				if (toff == -1 || strcmp("TAX", token) != 0)
					return -1;
				
				while(1) {
					tpos += strlen(token)+toff;
					memset(token, 0, sizeof(token));
					toff = _readOneToken(buf+tpos, token, sizeof(token));
					if (toff == -1 || strcmp("CNY", token) != 0)
					{
						break;;
					}

					tpos += strlen(token)+toff;
					memset(token, 0, sizeof(token));
					toff = _readOneToken(buf+tpos, token, sizeof(token));
					if (toff == -1)
					{
						break;;
					}
					pinfo->taxprice += atoi(token);
				}

				status = en_fsq_total;	
			}
			break;
		case en_fsq_total:
			{
				char token[4096] = {0};
				int tpos = 0;
				int toff = _readOneToken(buf, token, sizeof(token));
				if (toff == -1 || strcmp("TOTAL", token) != 0)
					return -1;
				
				tpos += strlen(token)+toff;
				memset(token, 0, sizeof(token));
				toff = _readOneToken(buf+tpos, token, sizeof(token));
				if (toff == -1 || strcmp("CNY", token) != 0)
					return -1;

				if (!bitfare) {
					tpos += strlen(token)+toff;
					memset(token, 0, sizeof(token));
					toff = _readOneToken(buf+tpos, token, sizeof(token));
					if (toff == -1 || atoi(token) <= 0)
					{
						return -1;
					}
					price = atoi(token);
				}
				
				status = en_fsq_cale;
			}
			break;
		case en_fsq_cale:
			{
				bool bwhole = false;
				while(1) {
					int i = strlen(buf)-1;
					for (; i >=0; i--) {
						if (buf[i] == ' ') {
							buf[i] = 0;
						}
						else
							break;
					}
					for (unsigned i = 0 ; i < strlen(buf)-3; i++)
					{
//						const char* ptes = buf+i;
						if (strncmp(buf+i, "ROE", 3) == 0) {
							for (unsigned int j = i+3; j < strlen(buf); j++) {
								if (buf [j] == '.' ) {
									if (j+7 == strlen(buf)) {
										bwhole = true;
										break;
									}
								}
							}
						}
					}
					
					if (!bwhole)
					{
						pos += offset;
						char temp[4096] = {0};
						offset = _getOneLine(pstr+pos, temp, sizeof(temp));
						if (offset == -1)
							return -1;

						if (_is_return(temp[strlen(temp)-1]))
							temp[strlen(temp)-1] = 0;
						
						strcat(buf, temp);
					}
					else
						break;
				}

				_fdqcalculateinfo(buf, pinfo);
				
				if (bother) {
					status = en_fsq_rate;
				}
				else {
					if (!bitfare) {
						pinfo->itprice = _intaddten(pinfo->itprice);
						pinfo->itprice += pinfo->qprice;
						pinfo->itprice += pinfo->taxprice;
					}
					status = en_fsq_value;
				}
			}
			break;
		case en_fsq_rate:
			{
				if (strncmp("RATE USED", buf, 9) != 0) {
					return -1;
				}
				double troe = atof(buf+15);
				
				pinfo->qprice = _floataddone((float)pinfo->qprice*troe);
				pinfo->itprice = _floataddone((float)pinfo->itprice*troe);

				if (!bitfare) {
					pinfo->itprice = _intaddten(pinfo->itprice);
					pinfo->itprice += pinfo->taxprice + pinfo->qprice;
				}

				for (int i = 0; i < pinfo->pricecount; i++) {
					pinfo->pprice[i].price *= troe;
				}
					
				
				status = en_fsq_value;
			}
			break;
		case en_fsq_value:
			{
				if (strncmp(buf, "TKT/TL", 6) == 0) {
					trimright(buf);
					if (strlen(buf) == 18) {
						strncpy(pinfo->valdata, buf+6, 7);
						strncpy(pinfo->valtime, buf+14, 4);
					}
					else if (strlen(buf) == 13) {
						strncpy(pinfo->valdata, buf+6, 7);
					}
					else
						return -1;
				}
			}
			break;
		}
		pos += offset;
	}
	return 0;
}

int CETermString::_fdqcalculateinfo( const char* pstr, fsqpriceinfo* pinfo )
{
	std::list<std::string> listtarget;
	enum {
		en_type_null,
		en_type_word,
		en_type_number,
	};
	int type = en_type_null;
	std::string strtemp = "";
	unsigned int i;
	for (i = 7 ; i < strlen(pstr)+1; i++) {
		if (type == en_type_null)
		{
			if (_is_number(pstr[i]))
				type = en_type_number;
			else if (_is_word(pstr[i]))
				type = en_type_word;
			else
				continue;
			strtemp += pstr[i];
			continue;
		}
		if (type == en_type_number && _is_number(pstr[i])) {
			strtemp += pstr[i];
		}
		else if (type == en_type_word && _is_word(pstr[i])) {
			strtemp += pstr[i];
		}
		else {
			if (strtemp == "X" && pstr[i] == '/') {
				strtemp = "";
				type = en_type_null;
				continue;
			}
			else if (strtemp == "M" && pstr[i] == '/') {
				strtemp += pstr[i];
			}
			else if (strtemp == "Q" && _is_number(pstr[i])) {
				strtemp += pstr[i];
				type = en_type_number;
			}			
			else {
				if (strtemp != "M"/* && strtemp.length() != 2*/)
					listtarget.push_back(strtemp);
				i--;
				strtemp = "";
				type = en_type_null;
			}
		}
	}
	if (listtarget.size() < 6)
		return -1;

	std::string strkey = *(--listtarget.end());
	if (!_is_number(strkey.c_str()))
		return -1;

	double roe = atof(strkey.c_str());

	std::vector<std::string> vectar;

	double qvalue = 0.0;

	while (!listtarget.empty()) {
		std::string strkey = *listtarget.begin();
		if (strkey == "NUC" || strkey == "END")
			break;
		if (strkey.length() == 3) {
			if (vectar.size()%3 == 0) 
				vectar.push_back(strkey);
			else if (vectar.size()%3 == 1) {
				if ((*(++listtarget.begin())).length() != 2)
					vectar.push_back(strkey);
			}
		}
		else if (strkey.length() == 2 && vectar.size()%3 == 0) {
			vectar.push_back(vectar[vectar.size()-2]);
			continue;
		}
		else if (strkey.length() == 2 && vectar.size()%3 == 1)
		{
		}
		else if ((strkey == "M/IT" || _is_number(strkey.c_str())) && vectar.size()%3 == 2) {
			vectar.push_back(strkey);
		}
		else if (strkey.c_str()[0] == 'Q' && vectar.size()%3 == 2 && _is_number(strkey.c_str()+1)) {
			qvalue += atof(strkey.c_str()+1);
		}
		else {
			return -1;
		}
		listtarget.pop_front();
	}

	if (vectar.size()%3 != 0)
		return -1;

	unsigned int count = vectar.size()/3;

	pinfo->pricecount = count;
	pinfo->pprice = (fsqpricedata*)malloc(sizeof(fsqpricedata)*count);

	int price = 0.0;
	for (i = 0; i < count; i++) {
		strcpy(pinfo->pprice[i].areastart, vectar[i*3].c_str());
		strcpy(pinfo->pprice[i].areaend, vectar[i*3+1].c_str());
		pinfo->pprice[i].price = _floataddone(atof(vectar[i*3+2].c_str())*roe);
		price += _floataddone(atof(vectar[i*3+2].c_str())*roe);
	}

	if (pinfo->itprice == 0)
		pinfo->itprice = price;

	pinfo->qprice = _floataddone(qvalue*roe);

	return 0;
}

bool CETermString::_is_number( char ch )
{
	if (ch == '.')
		return true;
	if (ch < '0' || ch > '9')
		return false;
	return true;
}

bool CETermString::_is_number( const char* str )
{
	if (strlen(str) == 0)
		return false;
	
	for (unsigned int i = 0 ; i < strlen(str); i++) {
		if (!_is_number(str[i]))
			return false;
	}
	return true;
}

bool CETermString::_is_word( char ch )
{
	if (ch >= 'A' && ch <= 'Z')
		return true;
	if (ch >= 'a' && ch <= 'z')
		return true;
	return false;
}

bool CETermString::_is_word( const char* str )
{
	if (strlen(str) == 0)
		return false;

	for (unsigned int i = 0 ; i < strlen(str); i++) {
		if (!_is_word(str[i]))
			return false;
	}
	return true;
}

int CETermString::_floataddone( float f )
{
	int res = (int)f;
	if (f - res > 0.0)
		res++;
	return res;
}

int CETermString::_intaddten( int n )
{
	return (n/10)*10 + (n%10!=0)*10;
}

int CETermString::DealFSIStr( const char* pstr, fsqpriceinfo* pinfo )
{
	int pos = 0;
	
	int line = _fsigetrestype(pstr+pos);
	if (line != 1)
		return line;
	
	while(line--) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		pos += offset;
	}
	
	while(1) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		if (offset == -1)
			return -1;
		
		pos += offset;
		
		if (_is_return(buf[strlen(buf)-1]))
			buf[strlen(buf)-1] = 0;
		
		if (_fsipriceflag(buf))
			break;
	}
	if (strlen(pstr + pos) <= 0)
		return -1;
	
	int off = _fsqgettripinfo(pstr + pos, pinfo);
	if (off == -1)
		return -1;
	
	if (-1 == _fsqgetpriceinfo(pstr+pos+off, pinfo))
		return -1;
	
	return 0;
}

void CETermString::FreeFSIRes( fsqpriceinfo* pinfo )
{
	if (pinfo != NULL) {
		if (pinfo->pline != NULL) {
			free(pinfo->pline);
		}
		if (pinfo->pprice != NULL) {
			free(pinfo->pprice);
		}
	}
}

int CETermString::DealFSQStr( const char* pstr, fsqpriceinfo* pinfo )
{
	int off = _fsqgettripinfo(pstr, pinfo);
	if (off == -1)
		return -1;
	
	if (-1 == _fsqgetpriceinfo(pstr+off, pinfo))
		return -1;
	
	return 0;
}

bool CETermString::_patjudgement( const char* pstr )
{
//	int pos = 0;
	char buf[4096] = {0};
	int offset = _getOneLine(pstr, buf, sizeof(buf));
	if (offset == -1)
		return false;

	if (strncmp(buf, ">PAT:A", 6) == 0)
		return true;

	return false;
}

int CETermString::DealPatStr( const char* pstr, patpriceinfo** pinfo )
{
	int pos = 0;
	*pinfo = NULL;

	int count  = 0;

	while (1) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		if (offset == -1)
			break;

		pos += offset;
		if (_is_return(buf[strlen(buf)-1]))
			buf[strlen(buf)-1] = 0;

		*pinfo = (patpriceinfo*)realloc(*pinfo, sizeof(patpriceinfo)*++count);

		_pat_status status = en_pat_num;
		int tpos = 0;
		while(1) {
			char token[4096] = {0};
			int toff = _readOneToken(buf+tpos, token, sizeof(token));
			if (toff == -1)
				break;
			switch (status)
			{
			case en_pat_num:
				{
					if (!_is_number(token))
						return -1;
					status = en_pat_seat;
				}
				break;
			case en_pat_seat:
				{
					status = en_pat_fare;
				}
				break;
			case en_pat_fare:
				{
					if (strncmp("FARE:CNY", token, 8) != 0)
						return -1;

					(*pinfo)[count-1].fare = atoi(token+8);

					status = en_pat_tax;
				}
				break;
			case en_pat_tax:
				{
					if (strncmp("TAX:CNY", token, 7) != 0)
						return -1;

					(*pinfo)[count-1].tax = atoi(token+7);
					status = en_pat_yq;
				}
				break;
			case en_pat_yq:
				{
					if (strncmp("YQ:CNY", token, 6) != 0)
						return -1;
					(*pinfo)[count-1].tax += atoi(token+6);
					status = en_pat_total;
				}
				break;
			case en_pat_total:
				{
					if (strncmp("TOTAL:", token, 6) != 0)
						return -1;
					(*pinfo)[count-1].total = atoi(token+6);
					status = en_pat_null;
				}
				break;
			default:
				break;
			}
			tpos += toff + strlen(token);
		}
		if (status != en_pat_null)
			return -1;

		offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		if (offset == -1)
			return -1;
		pos += offset;
	}

	return count;
}

void CETermString::FreePatRes( patpriceinfo* pinfo )
{
	if (pinfo != NULL)
		free(pinfo);
}

bool CETermString::_is_return( char ch )
{
	if (ch == '\r' || ch == '\n')
		return true;
	return false;
}

bool CETermString::_detrjudgement( const char* pstr )
{
	char buf[4096] = {0};
	int offset = _getOneLine(pstr, buf, sizeof(buf));
	if (offset == -1)
		return false;

	if (strncmp(buf, "DETR:TN/", 7) == 0)
		return true;

	return false;
}

void CETermString::trimleft( char* pstr )
{
	if (pstr == NULL)
		return ;

	char* pstart = pstr;
	for (unsigned int i = 0; i < strlen(pstr); i++) {
		if (pstr[i] == '\r' || pstr[i] == '\n' || pstr[i] == '\t' || pstr[i] == ' ') {
			pstart++;
		}
		else
			break;
	}
	for (unsigned int j = 0; j < strlen(pstart)+1; j++)
	{
		pstr[j] = pstart[j];
	}
}

void CETermString::trimright( char* pstr )
{
	if (pstr == NULL)
		return ;
	for(int  i = strlen(pstr)-1; i >= 0; i--) {
		if (pstr[i] == '\r' || pstr[i] == '\n' || pstr[i] == '\t' || pstr[i] == ' ') {
			pstr[i] = 0;
		}
		else
			break;
	}
}

void CETermString::FreeDetrRes( detrtripinfo* pinfo )
{
	if (pinfo == NULL)
		return;
	if (pinfo->pstatus == NULL)
		return;
	free(pinfo->pstatus);
}

int CETermString::DealDetrStr( const char* pstr, detrtripinfo* pinfo )
{
	int pos = 0;
	int status = en_detr_ticnum;
	while (1) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr+pos, buf, sizeof(buf));

		switch (status)
		{
		case en_detr_ticnum:
			{
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;

				if (strncmp("DETR:TN/", token, 8) != 0)
					return -1;

				int count = 0;
				for (unsigned int i = 8; i < strlen(token) && count < 13; i++) {
					if (_is_number(token[i])) {
						pinfo->ticketnum[count] = token[i];
						count++;
					}
				}
				pinfo->ticketnum[13] = 0;

				status = en_detr_issued;
			}
			break;
		case en_detr_issued:
			{
				if (strncmp("ISSUED BY:", buf, 10) != 0)
					return -1;

				trimright(buf);

				int len = strlen(buf);

				int i;
				for(i = len-1; i >= 0; i--) {
					if (buf[i] == ' ')
						break;
				}
				if (len-1 - i != 5)
				{
					return -1;
 				}
				strcpy(pinfo->tickettype, buf+i+1);

				status = en_detr_e_r;
			}
			break;
		case en_detr_e_r:
			{
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;
				
				if (strcmp("E/R:", token) != 0)
					return -1;
				status = en_detr_tcode;
			}
			break;
		case en_detr_tcode:
			{
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;
				
				if (strcmp("TOUR", token) != 0)
					return -1;
				status = en_detr_passenger;
			}
			break;			
		case en_detr_passenger:
			{
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;

				if (strcmp("PASSENGER:", token) != 0)
					return -1;

				char* pstart = buf + res + strlen(token);
				trimright(pstart);
				trimleft(pstart);
				if (strlen(pstart) >= sizeof(pinfo->passengername))
					return -1;

				strcpy(pinfo->passengername, pstart);

				status = en_detr_exch;
			}
			break;
		case en_detr_exch:
			{
				int tpos = 0;
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;
				
				if (strcmp("EXCH:", token) != 0)
					return -1;

				tpos += res + strlen(token);
				memset(token, 0, sizeof(token));
				res = _readOneToken(buf+tpos, token, sizeof(token));
				if (res == -1)
					return -1;

				if (_is_number(token[0]) && _is_number(token[1]) && _is_number(token[2])) {
					int count = 0;
					for (unsigned int i = 0; i < strlen(token) && count < 13; i++) {
						if (_is_number(token[i])) {
							pinfo->changenum[count] = token[i];
							count++;
						}
					}
					pinfo->changenum[13] = 0;
				}

				status = en_detr_trip;
			}
			break;
		case en_detr_trip:
			{
				char temp[4096] = {0};
				strcat(temp, buf);
				while(1) {
					pos += offset;
					memset(buf, 0, sizeof(buf));
					offset = _getOneLine(pstr+pos, buf, sizeof(buf));
					if (offset == -1)
						return -1;
					
					char token[4096] = {0};
					int res = _readOneToken(buf, token, sizeof(token));
					if (res == -1)
						return -1;

					if (strcmp(token, "FC:") == 0) {
						offset = 0;
						break;
					}
					else {
						strcat(temp, buf);
					}
				}

				if (-1 == _detrgettripinfp(temp, pinfo))
					return -1;
				status = en_detr_fc;
			}
			break;
		case en_detr_fc:
			{
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;
				
				if (strcmp("FC:", token) != 0)
					return -1;
				status = en_detr_trip;
			}
			break;
		case en_detr_fare:
			{
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;
				
				if (strcmp("FARE:", token) != 0)
					return -1;
				status = en_detr_trip;
			}
			break;
		case en_detr_tax:
			{
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;
				
				if (strcmp("TAX:", token) != 0)
					return -1;
				status = en_detr_trip;
			}
			break;
		case en_detr_total:
			{
				char token[4096] = {0};
				int res = _readOneToken(buf, token, sizeof(token));
				if (res == -1)
					return -1;
				
				if (strcmp("TOTAL:", token) != 0)
					return -1;
				status = en_detr_trip;
			}
			break;
		}
		pos += offset;
	}
}

int CETermString::_detrgettripinfp( const char* pstr, detrtripinfo* pinfo )
{

	bool bfirst = true;
	int pos = 0;
	while (1) {
		char buf[4096] = {0};
		int offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		if (offset == -1)
			break;
		
		if (_is_return(buf[strlen(buf)-1]))
			buf[strlen(buf)-1] = 0;

		pos += offset;

		int res = _detrfirstline(buf, pinfo);
		if (res == -1)
			return -1;

		memset(buf, 0, sizeof(buf));
		offset = _getOneLine(pstr+pos, buf, sizeof(buf));
		if (offset == -1)
			break;
		
		if (_is_return(buf[strlen(buf)-1]))
			buf[strlen(buf)-1] = 0;

		if (bfirst) {
			bfirst = false;
			res = _detrsecondline(buf, pinfo);
			if (res == -1)
				return -1;
		}
		
		pos += offset;
	}

	return 0;
}

int CETermString::_detrfirstline( const char* pstr, detrtripinfo* pinfo )
{
	int pos = 0;
	int status = en_detr_timeflag;
	bool blast = false;
	char tempdes[4] = {0};
	while(1) {
		char token[4096] = {0};
		int offset = _readOneToken(pstr+pos, token, sizeof(token));
		if (offset == -1)
			break;

		switch(status) {
		case en_detr_timeflag:
			{
				if (strlen(token) == 1) {
					status = en_detr_des;
				}
				else if (strcmp(token, "TO:") == 0) {
					status = en_detr_des;
					blast = true;
				}
				else {
					return -1;
				}
			}
			break;
		case en_detr_des:
			{
				if (strlen(token) == 3 && blast) {
					if (pinfo->count >= 1) {
						strcpy(pinfo->pstatus[pinfo->count-1].destination, token);
						return 0;
					}
					else
						return -1;
				}
				else if (strlen(token) == 7) {
					strcpy(tempdes, token+4);
				}
				else {
					return -1;
				}
				status = en_detr_company1;
			}
			break;
		case en_detr_company1:
			{
				if (strcmp(token, "VOID") == 0) {
					if (pinfo->count >= 1) {
						strcpy(pinfo->pstatus[pinfo->count-1].destination, tempdes);
						return 0;
					}
					else {
						return -1;
					}
				}
				else {
					pinfo->pstatus = (detrtripstatus*)realloc(pinfo->pstatus, sizeof(detrtripstatus)*(++pinfo->count));
					memset(pinfo->pstatus+pinfo->count-1, 0, sizeof(detrtripstatus));

					strcpy(pinfo->pstatus[pinfo->count-1].company, token);
					strcpy(pinfo->pstatus[pinfo->count-1].depature, tempdes);
					if (pinfo->count >= 2) {
						if (strlen(pinfo->pstatus[pinfo->count-2].destination) == 0) {
							strcpy(pinfo->pstatus[pinfo->count-2].destination, tempdes);
						}
					}
				}
				status = en_detr_company2;
			}
			break;
		case en_detr_company2:
			{
				if (!_is_word(token)) {
					status = en_detr_planenum;
					continue;
				}
				else {
					status = en_detr_planenum;
				}
			}
			break;
		case en_detr_planenum:
			{
				strcpy(pinfo->pstatus[pinfo->count-1].airnum, token);
				status = en_detr_seattype;
			}
			break;
		case en_detr_seattype:
			{
				if (strlen(token) != 1)
					return -1;
				strcpy(pinfo->pstatus[pinfo->count-1].seattype, token);
				status = en_detr_startdata;
			}
			break;
		case en_detr_startdata:
			{
				if (strlen(token) != 5)
					return -1;
				strcpy(pinfo->pstatus[pinfo->count-1].startdata, token);
				status = en_detr_starttime;
			}
			break;
		case en_detr_starttime:
			{
				if (strlen(token) != 4)
					return -1;
				strcpy(pinfo->pstatus[pinfo->count-1].starttime, token);
				status = en_detr_ok;
			}
			break;
		case en_detr_ok:
			{
				status = en_detr_seatdetail;
			}
			break;
		case en_detr_seatdetail:
			{
				status = en_detr_valuedata;
			}
			break;
		case en_detr_valuedata:
			{
				status = en_detr_package;
			}
			break;
		case en_detr_package:
			{
				if (strlen(token) != 3)
					return -1;
				strcpy(pinfo->pstatus[pinfo->count-1].package, token);
				status = en_detr_status;
			}
			break;
		case en_detr_status:
			{
				char temp[4096] = {0};
				strcpy(temp, pstr + pos);
				trimleft(temp);
				trimright(temp);
				if (strlen(temp) > sizeof(pinfo->pstatus[pinfo->count-1].ticstatus))
					return -1;
				strcpy(pinfo->pstatus[pinfo->count-1].ticstatus, temp);
				status = en_detr_null;
			}
			break;
		}
		pos += offset + strlen(token);
	}
	return 0;
}

int CETermString::_detrsecondline( const char* pstr, detrtripinfo* pinfo )
{
	int status = en_detr_airstation1;
	int pos = 0;
	while(1) {
		char token[4096] = {0};
		int offset = _readOneToken(pstr+pos, token, sizeof(token));
		if (offset == -1)
			break;

		switch(status) {
		case en_detr_airstation1:
			{
				if (strlen(token) > 2) {
					status = en_detr_pnr;
					continue;
				}
				else {
					status = en_detr_airstation2;
				}
			}
			break;
		case en_detr_airstation2:
			{
				status = en_detr_pnr;
			}
			break;
		case en_detr_pnr:
			{
				if (strlen(token) != 9)
					return -1;
				strcpy(pinfo->pnrnum, token+3);
				status = en_detr_comnum;
			}
			break;
		case en_detr_comnum:
			{
				if (strlen(token) != 9)
					return -1;
				strncpy(pinfo->aircomnum, token+1, 6);
				status = en_detr_null;
			}
			break;
		}
		pos += offset + strlen(token);
	}
	return 0;
}

int CETermString::DealAVStr( const char* pstr, avtravelInfo*** pinfo, const char* pdep, const char* pdes, int *pagetype )
{
    std::string str = _perdealachstr(pstr);

    char** precord = NULL;
    int count = _avgetrecords(str.c_str(), &precord, pagetype);
    if (count == 0)
        return -1;

    *pinfo = (avtravelInfo**)malloc(sizeof(avtravelInfo*)*count);
    memset(*pinfo, 0, sizeof(avtravelInfo*)*count);

    int idx = 0;

    for (int i = 0; i < count; i++) {
        (*pinfo)[idx] = (avtravelInfo*)malloc(sizeof(avtravelInfo));
        memset((*pinfo)[idx], 0, sizeof(avhtravelInfo));
        if (-1 == _avdealonrecord(precord[idx], (*pinfo)[idx])) {
            free((*pinfo)[idx]);
            (*pinfo)[idx] = NULL;
        }
        else {
            idx++;
        }
    }

    _freerecords(precord, count);
    if (idx == 0) {
        free(*pinfo);
        *pinfo = NULL;
    }

    return idx;
}

int CETermString::_avdealonrecord( const char* pstr, avtravelInfo* pinfo )
{
    int pos = 0;
    int idx = 0;
    while (1) {
        char buf[4096] = {0};
        int offSet = 0;
        offSet = _getOneLine(pstr+pos, buf, sizeof(buf));
        if (offSet == -1) {
            if (strlen(pinfo->destination) == 0 && pinfo->pinfo != NULL && pinfo->count > 0)
            {
                strcpy(pinfo->destination, (pinfo->pinfo+pinfo->count-1)->areaend);
            }
            break;
        }
        pos += offSet;

        pinfo->pinfo = (avInfo*)realloc(pinfo->pinfo , sizeof(avInfo)*(pinfo->count+1));
        memset(pinfo->pinfo+pinfo->count, 0, sizeof(avInfo));
        pinfo->pinfoex = (avInfoEx*)realloc(pinfo->pinfoex, sizeof(avInfoEx)*(pinfo->count+1));
        memset(pinfo->pinfoex+pinfo->count, 0, sizeof(avInfoEx));

        if (_is_return(buf[strlen(buf)-1])) {
            buf[strlen(buf)-1] = 0;
        }
        int res = _avfirstline(buf, pinfo->pinfo+pinfo->count, pinfo->pinfoex+pinfo->count);
        if (res == -1)
        {
            return -1;
        }
        if (buf[0] >= '0' && buf[0] <= '9') {
            idx = atoi(buf);
        }
        (pinfo->pinfo+pinfo->count)->idx = idx;

        if (strlen(pinfo->depature) == 0) {
            strcpy(pinfo->depature, (pinfo->pinfo+pinfo->count)->areastart);
        }
        if (strlen((pinfo->pinfo+pinfo->count)->areastart) == 0 && pinfo->count > 0) {
            strcpy((pinfo->pinfo+pinfo->count)->areastart, (pinfo->pinfo+pinfo->count-1)->areaend);
        }

        pinfo->count++;
    }
    return pinfo->count;
}

int CETermString::_avfirstline( const char* pstr, avInfo* pinfo, avInfoEx* pinfoE )
{
	int  index = 0;
	_avh_status status = en_avh_number;
	//bool bshare = false;
	while (1) {
		char token[4096] = {0};
		int res = _readOneToken(pstr+index, token, sizeof(token));
		if (strlen(token) == 0)
			break;

		if (status == en_avh_number) {
			if (strlen(token) >= 5)
			{
				int nstart = 0;
				if (token[0] == '*') {
				//	bshare = true;
					nstart = 1;
				}
				if (token[3] == '*') {
				//	bshare = true;
					nstart = 4;
				}
				strncpy(pinfo->aircompany, token+nstart, 2);
				strcpy(pinfo->airnumber, token+2+nstart);
				status = en_avh_citypair;
			}
			else {
				status = en_avh_airnumber;
			}
		}
		else if (status == en_avh_airnumber) {
			if (strlen(token) < 5)
				return -1;
			
			int nstart = 0;
			if (token[0] == '*') {
			//	bshare = true;
				nstart = 1;
			}
			strncpy(pinfo->aircompany, token+nstart, 2);
			strcpy(pinfo->airnumber, token+2+nstart);
			status = en_avh_citypair;
		}
		else if (status == en_avh_citypair) {
			if (strlen(token) == 6) {
				memcpy(pinfo->areastart, token, 3);
				memcpy(pinfo->areaend, token+3, 3);
				status = en_avh_starttime;
			}
			else if (strlen(token) == 3) {
				memcpy(pinfo->areaend, token, 3);
				status = en_avh_starttime;
			}
			else{
				return -1;
			}
		}
		else if (status == en_avh_starttime) {
			if (strlen(token) != 4 && strlen(token) != 6)
				return -1;
			
			memcpy(pinfo->timestart, token, strlen(token));
			
			status = en_avh_endtime;
		}
		else if (status == en_avh_endtime) {
			if (strlen(token) != 4 && strlen(token) != 6)
				return -1;
			
			memcpy(pinfo->timeend, token, strlen(token));
			
			status = en_avh_planetype;
		}
		else if (status == en_avh_planetype) {
			if (strlen(token) != 3)
				return -1;
			
			memcpy(pinfo->planetype, token, strlen(token));
			
			status = en_avh_staydiner;
		}
		else if (status == en_avh_staydiner) {
			if (strlen(token) > 3 || strlen(token) < 1)
				return -1;

			status = en_avh_eleticket;

			memcpy(pinfo->staycount, token, 1);

			if (pstr[index+res+2] != ' ') {
				memcpy(pinfo->dinerinfo, pstr+index+res+2, 1);
				
				index += res + 3;
				continue;
			}
		}
		else if (status == en_avh_eleticket) {
			
			status = en_avh_timeflag;
			if (strlen(token) != 1)
			{
				continue;
			}
		}
		else if (status == en_avh_timeflag) {

			if (res > 4) {
				status = en_avh_seatstatus;
				continue;
			}
			if (strlen(token) != 3)
				return -1;

			strcpy(pinfoE->timeflag, token);

			status = en_avh_seatstatus;
		}
		else if (status == en_avh_seatstatus) {
			if (strlen(token) != 2 || (strlen(token) == 3 && token[2] == '*')) {
				status = en_avh_null;
				continue;
			}
			memcpy(&pinfoE->detail[pinfoE->count][0], token, 2);
			pinfoE->count++;
		}
		index += res + strlen(token);
	}
// 	if (bshare)
// 		return 1;
	return 0;
}

int CETermString::_avgetrecords( const char* pstr, char*** pone, int* pagetype )
{
    *pagetype = en_page_single;
    int index = 0;
    std::vector<std::string> strvec;
//    int count = 0;
    std::string strtemp = "";
    while(1) {
        char temp[4096] = {0};
        int i = _getOneLine(pstr+index, temp, sizeof(temp));
        if (i == -1)
            break;

        index += i;

        if (temp[0] >= '1' && temp[0] <= '9') {
            if (strtemp != "") {
                strvec.push_back(strtemp);
            }
            if (temp[1] == '-') {
                *pagetype |= en_page_before;
            }
            if (temp[1] == '+') {
                *pagetype |= en_page_next;
            }
            strtemp = "";
        }
        else if (temp[0] == ' ' || temp[0] == '\t' || _is_return(temp[0])) {
            char token[4096] = {0};
            int offset = _readOneToken(temp, token, sizeof(token));
            if (offset == -1)
                continue;

            if (token[0] == '*') {
                continue;
            }
            char dep[4] = {0};
            char des[4] = {0};
            if (_avhgetdepdes(temp, dep, des)) {
                continue;
            }
        }
        else {
            continue;
        }
        strtemp += temp;
    }

    if (strtemp != "")
    {
        strvec.push_back(strtemp);
    }

    *pone = (char**)malloc(sizeof(void*)*strvec.size());
    for (unsigned int i = 0; i < strvec.size(); i++)
    {
        (*pone)[i] = (char*)malloc(strvec[i].length()+1);
        strcpy((*pone)[i], strvec[i].c_str());
    }

    return strvec.size();
}

void CETermString::FreeAVRes( avtravelInfo** pinfo, int count )
{
	for (int i = 0; i < count; i++) {
		if (pinfo[i]->pinfo != NULL) {
			free(pinfo[i]->pinfo);
			pinfo[i]->pinfo = NULL;
		}
		if (pinfo[i]->pinfoex != NULL) {
			free(pinfo[i]->pinfoex);
			pinfo[i]->pinfoex = NULL;
		}
		free(pinfo[i]);
		pinfo[i] = NULL;
	}
	free(pinfo);
}

bool CETermString::_getavflightinfo( const char* pstr, char* fno, char* timeend )
{
	char line[4096] = {0};
	int res = _getOneLine(pstr, line, sizeof(line));
	if (res == -1)
	{
		return false;
	}

//	MU2380 08OCT(WED)-13OCT(MON) HGHXIY
	int index = 0;
	char token[4096] = {0};
	res = _readOneToken(pstr+index, token, sizeof(token));
	if (strlen(token) == 0)
		return false;
	if (!_is_flightnum(token))
	{
		return false;
	}
	if (fno != NULL)
	{
		strcpy(fno, token);
	}

	index += res + strlen(token);
	
	res = _readOneToken(pstr+index, token, sizeof(token));
	if (strlen(token) != 21)
		return false;
	if (timeend != NULL)
	{
		memcpy(timeend, token+11, 5);
		timeend[5] = 0;
	}
	
	index += res + strlen(token);
	
	res = _readOneToken(pstr+index, token, sizeof(token));
	if (strlen(token) != 6)
		return false;
	
	index += res + strlen(token);

	return true;
}

bool CETermString::_is_flightnum(const char* pstr) {                                                         
    
    const char* pvalue = "0123456789QWERTYUIOPASDFGHJKLZXCVBNM";                                         
    if (pstr == NULL || strlen(pstr) < 5) {                                                              
        return false;                                                                                    
    }                                                                                                    
    
    std::string str = pstr;
    if (str.find_first_not_of(pvalue) != std::string::npos) {                                            
        return false;                                                                                    
    }                                                                                                    
    
    str = str.substr(0, 2);
    if (_is_number(str.c_str())) {                                                                         
        return false;                                                                                    
    }                                                                                                    
    
    if (!_is_number(pstr+2)) {                                                                             
        return false;                                                                                    
    }                                                                                                    
    
    return true;                                                                                         
}

bool CETermString::isAirCompany(const std::string line)
{
    bool bRet = false;
    std::string firstThreeChars = line.substr(0,3);
    //如果前三个字符是SEE或者空格应该就是航空公司二字码了
    if (firstThreeChars.compare("SEE") == 0 || firstThreeChars.compare("   ") == 0 )
    {
        bRet = true;
    }
    return bRet;
}

bool CETermString::isInfo(const std::string line)
{
    if(line.length() < 15){
        return false;
    }

    bool bRet = false;
    std::string firstSevenChars = line.substr(0,7);
    std::string secondSevenChars = line.substr(8,7);
    if (firstSevenChars.compare(secondSevenChars) == 0 && line.at(7) == '*')
    {
        bRet = true;
    }
    return bRet;
}

bool CETermString::isPrice(const std::string line)
{
    if(line.length() < 15){
        return false;
    }
    bool bRet = false;
    char firstChar = line.at(0)>0?line.at(0):0;
    char secondChar = line.at(1)>0?line.at(1):0;
    char thirdChar = line.at(2)>0?line.at(2):0;
    if (isdigit(firstChar) && isdigit(secondChar) && thirdChar == ' ')
    {
        bRet = true;
    }
    return bRet;
}

bool CETermString::isPage(const std::string line)
{
    bool bRet = false;
    std::string::size_type hasPage = line.find("PAGE");
    if (hasPage != std::string::npos)
    {
        bRet = true;
    }
    return bRet;
}

std::string CETermString::trim(const std::string content,char flag/*=' '*/)
{
//    int length = content.length();
    std::string::size_type firstNotFlagIndex = content.find_first_not_of(flag);
    std::string::size_type lastNotFlagIndex = content.find_last_not_of(flag);
    if (firstNotFlagIndex == std::string::npos && lastNotFlagIndex == std::string::npos)
    {
        return "";
    }
    return content.substr(firstNotFlagIndex,lastNotFlagIndex-firstNotFlagIndex+1);
}

fsdlinetype CETermString::LineType(const std::string line)
{

    fsdlinetype eRet = UNKNOW;
    if (isAirCompany(line))
    {
        eRet = AIRCOMPANY;
    } 
    else if (isInfo(line))
    {
        eRet = INFO;
    }
    else if (isPage(line))
    {
        eRet = PAGE;
    }
    else if (isPrice(line))
    {
        eRet = PRICE;
    }
    else if(isRate(line))
    {
        eRet = RATE;
    }
    return eRet;
}

int CETermString::DealFsdStr( const std::string pstr,fsdpriceinfo_s *pinfo )
{
    char lineSpliter = '\r';
    int startPos = 0;
    int endPos = 0;
    std::set<std::string> airCompanies;
    std::vector<fsdlinedata> lineDatas;
    endPos  = pstr.find(lineSpliter,startPos);
    while (endPos > 0)
    {
        std::string line = pstr.substr(startPos,endPos-startPos);
        switch (LineType(line))
        {
        case AIRCOMPANY:
            {
                int lastAlpha = line.find_last_of("1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                std::string subStr = line.substr(4,lastAlpha-3);
                std::istringstream istr(subStr);
                std::string sTmp;
                while( !istr.eof() )
                {
                    istr >> sTmp ; //get a word
                    std::string::size_type hasOtherChar = sTmp.find_first_not_of("1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                    if (hasOtherChar == std::string::npos && sTmp.length() == 2)
                    {
                        airCompanies.insert(sTmp);
                    }
                }
            }
            break;
        case INFO:
            {
                std::vector<std::string> tokens;
                std::istringstream istr(trim(line));
                std::string sTmp;
                while( !istr.eof() )
                {
                    istr >> sTmp ; //get a word
                    tokens.push_back(sTmp); 
                }
                if (tokens.size() == 5)
                {
                    //查询日期,查询航空
                    std::string token = tokens.at(0);
                    std::string searchDate = token.substr(0,7);
                    strcpy(pinfo->searchdate,searchDate.c_str());
                    std::string searchAirCompany = token.substr(16,2);
                    strcpy(pinfo->searchaircompany,searchAirCompany.c_str());
                    //城市对，旅行方向
                    token = tokens.at(1);
                    std::string cityPair = token.substr(0,6) ;
                    strcpy(pinfo->citypair,cityPair.c_str());
                    std::string travelDirect = token.substr(7,2) ;
                    strcpy(pinfo->traveldirect,travelDirect.c_str());
                    //实际里程
                    token = tokens.at(3);
                    token = trim(token);
                    std::string sRealMiles = token.substr(0,token.find('/'));
                    pinfo->realtravellength = atoi(sRealMiles.c_str());
                    //最大里程，货币种类
                    token = tokens.at(4);
                    token = trim(token);
                    std::string sMaxMiles = token.substr(0,token.find('/'));
                    pinfo->maxtravellength = atoi(sMaxMiles.c_str());
                    std::string moneyType = token.substr(token.find('/')+1,token.length() - token.find('/'));
                    strcpy(pinfo->moneytype,moneyType.c_str());
                }
            }
            break;
        case RATE:
            {
                std::string::size_type nindex = line.find("=");
                std::string::size_type eindexend = line.find(" ",nindex+2);
                std::string exchangeRate = "";
                float fExchangeRate = 0.0;
                if( nindex != std::string::npos)
                {
                    exchangeRate = trim(line.substr(nindex + 2,eindexend - nindex - 2));
                    fExchangeRate = atof(exchangeRate.c_str());
                    strcpy(pinfo->exchangeline,line.c_str());
                }else{

                }
                pinfo->exchangerate = fExchangeRate;
            }
            break;
        case PRICE:
            {
                fsdlinedata lineData = {0};
                //行号
                std::string serialNumber = line.substr(0,2);
                //舱位
                std::string cabin = line.substr(3,1);
                strcpy(lineData.cabin,cabin.c_str());
                //价格基础
                std::string priceBasis = trim(line.substr(4,6));
                strcpy(lineData.pricebasis,priceBasis.c_str());
                std::string sPriceType = trim(line.substr(12,1));
                //价格类型 0：指定运价1：比例运价
                int iPriceType = 0;
                if (sPriceType.compare("/") == 0)
                {
                    iPriceType = 0;
                }
                else if (sPriceType.compare("*") == 1)
                {
                    iPriceType = 1;
                }
                lineData.pricetype = iPriceType;
                //提前开票期
                std::string advancePeriod = trim(line.substr(13,4));
                if (advancePeriod.length() > 0)
                {
                    advancePeriod = trim(line.substr(18,1));
                    int iAdvancePeriod = atoi(advancePeriod.c_str());
                    lineData.ticketlimitday = iAdvancePeriod;
                    strcpy(lineData.ticketlimittime,trim(line.substr(18,1)).c_str());
                }
                else
                {
                    lineData.ticketlimitday = 0;
                }

                //单程票价
                std::string singleTripPrice = trim(line.substr(17,5));
                if (singleTripPrice.find_first_of("ABCDEFGHIJKLMNOPQRSTUVWXYZ") == std::string::npos && singleTripPrice.length()>0)
                {
                    //有单程票价
                    lineData.singletripprice = atoi(singleTripPrice.c_str());
                }
                else
                {
                    lineData.singletripprice = 0;
                }
                //往返票价
                std::string returnTripPrice = trim(line.substr(27,5));
                if (returnTripPrice.find_first_of("ABCDEFGHIJKLMNOPQRSTUVWXYZ") == std::string::npos && returnTripPrice.length()>0)
                {
                    //有往返程票价
                    lineData.returntripprice = atoi(returnTripPrice.c_str());
                }
                else
                {
                    lineData.returntripprice = 0;
                }
                //有舱位限制要求的舱位
                std::string cabLimit = trim(line.substr(33,2));
                if (cabLimit.length() == 2 && cabLimit.at(1) == '*')
                {
                    strcpy(lineData.seatlimit,cabLimit.substr(0,1).c_str());
                }
                else
                {
                    memset(lineData.seatlimit,0,sizeof(lineData.seatlimit));
                }
                //最短停留期
                std::string sMinStayPeriod = trim(line.substr(35,2));
                int iMinStayPeriod = -1;
                if (sMinStayPeriod.length() == 2 && sMinStayPeriod.at(1) == 'D')
                {
                    iMinStayPeriod = atoi(sMinStayPeriod.substr(0,1).c_str());
                }
                strcpy(lineData.minstayday, sMinStayPeriod.c_str());//= iMinStayPeriod;
                //最长停留期
                std::string sMaxStayPeriod = trim(line.substr(39,3));
                int firstNotNumeric = sMinStayPeriod.find_first_not_of("0123456789");
                int iMaxStayPeriod = -1;
                if (sMaxStayPeriod.length() > 0 && sMaxStayPeriod.at(sMaxStayPeriod.length()-1) == 'M')
                {
                    iMaxStayPeriod = atoi(sMaxStayPeriod.substr(0,firstNotNumeric-1).c_str());
                }
                strcpy(lineData.maxstayday ,sMaxStayPeriod.c_str());//= iMaxStayPeriod;
                //票价有效期
                std::string priceValidDateFrom = trim(line.substr(43,5));
                std::string priceValidDateTo = trim(line.substr(49,5));
                strcpy(lineData.ticketdeadlinefrom,priceValidDateFrom.c_str());
                strcpy(lineData.ticketdeadlineend,priceValidDateTo.c_str());
                //注释
                std::string comment = trim(line.substr(55,line.length()-55));
                strcpy(lineData.comment,comment.c_str());
                lineDatas.push_back(lineData);
            }
            break;
        default:
            /*std::cout<<"unknown:"<<line;*/
            break;
        }
        startPos = endPos+1;
        endPos = pstr.find(lineSpliter,startPos);
    }
    //报价的航空公司二字码记录
    fsdaircompanycode *fsdAirCompanies = (fsdaircompanycode *)malloc(sizeof(fsdaircompanycode) * airCompanies.size());
    std::set<std::string>::iterator it;
    int i = 0 ;
    for (it = airCompanies.begin() ; it != airCompanies.end() ; ++it,++i)
    {
        strcpy(fsdAirCompanies[i].code,(*it).c_str());
    }
    pinfo->aircompanycount = airCompanies.size();
    pinfo->aircompanys = fsdAirCompanies;
    //报价记录
    fsdlinedata *fsdLineData = (fsdlinedata *)malloc(sizeof(fsdlinedata)*lineDatas.size());
    std::vector<fsdlinedata>::iterator lineIt;
    i = 0 ;
    for (lineIt = lineDatas.begin() ; lineIt != lineDatas.end() ; ++lineIt,++i)
    {
        memcpy(&(pinfo->lines[i]),&*lineIt,sizeof(fsdlinedata));
        //memcpy(&fsdLineData[i],&*lineIt,sizeof(fsdlinedata));
    }
    pinfo->linecount = lineDatas.size();
    return 1;
}

void CETermString::FreeFsdRes( fsdpriceinfo_s *pinfo )
{
    if (pinfo != NULL)
    {
        if (pinfo->linecount>0 && pinfo->lines != NULL)
        {
            free(pinfo->lines);
            pinfo->linecount = 0;
        }
        if (pinfo->aircompanycount>0 && pinfo->aircompanys != NULL)
        {
            free(pinfo->aircompanys);
            pinfo->aircompanycount = 0;
            pinfo->aircompanys = NULL;
        }
        free(pinfo);
        pinfo = NULL;
    }
}


bool CETermString::isRate( const std::string line )
{
    bool bRet = false;
    std::string firstSevenChars = line.substr(0,7);
    if (firstSevenChars.compare("1 NUC =") == 0)
    {
        bRet = true;
    }
    return bRet;
}
bool CETermString::isFlightNoInfo(const std::string line)
{
    std::string realLine = trim(line);
    bool bRet = false;
    if (realLine.length() > 2 && realLine.substr(0,2).compare("AV") == 0)
    {
        bRet = true;
    }
    return bRet;
}

bool CETermString::isFlightInfo(const std::string line)
{
    bool bRet = false;
    std::vector<std::string> tokens;
    std::istringstream istr(trim(line));
    std::string sTmp;
    while( !istr.eof() )
    {
        istr >> sTmp ; //get a word
        tokens.push_back(sTmp); 
    }
    const char *alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const char *numeric = "0123456789+-";
    if(tokens.size() <4 )
        return bRet;
    if (tokens.at(0).find_first_not_of(alpha) == std::string::npos && tokens.at(1).find_first_not_of(numeric) == std::string::npos\
        &&tokens.at(2).find_first_not_of(alpha) == std::string::npos && tokens.at(3).find_first_not_of(numeric) == std::string::npos)
    {
        bRet = true;
    }
    return bRet;
}
bool CETermString::isCabinInfo(const std::string line)
{
    bool bRet = false;
    std::vector<std::string> tokens;
    std::istringstream istr(trim(line));
    std::string sTmp;
    while( !istr.eof() )
    {
        istr >> sTmp ; //get a word
        tokens.push_back(trim(sTmp)); 
    }
    if (tokens.size() > 0)
    {
        bRet = true;
    }
    for (unsigned int i = 0 ; i < tokens.size() ; ++i)
    {
        if (i == 0)
        {
            if(tokens.at(0).length() != 6 && tokens.at(0).length() != 2)
            {
                bRet = false;
            }
            break;
        }
        else if(tokens.at(i).length() != 2)
        {
            bRet = false;
            break;
        }
    }
    return bRet;
}
avslinetype CETermString::SpecialAvLineType(const std::string line)
{
    avslinetype eRet = UNKNOWAVLINE;
    if (isFlightInfo(line))
    {
        eRet = FLIGHT;
    } 
    else if (isCabinInfo(line))
    {
        eRet = CABIN;
    }
	else if (isFlightNoInfo(line))
    {
        eRet = FLIGHTNO;
    }
    return eRet;
}

int CETermString::DealSpecialAvStr(const std::string pstr,avSpecialInfo *pinfo)
{
    char lineSpliter = '\n';
    int startPos = 0;
    int endPos = 0;
    //std::set<std::string> cabins;
    std::vector<avsflight> flights;
    std::vector<avscabin> cabins;
    endPos  = pstr.find(lineSpliter,startPos);
    while (endPos > 0)
    {
        std::string line = pstr.substr(startPos,endPos-startPos);
        switch (SpecialAvLineType(line))
        {
        case FLIGHT:
            {
                avsflight flight = {0};
                std::string depature = trim(line.substr(0,3));
                strcpy(flight.departure,depature.c_str());
                std::string depatureTime = trim(line.substr(4,6));
                strcpy(flight.departuretime,depatureTime.c_str());
                std::string arrival = trim(line.substr(11,3));
                strcpy(flight.arrival,arrival.c_str());
                std::string arrivalTime = trim(line.substr(15,6));
                strcpy(flight.arrivaltime,arrivalTime.c_str());
                std::string week = trim(line.substr(22,3));
                strcpy(flight.week,week.c_str());
                std::string duration = trim(line.substr(27,5));
                int colonIndex = duration.find(':',0);
                int hours = atoi(duration.substr(0,colonIndex).c_str());
                int minutes = atoi(duration.substr(colonIndex+1).c_str());
                minutes = hours*60+minutes;
                flight.duration= minutes;
                std::string ground = trim(line.substr(33,6));
                colonIndex =0;
                colonIndex =ground.find(':',0);
                int stayHours = atoi(ground.substr(0,colonIndex).c_str());
                int stayMinutes = atoi(ground.substr(colonIndex+1).c_str());
                stayMinutes = stayHours*60+stayMinutes;
                flight.staytime = stayMinutes;
                std::string terminals = trim(line.substr(40,5));
                int slashIndex = terminals.find('/',0);
                std::string depatureTerminalStr = terminals.substr(0,slashIndex);
                std::string arrivalTerminalStr = terminals.substr(slashIndex+1);
                strcpy(flight.departureterminal,depatureTerminalStr.c_str());
				strcpy(flight.arrivalterminal,arrivalTerminalStr.c_str());
                std::string plantype = trim(line.substr(46,4));
                strcpy(flight.planetype,plantype.c_str());
                std::string meal = trim(line.substr(51  ,5));
                strcpy(flight.mealinfo,meal.c_str());
                std::string distance = trim(line.substr(57,8));
                flight.distance = atoi(distance.c_str());
                flights.push_back(flight);
            }
            break;
        case CABIN:
            {
                std::string subStr = trim(line);//.substr(7,lastAlpha-6);
                std::istringstream istr(subStr);
                std::string sTmp;
                std::vector<std::string> tokens;
                while( !istr.eof() )
                {
                    istr >> sTmp ; //get a word
                    tokens.push_back(sTmp);
                }
                if (tokens.size()> 0 && tokens.at(0).length() == 6)
                {
                    //new flight
                    avscabin tmpCabins  ={0};
                    unsigned int i;
                    for ( i= 0 ; i +1<  tokens.size(); ++i)
                    {
                        strcpy(tmpCabins.cabins[i],tokens[i+1].c_str());
                    }
                    tmpCabins.cabincount = i;
                    cabins.push_back(tmpCabins);
                } 
                else
                {
                    //the last flight
                    avscabin &tmpCabins =  cabins.at(cabins.size()-1);
                    for (unsigned  int i=0 ; i <  tokens.size(); ++i,++ tmpCabins.cabincount)
                    {
                        strcpy(tmpCabins.cabins[tmpCabins.cabincount],tokens[i].c_str());
                    }
                }
            }
            break;
		case FLIGHTNO:
            {
                std::string realLine = trim(line);
                int firstSepliter = realLine.find_first_of(" :/");
                int lastSepliter = realLine.find_last_of(" :/");
                strcpy(pinfo->flightNo,realLine.substr(firstSepliter+1,lastSepliter-firstSepliter-1).c_str());
            }
            break;
        default:
            /*std::cout<<"unknown:"<<line;*/
            break;
        }
        startPos = endPos+1;
        endPos = pstr.find(lineSpliter,startPos);
    }
    pinfo->flightcount = flights.size();
    for (unsigned int i = 0 ; i < flights.size() ; ++i)
    {
        pinfo->flights[i] = flights.at(i);
        if (cabins.size()>0)
        {
            pinfo->cabins = cabins.at(0);
        }
    }
    return 0;
}

bool CETermString::isOrderResultInfo(const std::string line)
{
    bool bRet = false;
    if (line.find("EOT SUCCESSFUL") != std::string::npos)
    {
        bRet = true;
    }
    return bRet;
}

bool CETermString::isOrderResultSegmentInfo(const std::string line)
{
    bool bRet = false;
    std::vector<std::string> tokens;
    std::istringstream istr(trim(line));
    std::string sTmp;
    while( !istr.eof() )
    {
        istr >> sTmp ; //get a word
        tokens.push_back(trim(sTmp)); 
    }
    if (tokens.size() == 7 && tokens.at(0).length() == 6 &&tokens.at(2).length() == 7&&tokens.at(3).length() == 6)
    {
        bRet = true;
    }
    return bRet;
}

orderresultlinetype CETermString::OrderResultLineType(const std::string line)
{
    orderresultlinetype eRet = ORDER_RESULT_UNKOWN;
    if (isOrderResultInfo(line))
    {
        eRet = ORDER_RESULT_INFO;
    } 
    else if (isOrderResultSegmentInfo(line))
    {
        eRet = ORDER_RESULT_SEGMENT;
    }
    return eRet;
}

int CETermString::weektoint(const std::string week)
{
    //1-7
    int iRet = 0;
    if (week.compare("MO"))
    {
        iRet = 1;
    } 
    else if(week.compare("TU"))
    {
        iRet = 2;
    }
    else if(week.compare("WE"))
    {
        iRet = 3;
    }
    else if(week.compare("TH"))
    {
        iRet = 4;
    }
    else if(week.compare("FR"))
    {
        iRet = 5;
    }
    else if(week.compare("SA"))
    {
        iRet = 6;
    }
    else if(week.compare("SU"))
    {
        iRet = 7;
    }
    return iRet;
}

int CETermString::statustoint(const std::string status)
{
    //0-4 NN DW DL UC DK
    int bRet = -1;
    if(status.compare("NN") == 0)
    {
        bRet = 0;
    }
    else if(status.compare("DW") == 1)
    {
        bRet = 1;
    }
    else if(status.compare("DL") == 2)
    {
        bRet = 2;
    }
    else if(status.compare("UC") == 3)
    {
        bRet = 3;
    }
    else if(status.compare("DK") == 4)
    {
        bRet = 4;
    }
    return bRet;
}

int CETermString::DealOrderResultStr(const std::string pstr,OrderResultInfo *pinfo)
{
    char lineSpliter = '\n';
    int startPos = 0;
    int endPos = 0;
    std::vector<FlightSegment> segments;
    endPos  = pstr.find(lineSpliter,startPos);
    while (endPos > 0)
    {
        std::string line = pstr.substr(startPos,endPos-startPos);
        switch (OrderResultLineType(line))
        {
        case ORDER_RESULT_INFO:
            {
                std::vector<std::string> tokens;
                std::istringstream istr(trim(line));
                std::string sTmp;
                while( !istr.eof() )
                {
                    istr >> sTmp ; //get a word
                    tokens.push_back(trim(sTmp)); 
                }
                strcpy(pinfo->pnr,tokens[0].c_str());
            }
            break;
        case ORDER_RESULT_SEGMENT:
            {
                std::vector<std::string> tokens;
                std::istringstream istr(trim(line));
                std::string sTmp;
                while( !istr.eof() )
                {
                    istr >> sTmp ; //get a word
                    tokens.push_back(trim(sTmp)); 
                }
                FlightSegment segment;
                strcpy(segment.aircompany,trim(tokens[0]).substr(0,2).c_str());
                strcpy(segment.flightno,trim(tokens[0]).c_str());
                strcpy(segment.cabin,trim(tokens[1]).c_str());
                segment.week = weektoint(trim(tokens[2]).substr(0,2));
                strcpy(segment.flydate,trim(tokens[2]).substr(2).c_str());
                strcpy(segment.depature,trim(tokens[3]).substr(0,3).c_str());
                strcpy(segment.arrival,trim(tokens[3]).substr(3).c_str());
                segment.status = statustoint(tokens[4].substr(0,2));
                strcpy(segment.flytime,trim(tokens[5]).c_str());
                strcpy(segment.arrivaltime,trim(tokens[6]).c_str());
                segments.push_back(segment);
            }
            break;
        default:
            /*std::cout<<"unknown:"<<line;*/
            break;
        }
        startPos = endPos+1;
        endPos = pstr.find(lineSpliter,startPos);
    }
    std::vector<FlightSegment>::iterator it = segments.begin();
    pinfo->segmentcount = segments.size();
    int i = 0 ; 
    for (; it != segments.end()  ; ++it,++i)
    {
        pinfo->segments[i]  = *it;
        pinfo->segments[i].segindex = i;
    }
    return 1;
}


