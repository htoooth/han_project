/*
 * InlandScanTask.cpp
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#include "InlandScanTask.h"
#include "svrloop.h"

InlandScanTask::InlandScanTask()
{
	// TODO Auto-generated constructor stub

}

InlandScanTask::~InlandScanTask()
{
	// TODO Auto-generated destructor stub
}

void InlandScanTask::doWork()
{
	MSGOUT(en_Msg_Debug,"InlandScanTask::doWork in=============================================thread id:%lu", pthread_self());
	if (data->status == SCANSTATUS_PROCESSING)
	{
		LowerCabinOrderData *orderData = data->orderData;
		std::vector<FlightSegment> trips = orderData->trips;
		if(trips.size() < 0)
		{
			MSGOUT(en_Msg_Debug,"seg count error,order id:%d,seg counts:%d",orderData->orderId,trips.size());
			return;
		}
		int count = trips.size();
		for (int i = 0; i < count; ++i)
		{
			FlightSegment seg = trips[i];
			bool isOk = false;
			StCommand savCommand = CommandGenerator::generateSpecialAv(isOk,seg.flightno, seg.flydate);
			savCommand.type = LCSAV;
			savCommand.result = NULL;
            savCommand.identifyId = LowerCabinScanTask::getUid();
			StCommands *cmdPatch = new StCommands;
			cmdPatch->clientid = orderData->clientId;
			cmdPatch->identifiers = ServerMain::generateContextKey(data);
			cmdPatch->count = 1;
			cmdPatch->current = 0;
			savCommand.identifiers = cmdPatch->identifiers;
            cmdPatch->commands.push_back(savCommand);
            
            //this count will be decreased in somewhere
            data->scanThreadCount += 1;
			//send the commands to the eterm sender app
			sendCommands(cmdPatch);
            //break;
		}
	}
	MSGOUT(en_Msg_Debug,"InlandScanTask::doWork out=============================================thread id:%lu", pthread_self());
}
