/*
* EtermCommandProcessor.cpp
*
*  Created on: 2015年1月15日
*      Author: Administrator
*/

#include "InlandEtermCommandProcessor.h"

#include <pthread.h>
#include <showmsg.h>
#include <map>
#include <string>
#include <vector>

#include "ETermString.h"
#include "structs.h"
#include "svrloop.h"

InlandEtermCommandProcessor::InlandEtermCommandProcessor() :
    cmdId(-1)
{
}

InlandEtermCommandProcessor::~InlandEtermCommandProcessor()
{
    // TODO Auto-generated destructor stub
}

void InlandEtermCommandProcessor::doWork()
{
    MSGOUT(en_Msg_Debug,"InlandEtermCommandProcessor::doWork in=============================================thread id:%lu",
        pthread_self());
    StCommand* command = getCommandByCmdId(cmdId);
    if (command != NULL)
    {
        std::vector<LowerCabinFlightCabins> cabins = data->settings->cabins;
        std::string cmdFlightNo = getFlightNoFromAVSCommand(command->content);
        LowerCabinFlightCabins cabinSet = getFlightCabinSettingByFlightNo(cmdFlightNo,cabins);
        switch (command->type)
        {
        case LCSAV:
            {
                MSGOUT(en_Msg_Debug,"InlandEtermCommandProcessor::doWork LCSAV in");
                avSpecialInfo *result = (avSpecialInfo *)command->formartedresult;
                avscabin asc = result->cabins;
                std::map<char,char> cabinMap = generateCabinMap(asc);
                int acl = cabinSet.availableCabin.length();
                bool hasLowerCabin = false;
                for (int i = 0; i < acl; ++i)
                {
                    if(cabinMap.count(cabinSet.availableCabin[i]) > 0)
                    {
                        //find the cabin, then test the cabin status
                        char cabinStatus =cabinMap[cabinSet.availableCabin[i]];
                        unsigned int ret= availableCabinFlags.find(cabinStatus);
                        if(ret != std::string::npos )
                        {
                            LowerCabinOrderData *orderData = data->orderData;
                            //the cabin is valid
                            hasLowerCabin = true;
                            StCommand rtCommand = CommandGenerator::generateRt(orderData->pnr);
                            rtCommand.result = NULL;
                            rtCommand.identifyId = LowerCabinScanTask::getUid();
                            bool isOk = false;
                            StCommand patCommand = CommandGenerator::generatePat(isOk);
                            patCommand.result = NULL;
                            patCommand.identifyId = LowerCabinScanTask::getUid();
                            StCommands *cmdPatch = new StCommands;
                            cmdPatch->clientid = orderData->clientId;
                            cmdPatch->identifiers = ServerMain::generateContextKey(data);
                            cmdPatch->count = 2;
                            cmdPatch->current = 0;
                            rtCommand.identifiers = cmdPatch->identifiers;
                            patCommand.identifiers = cmdPatch->identifiers;
                            cmdPatch->commands.push_back(rtCommand);
                            cmdPatch->commands.push_back(patCommand);
                            //send the commands to the ETERM sender app
                            sendCommands(cmdPatch);
                            break;
                        }
                    }
                }
                //no lower cabins
                if (!hasLowerCabin)
                {
                    if(-- data->scanThreadCount <= 0)
                        data->status = SCANSTATUS_WAITTING; 
                }
                MSGOUT(en_Msg_Debug,"InlandEtermCommandProcessor::doWork LCSAV out");
            }
            break;
        case LCAVH:
            {
                MSGOUT(en_Msg_Debug,"InlandEtermCommandProcessor::doWork LCAVH in");
                AvhResults * result = (AvhResults *)command->formartedresult;
                std::map<char,char> cabinMap = generateCabinMap(result,cmdFlightNo);
                int acl = cabinSet.availableCabin.length();
                bool hasLowerCabin = false;
                for (int i = 0; i < acl; ++i)
                {
                    if(cabinMap.count(cabinSet.availableCabin[i]) > 0)
                    {
                        //find the cabin, then test the cabin status
                        char cabinStatus =cabinMap[cabinSet.availableCabin[i]];
                        unsigned int ret= availableCabinFlags.find(cabinStatus);
                        if(ret != std::string::npos )
                        {
                            LowerCabinOrderData *orderData = data->orderData;
                            //the cabin is valid
                            hasLowerCabin = true;
                            StCommand rtCommand = CommandGenerator::generateRt(orderData->pnr);
                            rtCommand.result = NULL;
                            bool isOk = false;
                            StCommand qteCommand = CommandGenerator::generatePat(isOk);
                            qteCommand.result = NULL;
                            StCommands *cmdPatch = new StCommands;
                            cmdPatch->clientid = orderData->clientId;
                            cmdPatch->identifiers = ServerMain::generateContextKey(data);
                            cmdPatch->count = 2;
                            cmdPatch->current = 0;
                            cmdPatch->commands.push_back(rtCommand);
                            cmdPatch->commands.push_back(qteCommand);
                            //send the commands to the ETERM  sender app
                            sendCommands(cmdPatch);
                            break;
                        }
                    }
                }
                //no lower cabins
                if (!hasLowerCabin)
                {
                    data->status = SCANSTATUS_WAITTING; 
                }
                MSGOUT(en_Msg_Debug,"InlandEtermCommandProcessor::doWork LCAVH out");
            }
            break;
        case PAT:
            {
                MSGOUT(en_Msg_Debug,"InlandEtermCommandProcessor::doWork PAT in");
                PatResults *patResults =  (PatResults *)command->formartedresult;
                if(handle != NULL)
                {
                    handle->PostEventResult(DB_SEND_LOWERCABIN_COMMAND,0,&patResults,sizeof(patResults),NULL);
                }
                MSGOUT(en_Msg_Debug,"InlandEtermCommandProcessor::doWork PAT out");
            }
            break;
        default:
            break;
        }
    }
    else
    {
        MSGOUT(en_Msg_Debug, "this task is invalid.");
    }
    MSGOUT(en_Msg_Debug,
        "InlandEtermCommandProcessor::doWork in=============================================thread id:%lu",
        pthread_self());
}

int InlandEtermCommandProcessor::getCmdId() const
{
    return cmdId;
}

void InlandEtermCommandProcessor::setCmdId(int cmdId)
{
    this->cmdId = cmdId;
}
