/*
 * EtermCommandProcessor.h
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#ifndef INLANDETERMCOMMANDPROCESSOR_H_
#define INLANDETERMCOMMANDPROCESSOR_H_

#include "LowerCabinScanTask.h"

class InlandEtermCommandProcessor: public LowerCabinScanTask
{
public:
	InlandEtermCommandProcessor();
	virtual ~InlandEtermCommandProcessor();
	virtual void doWork();
	int getCmdId() const;
	void setCmdId(int cmdId);
protected:

private:
	int cmdId;
};

#endif /* INLANDETERMCOMMANDPROCESSOR_H_ */
