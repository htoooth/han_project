/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-11 19:48:53
# LastModified : 2015-02-12 17:07:21
# FileName     : etermsock.h
# Description  : 
 ******************************************************************************/
#ifndef _ETERMSOCK_H
#define _ETERMSOCK_H

#include "evcenter.h"

class EtermSvrSocket : public CenterSocket {
public:
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
public:
	EtermSvrSocket();
	virtual bool OnRecvData(char* pdata, unsigned int len);
	virtual void OnClose();
	bool PostDBRequest(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
	int sendcommnad(const char* cmd, unsigned int len, int id, int type);

protected:
	QueueEventModule*   m_pevent;
};

#endif // _ETERMSOCK_H
