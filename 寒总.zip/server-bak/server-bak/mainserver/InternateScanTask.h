/*
 * InternateScanTask.h
 *
 *  Created on: 2015年1月15日
 *      Author: Administrator
 */

#ifndef INTERNATESCANTASK_H_
#define INTERNATESCANTASK_H_

#include "LowerCabinScanTask.h"

class InternateScanTask: public LowerCabinScanTask
{
public:
	InternateScanTask();
	virtual ~InternateScanTask();
	virtual void doWork();
};

#endif /* INTERNATESCANTASK_H_ */
