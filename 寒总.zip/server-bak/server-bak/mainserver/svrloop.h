/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-26 18:11:23
# LastModified : 2014-07-01 16:23:53
# FileName     : svrloop.h
# Description  : 
 ******************************************************************************/
#ifndef _SVRLOOP_H
#define _SVRLOOP_H

#include <map>
#include <pthread.h>
#include <semaphore.h>

#include "serverset.h"
#include "loginsock.h"
#include "etermsock.h"
#include "scstructdef.h"
#include "scprotocol.h"
#include "scstructdef.h"
#include "ssstructdef.h"
#include "CommandGenerator.h"
#include "CommonLib.h"
#include "LowerCabinScanTask.h"
#include "InlandScanTask.h"
#include "InternateScanTask.h"
#include "InlandEtermCommandProcessor.h"
#include "InternateEtermCommandProcessor.h"

#ifdef Win32
#define _WIN32_TIMER // win32 timer don't work,use thread replace
#include <cygwin/types.h>
#include <pthread.h>
#endif

class ServerMain : public ServerSet {
public:
	virtual bool OnSocketRead(int fd, void* pdata, unsigned int ulen);
	virtual bool OnSocketConnect(int fd, struct sockaddr_in* paddr);
	virtual void OnSocketClose(int fd);
	virtual void OnEventTimer(unsigned int uid);
	virtual void SettleDBResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
	virtual void _stop();
	virtual bool _start();
    static std::string generateContextKey( LowerCabinScannerData * scannerData );
    ServerMain();

    static std::queue<LowerCabinScanTask*> tasks;
    static std::map<std::string, LowerCabinScannerData*> lowerCabinContext;
    static std::map<std::string,LowerAvResult> lowerAvResuts;
    static pthread_mutex_t rcMutex/*scanner resource mutex*/,rtMutex/*task resource mutex*/,avResultMutex/*av result mutex*/,uidMutex/*uid mutex*/;
    static sem_t semRc;
    static std::map<std::string,PhysicalCabin> aircompanyCabinMap;
protected:
	std::map<int, void*>		m_mapfd;
	std::map<int,std::queue<StCommands*> >    m_commands;//user commands queue
	std::queue<StCommands*> m_attachedcommand;//our own system commands queue
	LoginSvrSocket				m_sologin;
	EtermSvrSocket				m_soeterm;
	int							m_nsvrid;
	StNetAddrInfo				m_addrlogin;
	StNetAddrInfo				m_addretern;
	StNetAddrInfo				m_addrself;
    CETermString sEterm;
public:
	bool DealClientData(int fd, int wndid, void* pdata, unsigned int ulen);
	bool DealLogicSvrData(int fd, void* pdata, unsigned int ulen);
protected:
	bool verifyuserpwd(int fd, int wndid, StVerifyPasswd *pdata, unsigned int len);
	bool dealorderrequest(int fd, int wndid, StOrderRequest *pdata, unsigned int len);
	bool dealflightsearchrequest(int fd, int wndid, StFlightSearchRequest *pdata, unsigned int len);
	bool dealpriceconfirmrequest(int fd, int wndid, int *pdata, unsigned int len);
	bool dealticketpricerequest(int fd, int wndid, StFlightTrip *pdata, unsigned int len);
	bool deallowercabinsrequest(int fd, int wndid, StLowerCabinsRequest *pdata, unsigned int len);
    bool dealbestcabinpricerequest( int fd, int wndid, StTrip *pdata, unsigned int len );
	bool connectloginsvr();
	bool connectetermsvr();
	bool sendusercount();
	bool verifykeyword();
	bool sendsvraddr();
	bool firecommandsender(int idx);
	bool firecommandsender();
	//return  0:command exec complete else: command don't exec complete
	int processcommandresult(StCommands *&commands,_StEtermSvrResult *pResult);
	void simulatecommandresult(StCommands *&commands);
	int fetchfdfromclientid(int clientid);

	/************fetch policy price and ticket price******************/
	//inland single trip
	bool dealistpricerequest(int fd, int wndid, void *pdata, unsigned int len);
	//inland return trip
	bool dealirtpricerequest(int fd, int wndid, void *pdata, unsigned int len);
	//inland more trip
	bool dealimtpricerequest(int fd, int wndid, void *pdata, unsigned int len);
	//internate single trip
	bool dealfstpricerequest(int fd, int wndid, void *pdata, unsigned int len);
	//internate return trip
	bool dealfrtpricerequest(int fd, int wndid, void *pdata, unsigned int len);
	//internate more trip
	bool dealfmtpricerequest(int fd, int wndid, void *pdata, unsigned int len);
	/************fetch policy price and ticket price******************/
	/************command result handler*************************/
	void *clientFdCommandHandler(void *context,void *result);
	/************command result handler*************************/
	//load lower cabin orders timer function
	void startLowerCabinScanner();
    bool isInActiveTimeZone( LowerCabinSettings * settings );
    bool isInActiveTimeZoneToday( LowerCabinSettings * settings );
    LowerCabinScanTask * generateTaskByType( LowerCabinScannerData * scannerData, int step =0 );
    void startWorkThread( ServerMain* param , int count = 10);
    //thread function
    static void *workThread(void *params);
    AvhResults *kmpFind(AvhResults *avhiLink,StSegs &segs);
    void printCommands(StCommands * commands);
    
};

#endif // _SVRLOOP_H
