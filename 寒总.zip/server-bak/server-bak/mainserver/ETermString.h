// ETermString.h: interface for the CETermString class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ETERMSTRING_H__E755A53C_9C46_4AFF_84A9_DB562B612D6F__INCLUDED_)
#define AFX_ETERMSTRING_H__E755A53C_9C46_4AFF_84A9_DB562B612D6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>
#include <sstream>
#include <set>
#include <vector>
#include "string.h"
enum _turnpagetype {
	en_page_single	= 0x00000000,			// single page
	en_page_next	= 0x00000001,			// can turn to page next
	en_page_before	= 0x00000002,			// can turn to page before
};

#pragma pack(4)
/**************************AVH**************************/
struct avhInfo
{
    int     idx;
	char	aircompany[4];		// aircompany two code
	char	airnumber[8];		// airline number
	char	aircompanysh[4];	// share aircompany two code
	char	airnumbersh[8];		// share airline number
	char	areastart[4];		// three code of the depature city 
	char	timestart[8];		// airline start time
	char	stationstart[4];	// start airstation info
	char	areaend[4];			// three code of the destination city
	char	timeend[8];			// airline end time 
	char	stationend[4];		// depature airstation info
	char	planetype[8];		// airplane type
	char	staycount[4];		// stay city count
	char	dinerinfo[4];		// provide diner info
	char	totaltime[8];		// total travel time
};

struct avhInfoEx {
	char	timeflag[4];		// change time flag
	char	date[8];			// travel date info
	int		count;				// seat count
	char	detail[26][2];		// detail seat info	
};

struct avhtravelInfo {
	char		depature[4];		// depature area three code
	char		destination[4];		// destination area three code
	int			count;				// info count
	avhInfo*	pinfo;				// basice info (will not change normally
	avhInfoEx*	pinfoex;			// info will changed by time
};
/**************************AVH**************************/

/**************************AV**************************/
struct avInfo
{
    int     idx;
	char	aircompany[4];		// aircompany two code
	char	airnumber[8];		// airline number
	char	areastart[4];		// three code of the depature city 
	char	timestart[8];		// airline start time
	char	areaend[4];			// three code of the destination city
	char	timeend[8];			// airline end time 
	char	planetype[8];		// airplane type
	char	staycount[4];		// stay city count
	char	dinerinfo[4];		// provide diner info
};

struct avInfoEx {
	char	timeflag[4];		// change time flag
	char	date[8];			// travel date info
	int		count;				// seat count
	char	detail[26][2];		// detail seat info	
};

struct avtravelInfo {
	char		depature[4];		// depature area three code
	char		destination[4];		// destination area three code
	int			count;				// info count
	avInfo*		pinfo;				// basice info (will not change normally
	avInfoEx*	pinfoex;			// info will changed by time
};
/**************************AV**************************/

/**************************NFD**************************/
struct nfdpriceinfo {
	char		depature[4];		// depature area three code
	char		destination[4];		// destination area three code
	char		aircompany[4];		// airlines company two code
	int			owprice;			// one way price
	int			rtprice;			// round trip price
	char		seattype[4];		// seat type
	char		startdata[8];		// validity date start
	char		enddata[8];			// validity date end
	int 		advanceday;			// advance days
};
/**************************NFD**************************/


/**************************FD**************************/
struct fdpriceinfo {
	char		depature[4];		// depature area three code
	char		destination[4];		// destination area three code
	char		aircompany[4];		// airlines company two code
	int			owprice;			// one way price
	int			rtprice;			// round trip price
	char		seattype[4];		// seat type
    char        physeat[4];        // physical seat type
    char		startdata[8];		// validity date start
    char		enddata[8];		    // validity date end
    char        pricecal[8];
	int			distance;			// distance
};
/**************************FD**************************/

/**************************FSQ**************************/
struct fsqlinedata {
	char	areastart[4];
	char	areaend[4];
	char	datanvb[8];
	char	datanva[8];
	char	packageinfo[4];
	char	seattype[4];
};

struct fsqpricedata {
	char	areastart[4];
	char	areaend[4];
	int		price;
};

struct fsqpriceinfo {
	int				itprice;	// include all price 
	int				taxprice;	// not include Q price
	int				qprice;		// Q value info
	int				linecount;	// line count
	char			valdata[8];	// price value data
	char			valtime[8];	// price value time
	fsqlinedata*	pline;		// line info
	int				pricecount;	// price count
	fsqpricedata*	pprice;		// price info
};
/**************************FSQ**************************/

/**************************PAT**************************/
struct patpriceinfo {
	int		total;
	int		fare;
	int		tax;
};
/**************************PAT**************************/

/**************************DETR**************************/
struct detrtripstatus {
	char	depature[4];
	char	destination[4];
	char	company[4];
	char	airnum[8];
	char	seattype[4];
	char	startdata[8];
	char	starttime[8];
	char	package[4];
	char	ticstatus[16];
};

struct detrtripinfo {
	char			ticketnum[16];
	char			changenum[16];
	char			tickettype[8];
	char			passengername[32];
	char			pnrnum[8];
	char			aircomnum[8];
	int				count;
	detrtripstatus*	pstatus;
};

/**************************DETR**************************/

/**************************FSD**************************/
struct fsdlinedata
{
    int pricetype;//0:specify price '/' 1:ratio price '*'
    int singletripprice;//single trip price
    int returntripprice; // return trip price
    char minstayday[4];// min stay days
    char maxstayday[4];// max stay days
    int ticketlimitday;//ticket limit days
    char ticketlimittime[4];//4D
    char ticketdeadlinefrom[8];//ticket deadline start
    char ticketdeadlineend[8];//ticket deadline end
    char seatlimit[4];//limited seat
    char pricebasis[8];// basis of price
    char comment[8];//price comment
    char cabin[4];//cabin
};
struct fsdaircompanycode
{
    char code[4];//air company two codes
};
struct fsdpriceinfo_s
{
    int aircompanycount;//counts of air companies published price
    int linecount;
    int realtravellength;//real travel length
    int maxtravellength;//max travel length
    float exchangerate;//exchange rate
    char moneytype[4];// money type
    char traveldirect[4];//travel direct
    char searchdate[8];//search date
    char searchaircompany[4];//search air company two codes
    char citypair[8];//city pair
    char exchangeline[60];	// exchange rate
    fsdaircompanycode *aircompanys;
    fsdlinedata lines[27];
};
enum fsdlinetype
{
    AIRCOMPANY,
    INFO,
    PRICE,
    PAGE,
    RATE,
    UNKNOW
};
/**************************FSD**************************/

/**********************av special flight********************/
enum avslinetype
{
	FLIGHTNO,
    FLIGHT,
    CABIN,
    UNKNOWAVLINE
};
struct avscabin
{
    int cabincount;
    char cabins[26][4];
};
struct avsflight
{
    int distance;//miles
    int duration;//minutes
    char departureterminal[4];//1/2/3  
    char arrivalterminal[4];
    int staytime;//minutes
    char departure[4];
    char arrival[4];
    char departuretime[8];
    char arrivaltime[8];
    char week[4];
    char planetype[4];
    char mealinfo[8];
};

struct avSpecialInfo
{
    int flightcount;//flightcount
    char flightNo[8];// flight no
    avscabin cabins;
    avsflight flights[10];
};

/**********************av special flight********************/

/**********************order result********************/
struct FlightSegment 
{
    int week;                      //1-7
    int status;                     //0-4   NN DW DL UC DK
    int segindex;					//segment index
    char aircompany[4];      //ca
    char flightno[8];           //ca1234
    char cabin[4];               //a
    char flydate[8];            //24NOV
    char depature[4];          //PEK
    char arrival[4];              //SHA
    char flytime[8];             //0820
    char arrivaltime[8];        //1050
    FlightSegment()
    {
    	week = 1;
    	status = 0;
    	segindex = 1;
    	strcpy(aircompany,"CA");
    	strcpy(flightno,"CA4199");
    	strcpy(cabin,"Y");
    	strcpy(flydate,"24NOV");
    	strcpy(depature,"PEK");
    	strcpy(arrival,"SHA");
    	strcpy(flytime,"0820");
    	strcpy(arrivaltime,"1050");
    }
};
struct OrderResultInfo
{
    char pnr[8];    //HR7PDC
    int segmentcount;
    FlightSegment segments[20]; //max segments are 20
};
enum orderresultlinetype{
    ORDER_RESULT_INFO,
    ORDER_RESULT_SEGMENT,
    ORDER_RESULT_UNKOWN
};

/**********************order result********************/


#pragma pack()

class  CETermString
{
public:
	CETermString();
	virtual ~CETermString();
public:
	int DealReturnStr(const char* pstr);

	// include "\n"
    int _getOneLine(const char* pin, char* pout, unsigned int outlen);
	// return token offset 
    int _readOneToken(const char* pin, char* pout, unsigned int outlen);

//protected:
	void _freerecords(char** p, int count);
/***********************************************AVH***********************************************/
public:
	enum _avh_status {
		en_avh_number = 0,
		en_avh_airnumber,
		en_avh_timeflag,
		en_avh_seatstatus,
		en_avh_citypair,
		en_avh_starttime,
		en_avh_endtime,
		en_avh_planetype,
		en_avh_staydiner,
		en_avh_eleticket,
		en_avh_startstation,
		en_avh_endstation,
		en_avh_totaltime,
		en_avh_null,
	};
	int DealAVHStr(const char* pstr, avhtravelInfo*** pinfo, const char* pdep, const char* pdes, int *pagetype);
	
	void FreeAVHRes(avhtravelInfo** pinfo, int count);

	// get depature and destination
	bool _avhgetdepdes(const char* pstr, char* dep, char* des);

	std::string _perdealachstr(const char* pstr);

	// return -1 false; return 0 success; return 1 share airline
	int _avhfirstline(const char* pstr, avhInfo* pinfo, avhInfoEx* pinfoE);
	// return -1 false;
	int _avhsecondline(const char* pstr, bool bshare, avhInfo* pinfo, avhInfoEx* pinfoE);

	// return plane count ; -1 false
	int _avhgetrecords(const char* pstr, char*** pone, int* pagetype);

	int _avhdealonrecord(const char* pstr, avhtravelInfo* pinfo);
/***********************************************AVH***********************************************/
	
/***********************************************AVH***********************************************/
	// return 0 success ; -1 failed
	int _avdealonrecord(const char* pstr, avtravelInfo* pinfo);

	// return 0 success ; -1 failed
	int _avfirstline(const char* pstr, avInfo* pinfo, avInfoEx* pinfoE);
	
	// return plane count ; -1 false
	int _avgetrecords(const char* pstr, char*** pone, int* pagetype);

	int DealAVStr(const char* pstr, avtravelInfo*** pinfo, const char* pdep, const char* pdes, int *pagetype);

	void FreeAVRes(avtravelInfo** pinfo, int count);

/***********************************************AVH***********************************************/

/***********************************************NFD***********************************************/
protected:
public:
	enum _nfd_status {
			en_nfd_linenu = 0,
			en_nfd_company,
			en_nfd_onewaypr,
			en_nfd_roundtpr,
			en_nfd_fbc_tc,
			en_nfd_seattype,
			en_nfd_minmax,
			en_nfd_trvdate,
			en_nfd_rule,
			en_nfd_end,
		};
	int DealNFDStr(const char* pstr, nfdpriceinfo*** pinfo, const char* pdep, const char* pdes, int *pagetype);
	
	void FreeNFDRes(nfdpriceinfo** pinfo, int count);

	bool _nfdgettablepos(const char* pstr, int* arr, int size);
	int _nfdgetrecords(const char* pstr, char*** pone, int* pagetype);
	int _nfddealonerecord(const char* pstr, nfdpriceinfo* pinfo, int* pos );
	
	bool _nfdgetdepdes(const char* pstr, char* pdep, char* pdes);
/***********************************************NFD***********************************************/

/***********************************************FD***********************************************/
public:
	enum _fd_status {
			en_fd_linenu = 0,
			en_fd_company,
			en_fd_null1,
			en_fd_owprice,
			en_fd_rtprice,
	        en_fd_seattype,
			en_fd_null2,
			en_fd_null3,
			en_fd_start,
	        en_fd_end,
	        en_fd_pricecal,
			en_fd_null,
		};
	
	int DealFDStr(const char* pstr, fdpriceinfo*** pinfo, const char* pdep, const char* pdes, int distance, int *pagetype);
	
	void FreeFDRes(fdpriceinfo** pinfo, int count);
	
	int _fdgetrecords(const char* pstr, char*** pone, int* pagetype);

	int _fddealonerecord(const char* pstr, fdpriceinfo* pinfo);
	
	bool _fdgetdepdes(const char* pstr, char* pdep, char* pdes, int* pdistance);
/***********************************************FD***********************************************/

/***********************************************FSI***********************************************/
	enum _fsi_status {
		en_fsi_sword = 0,
		en_fsi_company,
		en_fsi_airnumber,
		en_fsi_start,
		en_fsi_end,
		en_fsi_plane,
		en_fsi_null,
	};

	int DealFSIStr(const char* pstr, fsqpriceinfo* pinfo);

	int DealFSQStr(const char* pstr, fsqpriceinfo* pinfo);
	
	void FreeFSIRes(fsqpriceinfo* pinfo);

	// plinebegin useful infomation start line
	bool _fsijudgement(const char* pstr, int* plinebegin);
	bool _fsiadapterinfo(const char* pstr);

	// return 1: can resolve the price info; -1 error ; 0 no price  
	int _fsigetrestype(const char* pstr);

	int _fsqgettripinfo(const char* pstr, fsqpriceinfo* pinfo);

	int _fsqgetpriceinfo(const char* pstr, fsqpriceinfo* pinfo);

	int _fdqcalculateinfo(const char* pstr, fsqpriceinfo* pinfo);

	int _floataddone(float f);

	int _intaddten(int n);

	enum _fsq_status {
		en_fsq_area = 0,
		en_fsq_seat,
		en_fsq_nvb,
		en_fsq_nva,
		en_fsq_package,

		en_fsq_fare,
		en_fsq_tax,
		en_fsq_total,
		en_fsq_cale,
		en_fsq_rate,
		en_fsq_value,
		en_fsq_null,
	};

	int _fsqdeal2type(const char* pstr, fsqpriceinfo* pinfo);

	// return -1 error; 1 start new line; 2 end by before
	int _fsqgetilinetype(const char* pstr);

	// *ATTN PRICED ON 08MAY14*1105
	bool _fsipriceflag(const char* pstr);
	
/***********************************************FSI***********************************************/
	
/***********************************************PAT***********************************************/
	enum _pat_status {
		en_pat_num = 0,
		en_pat_seat,
		en_pat_fare,
		en_pat_tax,
		en_pat_yq,
		en_pat_total,
		en_pat_null,
	};
	bool _patjudgement(const char* pstr);

	int DealPatStr(const char* pstr, patpriceinfo** pinfo);

	void FreePatRes(patpriceinfo* pinfo);
/***********************************************PAT***********************************************/

/***********************************************DETR***********************************************/
	enum _detr_status {
		en_detr_ticnum = 0,
		en_detr_issued,
		en_detr_e_r,
		en_detr_tcode,
		en_detr_passenger,
		en_detr_exch,
		en_detr_trip,
		en_detr_fc,
		en_detr_fare,
		en_detr_tax,
		en_detr_total,

		en_detr_timeflag,
		en_detr_des,
		en_detr_company1,
		en_detr_company2,
		en_detr_planenum,
		en_detr_seattype,
		en_detr_startdata,
		en_detr_starttime,
		en_detr_ok,
		en_detr_seatdetail,
		en_detr_valuedata,
		en_detr_package,
		en_detr_status,

		en_detr_airstation1,
		en_detr_airstation2,
		en_detr_pnr,
		en_detr_comnum,
		
		en_detr_null,
	};
	bool _detrjudgement(const char* pstr);

	int DealDetrStr(const char* pstr, detrtripinfo* pinfo);

	int _detrgettripinfp(const char* pstr, detrtripinfo* pinfo);

	int _detrfirstline(const char* pstr, detrtripinfo* pinfo);

	int _detrsecondline(const char* pstr, detrtripinfo* pinfo);

	void FreeDetrRes(detrtripinfo* pinfo);

/***********************************************DETR***********************************************/

/***********************************************AVFLIGHT***********************************************/
public:
	bool _getavflightinfo(const char* pstr, char* fno, char* timeend);
/***********************************************AVFLIGHT***********************************************/

    /***********************************************FSD***********************************************/
    bool isAirCompany(const std::string line);
    bool isInfo(const std::string line);
    bool isPrice(const std::string line);
    bool isPage(const std::string line);
    bool isRate(const std::string line);
    std::string trim(const std::string content,char flag=' ');
    fsdlinetype LineType(const std::string line);
    int DealFsdStr(const std::string pstr,fsdpriceinfo_s *pinfo);
    void FreeFsdRes(fsdpriceinfo_s *pinfo);
    /***********************************************FSD***********************************************/
/***********************************************AV special flight*************************************/
	bool isFlightNoInfo(const std::string line);
	bool isFlightInfo(const std::string line);
	bool isCabinInfo(const std::string line);
	avslinetype SpecialAvLineType(const std::string line);
	int DealSpecialAvStr(const std::string pstr,avSpecialInfo *pinfo);
/***********************************************AV special flight*************************************/

/**********************order result********************/
bool isOrderResultInfo(const std::string line);
bool isOrderResultSegmentInfo(const std::string line);
orderresultlinetype OrderResultLineType(const std::string line);
int weektoint(const std::string week);
int statustoint(const std::string status);
int DealOrderResultStr(const std::string pstr,OrderResultInfo *pinfo);


/**********************order result********************/



private:
	bool _is_number(char ch);
	bool _is_word(char ch);

	bool _is_number(const char* str);
	bool _is_word(const char* str); 
	bool _is_return(char ch);
	bool _is_flightnum(const char* pstr);

	void trimleft(char* pstr);
	void trimright(char* pstr);
public:
	static const  char*	s_mouth[12];
	static const  char*	s_week3[7];
	static const  char*	s_week2[7];
};

#endif // !defined(AFX_ETERMSTRING_H__E755A53C_9C46_4AFF_84A9_DB562B612D6F__INCLUDED_)
