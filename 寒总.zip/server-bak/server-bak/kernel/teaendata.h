/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-05 16:58:41
# LastModified : 2014-04-02 21:16:58
# FileName     : teaendata.h
# Description  : 
 ******************************************************************************/
#ifndef teaendata_h__
#define teaendata_h__

#include "dealnetdata.h"

const unsigned int SIZE_ENDATA = 8;
 
class TeaEndata : public IDealNetData 
{
public:
	// data encrypt
    virtual bool DealSendData(const void *datain, unsigned int inlen, void *dataout, unsigned int *outlen);
	// data decrypt
    virtual bool DealRecvData(const void *datain, unsigned int inlen, void *dataout, unsigned int *outlen);
	// return true will not DealRecvData (normaly return false)
	bool DealSpecialData(const void *data, unsigned int len);
	// get encrypt type
	virtual int GetEnType();

    TeaEndata(const char *key, int round = 32);
	void setkey(const char *key);

protected:
    void encrypt(const unsigned int *in, unsigned int *out);
    void decrypt(const unsigned int *in, unsigned int *out);
protected:
	unsigned int	m_uHeadLen;
    int				_round; //iteration round to encrypt or decrypt
    char			_key[16]; //encrypt or decrypt key
};

#endif // teaendata_h__

