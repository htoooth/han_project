/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-10 10:17:10
# LastModified : 2015-01-07 13:45:53
# FileName     : evcenter.cpp
# Description  : 
 ******************************************************************************/
#include <sys/socket.h>
#include <assert.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>
#include <arpa/inet.h>

#include <openssl/crypto.h> 
#include <openssl/x509.h> 
#include <openssl/pem.h> 
#include <openssl/ssl.h> 
#include <openssl/err.h>
#include <openssl/conf.h>
#include <openssl/engine.h>
#include <openssl/comp.h>


#include "evcenter.h"
#include "showmsg.h"
#include "dealnetdata.h"

CenterSocket::CenterSocket() {
	m_contype = en_Normal_Connect;
	m_sock = -1;
	m_isend = true;
	m_pcebase = NULL;
	m_ssl = NULL;
	m_ctx = NULL;
	m_preadev = NULL;
	m_pwriteev = NULL;
	m_pcecb = NULL;
	memset(&m_tmpdata, 0, sizeof(m_tmpdata));
}

CenterSocket::~CenterSocket() {
	if (!m_isend) {
		_stop_server();
	}
	if (m_tmpdata.pdata != NULL)
		free(m_tmpdata.pdata);
}	

bool CenterSocket::connectsocket(const char* pip, int port, int type, int timeout /*= 3*/)
{

	m_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (m_sock < 0)
		return false;

    struct hostent* phost = gethostbyname(pip);
    if (phost == NULL) {
        return false;
    }

    sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);


    struct timeval timeo = {0};
    timeo.tv_sec = timeout; 
    setsockopt(m_sock, SOL_SOCKET, SO_SNDTIMEO, &timeo, sizeof(timeo));
   
    for(int i = 0; phost->h_addr_list[i] != NULL; i++) {
         addr.sin_addr.s_addr = *((unsigned int *)phost->h_addr_list[i]);

         int res = connect(m_sock, (sockaddr*)&addr, sizeof(addr));
         if (res != 0) {
             MSGOUT(en_Msg_Error, "connect error, code:%d", res);
             continue;
         }

         m_contype = type;
         if (m_contype != en_Normal_Connect && m_contype != en_Server_Connect) {
             if(!connectSSL(m_contype))
                 return false;
         }
         int mask = fcntl(m_sock, F_GETFL, 0);
         fcntl(m_sock, F_SETFL , mask|O_NONBLOCK);

         evthread_use_pthreads();

         m_pcebase = event_base_new();
         if(m_pcebase == NULL)
             return false;

         m_preadev = (event*)malloc(sizeof(event));

         event_set(m_preadev, m_sock, EV_READ|EV_PERSIST, _on_read, this);
         event_base_set(m_pcebase, m_preadev);
         event_add(m_preadev, NULL);

         m_pwriteev = (event*)malloc(sizeof(event));
         event_set(m_pwriteev, m_sock, EV_WRITE, _on_write, this);
         event_base_set(m_pcebase, m_pwriteev);

         TAILQ_INIT(&m_qsend);

         m_isend = false;

         MSGOUT(en_Msg_Debug, "connect success");
    }

    if (m_isend) {
        return false;
    }

	pthread_t id;
	pthread_create(&id, NULL, assistfun, this);
	pthread_detach(id);

	return true;
}

bool CenterSocket::_start_server(void* pdata, ISvrCallback* pcb) {

	m_pcecb = pcb;

	return true;
}

void CenterSocket::_stop_server() {
	if (_is_end())
		return;

	closesocket();

	MSGOUT(en_Msg_Debug, "stop center socket event!!!");
//	event_base_loopexit(m_pcebase, NULL);
}

bool CenterSocket::_is_end() {
	return m_isend;
}

int CenterSocket::senddata(char* pdata, unsigned int len) {
	if (m_isend)
		return -1;

	_buf_node* pnode = (_buf_node*)malloc(sizeof(_buf_node));
	memset(pnode, 0, sizeof(_buf_node));

	if (m_contype == en_Server_Connect) {
		char* pbuf = (char*)malloc(len+sizeof(int));

		int* plen = (int*)pbuf;
		*plen = len;
		memcpy(plen+1, pdata, len);

		pnode->buf = pbuf;
		pnode->len = len+sizeof(int);
	}
	else {
		pnode->buf = (char*)malloc(len);
		memcpy(pnode->buf, pdata, len);
		pnode->len = len;
	}
	TAILQ_INSERT_TAIL(&m_qsend, pnode, enter);
	event_add(m_pwriteev, NULL);
	return len;
}

void CenterSocket::_on_read(int fd, short sock, void* arg) {
	
	CenterSocket* pthis =(CenterSocket*)arg;

	if(pthis->_is_end()) {
		return;
	}

	int res = -1;
	bool bfirst = true;
	if (pthis->m_contype == en_Server_Connect) {
	    while (1) {
	        if (pthis->m_tmpdata.totallen == 0) {
	            res = recv(fd, &pthis->m_tmpdata.totallen, sizeof(int), 0);
	            if (res <= 0) {
	                break;
	            }   
	            pthis->m_tmpdata.pdata = (char*)malloc(pthis->m_tmpdata.totallen);
//				MSGOUT(en_Msg_Debug, "total len: %d", pthis->m_tmpdata.totallen);
	        }   
	        else if (pthis->m_tmpdata.totallen > pthis->m_tmpdata.readlen) {
	            int leftlen = pthis->m_tmpdata.totallen - pthis->m_tmpdata.readlen; 
	            res = recv(fd, pthis->m_tmpdata.pdata+pthis->m_tmpdata.readlen, leftlen, 0); 
	            if (res <= 0) {
	                break;
	            }   
	            pthis->m_tmpdata.readlen += res;
//				MSGOUT(en_Msg_Debug, "total len: %d, read len: %d", pthis->m_tmpdata.totallen, pthis->m_tmpdata.readlen);
	        }   
			else if (pthis->m_tmpdata.totallen == pthis->m_tmpdata.readlen) {
				NetSocketHead* phead = (NetSocketHead*)pthis->m_tmpdata.pdata;
				if (phead->uMainCmd == (unsigned int)-1 && phead->uSubCmd == (unsigned int)-1) {
					if (phead->uHelpCmd == (unsigned int)-2) {
						pthis->senddata(pthis->m_tmpdata.pdata, pthis->m_tmpdata.totallen);
					}
				}
				else {
					if (!pthis->OnRecvData(pthis->m_tmpdata.pdata, pthis->m_tmpdata.totallen)) {
						free(pthis->m_tmpdata.pdata);
						memset(&pthis->m_tmpdata, 0, sizeof(pthis->m_tmpdata));
						pthis->closesocket();
						return ;
					}
				}
				free(pthis->m_tmpdata.pdata);
				memset(&pthis->m_tmpdata, 0, sizeof(pthis->m_tmpdata));
			}
			bfirst = false;
		}
		if (bfirst) {
			pthis->closesocket();
		}
	//	MSGOUT(en_Msg_Debug, "while(1) out!");
	}
	else if (pthis->m_contype == en_Normal_Connect) {
		char buf[MAX_BUFFSIZE] = {0};
		unsigned len = sizeof(buf);
		res = recv(fd, buf, len, 0);
		if (res < 0) {
            if (errno == EAGAIN) {
                return;
            }
            MSGOUT(en_Msg_Debug, "close, res: %d, errno: %d, EAGAIN: %d", res, errno, EAGAIN);
			pthis->_on_close();
			return ;
		}

		if (!pthis->OnRecvData(buf, res)) {
			pthis->closesocket();
		}
	}
	else {
		if (pthis->m_ssl != NULL) {
			char buf[MAX_BUFFSIZE] = {0};
			unsigned int len = MAX_BUFFSIZE;
			res = SSL_read(pthis->m_ssl, buf, len);
			if (res < 0) {
                if (errno == EAGAIN) {
                    return;
                }
                MSGOUT(en_Msg_Debug, "close, res: %d, errno: %d, EAGAIN: %d", res, errno, EAGAIN);
				pthis->_on_close();
                return;
            }
            if (!pthis->OnRecvData(buf, res)) {
                pthis->closesocket();
            }
		}
	}
}

void* CenterSocket::assistfun(void* pdata) {

	CenterSocket* pthis = (CenterSocket*)pdata;
	MSGOUT(en_Msg_Normal, "start dispatch!!!");

	event_base_dispatch(pthis->m_pcebase);

	event_base_free(pthis->m_pcebase);
	pthis->m_pcebase = NULL;

	libevent_global_shutdown();

	MSGOUT(en_Msg_Normal, "stop server!!!");
	if(pthis->m_pcecb != NULL) {
		pthis->m_pcecb->_end_callback("CenterSocket", pthis, 0);
	}
	return NULL;
}

bool CenterSocket::connectSSL(int type) {

	X509* server_cert = NULL; 
	char *str = NULL;

    SSL_library_init();

    SSLeay_add_ssl_algorithms(); 

    SSL_load_error_strings(); 

	switch(m_contype) {
		case en_SSLv2_Connect:
			m_ctx = SSL_CTX_new(SSLv2_client_method()); 
			break;
		case en_SSLv3_Connect:
			m_ctx = SSL_CTX_new(SSLv3_client_method()); 
			break;
		case en_SSLv23_Connect:
			m_ctx = SSL_CTX_new(SSLv23_client_method()); 
			break;
		case en_TLSv1_Connect:
			m_ctx = SSL_CTX_new(TLSv1_client_method()); 
			break;
		case en_DTLSv1_Connect:
			m_ctx = SSL_CTX_new(DTLSv1_client_method()); 
			break;
		default: 
		{
			close(m_sock);
			m_sock = -1;
			return false;
		}
		break;
	}

	if (m_ctx == NULL)
		return false;

	m_ssl = SSL_new(m_ctx);    
	if (m_ssl == NULL)
		return false;

	int res = SSL_set_fd(m_ssl, m_sock);

	MSGOUT(en_Msg_Debug, "m_ctx:%p, m_sock:%d, m_ssl:%p, res:%d", m_ctx, m_sock, m_ssl, res);

	res = SSL_connect(m_ssl);
	if (res < 0) {
		int code = SSL_get_error(m_ssl, res);
		MSGOUT(en_Msg_Debug, "SSL_connect res:%d, error code:%d", res, code);
		return false;
	}

	server_cert = SSL_get_peer_certificate(m_ssl);
	str = X509_NAME_oneline(X509_get_subject_name(server_cert), 0, 0);
	if (str == NULL)
		return false;

	OPENSSL_free(str);

	str = X509_NAME_oneline(X509_get_issuer_name(server_cert),0,0);
	if (str == NULL)
		return false;

	OPENSSL_free(str);
	X509_free(server_cert);

    ERR_remove_state(0);
                       
	return true;
}

void CenterSocket::closesocket() {
	if(_is_end())
		return ;

	_buf_node* pnode = (_buf_node*)malloc(sizeof(_buf_node));
	memset(pnode, 0, sizeof(_buf_node));

	TAILQ_INSERT_TAIL(&m_qsend, pnode, enter);
	event_add(m_pwriteev, NULL);  

	MSGOUT(en_Msg_Debug, "centsocket close!!!");
}

void CenterSocket::_on_write(int fd, short ev, void* arg) {
	CenterSocket* pthis = (CenterSocket*)arg;

	_buf_node* pbuf = TAILQ_FIRST(&pthis->m_qsend);
	if (pbuf == NULL)
		return;
	
	if (pbuf->len == 0) {
		TAILQ_REMOVE(&pthis->m_qsend, pbuf, enter);
		free(pbuf);
		pthis->_on_close();
		MSGOUT(en_Msg_Debug, "close!!!");
		return;
	}

	unsigned int len = -1;
	if (pthis->m_contype == en_Server_Connect || pthis->m_contype == en_Normal_Connect) {
		len = pbuf->len - pbuf->offset;
		len = write(fd, pbuf->buf + pbuf->offset,
						pbuf->len - pbuf->offset);

// 		MSGOUT(en_Msg_Debug, "fd : %d, len: %d, offset: %d, sendlen: %d", 
// 				fd, pbuf->len - pbuf->offset, pbuf->offset, len);
	}
	else {
		if (pthis->m_ssl != NULL) {
			len = SSL_write(pthis->m_ssl, pbuf->buf+pbuf->offset, pbuf->len - pbuf->offset);
//             MSGOUT(en_Msg_Debug, "len: %d, offset: %d, sendlen: %d", 
//                 pbuf->len - pbuf->offset, pbuf->offset, len);
        }
	}
	if (len == (unsigned int )-1) {
		if (errno == EINTR || errno == EAGAIN) {
			event_add(pthis->m_pwriteev, NULL);			
			return;
		}
		else {
			pthis->closesocket();
			return;
		}
	}
	else if (pbuf->offset+len < pbuf->len) {
		pbuf->offset += len;
		event_add(pthis->m_pwriteev, NULL);			
		return ;
	}
	TAILQ_REMOVE(&pthis->m_qsend, pbuf, enter);
	free(pbuf->buf);
	free(pbuf);
	if (TAILQ_FIRST(&pthis->m_qsend) != NULL) {
		event_add(pthis->m_pwriteev, NULL);
		return;
	}
}

void CenterSocket::_on_close() {

	m_isend = true;

	if(m_ssl != NULL) {
        SSL_shutdown(m_ssl);
/*
        char buf[4096] = {0};

        int nread = (ssize_t)SSL_read(m_ssl, buf, sizeof(buf));
        int err = SSL_get_error(m_ssl, (int)nread);

        switch(err) {
        case SSL_ERROR_NONE:
        case SSL_ERROR_ZERO_RETURN:
          MSGOUT(en_Msg_Debug, "This is the expected response. There was no data but only the close notify alert");
          break;
        case SSL_ERROR_WANT_READ:
          MSGOUT(en_Msg_Debug, "there's data pending, re-invoke SSL_read()");
          break;
        case SSL_ERROR_WANT_WRITE:
          MSGOUT(en_Msg_Debug, "SSL wants a write. Really odd. Let's bail out.");
          break;
        default:
            {
                int sslerror = ERR_get_error();
                MSGOUT(en_Msg_Debug, "openssl/ssl.h says look at error stack/return value/errno, err str: %s", ERR_error_string(sslerror, buf));
            }
        }

        switch(SSL_get_shutdown(m_ssl)) {
        case SSL_SENT_SHUTDOWN:
            MSGOUT(en_Msg_Debug, "SSL_get_shutdown() returned SSL_SENT_SHUTDOWN\n");
            break;
        case SSL_RECEIVED_SHUTDOWN:
            MSGOUT(en_Msg_Debug, "SSL_get_shutdown() returned SSL_RECEIVED_SHUTDOWN\n");
            break;
        case SSL_SENT_SHUTDOWN|SSL_RECEIVED_SHUTDOWN:
            MSGOUT(en_Msg_Debug, "SSL_get_shutdown() returned SSL_SENT_SHUTDOWN|"
                "SSL_RECEIVED__SHUTDOWN\n");
            break;
        }
        */

        SSL_free(m_ssl);
        m_ssl = NULL;
        SSL_CTX_free(m_ctx);
        m_ctx = NULL;
                            
// 		CONF_modules_unload(1); 
//         CONF_modules_free();

//        ERR_clear_error();
        ERR_free_strings();
        ERR_remove_thread_state(NULL);  
        ERR_remove_state(0);

//		ENGINE_cleanup();
		EVP_cleanup();
		CRYPTO_cleanup_all_ex_data();
// 		stack_st_SSL_COMP* p = SSL_COMP_get_compression_methods();
// 		if (p != NULL)
//             sk_SSL_COMP_free(p); 

        COMP_zlib_cleanup();
        
	}                         

    if (m_preadev != NULL) {
        event_del(m_preadev);
        free(m_preadev);
        m_preadev = NULL;
    }
    if (m_pwriteev != NULL) {
        //	event_del(m_pwriteev);
        free(m_pwriteev);
        m_pwriteev = NULL;
    }

	if (m_sock != -1) {
		//	shutdown(m_sock, SHUT_RDWR);
		close(m_sock);
		m_sock = -1;
	}
	_buf_node* pbuf = TAILQ_FIRST(&m_qsend);
	while (pbuf) {
		TAILQ_REMOVE(&m_qsend, pbuf, enter);
		free(pbuf->buf);
		free(pbuf);
		pbuf = TAILQ_FIRST(&m_qsend);
	}
    event_base_loopbreak(m_pcebase);

	OnClose();
}

void CenterSocket::releasesslres()
{
    stack_st_SSL_COMP* p = SSL_COMP_get_compression_methods();
    if (p != NULL)
        sk_SSL_COMP_free(p); 
}
