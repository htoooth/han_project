/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-25 16:25:14
# LastModified : 2014-12-26 16:58:37
# FileName     : odbmysqlmgr.h
# Description  : 
 ******************************************************************************/
#ifndef _ODBMYSQLMGR_H
#define _ODBMYSQLMGR_H

#include <mysql/mysql.h>
#include <list>
#include <string>

#include <odb/database.hxx>
#include <odb/transaction.hxx>

#include <odb/mysql/database.hxx>

#include "database.h"
#include "baseserver.h"

typedef odb::core::database ODB_MYSQL;

class OdbMySqlMgr : public DataBaseClass {
public:
	OdbMySqlMgr();
	virtual ~OdbMySqlMgr();
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual bool _is_end();
public:
	std::list<ODB_MYSQL*>	m_idle;
	_mysql_param		m_sqlparam;
	bool				m_isend;
public:
	virtual void* GetIdleDB();
	virtual bool SaveIdleDB(void* psql);
	virtual void* NewIdleDB();
	virtual void FreeConnect(void* psql);
protected:
	pthread_mutex_t	m_mulock;
};

#endif // _MYSQLMGR_H
