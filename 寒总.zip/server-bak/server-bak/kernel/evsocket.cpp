/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-13 10:48:57
# LastModified : 2015-01-07 13:44:42
# FileName     : evsocket.cpp
# Description  : 
 ******************************************************************************/
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <fcntl.h>
#include <event2/thread.h>
#include <sys/queue.h>

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/conf.h>
#include <openssl/engine.h>
#include <openssl/comp.h>

#include "evsocket.h"
#include "dealnetdata.h"
#include "showmsg.h"

unsigned int SocketModule::senddata(int fd, void *pdata, unsigned int ulen) {

	if(m_issoend)
		return -1;

	std::map<int, void*>::iterator it = m_mapevent.find(fd);
	if (m_mapevent.end() == it)
		return -1;

	_buf_node* pnode = NULL;
	_socket_param* p = (_socket_param*)it->second;
	if (p == NULL || p->bclosed) {
		return -1;
	}
	if (m_type == en_Server_Connect) {
		if (p->pdeal != NULL) {
			char* pbuf = (char*)malloc(ulen);
			unsigned int len = ulen;
			p->pdeal->DealSendData(pdata, ulen, pbuf, &len);
		
			char* ptemp = (char*)malloc(len+sizeof(int));
			int* plen = (int*)ptemp;
			*plen = len;
			memcpy(plen+1, pbuf, len);
			free(pbuf);

			pnode = (_buf_node*)malloc(sizeof(_buf_node));
			memset(pnode, 0, sizeof(_buf_node));

			pnode->buf = ptemp;
			pnode->len = len+sizeof(int);
			pnode->offset = 0;
		}
		else {
			char* ptemp = (char*)malloc(ulen+sizeof(int));
			int* plen = (int*)ptemp;
			*plen = ulen;
			memcpy(plen+1, pdata, ulen);

			pnode = (_buf_node*)malloc(sizeof(_buf_node));
			memset(pnode, 0, sizeof(_buf_node));
			pnode->buf = ptemp;
			pnode->len = ulen+sizeof(int);
			pnode->offset = 0;
		}
	}
	else {
		char* ptemp = (char*)malloc(ulen);
		memcpy(ptemp, pdata, ulen);

		pnode = (_buf_node*)malloc(sizeof(_buf_node));
		memset(pnode, 0, sizeof(_buf_node));
		pnode->buf = ptemp;
		pnode->len = ulen;
		pnode->offset = 0;
	}

	if (pnode != NULL) {
		TAILQ_INSERT_TAIL(&p->qsend, pnode, enter);
		event_add(p->pevwrite, NULL);

		return ulen;
	}
	else {
		return -1;
	}
}

void SocketModule::closeconnect(int fd) {

	std::map<int, void*>::iterator it = m_mapevent.find(fd);
	if (m_mapevent.end() == it)
		return;

	_socket_param* p = (_socket_param*)it->second;
	if (p->bclosed)
		return;

	p->bclosed = true;

	_buf_node* pnode = (_buf_node*)malloc(sizeof(_buf_node));
	memset(pnode, 0, sizeof(_buf_node));

	TAILQ_INSERT_TAIL(&p->qsend, pnode, enter);
	event_add(p->pevwrite, NULL);
}

void* SocketModule::assistfun(void* pdata) {
	SocketModule *pthis = (SocketModule*)pdata;
	
	MSGOUT(en_Msg_Normal, "start dispatch!!!");

	event_base_dispatch(pthis->m_psobase);

	event_base_free(pthis->m_psobase);
	pthis->m_psobase = NULL;

	libevent_global_shutdown();

	MSGOUT(en_Msg_Normal, "stop server!!!");
	if(pthis->m_psocb != NULL) {
		pthis->m_psocb->_end_callback("SocketModule", pthis, 0);
	}
	return NULL;
}

bool SocketModule::_start_server(void* pdata, ISvrCallback* pcb) {
	if (m_psobase != NULL)
		return true;

	evthread_use_pthreads();

	m_psocb = pcb;

	_bindparam* pparam = (_bindparam*)pdata;
	m_port = pparam->port;
	m_type = pparam->type;

	sockaddr_in addr = {0};
	m_svrsock = socket(AF_INET, SOCK_STREAM, 0);
	if (m_svrsock == -1) {
		MSGOUT(en_Msg_Error, "socket error");
		return false;
	}
	int yes = 1;
	setsockopt(m_svrsock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(m_port);
	addr.sin_addr.s_addr = INADDR_ANY;

	int res = bind(m_svrsock, (struct sockaddr*)&addr, sizeof(addr));

	if (m_type != en_Normal_Connect && m_type != en_Server_Connect) {
		m_ctx = createctx(m_type);
		if (m_ctx == NULL) {
			return false;
		}
	}

	if (res == -1) {
		MSGOUT(en_Msg_Error, "bind error");
		return false;
	}
	listen(m_svrsock, 10);

	int mask = fcntl(m_svrsock, F_GETFL, 0);
	fcntl(m_svrsock, F_SETFL , mask|O_NONBLOCK);

	MSGOUT(en_Msg_Debug, "listen OK!!! port:%d", m_port);

	m_psobase = event_base_new();

	m_plisev = (event*)malloc(sizeof(event));
	memset(m_plisev, 0, sizeof(event));
	event_set(m_plisev, m_svrsock, EV_READ|EV_PERSIST, _on_accept, this);

	event_base_set(m_psobase, m_plisev);
	event_add(m_plisev, NULL);

	MSGOUT(en_Msg_Debug, "add listen event!");

	pthread_create(&m_thid, NULL, assistfun, this);
	pthread_detach(m_thid);

	m_issoend = false;

	return true;
}

void SocketModule::_stop_server() {
	if (m_issoend || m_psobase == NULL)
		return ;
	m_issoend = true;

	event_del(m_plisev);
	free(m_plisev);
	m_plisev = NULL;

	if (m_svrsock != -1) {
	//	shutdown(m_svrsock, SHUT_RDWR);
		close(m_svrsock);
	}

	std::map<int, void*>::iterator ibegin = m_mapevent.begin();
	std::map<int, void*>::iterator iend = m_mapevent.end();
	for ( ;ibegin != iend; ibegin++) {
		_socket_param* p = (_socket_param*)ibegin->second;
		event_del(p->pevread);
		free(p->pevread);

		event_del(p->pevwrite);
		free(p->pevwrite);

		if (p->ssl != NULL) {
			SSL_shutdown(p->ssl);
			SSL_free(p->ssl);
		}
		_buf_node* pbuf = TAILQ_FIRST(&p->qsend);
		while(pbuf) {
			free(pbuf->buf);
			free(pbuf);
			TAILQ_REMOVE(&p->qsend, pbuf, enter);
			pbuf = TAILQ_FIRST(&p->qsend);
		}
		if (p->tmpdata.pdata != NULL) {
			free(p->tmpdata.pdata);
		}
	//	shutdown(ibegin->first, SHUT_RDWR);
		close(ibegin->first);
		free(p);
	}
	m_mapevent.clear();
	if (m_ctx != NULL) {
		SSL_CTX_free(m_ctx);
		m_ctx = NULL;

		CONF_modules_free();
		ERR_remove_state(0);
		COMP_zlib_cleanup();
		ENGINE_cleanup();
		CONF_modules_unload(1);
		ERR_free_strings();
		EVP_cleanup();
		CRYPTO_cleanup_all_ex_data();
		stack_st_SSL_COMP* p = SSL_COMP_get_compression_methods();
		if (p != NULL) 
			sk_SSL_COMP_free(p);
	}
	MSGOUT(en_Msg_Debug, "stop socket event!!!");

//	event_base_loopexit(m_psobase, NULL);
	event_base_loopbreak(m_psobase);
}

SocketModule::SocketModule() {
	m_psobase = NULL;
	m_pdealdata = NULL;
	m_psocb = NULL;
	m_issoend = true;
	m_mapevent.clear();
	m_ssl = NULL;
	m_ctx = NULL;
	m_svrsock = -1;
	m_plisev = NULL;
	m_port = -1;
	m_type = en_Normal_Connect;
    m_thid = -1;
}

SocketModule::~SocketModule() {
	if (!_is_end()) {
		_stop_server();
	}
}

bool SocketModule::_is_end() {
	return m_issoend;
}

void SocketModule::_on_read(int fd, short ev, void* arg) {

	SocketModule* pthis = (SocketModule*)arg;
	if (pthis->_is_end())
		return ;

	std::map<int, void*>::iterator it = pthis->m_mapevent.find(fd);
	if (it == pthis->m_mapevent.end()) {
		return;
	}
	_socket_param* p = (_socket_param*)it->second;
	if (p->bclosed) {
		return ;
	}

	if (pthis->m_type == en_Server_Connect) {
		int res = 0;
		bool bfirst = true;
		while (1) {
			if (p->tmpdata.totallen == 0) {
				res = recv(fd, &p->tmpdata.totallen, sizeof(int), 0);
				if (res <= 0) {
					break;
				}
				p->tmpdata.pdata = (char*)malloc(p->tmpdata.totallen);
			}
			else if (p->tmpdata.totallen > p->tmpdata.readlen){
				int leftlen = p->tmpdata.totallen - p->tmpdata.readlen; 
				res = recv(fd, p->tmpdata.pdata+p->tmpdata.readlen, leftlen, 0);
				if (res <= 0) {
					break;
				}
				p->tmpdata.readlen += res;
			}
			else if (p->tmpdata.totallen == p->tmpdata.readlen && p->tmpdata.totallen != 0) {
	
				char* ptemp = (char*)malloc(p->tmpdata.totallen);
	
				unsigned int len = p->tmpdata.totallen;

				if (p->pdeal != NULL) {
					p->pdeal->DealRecvData(p->tmpdata.pdata, p->tmpdata.totallen, ptemp, &len);
				}
				else {
					memcpy(ptemp, p->tmpdata.pdata, len);
				}

				free(p->tmpdata.pdata);
				memset(&p->tmpdata, 0, sizeof(p->tmpdata));
	
				if(!pthis->onread(fd, ptemp, len)) {
					free(ptemp);
					pthis->closeconnect(fd);
					return ;
				}
				free(ptemp);
			}
			bfirst = false;
		}
		if (bfirst) {
			pthis->_on_close(fd);
			return;
		}
	}
	else if (pthis->m_type == en_Normal_Connect) {
		char buf[MAX_BUFFSIZE] = {0};
		int res = recv(fd, buf, sizeof(buf), 0);
		if (res <= 0) {
			pthis->_on_close(fd);
			return;
		}
	
		if(!pthis->onread(fd, buf, res)) {
			pthis->closeconnect(fd);
			return;
		}
	}
	else {
		if (p->ssl == NULL) {
			pthis->closeconnect(fd);
			return;
		}
		else {
			char buf[MAX_BUFFSIZE] = {0};
			int len = SSL_read(p->ssl, buf, sizeof(buf));	
			if (len <= 0) {
				pthis->_on_close(fd);
				return;
			}
			if(!pthis->onread(fd, buf, len)) {
				pthis->closeconnect(fd);
				return;
			}
		}
	}
}

void SocketModule::setdealdataptr(int fd, IDealNetData* pdeal) {
	if(fd == -1) {
		m_pdealdata = pdeal;
	}
	else
	{
		std::map<int, void*>::iterator it = m_mapevent.find(fd);
		if (it == m_mapevent.end())
			return ;

		_socket_param* p = (_socket_param*)it->second;
		p->pdeal = pdeal;
	}
}

void SocketModule::_on_accept(int fd, short ev, void* arg) {

	SocketModule* pthis = (SocketModule*)arg;
	if (pthis->_is_end())
		return ;

	struct sockaddr_in claddr = {0};
	socklen_t slen = sizeof(claddr);
	int cfd = accept(fd, (sockaddr*)&claddr, &slen);
	if (cfd == -1) {
		MSGOUT(en_Msg_Error, "error!!!");
		return;
	}

	if (!pthis->onconnect(cfd, &claddr)) {
		MSGOUT(en_Msg_Debug, "close socket fd:%d", cfd);
		shutdown(cfd, SHUT_RDWR);
		close(cfd);
		return;
	}
	_socket_param* pev = (_socket_param*)malloc(sizeof(_socket_param));
	memset(pev, 0, sizeof(_socket_param));
	pev->pdeal = pthis->m_pdealdata;

	if (pthis->m_type != en_Normal_Connect && pthis->m_type != en_Server_Connect) {
		if (pthis->m_ctx != NULL) {
			pev->ssl = SSL_new(pthis->m_ctx);
			SSL_set_fd(pev->ssl, cfd);
			int res = SSL_accept(pev->ssl);
            if (res == -1) {
                MSGOUT(en_Msg_Debug, "accept error: %d", res);
                close(cfd);
                return;
            }
            ERR_remove_state(0);
            MSGOUT(en_Msg_Debug, "accept socket fd: %d, res: %d", cfd, res); 
		}
		else {
//			shutdown(cfd, SHUT_RDWR);
            MSGOUT(en_Msg_Debug, "ctx NULL!!!!");
			close(cfd);
			return;
		}
	}

    int mask = fcntl(cfd, F_GETFL, 0);
    fcntl(cfd, F_SETFL , mask|O_NONBLOCK);

	pev->pevread = (event*)malloc(sizeof(event));
	event_set(pev->pevread, cfd, EV_READ|EV_PERSIST, _on_read, arg);
	event_base_set(pthis->m_psobase, pev->pevread);
	event_add(pev->pevread, NULL);

	pev->pevwrite = (event*)malloc(sizeof(event));
	event_set(pev->pevwrite, cfd, EV_WRITE, _on_write, arg);
	event_base_set(pthis->m_psobase, pev->pevwrite);

	TAILQ_INIT(&pev->qsend);

	pthis->m_mapevent[cfd] = pev;

	MSGOUT(en_Msg_Debug, "accept success fd:%d", cfd);
}

SSL_CTX* SocketModule::createctx(int type) {
	SSL_CTX* ctx = NULL;
	switch(type) {
		case en_SSLv2_Connect:
		{
			SSL_library_init();
			OpenSSL_add_all_algorithms();
			SSL_load_error_strings();
			ctx = SSL_CTX_new(SSLv2_server_method());
		}
		break;
		case en_SSLv3_Connect:
		{
			SSL_library_init();
			OpenSSL_add_all_algorithms();
			SSL_load_error_strings();
			ctx = SSL_CTX_new(SSLv3_server_method());
		}
		break;
		case en_SSLv23_Connect:
		{
			SSL_library_init();
			OpenSSL_add_all_algorithms();
			SSL_load_error_strings();
			ctx = SSL_CTX_new(SSLv23_server_method());
		}
		break;
		case en_TLSv1_Connect:
		{
			SSL_library_init();
			OpenSSL_add_all_algorithms();
			SSL_load_error_strings();
			ctx = SSL_CTX_new(TLSv1_server_method());
		}
		break;
		case en_DTLSv1_Connect:
		{
			SSL_library_init();
			OpenSSL_add_all_algorithms();
			SSL_load_error_strings();
			ctx = SSL_CTX_new(DTLSv1_server_method());
		}
		break;
		default:
		{
			MSGOUT(en_Msg_Error, "undefine connect type");
			return NULL;
		}
	}
	if (ctx == NULL) {
		ERR_print_errors_fp(stderr);
		return NULL;
	}
	if(SSL_CTX_use_certificate_file(ctx, __CA_FILE, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);
		return NULL;
	}
	if(SSL_CTX_use_PrivateKey_file(ctx, __KEY_FILE, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);
		return NULL;
	}
	if(!SSL_CTX_check_private_key(ctx)) {
		ERR_print_errors_fp(stderr);
		return NULL;
	}
	return ctx;
}

void SocketModule::_on_write(int fd, short ev, void* arg) {
	SocketModule* pthis = (SocketModule*)arg;

	if (pthis->m_mapevent.find(fd) ==  pthis->m_mapevent.end()) {
		return;
	}
	_socket_param* p = (_socket_param*)pthis->m_mapevent[fd];
	if (p == NULL) {
		return;
	}
	_buf_node* pbuf = TAILQ_FIRST(&p->qsend);
	if (pbuf == NULL)
		return;
	
	if (pbuf->len == 0 && p->bclosed) {
		TAILQ_REMOVE(&p->qsend, pbuf, enter);
		free(pbuf);
		pthis->_on_close(fd);
		//MSGOUT(en_Msg_Debug, "_on_write close socket ,fd: %d", fd);
		return;
	}

	unsigned int len = -1;
	if (pthis->m_type == en_Server_Connect || pthis->m_type == en_Normal_Connect) {
		len = pbuf->len - pbuf->offset;
	//	MSGOUT(en_Msg_Debug, "fd : %d, len: %d, offset: %d, res: %d", fd, pbuf->len - pbuf->offset, pbuf->offset, len);
		len = write(fd, pbuf->buf + pbuf->offset,
						pbuf->len - pbuf->offset);

//		MSGOUT(en_Msg_Debug, "fd : %d, len: %d, offset: %d, res: %d", fd, pbuf->len - pbuf->offset, pbuf->offset, len);
	}
	else {
		if (p->ssl != NULL)
			len = SSL_write(p->ssl, pbuf->buf+pbuf->offset, 
								pbuf->len - pbuf->offset);

        MSGOUT(en_Msg_Debug, "fd : %d, len: %d, offset: %d, res: %d", fd, pbuf->len - pbuf->offset, pbuf->offset, len);
	}
	if (len == (unsigned int )-1) {
		if (errno == EINTR || errno == EAGAIN) {
			event_add(p->pevwrite, NULL);			
			return;
		}
		else {
			pthis->closeconnect(fd);
			return;
		}
	}
	else if (pbuf->offset+len < pbuf->len) {
		pbuf->offset += len;
		event_add(p->pevwrite, NULL);			
		return ;
	}
	TAILQ_REMOVE(&p->qsend, pbuf, enter);
	free(pbuf->buf);
	free(pbuf);
	if (TAILQ_FIRST(&p->qsend) != NULL) {
		event_add(p->pevwrite, NULL);
	}
}

void SocketModule::_on_close(int fd) {

	std::map<int, void*>::iterator it = m_mapevent.find(fd);
	if (m_mapevent.end() == it)
		return;

	_socket_param* p = (_socket_param*) it->second;
	m_mapevent.erase(it);

	p->bclosed = true;

	MSGOUT(en_Msg_Debug, "fd:%d param:%p", fd, p);
	if (p == NULL)
		return;

	if (p->pevread != NULL) {
		event_del(p->pevread);
		free(p->pevread);
	}

	if (p->pevwrite != NULL) {
		event_del(p->pevwrite);
		free(p->pevwrite);
	}

	if (p->ssl != NULL) {
		SSL_shutdown(p->ssl);
		SSL_free(p->ssl);
	}
	_buf_node* pbuf = TAILQ_FIRST(&p->qsend);
	while (pbuf) {
		TAILQ_REMOVE(&p->qsend, pbuf, enter);
		free(pbuf->buf);
		free(pbuf);
		pbuf = TAILQ_FIRST(&p->qsend);
	}
	if (p->tmpdata.pdata != NULL) {
		free(p->tmpdata.pdata);
	}
	//	shutdown(fd, SHUT_RDWR);
	close(fd);
	free(p);

	onclose(fd);
}

pthread_t SocketModule::getsockthreadid()
{
    return m_thid;
}
