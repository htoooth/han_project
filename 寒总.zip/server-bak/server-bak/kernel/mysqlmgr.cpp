/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-25 16:57:08
# LastModified : 2014-12-27 13:21:18
# FileName     : mysqlmgr.cpp
# Description  : 
 ******************************************************************************/
#include <string.h>
#include <stdlib.h>

#include "mysqlmgr.h"
#include "showmsg.h"

bool MySqlMgr::_start_server(void* pdata, ISvrCallback* pcb) {
	_mysql_param* p = (_mysql_param*)pdata;
	memcpy(&m_sqlparam, p, sizeof(_mysql_param));
	m_isend = false;
	return true;
}

void MySqlMgr::_stop_server() {
	m_isend = true;
	MYSQL *p = NULL;
	pthread_mutex_lock(&m_mulock);
	while(!m_idle.empty()) {
		p = m_idle.front();
		m_idle.pop_front();
		mysql_close(p);
		free(p);
	}
	pthread_mutex_unlock(&m_mulock);
	mysql_server_end();
}

bool MySqlMgr::_is_end() {
	return m_isend;
}

void* MySqlMgr::GetIdleDB() {
	if(m_isend)
		return NULL;
	MYSQL *p = NULL;
	pthread_mutex_lock(&m_mulock);
	//MSGOUT(en_Msg_Debug, "size:%d", m_idle.size());
	if (m_idle.empty()) {
		pthread_mutex_unlock(&m_mulock);
		return p;
	}
	p = m_idle.front();
	m_idle.pop_front();
	pthread_mutex_unlock(&m_mulock);
	if (!IsConnect(p)) {
		if (!Connect(p)) {
			free(p);
			return NULL;
		}
	}
	return p;
}

bool MySqlMgr::SaveIdleDB(void* psql) {
	pthread_mutex_lock(&m_mulock);
	m_idle.push_back((MYSQL*)psql);
	pthread_mutex_unlock(&m_mulock);
	return true;
}

void* MySqlMgr::NewIdleDB() {
	if(m_isend)
		return NULL;
    mysql_thread_init();
	MYSQL* p = (MYSQL*)malloc(sizeof(MYSQL));
	mysql_init(p);
	if (!Connect(p)) {
		free(p);
        mysql_thread_end();
		return NULL;
	}
    mysql_thread_end();
	return p;
}

bool MySqlMgr::IsConnect(MYSQL* psql) {
	return (0 == mysql_ping(psql));
}

bool MySqlMgr::Connect(MYSQL* psql) {
	if (NULL == mysql_real_connect(psql, m_sqlparam.addr, m_sqlparam.username, 
			m_sqlparam.passwd, m_sqlparam.dbname, m_sqlparam.port, NULL, 
			CLIENT_BASIC_FLAGS))//CLIENT_FOUND_ROWS|CLIENT_MULTI_RESULTS));
		return false;
	if(0 != mysql_set_character_set(psql, m_sqlparam.charset))
		return false;
//	MSGOUT(en_Msg_Debug, "New client character set: %s", mysql_character_set_name(psql));
	return true;
}

void MySqlMgr::FreeConnect(void* p) {
	if (p != NULL) {
		mysql_close((MYSQL*)p);
		free(p);
	}
}

MySqlMgr::MySqlMgr() {
	pthread_mutex_init(&m_mulock, NULL);
	m_isend = true;
}

MySqlMgr::~MySqlMgr() {
	if(!m_idle.empty())
		_stop_server();
	pthread_mutex_destroy(&m_mulock);
}
