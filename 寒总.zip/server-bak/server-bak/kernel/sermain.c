/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-18 20:52:38
# LastModified : 2014-11-04 17:33:12
# FileName     : sermain.c
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "serverset.h"
#include "queuebase.h"

class my_ser : public ServerSet {
public:
	virtual bool OnSocketRead(int fd, void* pdata, unsigned int ulen) {
		fprintf(stderr, "fd:%d, size:%u\n", fd, ulen);
		senddata(fd, pdata, ulen);
		return true;
	}

	virtual bool OnSocketConnect(int fd, struct sockaddr_in* paddr) {
		fprintf(stderr, "fd:%d connect!!!\n", fd);	
		return true;
	}

	virtual void OnSocketClose(int fd) {
		fprintf(stderr, "close fd:%d\n", fd);
	}

	virtual void OnEventTimer(unsigned int uid) {
		fprintf(stderr, "ontimer id:%u\n", uid);
	}

	virtual void SettleDBResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
		fprintf(stderr, "on db result, main:%d, assist:%d, ulen:%u\n", maincmd, assistcmd, ulen);
	}
	virtual bool _start() {
		fprintf(stderr, "start !!!!\n");
		return true;
	}
	virtual void _stop() {
		fprintf(stderr, "stop!!!\n");
	}
};

class my_event : public QueueEventModule {
public:
	virtual void SettleQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
		fprintf(stderr, "queue event, main:%d, assist:%d, ulen:%u\n", maincmd, assistcmd, ulen);
	}
};

int main(int argc, char *argv[]) {
	
	my_event ev;
	my_ser ser;
//	ser.setdealdataptr(NULL);
	ser.StartServer(&ev, 57329,  en_Normal_Connect, 4);

	fprintf(stderr, "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");

	return true;
}
