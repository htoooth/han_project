/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-17 10:35:08
# LastModified : 2014-11-12 19:07:47
# FileName     : serverset.cpp
# Description  : 
 ******************************************************************************/
#include <signal.h>
#include <event.h>
#include <unistd.h>

#include "serverset.h"
#include "showmsg.h"

ServerSet* ServerSet::m_pSer = NULL;

void ServerSet::PostDBRequest(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	if(m_pDB != NULL)
		m_pDB->PostQueueEvent(maincmd, assistcmd, pdata, ulen, pclient);
}

// return false will close conncet
bool ServerSet::onread(int fd, void* pdata, unsigned int ulen) {
	NetSocketHead* phead = (NetSocketHead*)pdata;
	if (phead == NULL || ulen == 0 || ulen == (unsigned int)-1) {
		return false;
	}
	if (phead->uMainCmd == (unsigned int)-1 && phead->uSubCmd == (unsigned int)-1) {
		if (phead->uHelpCmd == (unsigned int)-2) {
			if (m_mapevent.find(fd) == m_mapevent.end() 
					|| m_mapofftime.find(fd) == m_mapofftime.end())
				return false;
			m_mapofftime[fd] = time(NULL);
//			MSGOUT(en_Msg_Debug, "recv heart beat package, fd : %d", fd);
		}
		return true;
	}
    PostEventResult(DB_MAINCMD_SYSTEMCTL, DB_ASSISTCMD_SYSRECVDATA, pdata, ulen, (void*)(long)fd);
	return true;//OnSocketRead(fd, pdata, ulen);
}

// return false will close connect
bool ServerSet::onconnect(int fd, struct sockaddr_in* paddr) {
	m_mapofftime[fd] = time(NULL);
//	MSGOUT(en_Msg_Debug, "fd : %d, time_t : %u", fd, time(NULL));
	return OnSocketConnect(fd, paddr);
}

void ServerSet::onclose(int fd) {
	if (m_mapofftime.find(fd) != m_mapofftime.end())
		m_mapofftime.erase(fd);

    SendEventResult(DB_MAINCMD_SYSTEMCTL, DB_ASSISTCMD_SOCKETCLOSE, NULL, 0, (void*)(long)fd);
}

void ServerSet::ontimer(unsigned int uid) {
	time_t temp = time(NULL);
	if (uid == (unsigned int)-2) {
		std::map<int, time_t>::iterator ibegin = m_mapofftime.begin();
		std::map<int, time_t>::iterator iend = m_mapofftime.end();
		for ( ;ibegin != iend; ibegin++) {
			if (temp - ibegin->second > 30) {
				MSGOUT(en_Msg_Debug, "heart package close, fd: %d", ibegin->first);
				closeconnect(ibegin->first);
				if (m_mapofftime.size() != 0) {
					ibegin = m_mapofftime.begin();
					continue;
				}
				else {
					break;
				}
			}
			else {
				NetSocketHead head = {0};
				head.uMainCmd = (unsigned int)-1;
				head.uSubCmd = (unsigned int)-1;
				head.uHelpCmd = (unsigned int)-2;
				senddata(ibegin->first, &head, sizeof(head));
			}
		}
		settimer((unsigned int)-2, 1000*25);
	}
	else {
		SendEventResult(DB_MAINCMD_SYSTEMCTL, DB_ASSISTCMD_SYSTIMER, &uid, sizeof(unsigned int), NULL);
	}
}

void ServerSet::SettleQueueResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
    if (maincmd == DB_MAINCMD_SYSTEMCTL) {
        switch (assistcmd)
        {
        case DB_ASSISTCMD_SYSTIMER:
            {
                unsigned int uid = *((unsigned int*)pdata);
                OnEventTimer(uid);
                return;
            }
            break;
        case DB_ASSISTCMD_SYSRECVDATA:
            {
                int fd = (int)(long)pclient;
                if (!OnSocketRead(fd, pdata, ulen)) {
                    closeconnect(fd);
                }
                return;
            }
            break;
        case DB_ASSISTCMD_STOPSERVER:
            {
                StopServer();
                return;
            }
            break;
        case  DB_ASSISTCMD_SOCKETCLOSE:
            {
                int fd = (int)(long)pclient;
                OnSocketClose(fd);
                return;
            }
            break;
        default:
            {
                MSGOUT(en_Msg_Normal, "Unknow system assistcmd: %d, pdata: %p, ulen: %ld, pclient: %p", assistcmd, pdata, ulen, pclient);
            }
            return ;
        }
        
    }
	SettleDBResult(maincmd, assistcmd, pdata, ulen, pclient);
}

void ServerSet::onsignal(int nsig) {
	switch(nsig) {
	case SIGINT:
		{
			MSGOUT(en_Msg_Debug, "<-------------------stop------------------------>");
			MSGOUT(en_Msg_Debug, "signal:%d", nsig);
			if(m_pSer != NULL)
                m_pSer->PostEventResult(DB_MAINCMD_SYSTEMCTL, DB_ASSISTCMD_STOPSERVER, NULL, 0, NULL);
		}
		break;
	case SIGPIPE:
		{
			MSGOUT(en_Msg_Debug, "SIGPIPE !!!!");
		}
		break;
	default:
		return;
	};
}

bool ServerSet::StartServer(QueueEventModule* pDB, short port, int type, unsigned int uthread) {
	m_pSer = this;

	m_pDB = pDB;

	signal(SIGINT, onsignal);
	signal(SIGPIPE, onsignal);

	if(TimerModule::_start_server(NULL, this)) {
		addmodule();
	}
	else {
		MSGOUT(en_Msg_Error, "TimerModule error");
		return false;
	}

	_bindparam par = {0};
	par.type = type;
	par.port = port;
	if(SocketModule::_start_server(&par, this)) {
		addmodule();
	}
	else {
		MSGOUT(en_Msg_Error, "SocketModule error");
		return false;
	}

	if(QueueResModule::_start_server(NULL, this)) {
		addmodule();
	}
	else {
		MSGOUT(en_Msg_Error, "QueueResModule error");
		return false;
	}

	setdealdataptr(-1, &m_tea);

	_queue_init_param param = {0};
	param.pres = this;
	param.uthread = uthread;
    m_uDBCount = uthread;
	if (m_pDB != NULL) {
		if(m_pDB->_start_server(&param, this)) {
             addmodule();
		}
		else {
			MSGOUT(en_Msg_Error, "QueueEventModule error");
			return false;
		}
	}

    settimer((unsigned int)-2, 1000*25);

	if (!_start()) {
		MSGOUT(en_Msg_Error, "_start error");
		return false;
	}

	pthread_cond_wait(&m_cSer, &m_mSer);
    usleep(100*1000);
	
	MSGOUT(en_Msg_Normal, "stop server!!!");

	return true;
}

void ServerSet::StopServer() {
    MSGOUT(en_Msg_Debug, "begin stop server set");

    killtimer((unsigned int)-2);

    _stop();

	TimerModule::_stop_server();
}

ServerSet::ServerSet() : m_tea("0123456789ABCDEF"){
	pthread_mutex_init(&m_mSer, NULL);
    pthread_cond_init(&m_cSer, NULL); 

    pthread_mutex_init(&m_mmodule, NULL);
    sem_init(&m_semmodule, 0, 0);
	m_pDB = NULL;
}

ServerSet::~ServerSet() {
	pthread_mutex_destroy(&m_mSer);
	pthread_cond_destroy(&m_cSer);

    pthread_mutex_destroy(&m_mmodule);
    sem_destroy(&m_semmodule);    
}

void ServerSet::_end_callback(const char* pstr, void* pdata, int ntype) {

    MSGOUT(en_Msg_Debug, "end!!! module:%s", pstr);
    int count = 0;
    pthread_mutex_lock(&m_mmodule);
    sem_wait(&m_semmodule);
    sem_getvalue(&m_semmodule, &count);
    pthread_mutex_unlock(&m_mmodule);

    MSGOUT(en_Msg_Debug, "end!!! left: %d", count);

    if (count == 3) {
        if(m_pDB != NULL)
            m_pDB->_stop_server();
    }
    if (count == 2) {
        QueueResModule::_stop_server();
    }
    if (count == 1) {
        SocketModule::_stop_server();
    }
	if(0 == count) {
		pthread_cond_signal(&m_cSer);
	}
}

void ServerSet::addmodule() {
    sem_post(&m_semmodule);
}

void ServerSet::StopHeartPackage()
{
     killtimer(-2);
}
