/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-14 11:53:24
# LastModified : 2014-11-12 21:27:35
# FileName     : queuebase.cpp
# Description  : 
 ******************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

#include "queuebase.h"
#include "showmsg.h"

bool QueueResModule::PostEventResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {

	if(m_isresend)
		return false;

	queue_data* qdata = (queue_data*)malloc(sizeof(queue_data));
	memset(qdata, 0, sizeof(queue_data));
	qdata->maincmd = maincmd;
	qdata->assistcmd = assistcmd;
	qdata->pclient = pclient;
	if(ulen != 0)
	{   
		qdata->pdata = malloc(ulen);
		qdata->ulen = ulen;
		memcpy(qdata->pdata, pdata, ulen);
	}   
	pthread_mutex_lock(&m_resmulock);
	m_qresdata.push_back(qdata);
	pthread_mutex_unlock(&m_resmulock);
	Signal();
	return true;
}


bool QueueResModule::SendEventResult( int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient ) {

    if(m_isresend)
        return false;

    queue_data* qdata = (queue_data*)malloc(sizeof(queue_data));
    memset(qdata, 0, sizeof(queue_data));
    qdata->maincmd = maincmd;
    qdata->assistcmd = assistcmd;
    qdata->pclient = pclient;
    if(ulen != 0)
    {   
        qdata->pdata = malloc(ulen);
        qdata->ulen = ulen;
        memcpy(qdata->pdata, pdata, ulen);
    }   
    pthread_mutex_lock(&m_resmulock);
    m_qresdata.push_front(qdata);
    pthread_mutex_unlock(&m_resmulock);
    Signal();
    return true;
}



bool QueueResModule::_start_server(void* pdata, ISvrCallback *pcb) {

	if (!m_isresend)
		return true;

	m_prescb = pcb;

	pthread_t id = 0;
	pthread_create(&id, NULL, assistfun, this);
	pthread_detach(id);

	m_isresend = false;

	MSGOUT(en_Msg_Normal, "start server !!!");

	return true;
}

void QueueResModule::_stop_server() {

	if(m_isresend)
		return ;

    PostEventResult(0, 0, NULL, 0, NULL);
                                          
	m_isresend = true;
	MSGOUT(en_Msg_Debug, "stop server");
}
	
void* QueueResModule::assistfun(void* pdata) {

	QueueResModule* pthis = (QueueResModule*)pdata;
	while(1)
	{
		pthis->Wait();
		queue_data* pdata = pthis->GetOneResult();
		if(pdata->maincmd == 0 && pdata->assistcmd == 0) {
            free(pdata);
			MSGOUT(en_Msg_Debug, "Stop Server!!!");       
			break;
		}
		if (pdata != NULL) {
			pthis->SettleQueueResult(pdata->maincmd, pdata->assistcmd, pdata->pdata, pdata->ulen, pdata->pclient);
			if (pdata->pdata != NULL)
				free(pdata->pdata);
			free(pdata);
		}
	}

	MSGOUT(en_Msg_Normal, "stop server!!!");	
	if(pthis->m_prescb != NULL) {
		pthis->m_prescb->_end_callback("QueueResModule", pthis, 0);
	}
	return NULL;
}

queue_data* QueueResModule::GetOneResult() {

	pthread_mutex_lock(&m_resmulock);
	if (m_qresdata.empty()) {
		pthread_mutex_unlock(&m_resmulock);
		return NULL;
	}
	queue_data* pdata = m_qresdata.front();
	m_qresdata.pop_front();
	//MSGOUT(en_Msg_Debug, "left queue count: %d", m_qresdata.size());
	pthread_mutex_unlock(&m_resmulock);
	return pdata;
}

QueueResModule::QueueResModule() {

	sem_init(&m_ressem, 0, 0);

	pthread_mutex_init(&m_resmulock, NULL);
	m_isresend = true;
	m_prescb = NULL;
}

QueueResModule::~QueueResModule() {
	if(!m_isresend)
		_stop_server();

	sem_destroy(&m_ressem);

	pthread_mutex_destroy(&m_resmulock);
}

void QueueResModule::Wait() {
	sem_wait(&m_ressem);
}

void QueueResModule::Signal() {
	sem_post(&m_ressem);
}

bool QueueResModule::_is_end() {
	return m_isresend;
}

/********************************************************************/
bool QueueEventModule::PostQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {

	if(m_isevtend)
		return false;
	queue_data* qdata = (queue_data*)malloc(sizeof(queue_data));
	memset(qdata, 0, sizeof(struct queue_data));
	qdata->maincmd = maincmd;
	qdata->assistcmd = assistcmd;
	qdata->pclient = pclient;
	if(ulen != 0)
	{
		qdata->pdata = malloc(ulen);
		qdata->ulen = ulen;
		memcpy(qdata->pdata, pdata, ulen);
	}

	pthread_mutex_lock(&m_evtmulock);
	m_qevtdata.push(qdata);
	pthread_mutex_unlock(&m_evtmulock);

	TaskSignal();
	return true;
}

bool QueueEventModule::PostQueueResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	if(m_pres == NULL)
		return false;

	return m_pres->PostEventResult(maincmd, assistcmd, pdata, ulen, pclient);
}

bool QueueEventModule::_start_server(void* pdata, ISvrCallback* pcb) {
	_queue_init_param* p = (_queue_init_param*)pdata;
	m_pres = p->pres;
	m_uthread = p->uthread;
	m_pevtcb = pcb;
	for(unsigned int i = 0; i < m_uthread; i++) {
		pthread_t id = 0;
		pthread_create(&id, NULL, assistfun, this);
		pthread_detach(id);
		MSGOUT(en_Msg_Debug, "create thread:%lu", id);
        sem_post(&m_threadsem);
	}

	m_isevtend = false;

	MSGOUT(en_Msg_Normal, "start server!!!");

	return true;
}

void QueueEventModule::_stop_server() {
	if(m_isevtend)
		return ;

	for (unsigned int i = 0; i < m_uthread; i++) {
		PostQueueEvent(0, 0, NULL, 0, NULL);
	} 

	m_isevtend = true;
	MSGOUT(en_Msg_Debug, "stop!!!");
}

void* QueueEventModule::assistfun(void* pdata) {
	QueueEventModule* pthis = (QueueEventModule*)pdata;
//	static unsigned count = pthis->m_uthread;
	while(1) {
		pthis->TaskWait();
		queue_data* pdata = pthis->GetOneEvent();
		if (pdata->maincmd == 0 && pdata->assistcmd == 0) {
            free(pdata);
			MSGOUT(en_Msg_Debug, "Stop Server!!!");
			break;
		}
		pthis->SettleQueueEvent(pdata->maincmd, pdata->assistcmd, pdata->pdata, pdata->ulen, pdata->pclient);
		if (pdata->pdata != NULL)
			free(pdata->pdata);
		free(pdata);
	}
    sem_wait(&pthis->m_threadsem);
    int count = 0;
    sem_getvalue(&pthis->m_threadsem, &count);
	if (0 == count) {
		MSGOUT(en_Msg_Normal, "stop server!!!");
		if(pthis->m_pevtcb != NULL) {
			pthis->m_pevtcb->_end_callback("QueueEventModule", pthis, 0);
		}
    }

	return NULL;
}

QueueEventModule::QueueEventModule() {
	pthread_mutex_init(&m_evtmulock, NULL);
	sem_init(&m_tasksem, 0, 0);
    sem_init(&m_threadsem, 0, 0);
	m_pres = NULL;
	m_uthread = 1;
	m_isevtend = true;
	m_pevtcb = NULL;
}

QueueEventModule::~QueueEventModule() {
	if(!m_isevtend)
		_stop_server();
	pthread_mutex_destroy(&m_evtmulock);
    sem_destroy(&m_tasksem);           
    sem_destroy(&m_threadsem);
}

void QueueEventModule::TaskWait() {
	sem_wait(&m_tasksem);
}

void QueueEventModule::TaskSignal() {
	sem_post(&m_tasksem);
}

bool QueueEventModule::_is_end() {
	return m_isevtend;
}

queue_data* QueueEventModule::GetOneEvent() {
	pthread_mutex_lock(&m_evtmulock);
	if (m_qevtdata.empty()) {
		pthread_mutex_unlock(&m_evtmulock);
		return NULL;
	}
	queue_data* pdata = m_qevtdata.front();
	m_qevtdata.pop();
	//MSGOUT(en_Msg_Debug, "left task count: %d", m_qevtdata.size());
	pthread_mutex_unlock(&m_evtmulock);

	return pdata;	
}

