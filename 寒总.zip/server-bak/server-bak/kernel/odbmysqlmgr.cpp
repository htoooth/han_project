/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-25 16:57:08
# LastModified : 2014-12-26 15:57:38
# FileName     : odbmysqlmgr.cpp
# Description  : 
 ******************************************************************************/
#include <string.h>
#include <stdlib.h>

#include "showmsg.h"
#include "odbmysqlmgr.h"

bool OdbMySqlMgr::_start_server(void* pdata, ISvrCallback* pcb) {
	_mysql_param* p = (_mysql_param*)pdata;
	memcpy(&m_sqlparam, p, sizeof(_mysql_param));
	m_isend = false;
	return true;
}

void OdbMySqlMgr::_stop_server() {
	m_isend = true;
	ODB_MYSQL *p = NULL;
	pthread_mutex_lock(&m_mulock);
	while(!m_idle.empty()) {
		p = m_idle.front();
		m_idle.pop_front();
		delete p;
	}
	pthread_mutex_unlock(&m_mulock);
	mysql_server_end();
}

bool OdbMySqlMgr::_is_end() {
	return m_isend;
}

void* OdbMySqlMgr::GetIdleDB() {
	if(m_isend)
		return NULL;
	ODB_MYSQL *p = NULL;
	pthread_mutex_lock(&m_mulock);
	MSGOUT(en_Msg_Debug, "size:%d", m_idle.size());
	if (m_idle.empty()) {
		pthread_mutex_unlock(&m_mulock);
		return p;
	}
	p = m_idle.front();
	m_idle.pop_front();
	pthread_mutex_unlock(&m_mulock);
	return p;
}

bool OdbMySqlMgr::SaveIdleDB(void* psql) {
	pthread_mutex_lock(&m_mulock);
	m_idle.push_back((ODB_MYSQL*)psql);
	pthread_mutex_unlock(&m_mulock);
	return true;
}

void* OdbMySqlMgr::NewIdleDB() {
	if(m_isend)
		return NULL;
	ODB_MYSQL* p = new odb::mysql::database(m_sqlparam.username, m_sqlparam.passwd, m_sqlparam.dbname, m_sqlparam.addr, m_sqlparam.port, NULL,m_sqlparam.charset, CLIENT_BASIC_FLAGS);
	return p;
}

OdbMySqlMgr::OdbMySqlMgr() {
	pthread_mutex_init(&m_mulock, NULL);
	m_isend = true;
}

OdbMySqlMgr::~OdbMySqlMgr() {
	if(!m_idle.empty())
		_stop_server();
	pthread_mutex_destroy(&m_mulock);
}

void OdbMySqlMgr::FreeConnect(void* psql) {
	if (psql != NULL)
		delete (ODB_MYSQL*)psql;
}
