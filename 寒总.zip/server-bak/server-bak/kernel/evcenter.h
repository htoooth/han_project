/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-23 20:26:26
# LastModified : 2014-11-18 17:09:39
# FileName     : evcenter.h
# Description  : 
 ******************************************************************************/
#ifndef _EVCENTER_H
#define _EVCENTER_H

#include <event.h>
#include <event2/thread.h>
#include <sys/queue.h>

#include "baseserver.h"
#include "queuebase.h"
#include "evsocket.h"

struct ssl_st;
typedef ssl_st SSL;

struct ssl_ctx_st;
typedef ssl_ctx_st SSL_CTX;

enum _en_Socket_Connect_Type {
	en_Normal_Connect = 1,
	en_Server_Connect = 10,
	en_SSLv2_Connect = 100,
	en_SSLv3_Connect,
	en_SSLv23_Connect,
	en_TLSv1_Connect,
	en_DTLSv1_Connect,
};

class CenterSocket : public IServer {
public:
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual bool _is_end();
public:
	event_base*		m_pcebase;
	event*				m_preadev;
	event*				m_pwriteev;
	int					m_sock;
	int					m_contype;
	bool				m_isend;
	SSL*				m_ssl;
	SSL_CTX*			m_ctx;
	ISvrCallback*		m_pcecb;
public:
	CenterSocket();
	virtual ~CenterSocket();
	bool connectsocket(const char* pip, int port, int type, int timeout = 3);
	virtual bool OnRecvData(char* pdata, unsigned int len) = 0;
	virtual void OnClose() = 0;
	int senddata(char* pdata, unsigned int len);
	void closesocket();
    static void releasesslres();
protected:
	void _on_close();
	bool connectSSL(int type);
	static void _on_read(int fd, short sock, void* arg);
	static void _on_write(int fd, short sock, void* arg);
	static void* assistfun(void* pdata); 
private:
	_net_data_	m_tmpdata;
	TAILQ_HEAD(, _buf_node) m_qsend;
};

#endif // _EVCENTER_H
