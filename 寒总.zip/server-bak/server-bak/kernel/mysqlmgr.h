/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-25 16:25:14
# LastModified : 2014-12-26 16:58:11
# FileName     : mysqlmgr.h
# Description  : 
 ******************************************************************************/
#ifndef _MYSQLMGR_H
#define _MYSQLMGR_H

#include <mysql/mysql.h>
#include <list>
#include <string>

#include "baseserver.h"
#include "database.h"


class MySqlMgr : public DataBaseClass {
public:
	MySqlMgr();
	virtual ~MySqlMgr();
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual bool _is_end();
public:
	std::list<MYSQL*>	m_idle;
	_mysql_param		m_sqlparam;
	bool				m_isend;
public:
	virtual void* GetIdleDB();
	virtual bool SaveIdleDB(void* psql);
	virtual void FreeConnect(void* psql);
	virtual void* NewIdleDB();
protected:
	bool IsConnect(MYSQL* psql);
	bool Connect(MYSQL* psql);
protected:
	pthread_mutex_t	m_mulock;
};

#endif // _MYSQLMGR_H
