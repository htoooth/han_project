/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-14 10:00:52
# LastModified : 2014-11-12 21:27:11
# FileName     : queuebase.h
# Description  : 
 ******************************************************************************/
#ifndef _QUEUEBASE_H
#define _QUEUEBASE_H

#include <queue>
#include <semaphore.h>
#include <pthread.h>
#include <list>

#include "baseserver.h"

struct queue_data {
	int				maincmd;
	int				assistcmd;
	void*			pdata;
	unsigned int	ulen;
	void*			pclient;
};

class QueueResModule : public IServer {
public:

	virtual void SettleQueueResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) = 0;

	bool PostEventResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);

    bool SendEventResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);

	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual bool _is_end();
	
	static void* assistfun(void* pdata);

	queue_data* GetOneResult();

public:
	QueueResModule();
	virtual ~QueueResModule();
	void Wait();
	void Signal();
	ISvrCallback*	m_prescb;
protected:
	std::list<queue_data*> m_qresdata;
	sem_t					m_ressem;

	pthread_mutex_t			m_resmulock;
	bool					m_isresend;
};

struct _queue_init_param {
	QueueResModule*	pres;
	unsigned int	uthread;
};

class QueueEventModule : public IServer {
public:
	virtual void SettleQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) = 0;

	bool PostQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
	bool PostQueueResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);

	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual bool _is_end();
	static void* assistfun(void* pdata);

public:
	QueueEventModule();
	virtual ~QueueEventModule();
	void TaskWait();
	void TaskSignal();
	queue_data* GetOneEvent();
	ISvrCallback*	m_pevtcb;
protected:
	sem_t					m_tasksem;
    sem_t                   m_threadsem;
	unsigned int			m_uthread;
	pthread_mutex_t			m_evtmulock;
	QueueResModule*			m_pres;
	bool					m_isevtend;
	std::queue<queue_data*>	m_qevtdata;
};

#endif // _QUEUEBASE_H
