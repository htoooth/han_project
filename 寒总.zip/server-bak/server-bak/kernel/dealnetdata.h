/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-05 16:58:59
# LastModified : 2014-06-23 15:48:55
# FileName     : dealnetdata.h
# Description  : 
 ******************************************************************************/
#ifndef _DEALNETDATA_H__
#define _DEALNETDATA_H__

enum enDealData
{
	EN_TYPE_NULL = 0,
	EN_TEA_ENCODE,
};

struct NetSocketHead {
	unsigned int uMainCmd;
	unsigned int uSubCmd;
	unsigned int uHelpCmd;
	unsigned int uLen;
	unsigned int uRe;
};

#define HEAD_SIZE			(sizeof(NetSocketHead))
#define MAX_BUFFSIZE		(4096)
#define MAX_SEND_BUFSIZE	(MAX_BUFFSIZE-HEAD_SIZE)

class IDealNetData {
public:
	// data encrypt
	virtual bool DealSendData(const void *datain, unsigned int inlen, void *dataout, unsigned int *outlen) = 0;
	// data decrypt
	virtual bool DealRecvData(const void *datain, unsigned int inlen, void *dataout, unsigned int *outlen) = 0;
	// return true will not DealRecvData (normaly return false)
	virtual bool DealSpecialData(const void *data, unsigned int len) = 0;
	// get encrypt type
	virtual int GetEnType() { return EN_TYPE_NULL; }
};

#endif // _DEALNETDATA_H__
