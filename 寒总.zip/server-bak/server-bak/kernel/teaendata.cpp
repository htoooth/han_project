/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-05 16:58:46
# LastModified : 2014-09-01 14:35:16
# FileName     : teaendata.cpp
# Description  : 
 ******************************************************************************/
#include <string.h>

#include "teaendata.h"

TeaEndata::TeaEndata(const char *key, int round /*= 32*/) : _round(round) 
{
	m_uHeadLen = HEAD_SIZE;

    if (key != NULL)
       memcpy(_key, key, 16);
    else
       memset(_key, 0, 16);
}

bool TeaEndata::DealSendData(const void *datain, unsigned int inlen, void *dataout, unsigned int *outlen) 
{
	if (*outlen < inlen || inlen <= 0 || inlen < m_uHeadLen)
		return false;

	unsigned int i = 0;
	char *in = (char *)datain+m_uHeadLen;
	char *out = (char *)dataout+m_uHeadLen;
	inlen -= m_uHeadLen;


	if(inlen > 0) {
		for (; i < inlen+SIZE_ENDATA; i += SIZE_ENDATA) {
			if (inlen - i >= SIZE_ENDATA) {
				encrypt((const unsigned int*)(in+i), (unsigned int*)(out+i));
			}
			else {
				memcpy(&out[i], &in[i], inlen-i);
				break;
			}
		}
	}
	memcpy(dataout, datain, m_uHeadLen);
	*outlen = inlen + m_uHeadLen;
	return true;
}

bool TeaEndata::DealRecvData(const void *datain, unsigned int inlen, void *dataout, unsigned int *outlen) 
{
	if (*outlen < inlen || inlen <= 0 || inlen <m_uHeadLen)
		return false;

	char *in = (char *)datain+m_uHeadLen;
	char *out = (char *)dataout+m_uHeadLen;
	inlen -= m_uHeadLen;

	if (inlen > 0) {
		unsigned int i = 0;
		for (; i < inlen+SIZE_ENDATA; i += SIZE_ENDATA) {
			if (inlen - i >= SIZE_ENDATA) {
				decrypt((const unsigned int*)(in+i), (unsigned int*)(out+i));
			}
			else {
				memcpy(&out[i], &in[i], inlen-i);
				break;
			}
		}
	}
	memcpy(dataout, datain, m_uHeadLen);
	*outlen = inlen + m_uHeadLen;
	return true;
}

void TeaEndata::setkey(const char *key) 
{
	memcpy(_key, key, 16);
}

void TeaEndata::encrypt(const unsigned int *in, unsigned int *out) 
{

   unsigned int *k = (unsigned int*)_key;
   register unsigned int y = in[0];
   register unsigned int z = in[1];

   register unsigned int a = k[0];
   register unsigned int b = k[1];
   register unsigned int c = k[2];
   register unsigned int d = k[3];
   register unsigned int delta = 0x9E3779B9; /* (sqrt(5)-1)/2*2^32 */
   register int round = _round;
   register unsigned int sum = 0;

   while (round--) {    /* basic cycle start */
        sum += delta;
        y += ((z << 4) + a) ^ (z + sum) ^ ((z >> 5) + b);
        z += ((y << 4) + c) ^ (y + sum) ^ ((y >> 5) + d);
   }    /* end cycle */
   out[0] = y;
   out[1] = z;
}

void TeaEndata::decrypt(const unsigned int *in, unsigned int *out) 
{
    unsigned int *k = (unsigned int*)_key;
    register unsigned int y = in[0];
    register unsigned int z = in[1];

    register unsigned int a = k[0];
    register unsigned int b = k[1];
    register unsigned int c = k[2];
    register unsigned int d = k[3];
    register unsigned int delta = 0x9E3779B9; /* (sqrt(5)-1)/2*2^32 */
    register int round = _round;
    register unsigned int sum = 0;

   if (round == 32)
       sum = 0xC6EF3720; /* delta << 5*/
   else if (round == 16)
       sum = 0xE3779B90; /* delta << 4*/

   while (round--) {    /* basic cycle start */
       z -= ((y << 4) + c) ^ (y + sum) ^ ((y >> 5) + d);
       y -= ((z << 4) + a) ^ (z + sum) ^ ((z >> 5) + b);
       sum -= delta;
   }    /* end cycle */
   out[0] = y;
   out[1] = z;
}

int TeaEndata::GetEnType()
{
	return EN_TEA_ENCODE;
}

bool TeaEndata::DealSpecialData( const void *data, unsigned int len )
{
	NetSocketHead *pHead = (NetSocketHead*)data;
	if (pHead->uMainCmd == (unsigned int)-1  && pHead->uHelpCmd == (unsigned int)-1)
	{
		if (len - HEAD_SIZE != 16)
		{
			return false; 
		}
		char buf[16] = {0};
		unsigned int uout = 0;
		DealRecvData(data, 16, buf, &uout);
		
		setkey(buf);
		return true;
	}
	return false;
}

