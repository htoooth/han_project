/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-12 13:25:16
# LastModified : 2014-03-19 14:28:18
# FileName     : timemain.c
# Description  : 
 ******************************************************************************/
#include "evtimer.h"
#include <stdio.h>
#include <unistd.h>

class test_time : public TimerModule {
	
	virtual void ontimer(unsigned int nid) {
		fprintf(stderr, "ontimer id: %u\n", nid);
//		killtimer(nid);
	}
};

int main(int argc, char *argv[]) {

	test_time test;

	test._start_server(NULL, NULL);

	test.settimer(1, 1000);

	sleep(3);
//	test.killtimer(-1);
	test._stop_server();

	//while(1); 
	sleep(1);

	return 0;
}
