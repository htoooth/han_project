/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-13 21:03:24
# LastModified : 2015-03-04 13:07:02
# FileName     : sockmain.c
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <unistd.h>

#include "evsocket.h"

class my_end : public ISvrCallback {
public:
	virtual void _end_callback(const char* pdata) {
	
	}
};

int g_fd = 0;
class my_sock : public SocketModule {
public:
	virtual bool onread(int fd, void* pdata, unsigned int ulen) {
	//	if (ulen > 0 && ulen != (unsigned int)-1)
	//		senddata(fd, pdata, ulen);
		fprintf(stderr, "recv str: %s\n", pdata);
		return true;
	}
	virtual bool onconnect(int fd, struct sockaddr_in* paddr) {
		g_fd = fd;
		MSGOUT(en_Msg_Debug, "connect fd : %d", fd);
	
		return true;
	}
	virtual void onclose(int fd) {
		MSGOUT(en_Msg_Debug, "socket close fd : %d", fd);
		
	}
};

int main(int argc, char *argv[]) {
	
	my_sock sock;
//	my_end end;

	_bindparam param;
	param.port = 9876;
//	param.type = en_Normal_Connect;
//	param.type = en_Server_Connect;
	param.type = en_TLSv1_Connect;
	
//	sock._start_server(&port, &end);
	sock._start_server(&param, NULL);
	
	sleep(5);
	char buf[] = "qwertyuiopasdfghjklzxcvbnm";
	for(int i = 0; i < 1; i++ )
		sock.senddata(g_fd, buf, sizeof(buf));
	MSGOUT(en_Msg_Debug, "ccccccccccccccccccccccccccc");
	sleep(3);
	sock.closeconnect(g_fd);
	sleep(5);

	sleep(3);
	sock._stop_server();
	sleep(3);

	return 0;
}
