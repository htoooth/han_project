/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-26 15:35:12
# LastModified : 2014-10-10 10:11:51
# FileName     : readconf.cpp
# Description  : 
 ******************************************************************************/
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#include "readconf.h"

ReadConf::ReadConf() {
	m_mapvalue.clear();
}

ReadConf::~ReadConf() {
	m_mapvalue.clear();
}

int ReadConf::readfile(const char* filename) {
	if (filename == NULL) {
		return -1;
	}
	int fd = open(filename, O_RDONLY);
	if (fd == -1) {
		return -1;
	}
	return readparam(fd);
}

bool ReadConf::getvalue(const char* key, char* value, int size) {
	if (m_mapvalue.find(std::string(key)) == m_mapvalue.end())
		return false;
	int len = m_mapvalue[std::string(key)].length();
	if(size > len) {
		memset(value, 0, size);
		snprintf(value, len+1, m_mapvalue[std::string(key)].c_str());
		return true;
	}
	return false;
}

int ReadConf::readparam(int fd) {
	m_mapvalue.clear();
	char buf[2] = {0};
	std::string key = "";
	std::string value = "";
	int res = 0;
	bool breadkey = true;
	while((res = read(fd, buf, 1))) {
		if (res == -1)
			return -1;
		if (buf[0] == '#' || buf[0] == '\n') {
			while(buf[0] != '\n' && res != 0) {
				buf[0] = 0;
				res = read(fd, buf, 1);
				if (res == -1)
					return -1;
			}
		}
		else if (buf[0] == ' ') {
			while (buf[0] != ' ' && res != 0) {
				buf[0] = 0;
				res = read(fd, buf, 1);
				if (res == -1)
					return -1;
			}
		}
		else if (buf[0] == '\t') {
			while (buf[0] != '\t' && res != 0) {
				buf[0] = 0;
				res = read(fd, buf, 1);
				if (res == -1)
					return -1;
			}
		}
		else {
			if(breadkey) {
				key += buf;
				res = read(fd, buf, 1);
				if (res == -1)
					return -1;
				while(buf[0] != ' ' && buf[0] != '\t' && buf[0] != '\n' && res != 0) {
					key += buf;
					buf[0] = 0;
					res = read(fd, buf, 1);
					if (res == -1)
						return -1;
				}
				if (buf[0] == '\n') {
					m_mapvalue[key] = "";
					key = "";
					value = "";
					continue;
				}
				breadkey = false;
				buf[0] = 0;
			}
			else {
				value += buf;
				res = read(fd, buf, 1);
				if (res == -1)
					return -1;
				while(buf[0] != '\n' && res != 0) {
					value += buf;
					res = read(fd, buf, 1);
					if (res == -1)
						return -1;
				}
				m_mapvalue[key] = value;
				key = "";
				value = "";
				breadkey = true;
				buf[0] = 0;
			}
		}
	}
	close(fd);
	return m_mapvalue.size();
}

void ReadConf::test() {
	std::map<std::string, std::string>::iterator it = m_mapvalue.begin();
	while(it != m_mapvalue.end()) {
		printf("key: %s, value: %s\n", it->first.c_str(), it->second.c_str());
		it++;
	}
}
