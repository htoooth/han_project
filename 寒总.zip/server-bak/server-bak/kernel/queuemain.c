/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-15 16:24:12
# LastModified : 2014-03-20 11:41:14
# FileName     : queuemain.c
# Description  : 
 ******************************************************************************/

#include <pthread.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

#include "queuebase.h"
#include "showmsg.h"

class my_event : public QueueEventModule {
	virtual void SettleQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
		int i = rand()%10 + 1;
		i = 3;
		MSGOUT(en_Msg_Debug, "my_event sleep:%d, main:%d, assist:%d, data:%p, ulen:%u, pclient:%p\n", i, maincmd, assistcmd, pdata, ulen, pclient);
		sleep(i);
		MSGOUT(en_Msg_Debug, "my_event sleep:%d, main:%d, assist:%d, data:%p, ulen:%u, pclient:%p\n", i, maincmd, assistcmd, pdata, ulen, pclient);
	}
};

class my_res : public QueueResModule {
	virtual void SettleQueueResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
		MSGOUT(en_Msg_Debug, "my_res main:%d, assist:%d, data:%p, ulen:%u, pclient:%p\n", maincmd, assistcmd, pdata, ulen, pclient);			
	}
};


void* work(void* pdata) {
	my_event *pevn = (my_event*)pdata;
	int i = 10;
	while(i--) {
		pevn->PostQueueEvent(i, 100-i, NULL, 0, NULL);
		MSGOUT(en_Msg_Debug, "************************add event***********************");			
	//	sleep(1);
	}
}

int main(int argc, char *argv[]) {

	srand(time(NULL));
	
	my_res res;
	my_event evn;

	res._start_server(NULL, NULL);

	_queue_init_param pa = {0};
	pa.pres = &res;
	pa.uthread = 10;

	evn._start_server(&pa, NULL);

	pthread_t id;
	pthread_create(&id, NULL, work, &evn);
	pthread_detach(id);

	sleep(2);
	evn._stop_server();
	res._stop_server();
	sleep(9);

	return 0;
}
