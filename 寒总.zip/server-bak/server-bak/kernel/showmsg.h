/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2013-12-18 19:06:13
# LastModified : 2014-11-06 11:35:45
# FileName     : showmsg.h
# Description  : 
 ******************************************************************************/
#ifndef _SHOWMSG_H
#define _SHOWMSG_H

#include <stdio.h>

#include "baseserver.h"

enum _en_Msg_Level
{
	en_Msg_Debug 	= 0x00000001,	// $ debug msg, for coder use 
	en_Msg_Warning 	= 0x00000002,	// * warning msg, can ignore...
	en_Msg_Error	= 0x00000004, 	// # someting err, must do somting
	en_Msg_Normal	= 0x00000008,	// ^ tips msg, 
};

void setMsgMask(unsigned int maskKey);

void setWriteFile(FILE *file);

void msgOut(_en_Msg_Level enLev, const char *format, ...);

char getMaskChar(_en_Msg_Level enLev);

#define MSGOUT(type, arg, ...) msgOut(type, "file:%s line:%d %s "arg, __FILE__, __LINE__, __PRETTY_FUNCTION__, ##__VA_ARGS__)

#endif // _SHOWMSG_H
