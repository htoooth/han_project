/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-26 15:32:38
# LastModified : 2014-03-26 18:15:29
# FileName     : readconf.h
# Description  : 
 ******************************************************************************/
#ifndef _READCONF_H
#define _READCONF_H

#include <map>
#include <string>

#include "baseserver.h"

class ReadConf {
public:
	ReadConf();
	virtual ~ReadConf();
	int readfile(const char* filename);
	bool getvalue(const char* key, char* value, int size);
	void test();
protected:
	int readparam(int fd);
	std::map<std::string, std::string> m_mapvalue;
};

#endif // _READCONF_H
