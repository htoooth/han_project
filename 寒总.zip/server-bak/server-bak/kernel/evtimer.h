/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-02-18 17:30:10
# LastModified : 2014-09-23 18:12:37
# FileName     : evtimer.h
# Description  : 
 ******************************************************************************/
#ifndef _EVTIMER_H
#define _EVTIMER_H

#include <event.h>
#include <map>
#include <event2/thread.h>

#include "baseserver.h"

class TimerModule;

struct timer_arg {
	unsigned int	uid;
	struct event	tev;
	timeval			tv;
	TimerModule*	ptm;
};

class TimerModule : public IServer {
public:
	virtual void ontimer(unsigned int uid) = 0;
	void settimer(unsigned int uid, unsigned int msec);
	void killtimer(unsigned int uid);
public:
	TimerModule();
	virtual ~TimerModule();
	static void _on_timer(int fd, short event, void* arg);
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual bool _is_end();
	static void* assistfun(void* pdata);
public:
	bool			m_istiend;
	event_base*		m_ptibase;
	ISvrCallback*	m_pticb;
	std::map<unsigned int, timer_arg*> m_mapti;
};

#endif // _EVTIMER_H
