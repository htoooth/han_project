/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-01 21:32:59
# LastModified : 2014-04-02 14:04:54
# FileName     : mysqlmain.c
# Description  : 
 ******************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "mysqlmgr.h"

int main(int argc, char *argv[]) {
	_mysql_param param = {0};
	memcpy(param.dbname, "test", 4);
	memcpy(param.username, "logicserver", 11);
	memcpy(param.passwd, "zhijian_server", 14);
//	memcpy(param.addr, "112.124.96.174", 14);
	memcpy(param.addr, "192.168.1.120", 13);
	memcpy(param.charset, "uft-8", 5);
	param.port = 3306;

	MySqlMgr mgr;
	mgr._start_server(&param, NULL);
	
	for (int i = 0; i < 9; i++) {
		MYSQL *psql = mgr.GetIdleDB();
		if(psql == NULL) {
			psql = mgr.NewIdleDB();
			fprintf(stderr, "1111111111\n");
		}
//		if (res == CR_COMMANDS_OUT_OF_SYNC)
//			fprintf(stderr, " status:%d\n", psql->status);

		if(!mgr.IsConnect(psql)) {
			mgr.Connect(psql);
			fprintf(stderr, "2222222222\n");
		}
	//	int re = mysql_query(psql, "call proc_muti_res();");
		int re = mysql_query(psql, "call proc_sel();");
		
		do {
			if(re != 0)
			{
				fprintf(stderr, "err no:%d error:%s\n", re, mysql_error(psql));
			}
			MYSQL_RES *res = NULL;
			MYSQL_ROW row;
			res = mysql_store_result(psql);
			if (res == NULL)
				break;
			printf("row_count:%lu, field_count:%d\n", res->row_count, res->field_count);
			int i = 0, j = 0;
			for(; i < res->row_count; i++) {
				row = mysql_fetch_row(res);
				for (j = 0; j < res->field_count; j++) {
					printf("%s", row[j]);
				}
				printf("\n");
			}
			mysql_free_result(res);
		}
		while(!mysql_next_result(psql));
		mgr.SaveIdleDB(psql);
	}
	mgr._stop_server();
}
