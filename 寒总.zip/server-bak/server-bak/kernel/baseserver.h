/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-12 19:29:12
# LastModified : 2014-08-19 17:13:08
# FileName     : baseserver.h
# Description  : 
 ******************************************************************************/
#ifndef _BASESERVER_H
#define _BASESERVER_H

//#pragma pack(4)

struct _net_data_ {
    int		totallen;
    int		readlen;
    char*	pdata;
};

class ISvrCallback {
public:
	virtual void _end_callback(const char* pstr, void* pdata, int ntype) = 0;
};

class IServer {
public:
	virtual bool _start_server(void* pdata, ISvrCallback* pcb) = 0;
	virtual void _stop_server() = 0;
	virtual bool _is_end() = 0;
};


#endif // _BASESERVER_H
