/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-17 09:14:11
# LastModified : 2014-11-10 14:44:46
# FileName     : serverset.h
# Description  : 
 ******************************************************************************/
#ifndef _SERVERSET_H
#define _SERVERSET_H

#include "queuebase.h"
#include "evsocket.h"
#include "evtimer.h"
#include "teaendata.h"

#define DB_MAINCMD_SYSTEMCTL  (-1)

#define DB_ASSISTCMD_SYSTIMER       (-1)
#define DB_ASSISTCMD_SYSRECVDATA   (-2)
#define DB_ASSISTCMD_STOPSERVER     (-3)
#define DB_ASSISTCMD_SOCKETCLOSE     (-4)

class ServerSet : public TimerModule, public QueueResModule, public SocketModule, public ISvrCallback {
public:
	virtual bool OnSocketRead(int fd, void* pdata, unsigned int ulen) = 0;
	virtual bool OnSocketConnect(int fd, struct sockaddr_in* paddr) = 0;
	virtual void OnSocketClose(int fd) = 0;
	virtual void OnEventTimer(unsigned int uid) = 0;
	virtual void SettleDBResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) = 0;
	void PostDBRequest(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
public:
	// return false will close conncet
	virtual bool onread(int fd, void* pdata, unsigned int ulen);
	// return false will close connect
	virtual bool onconnect(int fd, struct sockaddr_in* paddr);
	virtual void onclose(int fd);
	virtual void ontimer(unsigned int uid);
	virtual void SettleQueueResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
	virtual void _end_callback(const char* pstr, void* pdata, int ntype);
	// for sub class
	virtual void _stop() = 0;
	virtual bool _start() = 0;
public:
	void addmodule();
	static void onsignal(int nsig);
	bool StartServer(QueueEventModule* pDB, short port, int type, unsigned int uthread);
	void StopServer();
    void StopHeartPackage();
	ServerSet();
	~ServerSet();
protected:
	QueueEventModule*	m_pDB;
	static ServerSet*	m_pSer;
	pthread_cond_t		m_cSer;
	pthread_mutex_t		m_mSer;
    pthread_mutex_t		m_mmodule;
    sem_t               m_semmodule;
	TeaEndata			m_tea;
	std::map<int, time_t>	m_mapofftime;
    unsigned int        m_uDBCount;
};

#endif // _SERVERSET_H
