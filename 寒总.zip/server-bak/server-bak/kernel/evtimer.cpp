/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-12 10:16:42
# LastModified : 2015-01-07 13:07:08
# FileName     : evtimer.cpp
# Description  : 
 ******************************************************************************/
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

#include "evtimer.h"
#include "showmsg.h"


void TimerModule::settimer(unsigned int uid, unsigned int msec) {

	if (m_istiend)
		return ;

	std::map<unsigned int, timer_arg*>::iterator it = m_mapti.end();
	if (m_mapti.find(uid) != it) {
		killtimer(uid);
	}

	timer_arg *pti = (timer_arg*)malloc(sizeof(timer_arg));
	memset(pti, 0, sizeof(timer_arg));
	pti->uid = uid;
	pti->ptm = this;

	m_mapti[uid] = pti;

	evtimer_set(&pti->tev, _on_timer, pti);
//	event_set(&pti->tev, -1, EV_TIMEOUT|EV_PERSIST, _on_timer, pti);
	event_base_set(m_ptibase, &pti->tev);

	pti->tv.tv_sec = msec/1000;
	pti->tv.tv_usec = (msec%1000)*1000;

	evtimer_add(&pti->tev, &pti->tv);
//	MSGOUT(en_Msg_Debug, "id:%u, msev:%u", uid, msec);
//	event_add(&pti->tev, &tv);
}

void TimerModule::killtimer(unsigned int uid) {

	std::map<unsigned int, timer_arg*>::iterator it = m_mapti.end();

	if (m_mapti.find(uid) != it) {
		timer_arg* pdata = m_mapti[uid];
		m_mapti.erase(uid);
		event_del(&pdata->tev);
		free(pdata);
		pdata = NULL;
	}
}

/*****************************************************/
TimerModule::TimerModule() {
	m_ptibase = NULL;
	m_mapti.clear();
	m_pticb = NULL;
	m_istiend = true;
}

TimerModule::~TimerModule() {
	if (!m_istiend) {
		_stop_server();
	}
}

bool TimerModule::_is_end() {
	return m_istiend;
}

void TimerModule::_on_timer(int fd, short event, void* arg) {

	timer_arg *parg = (timer_arg*)arg;
	if (parg->ptm->_is_end())
		return ;

	unsigned int id = parg->uid;
	if (id == (unsigned int)-1) {
		event_add(&parg->tev, &parg->tv);
	}
	else {
//	MSGOUT(en_Msg_Debug, "TimerModule::_on_timer id:%d", id);
		parg->ptm->m_mapti.erase(id);

		parg->ptm->ontimer(id);
		free(parg);
	//	event_del(&parg->tev);
	}
}

bool TimerModule::_start_server(void* pdata, ISvrCallback* pcb) {

	if (m_ptibase != NULL) {
		return true;
	}
	m_pticb = pcb;

	evthread_use_pthreads();

	m_ptibase = event_base_new();

	m_istiend = false;

	settimer(-1, 1000000);

	pthread_t id;
	pthread_create(&id, NULL, assistfun, this);
	pthread_detach(id);

	return true;
}

void TimerModule::_stop_server() {
	if (m_ptibase == NULL || m_istiend)
		return;

	m_istiend = true;

	std::map<unsigned int, timer_arg*>::iterator ibegin = m_mapti.begin();
	std::map<unsigned int, timer_arg*>::iterator iend = m_mapti.end();

	MSGOUT(en_Msg_Debug, "begin end");
	for ( ; ibegin != iend; ibegin++) {
		event_del(&ibegin->second->tev);
		MSGOUT(en_Msg_Debug, "del id:%u", ibegin->second->uid);
		free(ibegin->second);
		ibegin->second = NULL;
	}
	m_mapti.clear();

	MSGOUT(en_Msg_Debug, "stop");

	event_base_loopbreak(m_ptibase);
//	event_base_loopexit(m_ptibase, NULL);
}

void* TimerModule::assistfun(void* pdata) {

	TimerModule *pthis = (TimerModule*)pdata;

	MSGOUT(en_Msg_Normal, "start timer service");

	event_base_dispatch(pthis->m_ptibase);

	event_base_free(pthis->m_ptibase);
	pthis->m_ptibase = NULL;

	libevent_global_shutdown(); 

	MSGOUT(en_Msg_Normal, "stop timer service");
	if(pthis->m_pticb != NULL) {
		pthis->m_pticb->_end_callback("TimerModule", pthis, 0);
	}
	return NULL;
}
