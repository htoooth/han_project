/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-12-26 15:17:18
# LastModified : 2014-12-26 16:59:10
# FileName     : database.h
# Description  : 
 ******************************************************************************/
#ifndef _DATABASE_H
#define _DATABASE_H

#include "baseserver.h"

struct _mysql_param {
	char	dbname[40];
	char	username[40];
	char	passwd[20];
	char	addr[16];
	char	charset[10];
	short	port;
};

class DataBaseClass : public IServer {
public:
	virtual void* GetIdleDB() = 0;
	virtual bool SaveIdleDB(void* psql) = 0;
	virtual void FreeConnect(void* psql) = 0;
	virtual void* NewIdleDB() = 0;
};

#endif // _DATABASE_H
