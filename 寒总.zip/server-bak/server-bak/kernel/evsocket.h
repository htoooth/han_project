/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-12 19:17:16
# LastModified : 2014-11-10 18:10:38
# FileName     : evsocket.h
# Description  : 
 ******************************************************************************/
#ifndef _EVSOCKET_H
#define _EVSOCKET_H

#include <map>
#include <event.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#include "baseserver.h"
#include "dealnetdata.h"
#include "showmsg.h"
#include "evcenter.h"

#define __CA_FILE "cacert.pem"
#define __KEY_FILE "privkey.pem"

struct _buf_node;

struct _buf_node {
	char*			buf;
	unsigned int	len;
	unsigned int	offset;
	TAILQ_ENTRY(_buf_node) enter;
};

struct _socket_param {
	event*			pevread;
	event*			pevwrite;
	IDealNetData*	pdeal;
	SSL*			ssl;
	_net_data_		tmpdata;
	bool			bclosed;
	TAILQ_HEAD(, _buf_node) qsend;
};

struct _bindparam {
	int	port;
	int	type;
};

class SocketModule : public IServer {
public:
	// return false will close connect
	virtual bool onread(int fd, void *pdata, unsigned int ulen) = 0;

	// return false will close connect
	virtual bool onconnect(int fd, struct sockaddr_in* paddr) = 0;

	virtual void onclose(int fd) = 0;

	unsigned int senddata(int fd, void *pdata, unsigned int ulen);

	void closeconnect(int fd);
	
	static void* assistfun(void* pdata);

	SocketModule();

	virtual ~SocketModule();

	void _on_close(int fd);

public:
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual bool _is_end();
	static void _on_read(int fd, short ev, void* arg);
	static void _on_accept(int fd, short ev, void* arg);
	static void _on_write(int fd, short ev, void* arg);
	void setdealdataptr(int fd, IDealNetData* pdeal);
	SSL_CTX* createctx(int type);
    pthread_t getsockthreadid();
public:
	std::map<int, void*>	m_mapevent;
	ISvrCallback*			m_psocb;
	int						m_type;
protected:
	int				m_svrsock;
	IDealNetData*	m_pdealdata;
	int				m_port;
	event_base*		m_psobase;
	event*			m_plisev;
	bool			m_issoend;
	SSL_CTX*		m_ctx;
	SSL*			m_ssl;
    pthread_t       m_thid;
};

#endif // _EVSOCKET_H
