/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2013-12-18 19:43:55
# LastModified : 2014-11-18 17:21:52
# FileName     : showmsg.cpp
# Description  : 
 ******************************************************************************/
#include <time.h>
#include <stdarg.h>
#include <pthread.h>

#include "showmsg.h"

static unsigned int msgmask = 0xFFFFFFFF;		// control
static FILE *pfile = stderr;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void setMsgMask(unsigned int maskKey)
{
	msgmask = maskKey;
}

void setWriteFile(FILE *file)
{
	if (file != NULL) {
		pfile = file;
	}
}

void msgOut(_en_Msg_Level enLev, const char *format, ...)
{
	if((msgmask & enLev) == 0)
		return;
	pthread_mutex_lock(&lock);
	time_t temp = time(NULL);
	struct tm *ptm = localtime(&temp);
	fprintf(pfile, "@@ %02d-%02d %02d:%02d:%02d %c "
			,ptm->tm_mon+1, ptm->tm_mday,
			ptm->tm_hour, ptm->tm_min, ptm->tm_sec, getMaskChar(enLev));	

	va_list arg_ptr;
	va_start(arg_ptr, format);
	vfprintf(pfile, format, arg_ptr);
	va_end(arg_ptr);

	fprintf(pfile, "\n");
	fflush(pfile);

	pthread_mutex_unlock(&lock);
}

char getMaskChar(_en_Msg_Level enLev)
{
	switch(enLev)
	{
	case en_Msg_Debug:
		return '$';
	case en_Msg_Warning:
		return '*';
	case en_Msg_Error:
		return '#';
	case en_Msg_Normal:
		return '^';
	default:
		return '.';
	}
}
