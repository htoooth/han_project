/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2015-01-05 15:12:17
# LastModified : 2015-03-04 13:13:53
# FileName     : cenmain.c
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "evcenter.h"

int idx = 0;
class MyCentSock : public CenterSocket {
public:
	virtual bool OnRecvData(char* pdata, unsigned int len) {
		MSGOUT(en_Msg_Debug, "idx: %d, recv data : %s : len : %d", idx++, pdata, len);
		return true;
	}
	virtual void OnClose() {
		MSGOUT(en_Msg_Debug, "socket close!!!!!");
	}
};

int main(int argc, char *argv[]) {
	
	MyCentSock sock;
	sock._start_server(NULL, NULL);
//	sock.connectsocket("192.168.1.122", 9876, en_Server_Connect);
	sock.connectsocket("192.168.1.122", 9876, en_TLSv1_Connect);
	sleep(1);
	while(1) {
		char buf[] = "qwertyuiopasdfgjhjklzxcvbnm";
//		for(int i = 0; i < 10; i++) {
	//		sock.senddata(buf, sizeof(buf));
		//	if(-1 == sock.senddata(buf, sizeof(buf))) {
		//		break;
		//	}
//		}
	//	sock.closesocket();
//		MSGOUT(en_Msg_Debug, "cccccccccccccccccccccccccccccccccccccccccccccccccccccc");
		break;
	}
	sleep(10);
	MSGOUT(en_Msg_Debug, "stop server!!!!");
	sock._stop_server();
	sleep(3);
	return 0;
}
