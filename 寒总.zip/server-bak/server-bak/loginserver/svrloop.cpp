/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-27 14:36:25
# LastModified : 2014-11-12 15:27:57
# FileName     : svrloop.cpp
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>

#include "svrloop.h"
#include "scprotocol.h"
#include "ssprotocol.h"
#include "scstructdef.h"
#include "dbdefine.h"

bool ServerMain::OnSocketRead(int fd, void* pdata, unsigned int ulen) {

	if(pdata == NULL || ulen < sizeof(NetSocketHead)) 
		return false;

	NetSocketHead* p = (NetSocketHead*)pdata;

    if (p->uMainCmd == SYSTEM_PROTOCOL_TYPE) {
        switch (p->uSubCmd) {
        case SP_LOGINMAIN_VERIFY_KEYWORD:
            {
                return verifyserverkeyword(fd, (char*)pdata+HEAD_SIZE, ulen-HEAD_SIZE);
            }
            break;
        case SP_LOGINSVR_SET_DEALDATAPTR: 
            {
                setdealdataptr(fd, NULL);
                //MSGOUT(en_Msg_Debug, "ready verify fd:%d, ip:%s, port:%d", fd, pinfo->ip, pinfo->port);
                return true;
            }
            break;
        default:
            return false;
        }
    }

	switch(p->uMainCmd) {
		case LOGINSVR_CLIENT_TYPE:
			return DealClientData(fd, p->uHelpCmd, pdata, ulen);
		case MAINSVR_LOGINSVR_TYPE:
			return DealMainSvrData(fd, pdata, ulen);
	}

	return false;
}

bool ServerMain::OnSocketConnect(int fd, struct sockaddr_in* paddr) {

	_StConnectInfo* p = (_StConnectInfo*)malloc(sizeof(_StConnectInfo));
	memset(p, 0, sizeof(_StConnectInfo));

	p->fd = fd;
	strcpy(p->ip, inet_ntoa(paddr->sin_addr));
	p->port = ntohs(paddr->sin_port);

	m_mapfd[fd] = p;

	MSGOUT(en_Msg_Normal, "connect fd:%d, ip:%s, port:%d", fd, p->ip, p->port);

	return true;
}

void ServerMain::OnSocketClose(int fd) {

	void* p = m_mapfd[fd];
	if(p != NULL) {
		free(p);
		p = NULL;
	    m_mapfd.erase(fd);
	}

	if (m_mainsvr.find(fd) != m_mainsvr.end()) {
		p = m_mainsvr[fd];
		if (p != NULL) {
			free(p);
			p = NULL;
		}
		m_mainsvr.erase(fd);
		MSGOUT(en_Msg_Normal, "erase mainserver fd:%d", fd);
	}

	MSGOUT(en_Msg_Normal, "close fd:%d", fd);
}

void ServerMain::OnEventTimer(unsigned int uid) {

}

void ServerMain::SettleDBResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	switch(maincmd) {
		case DB_VERIFY_USERPWD: 
			{
				dbuserloginret(maincmd, assistcmd, (int*)pdata, ulen, pclient);
			}
			break;
		case DB_GET_GROUPINFO:
			{
				dbgroupinforet(maincmd, assistcmd, (StCompanyInfo*)pdata, ulen, pclient);
			}
			break;
		default:
			return ;
	}
}

bool ServerMain::verifyuserpwd(int fd, int wndid, StLoginInfo* pdata, unsigned int len) {
	if(len != sizeof(StLoginInfo) || pdata == NULL) {
		return false;
	}
	PostDBRequest(DB_VERIFY_USERPWD, wndid, pdata, len, (void*)(long)fd);
	return true;
}

bool ServerMain::_start() {

	return true;
}

void ServerMain::_stop() {

	std::map<int, void*>::iterator it = m_mapfd.begin();
	for(; it != m_mapfd.end(); it++) {
		void* p = it->second;
		free(p);
	}
	m_mapfd.clear();

	it = m_mainsvr.begin();
	for(; it != m_mainsvr.end(); it++) {
		void* p = it->second;
		free(p);
	}
	m_mainsvr.clear();
}

bool ServerMain::DealClientData(int fd, int wndid, void* pdata, unsigned int ulen) {

	NetSocketHead* p = (NetSocketHead*)pdata;

    std::map<int, void*>::iterator it = m_mapfd.find(fd);
    if(it == m_mapfd.end() || it->second == NULL) {
        return false;
    }

	_StConnectInfo* pinfo = (_StConnectInfo*)it->second;

	if (p->uSubCmd != LC_VERIFY_USER_PASSWD) {
		if (pinfo->contype != CON_TYPE_CLIENT_COM)
			return false;
	}

	switch (p->uSubCmd) {
		case LC_VERIFY_USER_PASSWD:
			{
				return verifyuserpwd(fd, wndid, (StLoginInfo*)(p+1), ulen-HEAD_SIZE);
			}
		case LC_GET_GROUPINFO:
			{
				return getusercompanyinfo(fd, wndid, (int*)(p+1), ulen-HEAD_SIZE);
			}
		default:
			MSGOUT(en_Msg_Warning, "unknow cmd, maincmd:%d subcmd:%d", p->uMainCmd, p->uSubCmd);
			return false;
	}
	return false;
}

bool ServerMain::DealMainSvrData(int fd, void* pdata, unsigned int ulen) {

    NetSocketHead* p = (NetSocketHead*)pdata;

    std::map<int, void*>::iterator it = m_mapfd.find(fd);
    if(it == m_mapfd.end() || it->second == NULL) {
        return false;
    }

	_StConnectInfo* pinfo = (_StConnectInfo*)it->second;

	MSGOUT(en_Msg_Debug, "main server data fd:%d, main:%d, sub:%d, ulen:%d", fd, p->uMainCmd, p->uSubCmd, ulen);

	if (pinfo->contype != CON_TYPE_MAINSVR_LOGINSVR)
		return false;
	switch(p->uSubCmd) {
		case ML_UPDATA_SVRUSER:
			{
				return dealupdatauser(fd, (char*)(p+1), ulen-HEAD_SIZE);
			}
			break;
		case ML_MAINSVR_INFO:
			{
				return dealrecvsvrinfo(fd, (char*)(p+1), ulen-HEAD_SIZE);			
			}	
			break;
		default:
			MSGOUT(en_Msg_Warning, "unknow cmd, maincmd:%d subcmd:%d", p->uMainCmd, p->uSubCmd);
			return false;
	}
	return false;
}

bool ServerMain::verifyserverkeyword(int fd, char *pdata, unsigned int len) {
	bool bright = false;
	if ((len == strlen(__key_mainsvr_loginsvr__)+1) && (strcmp(pdata, __key_mainsvr_loginsvr__) == 0))
		bright = true;

	_StConnectInfo* pinfo = (_StConnectInfo*)m_mapfd[fd];
	if (bright && pinfo != NULL) {
		pinfo->contype = CON_TYPE_MAINSVR_LOGINSVR;
		char buf[MAX_BUFFSIZE] = {0};
		NetSocketHead* phead = (NetSocketHead*)buf;
		phead->uMainCmd = SYSTEM_PROTOCOL_TYPE;
		phead->uSubCmd = SP_LOGINMAIN_VERIFY_KEYWORD;
		phead->uHelpCmd = VERIFY_ERROR_NULL;
		phead->uLen = HEAD_SIZE;
		senddata(fd, buf, phead->uLen);

		_StMainSvrInfo* pmaininfo = (_StMainSvrInfo*)malloc(sizeof(_StMainSvrInfo));
		memset(pmaininfo, 0, sizeof(_StMainSvrInfo));
		m_mainsvr[fd] = pmaininfo;

		MSGOUT(en_Msg_Normal, "ok fd:%d, ip:%s, port:%d", fd, pinfo->ip, pinfo->port);
		return true;
	}
	MSGOUT(en_Msg_Error, "failed fd:%d, ip:%s, port:%d", fd, pinfo->ip, pinfo->port);
	return false;
}

bool ServerMain::dealrecvsvrinfo(int fd, char *pdata, unsigned int len) {
	if (pdata == NULL || len != sizeof(StNetAddrInfo) || m_mainsvr[fd] == NULL)
		return false;

	_StMainSvrInfo* pinfo = (_StMainSvrInfo*)m_mainsvr[fd];

	memcpy(&pinfo->addr, pdata, len);

	MSGOUT(en_Msg_Normal, "recv info id:%d, ip:%s, port:%d", pinfo->addr.id, pinfo->addr.ip, pinfo->addr.port);
	return true;
}

bool ServerMain::dealupdatauser(int fd, char *pdata, unsigned int len) {

	if (pdata == NULL || len != sizeof(_StMainSvrUpUser))
		return false;

	_StMainSvrUpUser* puser = (_StMainSvrUpUser*)pdata;

	_StMainSvrInfo* pinfo = (_StMainSvrInfo*)m_mainsvr[fd];
	if (pinfo == NULL)
		return false;

	pinfo->usercount = puser->usercount;

	MSGOUT(en_Msg_Normal, "id:%d, count:%d", pinfo->addr.id, pinfo->usercount);

	return true;
}

void ServerMain::dbuserloginret(int maincmd, int assistcmd, int* pres, unsigned int ulen, void* pclient) {
	
	if (pres == NULL || ulen != 8 || pclient == NULL) {
		MSGOUT(en_Msg_Error, "error");
		return ;
	}
	int fd = (int)(long)pclient;

	char buf[MAX_BUFFSIZE] = {0};
	NetSocketHead* phead = (NetSocketHead*)buf;

	phead->uMainCmd = LOGINSVR_CLIENT_TYPE;
	phead->uSubCmd = LC_VERIFY_USER_PASSWD;
	phead->uHelpCmd = assistcmd;

	MSGOUT(en_Msg_Debug, "id: %d", pres[1]);

	phead->uLen = HEAD_SIZE + sizeof(int);
	unsigned int len = phead->uLen;
	memcpy(phead+1, pres, sizeof(int));


	if (pres[0] != VERIFY_ERROR_NULL) {
		senddata(fd, buf, len);
		closeconnect(fd);
	}
	else {
        std::map<int, void*>::iterator it = m_mapfd.find(fd);
        if (it == m_mapfd.end() || it->second == NULL) {
            MSGOUT(en_Msg_Debug, "error connect, fd: %d", fd); 
            return;
        }
        _StConnectInfo* pinfo = (_StConnectInfo*)it->second;
		senddata(fd, buf, len);
		pinfo->contype = CON_TYPE_CLIENT_COM;
		pinfo->id = pres[1];
		PostDBRequest(DB_GET_GROUPINFO, assistcmd, pres+1, sizeof(int), (void*)(long)fd);
	}
	MSGOUT(en_Msg_Debug, "send!!!!");
}

StNetAddrInfo* ServerMain::getmainserveraddr() {
	if (m_mainsvr.empty()) {
		MSGOUT(en_Msg_Debug, "no mainserver!!!");
		return NULL;
	}
	
	std::map<int, void*>::iterator it = m_mainsvr.begin();
	int nmax = 0x7FFFFFFF;
	StNetAddrInfo* paddr = NULL;
	for (; it != m_mainsvr.end(); it++) {
		_StMainSvrInfo* pinfo = (_StMainSvrInfo*)it->second;
		if (pinfo == NULL)
			continue;
		if (nmax > pinfo->usercount) {
			nmax = pinfo->usercount;
			paddr = &pinfo->addr;
		}
	}
	return paddr;
}

bool ServerMain::sendmainsvraddr(int fd, int wndid) {
	
	StNetAddrInfo* paddr = getmainserveraddr();
	if (paddr != NULL) {
		char buf[MAX_BUFFSIZE] = {0};
		NetSocketHead* phead = (NetSocketHead*)buf;
		phead->uMainCmd = LOGINSVR_CLIENT_TYPE;
		phead->uSubCmd = LC_MAINSVR_ADDR;
		phead->uHelpCmd = wndid;
		phead->uLen = HEAD_SIZE + sizeof(StNetAddrInfo);

		memcpy(phead+1, paddr, sizeof(StNetAddrInfo));

		MSGOUT(en_Msg_Debug, "send svraddr fd:%d, id:%d, ip:%s, port:%d", fd, paddr->id, paddr->ip, paddr->port);

		senddata(fd, buf, phead->uLen);

		return true;
	}
	else {
		MSGOUT(en_Msg_Error, "no main serve connect");
	}
	return false;
}

bool ServerMain::getusercompanyinfo(int fd, int wndid, int* pidx, unsigned int len) {
	if (pidx == NULL || len != sizeof(int)) {
		return false;
	}
	PostDBRequest(DB_GET_GROUPINFO, wndid, pidx, len, (void*)(long)fd);
	return true;
}

void ServerMain::dbgroupinforet(int maincmd, int assistcmd, StCompanyInfo* pinfo, unsigned int ulen, void* pclient) {
	int fd = (int)(long)pclient;
	if (pinfo == NULL || ulen != sizeof(StCompanyInfo) || pclient == NULL) {
		MSGOUT(en_Msg_Debug, "pinfo:%p, ulen:%d, pclient:%p", pinfo, ulen, pclient);
		MSGOUT(en_Msg_Error, "error");
		if (fd > 0) {
			closeconnect(fd);
		}
		return ;
	}

    std::map<int, void*>::iterator it = m_mapfd.find(fd);
	if (it == m_mapfd.end() || it->second == NULL) {
		MSGOUT(en_Msg_Normal, "send but close!!!");
		return ;
	}

	char buf[MAX_BUFFSIZE] = {0};
	NetSocketHead* phead = (NetSocketHead*)buf;
	phead->uMainCmd = LOGINSVR_CLIENT_TYPE;
	phead->uSubCmd = LC_GET_GROUPINFO;
	phead->uHelpCmd = assistcmd;
	phead->uLen = HEAD_SIZE + sizeof(StCompanyInfo);
	
	memcpy(phead+1, pinfo, sizeof(StCompanyInfo));

	MSGOUT(en_Msg_Debug, "userinfo id:%d, name:%s, unitid:%d, unitname:%s, companyid:%d, companyname:%s", 
			pinfo->idx, pinfo->nickname, pinfo->unitid, pinfo->unitname, pinfo->companyid, pinfo->companyname);

	senddata(fd, buf, phead->uLen);
	sendmainsvraddr(fd, assistcmd);
//	closeconnect(p->fd);
}
