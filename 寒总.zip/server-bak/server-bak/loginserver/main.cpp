/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-26 17:53:54
# LastModified : 2014-07-07 15:32:13
# FileName     : main.cpp
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

#include "showmsg.h"
#include "readconf.h"
#include "svrloop.h"
#include "dbevent.h"

int main(int argc, char *argv[]) {

	ReadConf cf;
	cf.readfile("server.conf");

	char buf[40] = {0};
	cf.getvalue("bindport", buf, sizeof(buf));
	short port = atoi(buf);
	if(port <= 0) {
		MSGOUT(en_Msg_Error, "main readconf bind port error!!!");
		return 1;
	}

	memset(buf, 0, sizeof(buf));
	cf.getvalue("dbthread", buf, sizeof(buf));
	unsigned int n = atoi(buf);
	if(n <=0 )
		n = 2;

	memset(buf, 0, sizeof(buf));
	cf.getvalue("logfile", buf, sizeof(buf));

	FILE* pf = NULL;
	if(strcmp(buf, "stderr") != 0) {
		pf = fopen(buf, "ab");
		if(pf != NULL)
			setWriteFile(pf);
	}

	MSGOUT(en_Msg_Normal, "<-----------------start----------------->");

	ServerMain svr;
	MysqlHandle sql;
	svr.StartServer(&sql, port, en_Server_Connect, n);

	if(pf != NULL)
		fclose(pf);

	MSGOUT(en_Msg_Normal, "<------------------end------------------>");
	
	return 0;
}
