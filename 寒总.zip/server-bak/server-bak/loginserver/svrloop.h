/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-26 18:11:23
# LastModified : 2014-07-01 13:57:32
# FileName     : svrloop.h
# Description  : 
 ******************************************************************************/
#ifndef _SVRLOOP_H
#define _SVRLOOP_H

#include "serverset.h"
#include "ssstructdef.h"
#include "scstructdef.h"

class ServerMain : public ServerSet {
public:
	virtual bool OnSocketRead(int fd, void* pdata, unsigned int ulen);
	virtual bool OnSocketConnect(int fd, struct sockaddr_in* paddr);
	virtual void OnSocketClose(int fd);
	virtual void OnEventTimer(unsigned int uid);
	virtual void SettleDBResult(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
	virtual void _stop();
	virtual bool _start();
protected:
	std::map<int, void*>		m_mapfd;
	std::map<int, void*>		m_mainsvr;
public:
	bool DealClientData(int fd, int wndid, void* pdata, unsigned int ulen);
	bool DealMainSvrData(int fd, void* pdata, unsigned int ulen);
protected:
	bool verifyuserpwd(int fd, int wndid, StLoginInfo* pdata, unsigned int len);
	bool getusercompanyinfo(int fd, int wndid, int* idx, unsigned int len);
protected:
	bool verifyserverkeyword(int fd, char *pdata, unsigned int len);
	bool dealrecvsvrinfo(int fd, char *pdata, unsigned int len);
	bool dealupdatauser(int fd, char *pdata, unsigned int len);
protected:
	void dbuserloginret(int maincmd, int assistcmd, int* pres, unsigned int ulen, void* pclient);
	void dbgroupinforet(int maincmd, int assistcmd, StCompanyInfo* pinfo, unsigned int ulen, void* pclient);
protected:
	StNetAddrInfo* getmainserveraddr();
	bool sendmainsvraddr(int fd, int wndid);
};

#endif // _SVRLOOP_H
