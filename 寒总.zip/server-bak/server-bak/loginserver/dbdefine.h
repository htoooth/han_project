/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-04-01 18:13:23
# LastModified : 2014-08-08 17:48:44
# FileName     : dbdefine.h
# Description  : 
 ******************************************************************************/
#ifndef _DBDEFINE_H
#define _DBDEFINE_H

enum {
	DB_VERIFY_USERPWD = 1,
	DB_GET_GROUPINFO,
	DB_INSERT_SESSION
};

#endif // _DBDEFINE_H
