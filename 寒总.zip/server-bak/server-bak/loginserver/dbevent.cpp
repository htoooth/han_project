/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-25 15:38:07
# LastModified : 2014-12-26 18:18:03
# FileName     : dbevent.cpp
# Description  : 
 ******************************************************************************/
#include <stdlib.h>
#include <string.h>

#include "dbevent.h"
#include "dbdefine.h"
#include "showmsg.h"
#include "scstructdef.h"
#include "ssstructdef.h"
#include "scprotocol.h"
#include "ssprotocol.h"

bool MysqlHandle::_start_server(void* pdata, ISvrCallback* pcb) {
	ReadConf cf;
	if (-1 == cf.readfile("server.conf")) {
		MSGOUT(en_Msg_Error, "server.conf error!!!");
	}
	_mysql_param param = {{0}};
	do {
		if(!cf.getvalue("mysql_dbname", param.dbname, sizeof(param.dbname)))
			break;
		if(!cf.getvalue("mysql_username", param.username, sizeof(param.username)))
			break;
		if(!cf.getvalue("mysql_passwd", param.passwd, sizeof(param.passwd)))
			break;
		if(!cf.getvalue("mysql_addr", param.addr, sizeof(param.addr)))
			break;
		if(!cf.getvalue("mysql_charset", param.charset, sizeof(param.charset)))
			break;

		char buf[10] = {0};
		if(!cf.getvalue("mysql_port", buf, sizeof(buf)))
			break;
		param.port = atoi(buf);
		if (param.port <= 0)
			break;
		m_psqlmgr = new MySqlMgr();
		if(!m_psqlmgr->_start_server(&param, NULL)) {
			MSGOUT(en_Msg_Error, "mysql _start_server error!!!");
			break;
		}

		return QueueEventModule::_start_server(pdata, pcb);
	}while(false);
	
	MSGOUT(en_Msg_Error, "mysql conf error!!!");
	return false;	
}

void MysqlHandle::_stop_server() {
	QueueEventModule::_stop_server();
	m_psqlmgr->_stop_server();
	delete (MySqlMgr*)m_psqlmgr;
	m_psqlmgr = NULL;
}

void MysqlHandle::SettleQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient) {
	MYSQL* psql = (MYSQL*)m_psqlmgr->GetIdleDB();
	if (psql == NULL)
	{    
		psql = (MYSQL*)m_psqlmgr->NewIdleDB();
		if (psql == NULL) {
			MSGOUT(en_Msg_Error,
				"MysqlHandle::SettleQueueEvent (2) connect mysql failed!!!");
			return ;
		}    
	}    
	try {
		switch(maincmd) {
			case DB_VERIFY_USERPWD:
			{
				verifyuserpwd(psql, assistcmd, (StLoginInfo*)pdata, ulen, pclient);
			}
			break;
			case DB_GET_GROUPINFO:
			{
				getusergroupinfo(psql, assistcmd, (int*)pdata, ulen, pclient);
			}
			break;
			case DB_INSERT_SESSION:
			{
				MSGOUT(en_Msg_Debug, "iiiiiiiiiiiiiiiiiiiii");
				StCompanyInfo *pinfo =(StCompanyInfo *)pdata;
				char tmp[32];
				sprintf(tmp,"%d",pinfo->unitid);
				int iret = insertSessionId(psql,pinfo->sessionid,tmp);
				MSGOUT(en_Msg_Debug,"insert session id count:%d",iret);
			}
			break;
		default:
			MSGOUT(en_Msg_Normal, "unknow cmd maincmd:%d, assistcmd:%d, pdata:%p, len:%u", maincmd, assistcmd, pdata, ulen);
			break;
		}
		m_psqlmgr->SaveIdleDB(psql);
	}
	catch(...) {
		if (m_psqlmgr != NULL && psql != NULL) {
			 MSGOUT(en_Msg_Error,
				"MysqlHandle::SettleQueueEvent maincmd:%d, assistcmd:%d, pdata:%p, len:%u, errstr:%s",
				maincmd, assistcmd, pdata, ulen, mysql_error(psql));
			 m_psqlmgr->FreeConnect(psql);
		}
	}
}

void MysqlHandle::verifyuserpwd(MYSQL* psql, int wndid, StLoginInfo* pdata, unsigned int len, void* pclient) {

	const char *proc = "proc_checkuserpwdbyname";
	StLoginInfo* p = (StLoginInfo*)pdata;
	char buf[4096] = {0};
	sprintf(buf, "call %s ('%s');", proc, p->name);
	MSGOUT(en_Msg_Debug, "%s", buf);
	int ret = mysql_query(psql, buf);
	if (ret != 0) {
		throw ret;
	}
	int arr[2] = {0};
	arr[0] = VERIFY_ERROR_UNKNOW;

	do {
		MYSQL_RES *res = mysql_store_result(psql);
		if (res == NULL) {
			break;
		}
		else {
			if(res->row_count == 1) {
				MYSQL_ROW row = mysql_fetch_row(res);
				if(row == NULL) {
					mysql_free_result(res);
					break;
				}
				arr[1] = atoi(row[0]);
				if (strcmp(row[1], pdata->passwd) == 0) {
					arr[0] = VERIFY_ERROR_NULL;
				}
				else {
					arr[0] = VERIFY_ERROR_PWD;
				}
				MSGOUT(en_Msg_Debug, "user id: %d", arr[0]);
			}
			else {
				arr[0] = VERIFY_ERROR_NAME;
			}
			mysql_free_result(res);
		}
	}
	while(!mysql_next_result(psql));
	PostQueueResult(DB_VERIFY_USERPWD, wndid, arr, sizeof(arr), pclient);
}

void MysqlHandle::getusergroupinfo(MYSQL* psql, int wndid, int* pid, unsigned int len, void* pclient) {
	
	const char* proc = "proc_getuseruintinfo";
	int id = *pid;
	char buf[4096] = {0};
	sprintf(buf, "call %s (%d);", proc, id);
	int ret = mysql_query(psql, buf);
	StCompanyInfo info = {0};
	if (ret != 0) {
		throw ret;
	}
	do {
		MYSQL_RES* res = mysql_store_result(psql);
		if (res == NULL) {
			break;
		}
		else {
			if(res->row_count == 1) {
				MYSQL_ROW row = mysql_fetch_row(res);
				if (row == NULL) {
					mysql_free_result(res);
					break;
				}
				info.idx = id;
				if (row[0] != NULL)
					strcpy(info.nickname, row[0]);
				if (row[1] != NULL)
					info.unitid = atoi(row[1]);
				if (row[2] != NULL)
					strcpy(info.unitname, row[2]);
				if (row[3] != NULL)
					info.companyid = atoi(row[3]);
				if (row[4] != NULL)
					strcpy(info.companyname, row[4]);
				if (row[5] != NULL)
				{
					strcpy(info.account, row[5]);
					char * sessionId = getSessionId(info.unitid,32);
					strcpy(info.sessionid, sessionId);
					free(sessionId);
				}
			}
			mysql_free_result(res);
		}
	}
	while(!mysql_next_result(psql));
	PostQueueResult(DB_GET_GROUPINFO, wndid, &info, sizeof(info), pclient);
	PostQueueEvent(DB_INSERT_SESSION, wndid, &info, sizeof(info), pclient);
}

char * MysqlHandle::getSessionId(int id,int idLength)
{
    char *sessionId = (char *)malloc(sizeof(char)*(idLength+1));
    int sec = 0;
    /*int count = strlen(userName);
    int userNameAscii = 0;*/
    int i = 0;
    const char *charWarehouse = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    int warehouseCount = strlen(charWarehouse);
    int randNum = 0;
    memset(sessionId,0,sizeof(char)*(idLength+1));
    if(sessionId == NULL)
    {
        printf("malloc memery error.\n");
        return sessionId;
    }
    /*//计算用户名的ascii码和
    for(i ; i < count; ++ i)
    {
        userNameAscii +=(int)userName[i];
        if (i%2)
        {
            userNameAscii +=(int)userName[i];
        }
    }*/
    sec= (int)time(NULL);
    sec += id;
    for(i = 0 ; i < idLength ; ++ i)
    {
        srand(sec+i);
        randNum = rand()%(warehouseCount-1);
        sessionId[i] = charWarehouse[randNum];
    }
    return sessionId;
}

int MysqlHandle::insertSessionId(MYSQL* psql,char *sessionId,char *userId)
{
	const char* proc = "proc_creatsession"; 
	int id = atoi(userId);
	char buf[4096] = {0};
	sprintf(buf, "call %s ('%s',%d);", proc, sessionId, id);
	int ret = mysql_query(psql, buf);
	if (ret != 0) {
		MSGOUT(en_Msg_Error, "%s", buf);
		throw ret;
	}
	do {
		MYSQL_RES* res = mysql_store_result(psql);
		if (res == NULL) {
			break;
		}
		else {
			if(res->row_count == 1) {
				MYSQL_ROW row = mysql_fetch_row(res);
				if (row == NULL) {
					mysql_free_result(res);
					break;
				}
				if (row[0] != NULL)
					ret = atoi(row[0]);
				else {
					ret = -1;
				}
			}
			mysql_free_result(res);
		}
	}while(!mysql_next_result(psql));
	return ret;
}
