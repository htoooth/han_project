/*******************************************************************************
# Author       : zenghao
# Email        : zenghao.1989@163.com
# CreateTime   : 2014-03-25 15:31:43
# LastModified : 2014-12-26 18:17:07
# FileName     : dbevent.h
# Description  : 
 ******************************************************************************/
#ifndef _DBEVENT_H
#define _DBEVENT_H

#include "baseserver.h"
#include "queuebase.h"
#include "mysqlmgr.h"
#include "readconf.h"
#include "scstructdef.h"

class MysqlHandle : public QueueEventModule {
public:
	virtual bool _start_server(void* pdata, ISvrCallback* pcb);
	virtual void _stop_server();
	virtual void SettleQueueEvent(int maincmd, int assistcmd, void* pdata, unsigned int ulen, void* pclient);
protected:
	DataBaseClass*	m_psqlmgr;
protected:
	void verifyuserpwd(MYSQL* psql, int wndid, StLoginInfo* pdata, unsigned int len, void* pclient);
	void getusergroupinfo(MYSQL* psql, int wndid, int* pid, unsigned int len, void* pclient);
	int insertSessionId(MYSQL* psql,char *sessionId,char *userId);
	char * getSessionId(int id,int idLength);
};

#endif // _DBEVENT_H
